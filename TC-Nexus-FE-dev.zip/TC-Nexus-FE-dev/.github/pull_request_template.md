## Checklist

- [ ] Code duplication check
      (https://en.wikipedia.org/wiki/Don%27t_repeat_yourself)
- [ ] Positive scenario check - dev must check that code is working before
      creating a PR
- [ ] Error/loading/empty state handling - if you have backend request, usually
      we need implement error and loading states of it. Also usually we need
      something to show if we received empty response, as showing empty space to
      a user is not good
- [ ] Unused code cleanup
      (https://en.wikipedia.org/wiki/You_aren%27t_gonna_need_it)
- [ ] Clean console - be sure that there are no React.js (or any other lib)
      warnings or errors in dev console caused by your code
- [ ] propTypes declaration

## Description

The purpose of this PR is ...

## How To Test
