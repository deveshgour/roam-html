import { dirname } from 'path';
import { fileURLToPath } from 'url';
import { FlatCompat } from '@eslint/eslintrc';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const compat = new FlatCompat({
  baseDirectory: __dirname,
});

const eslintConfig = [
  ...compat.extends('next/core-web-vitals'),
  {
    files: ['**/*.{js,jsx,ts,tsx}'],
    plugins: {
      '@typescript-eslint': (await import('@typescript-eslint/eslint-plugin'))
        .default,
      prettier: (await import('eslint-plugin-prettier')).default,
    },
    languageOptions: {
      parser: (await import('@typescript-eslint/parser')).default,
      parserOptions: {
        ecmaVersion: 'latest',
        sourceType: 'module',
      },
    },
    rules: {
      'import/prefer-default-export': 'off',
      'consistent-return': 'warn',
      'prefer-promise-reject-errors': 'off',
      'prefer-destructuring': [
        'error',
        {
          object: true,
          array: false,
        },
      ],
      'no-underscore-dangle': 'off',
      'no-nested-ternary': 'warn',
      'class-methods-use-this': [
        'error',
        {
          exceptMethods: [
            'componentDidMount',
            'componentDidUpdate',
            'componentWillUnmount',
            'render',
          ],
        },
      ],
      'react/no-unused-prop-types': 'error',
      'react/prop-types': [
        'error',
        {
          ignore: ['match', 'history', 'location'],
        },
      ],
      'react/sort-prop-types': 'error',
      eqeqeq: 'off',
      'no-useless-concat': 'off',
      'import/no-extraneous-dependencies': 'error',
      'import/no-nodejs-modules': 'off',
      'react/forbid-prop-types': ['warn'],
      'no-unused-vars': 'error',
      '@next/next/no-img-element': 'off',
      '@typescript-eslint/no-unused-vars': [
        'error',
        {
          varsIgnorePattern: '^_',
          argsIgnorePattern: '^_',
        },
      ],
      'no-console': [
        'error',
        {
          allow: ['warn', 'error'],
        },
      ],
    },
  },
];

export default eslintConfig;
