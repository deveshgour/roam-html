import Icon from '@components/coreUI/icon';

type LoaderSize = 'sm' | 'md' | 'lg';

interface LoaderProps {
  size?: LoaderSize;
}

const Loader = ({ size = 'md' }: LoaderProps) => {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-8 h-8',
    lg: 'w-12 h-12',
  };

  return (
    <Icon
      iconName="loader"
      iconProps={{
        className: `${sizeClasses[size]} animate-spin text-primary`,
      }}
    />
  );
};

export default Loader;
