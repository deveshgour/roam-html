export const STATUS = {
  ACTIVE: 'active',
  INACTIVE: 'inactive',
};

export const USER_ROLES = {
  ADMIN: 'Admin',
  USER: 'User',
};
