/**
 * UserProfileInfo
 *
 * A panel that displays user profile information, such as name, email, phone number, location, and access levels.
 *
 * @param {UserProfileInfoProps} props
 * @returns {JSX.Element}
 */
import { Avatar, AvatarFallback, AvatarImage } from '@components/coreUI/avatar';
import SidePanel from '@components/coreUI/drawer';
import Icon from '@components/coreUI/icon';
import { Switch } from '@components/coreUI/switch';
import {
  ProfileData,
  UserProfileInfoProps,
} from '@/components/userProfileInfo/types';
import { STATUS, USER_ROLES } from '@components/userProfileInfo/constants';
import ResetPasswordModal from '../resetPassword';
import { Button } from '../coreUI/button';
import { useState } from 'react';
import { showErrorMsg, showSuccessMsg } from '@/utils/notifications';
import { TOAST_MESSAGES } from '@/constants/messages';
import { resetPassword } from '@/services/user';
const UserProfileInfo = ({
  isOpen = false,
  onClose = () => {},
  userProfile = {},
  loading = false,
}: UserProfileInfoProps) => {
  const user = userProfile as ProfileData;
  const roleLabel = user?.UserRole ? USER_ROLES.ADMIN : USER_ROLES.USER;
  const status = user?.status ? STATUS.ACTIVE : STATUS.INACTIVE;
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  /**
   * Resets the user's password.
   * @param {string} userId The user id
   * @param {Object} values The values to reset the password with
   * @param {string} values.newPassword The new password
   * @param {string} values.confirmPassword The confirm password
   * @param {string} values.currentPassword The current password
   */
  const handleResetPassword = async (
    userId: string,
    values: {
      newPassword: string;
      confirmPassword: string;
      currentPassword: string;
    }
  ) => {
    try {
      // Set the submitting state
      setIsSubmitting(true);

      // Check if the passwords match
      if (values.newPassword !== values.confirmPassword) {
        // Show an error message
        showErrorMsg('Passwords do not match');
        return;
      }

      // Make the API call to reset the password
      await resetPassword(userId, values.newPassword, values.currentPassword);

      // Show a success message
      showSuccessMsg(TOAST_MESSAGES.PASSWORD_RESET_SUCCESS);

      // Close the reset modal
      setIsResetModalOpen(false);
    } catch (error) {
      // Log any errors
      console.error('Error resetting password:', error);
    } finally {
      // Set the submitting state back to false
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <SidePanel
        header
        title={
          <div className="flex gap-x-4 items-center">
            <h2 className="text-xl font-normal text-black uppercase leading-none">
              Profile Info
            </h2>
            {loading ? (
              <div className="w-16 h-5 bg-gray-200 animate-pulse rounded-md"></div>
            ) : (
              <span
                className={`px-4 py-1 rounded-md text-xs capitalize font-medium ${
                  status
                    ? 'bg-green-100 text-green-800'
                    : 'bg-red-100 text-red-800'
                }`}
              >
                {status}
              </span>
            )}
          </div>
        }
        rightActions={
          <Button
            variant="ghost"
            title="Reset Password"
            iconOnly
            icon={
              <Icon
                iconName="keyReset"
                iconProps={{ className: '!w-6 !h-6 text-gray' }}
              />
            }
            onClick={() => setIsResetModalOpen(true)}
          />
        }
        open={isOpen}
        onClose={onClose}
      >
        <div className="flex flex-col h-full bg-white p-6 overflow-y-auto">
          <div className="flex items-center gap-3 border-b pt-2 pb-4">
            <Avatar className="!h-9 !w-9">
              {loading ? (
                <div className="h-9 w-9 bg-gray-200 animate-pulse rounded-full"></div>
              ) : (
                <>
                  <AvatarImage src={user?.img} alt={user?.name} />
                  <AvatarFallback className="uppercase">
                    {user?.name
                      ?.split(' ')
                      .map((word) => word.charAt(0))
                      .join('')}
                  </AvatarFallback>
                </>
              )}
            </Avatar>
            <div className="flex-1">
              <div className="flex items-center gap-2 justify-between">
                {loading ? (
                  <div className="w-36 h-4 bg-gray-200 animate-pulse rounded"></div>
                ) : (
                  <>
                    <h3 className="font-normal text-sm capitalize">
                      {user?.name}
                    </h3>
                    <label className="text-xs text-gray-600 font-medium leading-none block bg-gray-100 rounded-2xl px-3 py-1.5">
                      {roleLabel}
                    </label>
                  </>
                )}
              </div>
            </div>
          </div>
          <div className="">
            {loading ? (
              Array.from({ length: 5 }).map((_, index) => (
                <div
                  key={index}
                  className="h-6 bg-gray-200 animate-pulse my-7 rounded"
                ></div>
              ))
            ) : (
              <>
                <div className="flex items-center gap-2 text-gray-700 text-base border-b border-light-gray py-4">
                  <Icon
                    iconName="emailFilled"
                    iconProps={{ className: 'w-4 h-4 text-gray-400' }}
                  />
                  {user?.email}
                </div>
                <div className="flex items-center gap-2 text-gray-700 text-base border-b border-light-gray py-4">
                  <Icon
                    iconName="phone"
                    iconProps={{ className: 'w-4 h-4 text-gray-400' }}
                  />
                  {user?.phone}
                </div>
                <div className="flex items-center gap-2 text-gray-700 text-base border-b border-light-gray py-4">
                  <Icon
                    iconName="mapPinFilled"
                    iconProps={{ className: 'w-4 h-4 text-gray-400' }}
                  />
                  {user?.location}
                </div>
                <div className="flex items-center gap-2 text-gray-700 text-base border-b border-light-gray py-4">
                  <Icon
                    iconName="user"
                    iconProps={{ className: 'w-4 h-4 text-gray-400' }}
                  />
                  User ID - <span className="font-bold">{user?.userId}</span>
                </div>
                <div className="flex items-center gap-2 text-gray-700 text-base border-b border-light-gray py-4">
                  <Icon
                    iconName="building"
                    iconProps={{ className: 'w-4 h-4 text-gray-800' }}
                  />
                  Last Login -{' '}
                  <span className="font-bold">{user?.lastLogin}</span>
                </div>
              </>
            )}
          </div>
          <div className="mt-6 space-y-3">
            <h4 className="font-medium text-gray text-lg">Access Levels</h4>
            {loading ? (
              Array.from({ length: 3 }).map((_, index) => (
                <div
                  key={index}
                  className="h-16 bg-gray-200 animate-pulse my-10 rounded-md"
                ></div>
              ))
            ) : (
              <div className="space-y-4">
                {user?.accessLevels.map((level, index) => (
                  <div key={level.name} className="flex items-start gap-3">
                    <Switch
                      id={`switch-${level.name}-${index}`}
                      checked={level.enabled}
                      disabled
                      label={level.name}
                      description={level.description}
                    />
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </SidePanel>
      {isResetModalOpen && (
        <ResetPasswordModal
          open={isResetModalOpen}
          onClose={() => setIsResetModalOpen(false)}
          onSubmit={(values) => handleResetPassword(user?.userId, values)} // Passing user ID dynamically
          isSubmitting={isSubmitting}
        />
      )}
    </>
  );
};

export default UserProfileInfo;
