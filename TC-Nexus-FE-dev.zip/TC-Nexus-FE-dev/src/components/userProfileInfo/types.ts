export interface UserProfileInfoProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: ProfileData | object;
  loading: boolean;
}

export interface ProfileData {
  name: string;
  email: string;
  phone: string;
  location: string;
  userId: string;
  lastLogin: string;
  UserRole: boolean;
  img: string;
  accessLevels: AccessLevel[];
  status: boolean;
}

export interface userPermissions {
  system_administration: number;
  all_screens_access: number;
  sales_revenue: number;
  profit_margin_retail: number;
  profit_margin_nc: number;
  lead_conversion: number;
  cac: number;
  operations: number;
  sales_report: number;
  new_construction_bids: number;
  marketing_lead: number;
}

export interface AccessLevel {
  name: string;
  description: string;
  enabled: boolean;
}
