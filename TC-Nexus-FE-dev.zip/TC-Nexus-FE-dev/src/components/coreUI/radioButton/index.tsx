import * as React from 'react';

/**
 * RadioGroup component is a wrapper for a group of radio buttons.
 *
 * @param {React.HTMLAttributes<HTMLDivElement>} props - Properties passed to the RadioGroup component
 * @param {React.Ref<HTMLDivElement>} ref - Forwarded ref to the div element
 */
const RadioGroup = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className = '', ...props }, ref) => {
  return <div className={`grid gap-3 ${className}`} {...props} ref={ref} />;
});
RadioGroup.displayName = 'RadioGroup';

/**
 * Interface for props used in RadioGroupItem component.
 */
interface RadioGroupItemProps
  extends React.InputHTMLAttributes<HTMLInputElement> {
  id: string;
  label: string;
  value: string;
  checked?: boolean;
  name?: string;
  disabled?: boolean;
  onchange?: () => void;
  customSize?: 'sm' | 'md' | 'lg'; // Using predefined size values
}

/**
 * RadioGroupItem component is a single radio button with a label.
 *
 * @param {RadioGroupItemProps} props - Properties passed to the RadioGroupItem component
 * @param {React.Ref<HTMLInputElement>} ref - Forwarded ref to the input element
 */
const RadioGroupItem = React.forwardRef<HTMLInputElement, RadioGroupItemProps>(
  (
    {
      className = '',
      id = '',
      label = '',
      value = '',
      checked = false,
      name = '',
      disabled = false,
      onChange = () => {},
      customSize = 'md', // Default size is medium
      ...props
    },
    ref
  ) => {
    // Predefined size classes
    const sizeClasses = {
      sm: 'h-4 w-4',
      md: 'h-5 w-5',
      lg: 'h-6 w-6',
    };

    const radioSize = sizeClasses[customSize]; // Select the correct size class based on the `customSize` prop

    /** CSS classes for the radio input */
    const radioClasses = `
      aspect-square rounded-full border border-primary text-black focus:outline-none focus-visible:ring-1 focus-visible:ring-ring
      ${disabled ? 'cursor-not-allowed opacity-50' : ''}
      ${className}
    `;

    return (
      <div className={`inline-flex items-center ${className}`}>
        <input
          type="radio"
          ref={ref}
          id={id}
          value={value}
          checked={checked}
          name={name}
          disabled={disabled}
          className="sr-only"
          onChange={onChange} // Added onChange event
          {...props}
        />
        <label
          htmlFor={id}
          className={`flex items-center cursor-pointer ${disabled ? 'cursor-not-allowed opacity-50' : ''}`}
        >
          <span className={`${radioClasses} ${radioSize}`}>
            {checked ? (
              <span className="flex items-center justify-center w-full h-full">
                <span
                  className="rounded-full bg-primary"
                  style={{ width: '50%', height: '50%' }} // Adjust inner circle size dynamically
                />
              </span>
            ) : null}
          </span>
          <span className="ml-2 text-sm font-normal">{label}</span>
        </label>
      </div>
    );
  }
);
RadioGroupItem.displayName = 'RadioGroupItem';

export { RadioGroup, RadioGroupItem };
