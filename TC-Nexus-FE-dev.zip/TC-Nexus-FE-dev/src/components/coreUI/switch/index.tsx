import * as React from 'react';
import * as SwitchPrimitives from '@radix-ui/react-switch';

/**
 * SwitchProps interface.
 *
 * @interface SwitchProps
 * @extends {React.ComponentPropsWithoutRef<typeof SwitchPrimitives.Root>}
 * @property {boolean} [disabled] - Whether the switch is disabled
 * @property {boolean} [checked] - Whether the switch is checked
 * @property {string} [className] - Additional class names for the switch
 * @property {(checked: boolean) => void} [onChange] - Change event handler
 * @property {string} [label] - Label text for the switch
 * @property {string} [description] - Description text for the switch
 */
interface SwitchProps
  extends Omit<
    React.ComponentPropsWithoutRef<typeof SwitchPrimitives.Root>,
    'onChange'
  > {
  disabled?: boolean;
  checked?: boolean;
  className?: string;
  // eslint-disable-next-line no-unused-vars
  onChange?: (checked: boolean) => void;
  id?: string;
  label?: React.ReactNode;
  descriptionStyle?: string;
  description?: React.ReactNode;
}

/**
 * Switch component.
 *
 * @param {SwitchProps} props - Properties passed to the Switch component
 * @param {React.Ref<typeof SwitchPrimitives.Root>} ref - Forwarded ref to the switch element
 * @returns {React.ReactElement} Switch component
 */
const Switch = React.forwardRef<HTMLButtonElement, SwitchProps>(
  (
    {
      className,
      disabled = false,
      checked = false,
      onChange = () => {},
      label = '',
      description = '',
      descriptionStyle,
      id = '',
      ...props
    },
    ref
  ) => {
    /**
     * Define the CSS classes for the switch element.
     *
     * @type {string}
     */
    const switchClasses = `peer inline-flex h-5 w-10 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-800 focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary-800 data-[state=unchecked]:bg-gray-200 ${className}`;

    /**
     * Define the CSS classes for the dot element.
     *
     * @type {string}
     */
    const dotClasses = `pointer-events-none block h-4 w-4 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-5 data-[state=unchecked]:translate-x-0`;

    const handleLabelClick = () => {
      if (!disabled && onChange) {
        onChange(!checked);
      }
    };

    return (
      <div className="flex items-start">
        <SwitchPrimitives.Root
          className={switchClasses}
          ref={ref}
          disabled={disabled}
          checked={checked}
          onCheckedChange={onChange} // Pass the onChange handler
          id={id}
          {...props}
        >
          <SwitchPrimitives.Thumb className={dotClasses} />
        </SwitchPrimitives.Root>
        {label || description ? (
          <label
            htmlFor={id}
            className={`ml-2 text-sm font-normal ${disabled ? 'cursor-not-allowed opacity-50' : 'cursor-pointer'}`}
            onClick={handleLabelClick}
          >
            {label && (
              <span
                className={`${description ? 'font-medium' : 'font-medium mt-[4px] block'}`}
              >
                {label}
              </span>
            )}
            {description && (
              <p className={`text-xs  text-gray-500 ${descriptionStyle}`}>
                {description}
              </p>
            )}
          </label>
        ) : null}
      </div>
    );
  }
);

Switch.displayName = SwitchPrimitives.Root.displayName;

export { Switch };
