import React from 'react';

interface TotalCardProps {
  title: string;
  value: string | number;
  trend?: {
    value: number;
    isPositive: boolean;
    comparisonText?: string;
    icon?: React.ReactNode;
  };
  className?: string;
  valuePrefix?: string;
  valueSuffix?: string;
  trendGraph?: React.ReactNode;
}

const TotalCard: React.FC<TotalCardProps> = ({
  title,
  value,
  trend,
  className = '',
  valuePrefix = '',
  valueSuffix = '',
  trendGraph,
}) => {
  return (
    <div className={`p-4 rounded-lg h-[140px] ${className}`}>
      <h3 className="text-gray-700 text-[18px] font-medium mb-3">{title}</h3>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-baseline">
            <span className="text-[24px] text-gray-900">
              {valuePrefix}
              {value}
              {valueSuffix}
            </span>
          </div>
          {trendGraph && <div className="w-20 h-8">{trendGraph}</div>}
        </div>

        {trend && (
          <div className="flex items-center gap-1.5">
            <span
              className={`${
                trend.isPositive ? 'text-teal-500' : 'text-red-500'
              } text-sm font-medium`}
            >
              {trend.value}%
            </span>
            {trend.icon && <span>{trend.icon}</span>}
            {trend.comparisonText && (
              <span className="text-gray-500 text-xs">
                {trend.comparisonText}
              </span>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default TotalCard;
