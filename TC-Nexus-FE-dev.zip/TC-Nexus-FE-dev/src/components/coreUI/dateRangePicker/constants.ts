const CALENDAR_QUICK_OPTIONS = {
  today: 'Today',
  thisWeek: 'This Week',
  lastWeek: 'Last Week',
  thisMonth: 'This Month',
  lastMonth: 'Last Month',
  thisYear: 'This Year',
  lastYear: 'Last Year',
  custom: 'Custom',
};

export { CALENDAR_QUICK_OPTIONS };
