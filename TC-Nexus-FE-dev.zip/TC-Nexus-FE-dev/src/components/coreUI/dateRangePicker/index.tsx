'use client';

import React, { useEffect, useState } from 'react';
import DatePicker from 'react-datepicker';
import { enGB } from 'date-fns/locale';
import {
  startOfISOWeek,
  endOfISOWeek,
  subWeeks,
  startOfMonth,
  endOfMonth,
  startOfYear,
  endOfYear,
  subMonths,
  subYears,
  format,
  getYear,
} from 'date-fns';

import { CALENDAR_QUICK_OPTIONS } from './constants';

import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/coreUI/popover';
import { Button } from '@/components/coreUI/button';

import 'react-datepicker/dist/react-datepicker.css';
import Icon from '@/components/coreUI/icon';

interface DatePickerProps {
  primaryBtnText?: string;
  dateFormat?: string;
  secondaryBtnText?: string;
  // eslint-disable-next-line no-unused-vars
  onPrimaryBtnClick?: (dates: [Date | null, Date | null]) => void;
  // eslint-disable-next-line no-unused-vars
  onSecondaryBtnClick?: (dates: [Date | null, Date | null]) => void;
  value?: [Date | null, Date | null] | null;
  disabled?: boolean;
  calendarPluginProps?: any;
  onClearBtnClick?: () => void;
  monthOnlyView?: boolean;
}

/**
 * A date range picker component that displays a multi-month calendar.
 * It provides a button with a label that shows the selected date range.
 * When clicked, a popover appears with a sidebar containing quick options
 * to select a date range, and a multi-month calendar to select a date range.
 *
 * The component accepts the following props:
 * - `primaryBtnText`: The text to display on the primary button.
 * - `secondaryBtnText`: The text to display on the secondary button.
 * - `onPrimaryBtnClick`: A callback function to trigger when the primary button is clicked.
 * - `onSecondaryBtnClick`: A callback function to trigger when the secondary button is clicked.
 * - `value`: The selected date range to display on the button.
 *   It can be an array of two dates, or null.
 *
 * The component emits the following events:
 * - `onPrimaryBtnClick`: Triggers when the primary button is clicked.
 *   It emits the selected date range as an array of two dates.
 * - `onSecondaryBtnClick`: Triggers when the secondary button is clicked.
 *   It emits the selected date range as an array of two dates.
 *
 * The component uses the `react-datepicker` library to render the calendar.
 * The `react-datepicker` library provides a lot of customization options.
 * Check out the `react-datepicker` documentation for more information.
 */
const DateRangePickerWithSidebar = ({
  primaryBtnText = 'Ok',
  secondaryBtnText = 'Cancel',
  onPrimaryBtnClick = () => {},
  onSecondaryBtnClick = () => {},
  dateFormat = 'yyyy-MM-dd',
  value = null,
  disabled = false,
  onClearBtnClick,
  calendarPluginProps = {},
  monthOnlyView = false,
}: DatePickerProps) => {
  // States
  const [isOpen, setIsOpen] = useState(false);
  const [startDate, setStartDate] = useState<Date | null>(null);
  const [endDate, setEndDate] = useState<Date | null>(null);
  const [activeOption, setActiveOption] = useState<string>(
    CALENDAR_QUICK_OPTIONS.today
  );
  const [dateRange, setDateRange] = useState({
    appliedRange: activeOption,
    appliedStartDate: null as Date | null,
    appliedEndDate: null as Date | null,
  });

  const [selectedStartDate = null, selectedEndDate = null] = value || [];
  const [isRangeApplied, setIsRangeApplied] = useState(false);
  const [selectedOption, setSelectedOption] = useState<string>(
    monthOnlyView
      ? CALENDAR_QUICK_OPTIONS.thisMonth
      : CALENDAR_QUICK_OPTIONS.today
  );

  const now = new Date();
  let start: Date | null = null;
  let end: Date | null = null;
  start = startOfMonth(now);
  end = endOfMonth(now);
  const formattedRange = `${format(start, dateFormat)} - ${format(end, dateFormat)}`;

  useEffect(() => {
    if (monthOnlyView) {
      setStartDate(start);
      setEndDate(end);
      setActiveOption(formattedRange);
    }
  }, []);

  const handleSidebarSelection = (option: string) => {
    const now = new Date();
    let start: Date | null = null;
    let end: Date | null = null;

    const dateRanges = {
      [CALENDAR_QUICK_OPTIONS.today]: [now, now],
      [CALENDAR_QUICK_OPTIONS.thisWeek]: [
        startOfISOWeek(now),
        endOfISOWeek(now),
      ],
      [CALENDAR_QUICK_OPTIONS.lastWeek]: [
        startOfISOWeek(subWeeks(now, 1)),
        endOfISOWeek(subWeeks(now, 1)),
      ],
      [CALENDAR_QUICK_OPTIONS.thisMonth]: [startOfMonth(now), endOfMonth(now)],
      [CALENDAR_QUICK_OPTIONS.lastMonth]: [
        startOfMonth(subMonths(now, 1)),
        endOfMonth(subMonths(now, 1)),
      ],
      [CALENDAR_QUICK_OPTIONS.thisYear]: [startOfYear(now), endOfYear(now)],
      [CALENDAR_QUICK_OPTIONS.lastYear]: [
        startOfYear(subYears(now, 1)),
        endOfYear(subYears(now, 1)),
      ],
      [CALENDAR_QUICK_OPTIONS.custom]: [null, null],
    };

    if (monthOnlyView) {
      [start, end] = dateRanges[option] || [null, null];
    } else {
      const [newStart, newEnd] = dateRanges[option] || [null, null];
      setStartDate(newStart);
      setEndDate(newEnd);
    }

    if (start && end) {
      setStartDate(start);
      setEndDate(end);
      const formattedRange = `${format(start, dateFormat)} - ${format(end, dateFormat)}`;
      setActiveOption(formattedRange);
    } else {
      setActiveOption(option);
    }

    // Update the selected option
    setSelectedOption(option);
  };

  /**
   * Handle date change event
   * @param {Date[] | [Date | null, Date | null]} dates - The selected date range
   */
  const handleDateChange = (dates: [Date | null, Date | null]) => {
    const [startDate, endDate] = dates;
    setStartDate(startDate);
    setEndDate(endDate);

    // If the user selects a range manually, store that range as the active option.
    // if (startDate && endDate) {
    //   setActiveOption(CALENDAR_QUICK_OPTIONS.custom);
    // }
    if (startDate && endDate) {
      const formattedRange = `${format(startDate, dateFormat)} - ${format(endDate, dateFormat)}`;
      setActiveOption(formattedRange);
    }
  };
  /**
   * Resets the start and end dates to null.
   */
  const resetSelection = () => {
    setStartDate(dateRange.appliedStartDate);
    setEndDate(dateRange.appliedEndDate);
    setActiveOption(dateRange.appliedRange);
  };

  /**
   * Handles the primary button click event.
   * Triggers the onPrimaryBtnClick callback, resets the date selection,
   * and closes the popover.
   */
  const handlePrimaryBtnClick = () => {
    if (monthOnlyView) {
      if (
        startDate &&
        endDate &&
        startDate.toDateString() === new Date().toDateString() &&
        endDate.toDateString() === new Date().toDateString()
      ) {
        setStartDate(null);
        setEndDate(null);
        handleClearFilters();
        onPrimaryBtnClick(structuredClone([null, null]));
        setIsOpen(false);
        return;
      }
    }
    onPrimaryBtnClick(structuredClone([startDate, endDate]));
    setIsOpen(false);
    setDateRange((prev) => ({
      ...prev,
      appliedRange: activeOption,
      appliedStartDate: startDate,
      appliedEndDate: endDate,
    }));
    setIsRangeApplied(true);
  };

  /**
   * Handles the secondary button click event.
   * Triggers the onSecondaryBtnClick callback, resets the date selection,
   * and closes the popover.
   */
  const handleSecondaryBtnClick = () => {
    onSecondaryBtnClick([startDate, endDate]);
    setIsOpen(false);
    resetSelection();
  };

  /**
   * Format a given date according to the configured dateFormat.
   * If the given date is null or undefined, an empty string is returned.
   *
   * @param {Date | null} date - The date to be formatted
   * @returns {string} The formatted date string
   */

  // Generate array of years for dropdown (e.g., last 100 years)
  const yearsForDropdown = Array.from(
    { length: 6 },
    (_, i) => getYear(new Date()) - i
  );
  const minDate = new Date(2020, 0, 1); // Jan 1, 2020

  const maxDate = new Date(now.getFullYear(), 11, 31); // Dec 31 of current year

  // Custom header renderer for DatePicker
  const renderCustomHeader = ({
    date,
    changeYear,
    decreaseYear,
    increaseYear,
    decreaseMonth,
    increaseMonth,
    prevYearButtonDisabled,
    nextYearButtonDisabled,
    prevMonthButtonDisabled,
    nextMonthButtonDisabled,
    customHeaderCount,
  }: any) => {
    const isFirstCalendar = customHeaderCount === 0;

    const displayDate = isFirstCalendar
      ? date
      : new Date(new Date(date).setMonth(date.getMonth() + 1));
    // Calculate display year based on calendar position
    const displayYear = isFirstCalendar
      ? date.getFullYear()
      : date.getFullYear() + 1;

    // Generate year options for each calendar
    const getYearOptions = () => {
      const currentYear = new Date().getFullYear();
      const minYear = 2020;
      const maxYear = currentYear;

      if (isFirstCalendar) {
        // First calendar shows from minYear to (second calendar year - 1)
        return Array.from(
          { length: maxYear - minYear + 1 },
          (_, i) => minYear + i
        );
      } else {
        // Second calendar shows from (first calendar year + 1) to maxYear
        const firstCalendarYear = date.getFullYear();
        return Array.from(
          { length: maxYear - firstCalendarYear },
          (_, i) => firstCalendarYear + i + 1
        );
      }
    };

    const years = getYearOptions();

    const handleYearChange = (selectedYear: number) => {
      changeYear(selectedYear);
      if (isFirstCalendar) {
        const currentYear = new Date().getFullYear();
        if (selectedYear === currentYear) {
          setActiveOption(CALENDAR_QUICK_OPTIONS.thisYear);
        } else if (selectedYear === currentYear - 1) {
          setActiveOption(CALENDAR_QUICK_OPTIONS.lastYear);
        } else {
          setActiveOption(CALENDAR_QUICK_OPTIONS.custom);
        }
      }
    };

    return monthOnlyView ? (
      <div className="flex items-center justify-between px-2 py-2 w-full">
        {isFirstCalendar && (
          <button
            onClick={decreaseYear}
            disabled={prevYearButtonDisabled || displayYear <= 2020}
            type="button"
            className={`p-1 ${
              prevYearButtonDisabled || displayYear <= 2020
                ? 'text-gray-300'
                : 'text-gray-700 hover:text-primary-800'
            }`}
          >
            <Icon
              iconName="chevronLeft"
              iconProps={{ className: '!h-4 !w-4' }}
            />
          </button>
        )}
        <div className="flex gap-2 items-center">
          <div className="relative inline-block">
            <select
              value={displayYear}
              onChange={({ target: { value } }) =>
                handleYearChange(Number(value))
              }
              className="appearance-none text-sm font-medium bg-transparent cursor-pointer hover:text-primary-800 focus:outline-none pr-6 border border-gray-200 rounded px-2 py-1"
            >
              {years.map((year) => (
                <option key={year} value={year}>
                  {year}
                </option>
              ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-1">
              <Icon
                iconName="chevronDown"
                iconProps={{ className: '!h-3 !w-3 text-gray-500' }}
              />
            </div>
          </div>
        </div>
        {isFirstCalendar && (
          <button
            onClick={increaseYear}
            disabled={
              nextYearButtonDisabled || displayYear >= new Date().getFullYear()
            }
            type="button"
            className={`p-1 ${
              nextYearButtonDisabled || displayYear >= new Date().getFullYear()
                ? 'text-gray-300'
                : 'text-gray-700 hover:text-primary-800'
            }`}
          >
            <Icon
              iconName="chevronRight"
              iconProps={{ className: '!h-4 !w-4' }}
            />
          </button>
        )}
      </div>
    ) : (
      <div className="flex items-center justify-between px-2 py-2">
        {isFirstCalendar && (
          <button
            onClick={decreaseMonth}
            disabled={prevMonthButtonDisabled}
            type="button"
            className={`p-1 ${prevMonthButtonDisabled ? 'text-gray-300' : 'text-gray-700 hover:text-primary-800'}`}
          >
            <Icon
              iconName="chevronLeft"
              iconProps={{ className: '!h-4 !w-4' }}
            />
          </button>
        )}
        {!isFirstCalendar && <div className="w-8" />}

        <div className="flex gap-2 items-center">
          <span className="text-sm font-medium">
            {format(displayDate, 'MMMM')}
          </span>
          <div className="relative inline-block">
            <select
              value={getYear(displayDate)}
              onChange={({ target: { value } }) =>
                handleYearChange(Number(value))
              }
              className="appearance-none text-sm font-medium bg-transparent cursor-pointer hover:text-primary-800 focus:outline-none pr-6 border border-gray-200 rounded px-2 py-1"
            >
              {yearsForDropdown.map((year) => (
                <option key={year} value={year}>
                  {year}
                </option>
              ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-1">
              <Icon
                iconName="chevronDown"
                iconProps={{ className: '!h-3 !w-3 text-gray-500' }}
              />
            </div>
          </div>
        </div>

        {!isFirstCalendar && (
          <button
            onClick={increaseMonth}
            disabled={nextMonthButtonDisabled}
            type="button"
            className={`p-1 ${nextMonthButtonDisabled ? 'text-gray-300' : 'text-gray-700 hover:text-primary-800'}`}
          >
            <Icon
              iconName="chevronRight"
              iconProps={{ className: '!h-4 !w-4' }}
            />
          </button>
        )}
        {isFirstCalendar && <div className="w-8" />}
      </div>
    );
  };

  useEffect(() => {
    if (value) {
      const [startDate = null, endDate = null] = value || [];
      setStartDate(startDate);
      setEndDate(endDate);
    }
  }, [value]);

  const handleClearFilters = () => {
    setStartDate(null);
    setEndDate(null);
    setDateRange({
      appliedRange: 'Today',
      appliedStartDate: null,
      appliedEndDate: null,
    });
    setActiveOption('Today');
    setIsRangeApplied(false);

    if (onClearBtnClick) {
      onClearBtnClick();
    }
  };

  const handleMonthChange = (date: Date) => {
    const selectedMonthStart = startOfMonth(date);
    const selectedMonthEnd = endOfMonth(date);

    if (!startDate) {
      setStartDate(selectedMonthStart);
      setEndDate(null);
      setActiveOption(`${format(selectedMonthStart, dateFormat)} - ...`);
    } else {
      if (selectedMonthStart < startDate) {
        setEndDate(endOfMonth(startDate));
        setStartDate(selectedMonthStart);
        setActiveOption(
          `${format(selectedMonthStart, dateFormat)} - ${format(endOfMonth(startDate), dateFormat)}`
        );
      } else {
        setEndDate(selectedMonthEnd);
        setActiveOption(
          `${format(startDate, dateFormat)} - ${format(selectedMonthEnd, dateFormat)}`
        );
      }
    }

    setSelectedOption(CALENDAR_QUICK_OPTIONS.custom);
  };

  const timePeriodOptions = monthOnlyView
    ? [CALENDAR_QUICK_OPTIONS.thisMonth, CALENDAR_QUICK_OPTIONS.lastMonth]
    : Object.values(CALENDAR_QUICK_OPTIONS);

  return (
    <Popover
      open={isOpen}
      onOpenChange={(popoverState: boolean) => {
        if (!popoverState) {
          resetSelection();
        } else if (!selectedStartDate && !selectedEndDate) {
          // If opening after being cleared, set to today
          const now = new Date();
          setStartDate(now);
          setEndDate(now);
          setDateRange({
            appliedRange: 'Today',
            appliedStartDate: now,
            appliedEndDate: now,
          });
        }
        setIsOpen(popoverState);
      }}
    >
      <PopoverTrigger asChild>
        <Button
          variant="outlineLight"
          disabled={disabled}
          full
          className="!justify-start h-10"
          icon={
            <Icon
              iconName="calendar"
              iconProps={{ className: 'text-gray-500 !h-[18px] !w-[18px]' }}
            />
          }
        >
          {selectedStartDate && selectedEndDate ? (
            activeOption
          ) : (
            <span className="font-normal text-gray-600">Select Date Range</span>
          )}
          {isRangeApplied && startDate && endDate ? (
            <span
              className="ml-auto cursor-pointer"
              onClick={(e) => {
                e.stopPropagation();
                handleClearFilters();
              }}
            >
              <Icon
                iconName="cross"
                iconProps={{ className: 'text-red-600 !h-4 !w-4' }}
              />
            </span>
          ) : (
            <span className="ml-auto">
              <Icon
                iconName="arrowUp"
                iconProps={{ className: 'text-gray-600 !h-[18px] !w-[18px]' }}
              />
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent
        className="w-[320px] xs:w-auto rounded-lg h-auto xs:h-auto"
        align="start"
      >
        <div className="flex gap-4 flex-col xs:flex-row overflow-y-auto max-h-[460px] p-4">
          {/* Left Sidebar */}
          <div className="w-full xs:w-32">
            <ul className="flex items-center flex-wrap mt-2 gap-2 xs:mt-0 pb-2 xs:pb-0 border-b xs:border-0 xs:space-y-3.5">
              {timePeriodOptions.map((option) => (
                <li key={option}>
                  <a
                    className={`w-full text-[13px] xs:text-sm text-left px-2 xs:px-4 xs:py-2 cursor-pointer
                      ${selectedOption === option ? 'text-primary-800' : 'text-gray-700 hover:text-primary-800'}
                    `}
                    onClick={() => handleSidebarSelection(option)}
                  >
                    {option}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Right Section with Multi-Month Calendar */}
          <div className="flex flex-col">
            <DatePicker
              inline
              selected={startDate}
              onChange={monthOnlyView ? handleMonthChange : handleDateChange}
              showMonthYearPicker={monthOnlyView}
              selectsRange
              monthsShown={monthOnlyView ? 1 : 2}
              startDate={startDate}
              endDate={endDate}
              locale={enGB}
              calendarClassName="tc-datepicker-wrap font-roboto select-none"
              renderCustomHeader={renderCustomHeader}
              calendarStartDay={1}
              formatWeekDay={(day) => day?.substring(0, 3)}
              {...calendarPluginProps}
              minDate={minDate}
              maxDate={maxDate}
            />
            <div className="flex flex-row xs:mt-2 gap-4 border-t xs:border-0 p-3 py-4 xs:p-0 xs:pt-0">
              <Button
                className="basis-1/2"
                size="sm"
                onClick={handlePrimaryBtnClick}
              >
                {primaryBtnText}
              </Button>
              <Button
                className="basis-1/2"
                variant="outlineLight"
                size="sm"
                onClick={handleSecondaryBtnClick}
              >
                {secondaryBtnText}
              </Button>
            </div>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
};

export default DateRangePickerWithSidebar;
