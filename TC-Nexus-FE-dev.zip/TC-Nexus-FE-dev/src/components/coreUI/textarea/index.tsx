import * as React from 'react';

// Define properties for the TextArea component
interface TextAreaProps
  extends Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, 'height'> {
  label?: string; // Optional label for the textarea
  height?: string; // Size of the textarea, default is 'md'
  error?: string; // Optional error message
}

/**
 * TextArea component renders a customizable textarea field with a label and error handling.
 *
 * @param {TextAreaProps} props - Properties passed to the TextArea component
 * @param {React.Ref<HTMLTextAreaElement>} ref - Forwarded ref to the textarea element
 */
const TextArea = React.forwardRef<HTMLTextAreaElement, TextAreaProps>(
  ({ className, label = '', height, error = '', ...props }, ref) => {
    // Combine classes for the textarea element
    const textAreaClasses = `flex w-full border border-gray-300 focus:ring-2 focus:border-transparent bg-transparent resize-none transition-colors placeholder:text-muted-foreground focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50 
    ${
      error
        ? 'border-red-500 focus-visible:ring-2 focus-visible:ring-red-500'
        : 'focus-visible:ring-2 focus-visible:ring-gray-400 '
    } ${className}`;

    // Combine classes for the error field
    const errorFieldClasses = `flex text-xs my-1 font-normal ${
      error ? 'text-red-500' : 'text-black'
    }`;

    return (
      <div className="w-full">
        {/* Render label if provided */}
        {label && (
          <label
            className="text-xs text-gray font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 mb-2 block"
            htmlFor={props?.id}
          >
            {label}
          </label>
        )}

        {/* Main textarea field */}
        <textarea
          {...props}
          className={`${textAreaClasses}`}
          ref={ref}
          autoComplete="off"
          style={{ height }}
        />

        {/* Render error message if error is present */}
        {error && <div className={errorFieldClasses}>{error}</div>}
      </div>
    );
  }
);

TextArea.displayName = 'TextArea';

export { TextArea };
