import * as React from 'react';

// Define the properties for the TextInput component
interface TextInputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'> {
  label?: string | React.ReactNode; // Optional label for the input
  startAdornment?: React.ReactNode; // Optional icon to display on the left of the input
  endAdornment?: React.ReactNode; // Optional icon to display on the right of the input
  size?: 'sm' | 'md' | 'lg'; // Size of the input, default is 'md'
  error?: string; // Optional error state for the input
}

/**
 * TextInput component renders a customizable input field with optional icons and label.
 *
 * @param {TextInputProps} props - Properties passed to the TextInput component
 * @param {React.Ref<HTMLInputElement>} ref - Forwarded ref to the input element
 */
const TextInput = React.forwardRef<HTMLInputElement, TextInputProps>(
  (
    {
      className,
      label,
      startAdornment = null,
      endAdornment = null,
      size = 'md',
      error = '',
      ...props
    },
    ref
  ) => {
    // Combine classes for the input element
    const inputClasses = `flex w-full border border-gray-300 focus:ring-2 focus:border-transparent bg-transparent px-4 transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50 
    ${
      error
        ? 'border-red-500 focus-visible:ring-2 focus-visible:ring-red-500'
        : 'focus-visible:ring-2 focus-visible:ring-gray-400 '
    } ${className}`;

    // Define CSS classes for different input sizes
    const inputSizeClasses = {
      sm: 'h-9 text-xs md:text-xs py-2 rounded-lg',
      md: 'h-10 text-sm md:text-sm rounded-lg',
      lg: 'h-14 text-sm md:text-base py-4 rounded-xl',
    };

    // Combine classes for the error field
    const errorFieldClasses = `flex text-xs my-1 font-normal ${error ? 'text-red-500' : 'text-black'}`;

    return (
      <div className="w-full">
        {/* Render label if provided */}
        {typeof label === 'string' ? (
          <label
            className="text-xs text-gray  font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 mb-2 block"
            htmlFor={props?.id}
          >
            {label || ''}
          </label>
        ) : (
          label
        )}

        <div className="relative">
          {/* Render left icon if provided */}
          {startAdornment ? startAdornment : null}

          {/* Main input field */}
          <input
            {...props}
            className={`${inputSizeClasses[size]} ${inputClasses}`}
            ref={ref}
            autoComplete="off"
          />

          {/* Render right icon if provided */}
          {endAdornment ? endAdornment : null}
        </div>

        {/* Render error message if error is present */}
        {error && <div className={errorFieldClasses}>{error}</div>}
      </div>
    );
  }
);

TextInput.displayName = 'TextInput';

export { TextInput };
