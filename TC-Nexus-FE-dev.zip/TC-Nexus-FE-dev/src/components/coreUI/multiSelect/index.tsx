'use client';
import React, { useEffect, useRef, useState } from 'react';
import Select, { components, MultiValue } from 'react-select';
import { Checkbox } from '@/components/coreUI/checkbox';
import Icon from '@/components/coreUI/icon';
export interface Option {
  label: string;
  value: string | number;
}

interface MultiSelectProps {
  options: Option[];
  value: Option[];
  // eslint-disable-next-line no-unused-vars
  onChange: (selected: Option[] | Option) => void;
  size?: 'sm' | 'md' | 'lg';
  icon?: string; // Optional icon prop
  placeholder?: string;
  isDisabled?: boolean;
  isLoading?: boolean;
  isClearable?: boolean;
  className?: string;
  iconSize?: number;
  iconColor?: string;
  iconStrokeWidth?: number;
  showCheckbox?: boolean; // New prop
  hideSelectedOptions?: boolean;
  closeMenuOnSelect?: boolean;
  selectProps?: any;
  isMulti?: boolean;
  backgroundColor?: string; // New prop for background color
  openDropdown?: string; // Prop to control which dropdown is open
  setOpenDropdown?: () => void; // Function to update openDropdown
  menuIsOpen?: boolean;
  // eslint-disable-next-line no-unused-vars
  setMenuIsOpen?: (isOpen: boolean) => void;
}

const SELECT_HEIGHTS = { sm: '32px', md: '38px', lg: '48px' };

const MultiSelect: React.FC<MultiSelectProps> = ({
  options,
  value,
  onChange,
  size = 'md',
  icon = '', // Renamed to Icon for JSX usage
  placeholder = 'Select...',
  isDisabled = false,
  isLoading = false,
  isClearable = true,
  className,
  iconSize = 18,
  iconColor = 'rgb(var(--color-gray-500))',
  iconStrokeWidth = 1.5,
  showCheckbox = false,
  hideSelectedOptions = false,
  selectProps = {},
  isMulti = true,
  backgroundColor = 'white', // Default to white
  openDropdown,
  menuIsOpen,
  setMenuIsOpen,
}) => {
  const selectRef = useRef<HTMLDivElement>(null);
  const [localMenuIsOpen, setLocalMenuIsOpen] = useState(false);

  const handleClick = () => {
    if (setMenuIsOpen) {
      setMenuIsOpen(true);
    } else {
      setLocalMenuIsOpen(true);
    }
  };

  const handleClickOutside = (event: MouseEvent) => {
    if (
      selectRef?.current &&
      !selectRef?.current?.contains(event?.target as Node)
    ) {
      if (setMenuIsOpen) {
        setMenuIsOpen?.(false);
      } else {
        setLocalMenuIsOpen?.(false);
      }
    }
  };
  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  useEffect(() => {
    if (openDropdown !== 'multiSelect') {
      setMenuIsOpen?.(false);
      setLocalMenuIsOpen(false);
    } else {
      setMenuIsOpen?.(true);
      setLocalMenuIsOpen(true);
    }
  }, [openDropdown]);
  // Custom ValueContainer with optional icon
  const ValueContainer = ({ children, ...props }: any) => {
    const selectedValues = props.getValue();
    const count = selectedValues.length;
    const showCount = isMulti && count > 1;

    return (
      <components.ValueContainer {...props}>
        {icon && (
          <Icon
            iconName={icon}
            iconProps={{
              className: `ml-2 text-[rgb(var(--color-gray-500))]`,
              style: {
                strokeWidth: iconStrokeWidth,
                color: iconColor,
              },
            }}
          />
        )}
        {showCount ? (
          <div
            style={{
              display: 'flex',
              gap: '8px',
              alignItems: 'center',
              flexWrap: 'nowrap',
            }}
          >
            {selectedValues.slice(0, 1).map((val: Option) => (
              <div
                key={val.value}
                className="multi-select__multi-value"
                style={{ margin: 0 }}
              >
                <div className="multi-select__multi-value__label">
                  {val.label}
                </div>
                <div
                  className="multi-select__multi-value__remove"
                  onClick={(e) => {
                    e.stopPropagation();
                    const newValue = selectedValues.filter(
                      (v: Option) => v.value !== val.value
                    );
                    onChange(newValue);
                    setMenuIsOpen?.(false);
                  }}
                >
                  ×
                </div>
              </div>
            ))}
            <div className="multi-select__multi-value" style={{ margin: 0 }}>
              <div className="multi-select__multi-value__label">
                +{count - 1} more
              </div>
            </div>
          </div>
        ) : (
          children.filter((child: any) => child?.type !== components.Input)
        )}
        {children.find((child: any) => child?.type === components.Input)}{' '}
      </components.ValueContainer>
    );
  };

  // Custom Option component with conditional checkbox
  const Option = ({ children, isSelected, ...props }: any) => {
    return (
      <components.Option {...props}>
        <div className="flex items-center gap-2 cursor-pointer">
          {showCheckbox && <Checkbox size="sm" checked={isSelected} />}
          {children}
        </div>
      </components.Option>
    );
  };

  const getHeightBySize = (size: 'sm' | 'md' | 'lg') => {
    return SELECT_HEIGHTS[size];
  };

  return (
    <div ref={selectRef} onClick={handleClick}>
      <Select
        isMulti={isMulti}
        instanceId="multi-select"
        options={options}
        value={value}
        onChange={(selected: MultiValue<Option>) =>
          onChange(selected as Option[])
        }
        onFocus={() => {
          // setMenuIsOpen(true);
        }}
        onBlur={() => setMenuIsOpen?.(false)}
        placeholder={placeholder}
        closeMenuOnSelect={false}
        isDisabled={isDisabled}
        isLoading={isLoading}
        isClearable={isClearable}
        className={`${className} ${getHeightBySize(size)}`}
        classNamePrefix="multi-select"
        hideSelectedOptions={hideSelectedOptions}
        components={{ ValueContainer, Option }}
        isSearchable={true}
        menuIsOpen={menuIsOpen ?? localMenuIsOpen}
        {...selectProps}
        styles={{
          valueContainer: (base) => ({
            ...base,
            paddingLeft: icon ? 0 : 8,
            display: 'flex',
            gap: '8px',
            alignItems: 'center',
            minHeight: getHeightBySize(size),
            cursor: 'text',
            padding: '2px 8px',
            width: '100%',
            '& *': {
              cursor: 'pointer',
            },
          }),
          menu: (base) => ({
            ...base,
            borderRadius: '8px',
            marginTop: 0,
            marginBottom: 0,
            cursor: 'pointer',
            zIndex: 99,
          }),
          multiValue: (base) => ({
            ...base,
            backgroundColor: 'rgb(var(--color-gray-100))',
            margin: 0,
            borderRadius: '6px',
            padding: '2px 7px',
            fontSize: '13px',
            color: 'rgb(var(--color-gray-900))',
            fontWeight: '500',
            display: 'flex',
            alignItems: 'center',
            maxWidth: '110px',
            '&:hover': {
              opacity: 0.8,
            },
            cursor: 'pointer',
          }),
          multiValueRemove: (base) => ({
            ...base,
            borderRadius: '0 6px 6px 0',
            paddingLeft: 6,
            paddingRight: 6,
            '&:hover': {
              backgroundColor: 'transparent',
              color: 'rgb(var(--color-gray-600))',
            },
            '& > svg': {
              height: 14,
              width: 14,
              fill: 'rgb(var(--color-red-600))',
            },
            cursor: 'pointer',
          }),
          control: (base, state) => ({
            ...base,
            minHeight: getHeightBySize(size),
            backgroundColor,
            borderRadius: '6px',
            borderColor: state.isFocused
              ? 'rgb(var(--color-gray-300))'
              : 'rgb(var(--color-gray-300))',
            boxShadow: state.isFocused ? 'none' : 'none',
            '&:hover': {
              borderColor: 'rgb(var(--color-gray-300))',
            },
            cursor: 'pointer',
            '& *': {
              cursor: 'pointer',
            },
          }),
          dropdownIndicator: (base) => ({
            ...base,
            cursor: 'pointer',
            padding: '0 8px',
            '& > svg': {
              height: 14,
              width: 14,
              fill: 'rgb(var(--color-gray-600))',
            },
          }),
          input: (base) => ({
            ...base,
            margin: 0,
            padding: 0,
            cursor: 'text',
            fontSize: '13px',
          }),
          singleValue: (base) => ({
            ...base,
            cursor: 'pointer',
          }),
          placeholder: (base) => ({
            ...base,
            marginLeft: icon ? '16px' : '0',
            fontSize: '14px',
            fontWeight: '400',
            position: 'absolute',
            color: 'rgb(var(--color-gray-600))',
            left: icon ? `${iconSize + 16}px` : '8px', // Account for iconSize + padding
            margin: 0,
          }),
        }}
      />
    </div>
  );
};

export default MultiSelect;
