'use client';
import * as React from 'react';
import * as CheckboxPrimitive from '@radix-ui/react-checkbox';
import Icon from '@components/coreUI/icon';

/**
 * CheckboxProps interface.
 *
 * @interface CheckboxProps
 * @extends {React.ComponentPropsWithoutRef<typeof CheckboxPrimitive.Root>}
 * @property {boolean} [disabled] - Whether the checkbox is disabled
 * @property {'sm' | 'md' | 'lg'} [size='sm'] - Size of the checkbox
 * @property {string} [id] - ID for the checkbox
 * @property {string} [name] - Name for the checkbox
 * @property {boolean} [checked] - Whether the checkbox is checked
 * @property {string} [label] - Label for the checkbox
 * @property {(checked: boolean) => void} [onChange] - Change event handler
 */
interface CheckboxProps
  extends React.ComponentPropsWithoutRef<typeof CheckboxPrimitive.Root> {
  disabled?: boolean;
  size?: 'sm' | 'md' | 'lg';
  id?: string;
  name?: string;
  checked?: boolean;
  label?: string;
  // eslint-disable-next-line no-unused-vars
  onchange?: (checked: boolean) => void;
  className?: string;
}

/**
 * Checkbox component.
 *
 * @param {CheckboxProps} props - Properties passed to the Checkbox component
 * @param {React.Ref<HTMLButtonElement>} ref - Forwarded ref to the checkbox element
 * @returns {React.ReactElement} Checkbox component
 */
const Checkbox = React.forwardRef<HTMLButtonElement, CheckboxProps>(
  (
    {
      className = '',
      disabled = false,
      size = 'md',
      id = '',
      name = '',
      checked = false,
      label = '',
      onchange = () => {},
      ...props
    },
    ref
  ) => {
    // Define CSS classes for different checkbox sizes
    const sizeClasses = {
      sm: 'h-4 w-4',
      md: 'h-5 w-5',
      lg: 'h-6 w-6',
    };

    // Define the CSS classes for the root element
    const rootClasses = `peer ${sizeClasses[size]} shrink-0 rounded-sm border text-black border-gray-300 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-primary-800 disabled:cursor-not-allowed disabled:opacity-60 disabled:bg-gray-200 data-[state=checked]:bg-primary-800 data-[state=checked]:border-primary-800 data-[state=checked]:text-white ${className}`;
    const indicatorClasses = 'flex items-center justify-center text-current';

    return (
      <div className="flex items-center">
        <CheckboxPrimitive.Root
          ref={ref}
          className={rootClasses}
          disabled={disabled}
          id={id}
          name={name}
          checked={checked}
          onCheckedChange={onchange}
          {...props}
        >
          <CheckboxPrimitive.Indicator className={indicatorClasses}>
            <Icon
              iconName="check"
              iconProps={{ className: `!w-4 !h-4 ${sizeClasses[size]}` }}
            />
          </CheckboxPrimitive.Indicator>
        </CheckboxPrimitive.Root>
        {label ? (
          <label
            htmlFor={id}
            className={`ml-2 text-sm font-normal ${disabled ? 'cursor-not-allowed opacity-50' : 'cursor-pointer'}`}
          >
            {label}
          </label>
        ) : null}
      </div>
    );
  }
);

Checkbox.displayName = CheckboxPrimitive.Root.displayName;

export { Checkbox };
