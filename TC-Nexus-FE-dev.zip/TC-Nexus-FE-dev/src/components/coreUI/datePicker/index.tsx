'use client';

import React from 'react';
import DatePicker from 'react-datepicker';
import { TextInput } from '@/components/coreUI/textInput';
import 'react-datepicker/dist/react-datepicker.css';

interface CustomInputProps {
  value?: string;
  onClick?: () => void;
  // eslint-disable-next-line no-unused-vars
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  error?: string;
  touched?: boolean;
  label?: string;
  placeholder?: string;
}

const CustomInput = React.forwardRef<HTMLInputElement, CustomInputProps>(
  ({ value, onClick, onChange, error, touched, label, placeholder }, ref) => (
    <TextInput
      size="sm"
      className="!bg-gray-50"
      label={label}
      name="date"
      maxLength={100}
      placeholder={placeholder}
      readOnly
      error={touched && error ? error : ''}
      value={value || ''}
      onClick={onClick}
      onChange={onChange}
      ref={ref}
    />
  )
);
CustomInput.displayName = 'CustomInput';

interface DatePickerProps {
  selected: Date | null;
  // eslint-disable-next-line no-unused-vars
  onChange: (date: Date | null) => void;
  label?: string;
  placeholder?: string;
  error?: string;
  touched?: boolean;
  minDate?: Date;
  maxDate?: Date;
  disabled?: boolean;
  isClearable?: boolean;
  dateFormat?: string;
  showTimeSelect?: boolean;
  className?: string;
}

const CustomDatePicker: React.FC<DatePickerProps> = ({
  selected,
  onChange,
  label = 'Date',
  placeholder = 'MM/DD/YYYY',
  error,
  touched,
  minDate,
  maxDate,
  disabled = false,
  isClearable = false,
  dateFormat = 'yyyy-MM-dd',
  showTimeSelect = false,
  className = '',
}) => {
  return (
    <div className={className}>
      <DatePicker
        selected={selected}
        onChange={(date: Date | null) => {
          if (date === null && isClearable) {
            onChange(null);
          } else {
            onChange(date);
          }
        }}
        dateFormat={dateFormat}
        placeholderText={placeholder}
        customInput={
          <CustomInput
            label={label}
            placeholder={placeholder}
            error={error}
            touched={touched}
          />
        }
        minDate={minDate}
        maxDate={maxDate}
        disabled={disabled}
        isClearable={isClearable}
        showTimeSelect={showTimeSelect}
        showPopperArrow={false}
        className="w-full"
        wrapperClassName="w-full"
        calendarClassName="shadow-lg border border-gray-200 rounded-lg"
      />
    </div>
  );
};

export default CustomDatePicker;
