import React from 'react';
import { Button } from '../button';
import Icon from '@components/coreUI/icon';

/**
 * Renders a pagination component for tables.
 *
 * @param {number} page The current page number.
 * @param {number} totalItems The total number of items in the table.
 * @param {number} pageSize The number of items per page.
 * @param {(page: number) => void} onPageChange A callback function that is called when the page number changes.
 * @returns {JSX.Element} A pagination component.
 */
export function Pagination({
  page: _page,
  totalItems,
  pageSize,
  onPageChange,
}: {
  /* eslint-disable no-unused-vars */
  page: number;
  totalItems: number;
  pageSize: number;
  onPageChange: (page: number) => void;
}) {
  const totalPages = Math.ceil(totalItems / pageSize);

  /**
   * Generates an array of page numbers with dots indicating gaps.
   *
   * @param {number} currentPage The current page number.
   * @param {number} totalPages The total number of pages.
   * @returns {Array<number | string>} An array of page numbers and dots.
   */
  function generatePaginationRange(currentPage: number, totalPages: number) {
    // For 5 or fewer pages, show all numbers
    if (totalPages <= 5) {
      return Array.from({ length: totalPages }, (_, i) => i + 1);
    }

    // Always include first and last page
    // Include current page and one neighbor on each side
    const pages = new Set([
      1, // First page
      totalPages, // Last page
      currentPage, // Current page
      currentPage - 1, // Previous page
      currentPage + 1, // Next page
    ]);

    // Remove invalid page numbers
    const result = Array.from(pages)
      .filter((page) => page > 0 && page <= totalPages)
      .sort((a, b) => a - b);

    // Add dots where there are gaps
    const withDots = [];
    for (let i = 0; i < result.length; i++) {
      withDots.push(result[i]);
      if (i < result.length - 1 && result[i + 1] - result[i] > 1) {
        withDots.push('...');
      }
    }

    return withDots;
  }

  return (
    <div className="flex items-center justify-between p-6">
      <div className="text-sm text-black font-medium">
        Showing {(_page - 1) * pageSize + 1}-
        {Math.min(_page * pageSize, totalItems)} from {totalItems}
      </div>
      <div className="flex items-center gap-2">
        <Button
          variant="outlineLight"
          onClick={() => onPageChange(_page - 1)}
          disabled={_page === 1}
          iconOnly
          icon={
            <Icon
              iconName="chevronLeft"
              iconProps={{ className: '!w-5 !h-5 text-gray' }}
            />
          }
        />
        {generatePaginationRange(_page, totalPages).map((pageNum, idx) => (
          <React.Fragment key={idx}>
            {pageNum === '...' ? (
              <span className="px-2 text-gray">...</span>
            ) : (
              <Button
                variant={_page === pageNum ? 'secondary' : 'outlineLight'}
                onClick={() => onPageChange(pageNum as number)}
                className={`h-8 w-8`}
              >
                {pageNum}
              </Button>
            )}
          </React.Fragment>
        ))}
        <Button
          variant="outlineLight"
          onClick={() => onPageChange(_page + 1)}
          disabled={_page === totalPages}
          iconOnly
          icon={
            <Icon
              iconName="chevronLeft"
              iconProps={{ className: '!w-5 !h-5 text-gray rotate-180' }}
            />
          }
        />
      </div>
    </div>
  );
}
