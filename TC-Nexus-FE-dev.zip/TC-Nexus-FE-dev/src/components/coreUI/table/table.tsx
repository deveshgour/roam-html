import * as React from 'react';
import { cn } from '@/lib/utils';

// Define theme-based classes
const tableThemes = {
  default: {
    table: 'w-full caption-bottom text-sm',
    thead: '[&_tr]:border-b border-gray-200 bg-gray-100',
    tbody: '[&_tr:last-child]:border-0',
    tfoot: 'border-t bg-muted/50 font-medium [&>tr]:last:border-b-0',
    tr: 'border-b border-gray-200 transition-colors hover:bg-gray-100/50 data-[state=selected]:bg-muted',
    th: 'h-12 px-4 text-left align-middle font-medium text-muted-foreground text-black uppercase text-xs',
    td: 'px-4 py-3 text-sm text-black font-normal align-middle',
    caption: 'mt-4 text-sm text-muted-foreground',
  },
  striped: {
    table: 'w-full caption-bottom text-sm',
    thead: '[&_tr]:border-b border-gray-100 text-gray-800',
    tbody: '[&_tr:last-child]:border-0 bg-gray-200',
    tfoot: 'bg-gray-100 font-semibold text-gray bg-gray-100',
    tr: 'even:bg-gray-50 bg-white transition-colors data-[state=selected]:bg-gray-500',
    th: 'h-12 px-4 first:pl-6 last:pr-6 text-left align-middle font-medium text-gray capitalize text-xs',
    td: 'px-4 py-4 first:pl-6 last:pr-6 text-xs text-gray-800 font-normal align-middle text-left',
    caption: 'mt-4 text-sm text-gray-600',
  },
};

// Create a context to store the theme
const TableThemeContext = React.createContext<
  typeof tableThemes.default | null
>(null);

// Table Component
const Table = React.forwardRef<
  HTMLTableElement,
  React.HTMLAttributes<HTMLTableElement> & { theme?: keyof typeof tableThemes }
>(({ className, theme = 'default', ...props }, ref) => {
  const selectedTheme = tableThemes[theme] || tableThemes.default;

  return (
    <TableThemeContext.Provider value={selectedTheme}>
      <div className="relative w-full h-full">
        <table
          ref={ref}
          className={cn(selectedTheme.table, className)}
          {...props}
        />
      </div>
    </TableThemeContext.Provider>
  );
});
Table.displayName = 'Table';

// Sub-components using the theme from context
const useTableTheme = () => {
  const theme = React.useContext(TableThemeContext);
  if (!theme) throw new Error('Table components must be used inside <Table>.');
  return theme;
};

// Table Header
const TableHeader = React.forwardRef<
  HTMLTableSectionElement,
  React.HTMLAttributes<HTMLTableSectionElement> & {
    theme?: keyof typeof tableThemes;
  }
>(({ className, ...props }, ref) => {
  const theme = useTableTheme();
  return <thead ref={ref} className={cn(theme.thead, className)} {...props} />;
});
TableHeader.displayName = 'TableHeader';

// Table Body
const TableBody = React.forwardRef<
  HTMLTableSectionElement,
  React.HTMLAttributes<HTMLTableSectionElement> & {
    theme?: keyof typeof tableThemes;
  }
>(({ className, ...props }, ref) => {
  const theme = useTableTheme();
  return <tbody ref={ref} className={cn(theme.tbody, className)} {...props} />;
});
TableBody.displayName = 'TableBody';

// Table Footer
const TableFooter = React.forwardRef<
  HTMLTableSectionElement,
  React.HTMLAttributes<HTMLTableSectionElement> & {
    theme?: keyof typeof tableThemes;
  }
>(({ className, ...props }, ref) => {
  const theme = useTableTheme();
  return <tfoot ref={ref} className={cn(theme.tfoot, className)} {...props} />;
});
TableFooter.displayName = 'TableFooter';

// Table Row
const TableRow = React.forwardRef<
  HTMLTableRowElement,
  React.HTMLAttributes<HTMLTableRowElement> & {
    theme?: keyof typeof tableThemes;
  }
>(({ className, ...props }, ref) => {
  const theme = useTableTheme();
  return <tr ref={ref} className={cn(theme.tr, className)} {...props} />;
});
TableRow.displayName = 'TableRow';

// Table Head Cell
const TableHead = React.forwardRef<
  HTMLTableCellElement,
  React.ThHTMLAttributes<HTMLTableCellElement> & {
    className?: string;
    theme?: keyof typeof tableThemes;
  }
>(({ className, ...props }, ref) => {
  const theme = useTableTheme();
  return <th ref={ref} className={cn(theme.th, className)} {...props} />;
});
TableHead.displayName = 'TableHead';

// Table Cell
const TableCell = React.forwardRef<
  HTMLTableCellElement,
  React.TdHTMLAttributes<HTMLTableCellElement> & {
    className?: string;
    theme?: keyof typeof tableThemes;
  }
>(({ className, ...props }, ref) => {
  const theme = useTableTheme();
  return <td ref={ref} className={cn(theme.td, className)} {...props} />;
});
TableCell.displayName = 'TableCell';

// Table Caption
const TableCaption = React.forwardRef<
  HTMLTableCaptionElement,
  React.HTMLAttributes<HTMLTableCaptionElement> & {
    theme?: keyof typeof tableThemes;
  }
>(({ className, ...props }, ref) => {
  const theme = useTableTheme();
  return (
    <caption ref={ref} className={cn(theme.caption, className)} {...props} />
  );
});
TableCaption.displayName = 'TableCaption';

export {
  Table,
  TableHeader,
  TableBody,
  TableFooter,
  TableHead,
  TableRow,
  TableCell,
  TableCaption,
};
