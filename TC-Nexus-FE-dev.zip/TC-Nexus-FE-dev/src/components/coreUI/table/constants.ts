const SORTING_TYPES = {
  ASC: 'asc',
  DESC: 'desc',
  NONE: 'none',
};

export { SORTING_TYPES };
