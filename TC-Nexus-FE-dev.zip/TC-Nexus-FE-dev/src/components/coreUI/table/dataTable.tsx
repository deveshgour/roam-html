/* eslint-disable no-unused-vars */
import React, { useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/coreUI/table/table';

import { TextInput } from '@/components/coreUI/textInput';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/coreUI/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/coreUI/popover';
import { Button } from '@/components/coreUI/button';
import { Checkbox } from '@/components/coreUI/checkbox';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/coreUI/scrollBar';
import { SORTING_TYPES } from './constants';
import Icon from '@components/coreUI/icon';
import NoDataFound from '@/components/noDataFound';

interface ColumnDef {
  header: string;
  accessorKey: string;
  cell?: (row: any) => React.ReactNode;
  sortable?: boolean;
}

interface DataTableProps<T> {
  data: T[];
  columns: ColumnDef[];
  loading?: boolean;
  showSkeleton?: boolean;
  // Pagination props
  page: number;
  pageSize: number;
  totalItems: number;
  pageSizeOptions?: number[];
  onPageChange: (page: number) => void;
  onPageSizeChange?: (pageSize: number) => void;
  onSearch?: (query: string) => void;
  onRowClick?: (row: T) => void;
  // Display options
  showSearch?: boolean;
  showPagination?: boolean;
  scrollAreaClassName?: string;
  showPageSize?: boolean;
  selectedRows?: string[];
  onRowSelect?: (id: string, selected: boolean) => void;
  onSelectAll?: (selected: boolean, ids: string[]) => void;
  actions?: {
    label: string | ((row: T) => string);
    onClick?: (row: T) => void;
    href?: string | ((row: T) => string);
    icon?: React.ReactNode;
  }[];
  actionTrigger?: React.ReactNode;
  getRowId: (row: T) => string;
  headerActions?: React.ReactNode;
  filters?: React.ReactNode;
  showFilters?: boolean;
  sorting?: {
    field: string;
    direction: 'asc' | 'desc' | null;
  };
  onSortingChange?: (field: string, direction: 'asc' | 'desc' | null) => void;
}

const DOTS = '...';
function generatePaginationRange(currentPage: number, totalPages: number) {
  // For 5 or fewer pages, show all numbers
  if (totalPages <= 5) {
    return Array.from({ length: totalPages }, (_, i) => i + 1);
  }

  // Always include first and last page
  // Include current page and one neighbor on each side
  const pages = new Set([
    1, // First page
    totalPages, // Last page
    currentPage, // Current page
    currentPage - 1, // Previous page
    currentPage + 1, // Next page
  ]);

  // Remove invalid page numbers
  const result = Array.from(pages)
    .filter((page) => page > 0 && page <= totalPages)
    .sort((a, b) => a - b);

  // Add dots where there are gaps
  const withDots = [];
  for (let i = 0; i < result.length; i++) {
    withDots.push(result[i]);
    if (i < result.length - 1 && result[i + 1] - result[i] > 1) {
      withDots.push(DOTS);
    }
  }

  return withDots;
}

export function DataTable<T>({
  data,
  columns,
  loading = false,
  showSkeleton = true,
  page,
  pageSize,
  totalItems,
  pageSizeOptions = [5, 10, 25, 50, 100],
  onPageChange,
  onPageSizeChange,
  onSearch,
  onRowClick,
  showSearch = true,
  scrollAreaClassName = '',
  showPagination = true,
  showPageSize = true,
  selectedRows = [],
  onRowSelect,
  onSelectAll,
  actions = [],
  actionTrigger,
  getRowId,
  headerActions,
  filters,
  showFilters = false,
  sorting,
  onSortingChange,
}: DataTableProps<T>) {
  const totalPages = Math.ceil(totalItems / pageSize);
  const [searchValue, setSearchValue] = useState('');

  const handleSort = (column: ColumnDef) => {
    if (!column.sortable || !onSortingChange) return;

    const isCurrentColumn = sorting?.field === column.accessorKey;
    let newDirection:
      | typeof SORTING_TYPES.ASC
      | typeof SORTING_TYPES.DESC
      | null = SORTING_TYPES.ASC;

    if (isCurrentColumn && sorting.direction === SORTING_TYPES.ASC) {
      newDirection = SORTING_TYPES.DESC;
    }

    onSortingChange(column.accessorKey, newDirection as 'asc' | 'desc');
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e?.target?.value;
    setSearchValue(value);
    onSearch?.(value); // Call the onSearch callback if provided
  };

  const handleClearSearch = () => {
    setSearchValue(''); // Clear the search value
    onSearch?.(''); // Trigger the onSearch callback with an empty value
  };

  return (
    <div className="space-y-5 flex flex-col h-full">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4 w-full max-w-sm">
          {showSearch && (
            <TextInput
              placeholder="Search"
              onChange={handleSearchChange}
              value={searchValue}
              className="pl-10"
              startAdornment={
                <div className="absolute left-4 top-1/2 transform -translate-y-1/2">
                  <Icon
                    iconName="search"
                    iconProps={{ className: `h-4 w-4 text-gray-500` }}
                  />
                </div>
              }
              endAdornment={
                searchValue && ( // Only show the close button if there's text in the input
                  <div
                    className="absolute right-4 top-1/2 transform -translate-y-1/2 cursor-pointer "
                    onClick={handleClearSearch}
                  >
                    <Icon
                      iconName="cross"
                      iconProps={{
                        className: `h-4 w-4 text-red-600 hover:text-red-500`,
                      }}
                    />
                  </div>
                )
              }
            />
          )}
        </div>
        <div className="flex items-center gap-3">
          {showPageSize && (
            <Select
              value={String(pageSize)}
              onValueChange={(value) => {
                onPageSizeChange?.(Number(value));
                onPageChange(1);
              }}
            >
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Rows per page" />
              </SelectTrigger>
              <SelectContent>
                {pageSizeOptions.map((size) => (
                  <SelectItem key={size} value={String(size)}>
                    {size} rows
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          {showFilters && (
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outlineLight" className="gap-2">
                  <Icon
                    iconName="list"
                    iconProps={{ className: 'w-4 h-4 text-gray-600' }}
                  />
                  Filters
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-96" align="end">
                <div className="">{filters}</div>
              </PopoverContent>
            </Popover>
          )}
          {headerActions}
        </div>
      </div>

      <div className="border border-gray-200 flex-1 flex flex-col">
        <ScrollArea className={`${scrollAreaClassName} overflow-auto`}>
          <Table theme="default">
            <TableHeader className="sticky top-0 z-10">
              <TableRow>
                {onRowSelect && (
                  <TableCell className="w-[50px]">
                    <Checkbox
                      size="sm"
                      checked={
                        data.length > 0 && selectedRows.length === data.length
                      }
                      onCheckedChange={(checked) =>
                        onSelectAll?.(
                          !!checked,
                          checked ? data.map(getRowId) : []
                        )
                      }
                      onClick={(e) => e.stopPropagation()}
                    />
                  </TableCell>
                )}
                {columns.map((column) => (
                  <TableHead
                    key={column.accessorKey}
                    className={
                      column.sortable
                        ? 'cursor-pointer select-none whitespace-nowrap'
                        : 'whitespace-nowrap'
                    }
                    onClick={() => column.sortable && handleSort(column)}
                  >
                    <div className="flex items-center gap-2">
                      {column.header}
                      {column.sortable && (
                        <div className="flex flex-col">
                          <Icon
                            iconName="arrowUp"
                            iconProps={{
                              className: `h-3 w-3 transition-colors rotate-180 ${
                                sorting?.field === column.accessorKey &&
                                sorting.direction === SORTING_TYPES.ASC
                                  ? 'text-foreground'
                                  : 'text-muted-foreground/30'
                              }`,
                            }}
                          />
                          <Icon
                            iconName="arrowUp"
                            iconProps={{
                              className: `h-3 w-3 transition-colors ${
                                sorting?.field === column.accessorKey &&
                                sorting.direction === SORTING_TYPES.DESC
                                  ? 'text-foreground'
                                  : 'text-muted-foreground/30'
                              }`,
                            }}
                          />
                        </div>
                      )}
                    </div>
                  </TableHead>
                ))}
                {actions.length > 0 && (
                  <TableHead className="w-[70px]">Actions</TableHead>
                )}
              </TableRow>
            </TableHeader>
            <TableBody>
              {(() => {
                if (loading && showSkeleton) {
                  return Array.from({ length: pageSize }).map((_, rowIndex) => (
                    <TableRow key={`skeleton-${rowIndex}`}>
                      {onRowSelect && (
                        <TableCell className="w-[50px]">
                          <div className="h-4 w-4 rounded bg-gray-200 animate-pulse" />
                        </TableCell>
                      )}
                      {columns.map((column, colIndex) => (
                        <TableCell key={`skeleton-${rowIndex}-${colIndex}`}>
                          <div className="h-4 w-full max-w-[200px] rounded bg-gray-200 animate-pulse" />
                        </TableCell>
                      ))}
                      {actions.length > 0 && (
                        <TableCell className="w-[70px]">
                          <div className="h-6 w-6 rounded bg-gray-200 animate-pulse mx-auto" />
                        </TableCell>
                      )}
                    </TableRow>
                  ));
                }
                if (data?.length === 0) {
                  return (
                    <TableRow>
                      <TableCell
                        colSpan={
                          columns.length +
                          (onRowSelect ? 1 : 0) +
                          (actions.length > 0 ? 1 : 0)
                        }
                        className="h-[400px] text-center"
                      >
                        <div className="flex flex-col items-center justify-center text-gray-500">
                          <NoDataFound
                            icon="noTable"
                            title="No Record Found"
                            description="There is no record to show you right now"
                          />
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                }
                return data.map((row: any, rowIndex) => (
                  <TableRow
                    key={rowIndex}
                    onClick={() => onRowClick?.(row)}
                    className={onRowClick ? 'cursor-pointer' : ''}
                  >
                    {onRowSelect && (
                      <TableCell className="w-[50px]">
                        <Checkbox
                          checked={selectedRows.includes(getRowId(row))}
                          size="sm"
                          onCheckedChange={(checked) =>
                            onRowSelect(getRowId(row), !!checked)
                          }
                          onClick={(e) => e.stopPropagation()}
                        />
                      </TableCell>
                    )}
                    {columns.map((column) => (
                      <TableCell key={column.accessorKey}>
                        {column.cell
                          ? column.cell(row)
                          : row[column.accessorKey]}
                      </TableCell>
                    ))}
                    {actions.length > 0 && (
                      <TableCell className="w-[70px] text-center">
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={(e) => e.stopPropagation()}
                            >
                              {actionTrigger || (
                                <Icon
                                  iconName="roundEllipsis"
                                  iconProps={{
                                    className: '!w-8 !h-8 text-gray',
                                  }}
                                />
                              )}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-[200px] p-0" align="end">
                            <div className="flex flex-col py-1">
                              {actions.map((action, index) => (
                                <Button
                                  key={index}
                                  variant="ghost"
                                  className="!justify-start rounded-none px-4 py-2 font-normal hover:bg-gray-100"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    action.onClick?.(row);
                                  }}
                                >
                                  {typeof action.label === 'function'
                                    ? action.label(row)
                                    : action.label}
                                </Button>
                              ))}
                            </div>
                          </PopoverContent>
                        </Popover>
                      </TableCell>
                    )}
                  </TableRow>
                ));
              })()}
            </TableBody>
          </Table>
        </ScrollArea>

        {showPagination && data.length > 0 && !loading && (
          <div className="flex items-center justify-between px-6 py-4 bg-gray-100">
            <div className="text-sm text-black font-medium">
              Showing {(page - 1) * pageSize + 1}-
              {Math.min(page * pageSize, totalItems)} from {totalItems}
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outlineLight"
                onClick={() => onPageChange(page - 1)}
                disabled={page === 1}
                iconOnly
                icon={
                  <Icon
                    iconName="chevronLeft"
                    iconProps={{ className: '!w-5 !h-5 text-gray' }}
                  />
                }
              />
              {generatePaginationRange(page, totalPages).map((pageNum, idx) => (
                <React.Fragment key={idx}>
                  {pageNum === DOTS ? (
                    <span className="px-2 text-gray-600">...</span>
                  ) : (
                    <Button
                      variant={page === pageNum ? 'secondary' : 'outlineLight'}
                      onClick={() => onPageChange(pageNum as number)}
                      className={cn('h-8 w-8')}
                    >
                      {pageNum}
                    </Button>
                  )}
                </React.Fragment>
              ))}
              <Button
                variant="outlineLight"
                onClick={() => onPageChange(page + 1)}
                disabled={page === totalPages}
                iconOnly
                icon={
                  <Icon
                    iconName="chevronLeft"
                    iconProps={{ className: '!w-5 !h-5 text-gray rotate-180' }}
                  />
                }
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
