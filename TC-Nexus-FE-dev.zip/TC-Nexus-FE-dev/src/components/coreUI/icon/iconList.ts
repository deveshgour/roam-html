import AngleDown from '@/app/assets/svg/angleDown';
import ArrowUp from '@/app/assets/svg/arrowUp';
import Bar from '@/app/assets/svg/bar';
import Bell from '@/app/assets/svg/bell';
import Calendar from '@/app/assets/svg/calendar';
import Check from '@/app/assets/svg/check';
import ChevronLeft from '@/app/assets/svg/chevronLeft';
import ChevronRight from '@/app/assets/svg/chevronRight';
import Coin from '@/app/assets/svg/coin';
import Cross from '@/app/assets/svg/cross';
import DollarSign from '@/app/assets/svg/dollarSign';
import DollarSignOutline from '@/app/assets/svg/dollarSignOutline';
import Role from '@/app/assets/svg/role';
import Email from '@/app/assets/svg/email';
import EmailFilled from '@/app/assets/svg/emailFilled';
import Export from '@/app/assets/svg/export';
import Eye from '@/app/assets/svg/eye';
import EyeOff from '@/app/assets/svg/eyeOff';
import History from '@/app/assets/svg/history';
import List from '@/app/assets/svg/list';
import Loader from '@/app/assets/svg/loader';
import Lock from '@/app/assets/svg/lock';
import LockFilled from '@/app/assets/svg/lockFilled';
import MapPin from '@/app/assets/svg/mapPin';
import Phone from '@/app/assets/svg/phone';
import Plus from '@/app/assets/svg/plus';
import RoundEllipsis from '@/app/assets/svg/roundEllipsis';
import Search from '@/app/assets/svg/search';
import ShoppingCart from '@/app/assets/svg/shoppingCart';
import TrendingDown from '@/app/assets/svg/trendingDown';
import TrendingUp from '@/app/assets/svg/trendingUp';
import User from '@/app/assets/svg/user';
import UserOutline from '@/app/assets/svg/userOutline';
import MapPinFilled from '@/app/assets/svg/mapPinFilled';
import Building from '@/app/assets/svg/building';
import KeyReset from '@/app/assets/svg/keyReset';
import LineChart from '@/app/assets/svg/lineChart';
import CalendarOutline from '@/app/assets/svg/calendarOutline';
import Percentage from '@/app/assets/svg/percentage';
import DataExchange from '@/app/assets/svg/dataExchange';
import Door from '@/app/assets/svg/door';
import Home from '@/app/assets/svg/home';
import Document from '@/app/assets/svg/document';
import WebCam from '@/app/assets/svg/webCam';
import Sign from '@/app/assets/svg/sign';
import Table from '@/app/assets/svg/table';
import Logo from '@/app/assets/svg/logo';
import NoTable from '@/app/assets/svg/noTable';
import NoChart from '@/app/assets/svg/noChart';
import RotateOutline from '@/app/assets/svg/rotateOutline';
import UserGroup from '@/app/assets/svg/userGroup';
import Operations from '@/app/assets/svg/operations';
import GoogleReviews from '@/app/assets/svg/googleReviews';
import Star from '@/app/assets/svg/star';
import Tick from '@/app/assets/svg/tick';
import Bag from '@/app/assets/svg/bag';
import Exchange from '@/app/assets/svg/exchange';
import WealthIcon from '@/app/assets/svg/wealth';
import MoneyIcon from '@/app/assets/svg/money';
import HandMoney from '@/app/assets/svg/handMoney';
import Dashboard from '@/app/assets/svg/dashboard';
import Graph from '@/app/assets/svg/graph';
import Arrow from '@/app/assets/svg/arrowIcon';
import ArrowDown from '@/app/assets/svg/arrowDown';

const iconList = {
  email: Email,
  lock: Lock,
  eyeOff: EyeOff,
  dollarSign: DollarSign,
  eye: Eye,
  calendar: Calendar,
  arrowUp: ArrowUp,
  mapPin: MapPin,
  user: User,
  export: Export,
  arrow: Arrow,
  arrowDown: ArrowDown,
  shoppingCart: ShoppingCart,
  history: History,
  coin: Coin,
  bell: Bell,
  chevronLeft: ChevronLeft,
  graph: Graph,
  chevronRight: ChevronRight,
  dollarSignOutline: DollarSignOutline,
  dashboard: Dashboard,
  role: Role,
  operations: Operations,
  googleReviews: GoogleReviews,
  star: Star,
  tick: Tick,
  userOutline: UserOutline,
  angleDown: AngleDown,
  search: Search,
  plus: Plus,
  phone: Phone,
  check: Check,
  cross: Cross,
  list: List,
  roundEllipsis: RoundEllipsis,
  loader: Loader,
  bar: Bar,
  trendingUp: TrendingUp,
  trendingDown: TrendingDown,
  emailFilled: EmailFilled,
  mapPinFilled: MapPinFilled,
  lockFilled: LockFilled,
  building: Building,
  keyReset: KeyReset,
  lineChart: LineChart,
  calendarOutline: CalendarOutline,
  percentage: Percentage,
  dataExchange: DataExchange,
  door: Door,
  home: Home,
  document: Document,
  webCam: WebCam,
  sign: Sign,
  table: Table,
  logo: Logo,
  noTable: NoTable,
  noChart: NoChart,
  rotateOutline: RotateOutline,
  userGroup: UserGroup,
  bag: Bag,
  exchange: Exchange,
  handMoney: HandMoney,
  money: MoneyIcon,
  wealth: WealthIcon,
};
export { iconList };
