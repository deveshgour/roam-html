import React from 'react';
import { iconList } from './iconList';

/**
 * Icon component
 * Syntax to use this component
 * <Icon
		iconName="Email"
		iconProps={{ width: '200px', height: '200px', className: 'h-6 w-6' }}
	 />
 * @param {String} iconName
 * @param {Object} iconProps
 * @returns Node
 */
const Icon = ({
  iconName = '',
  iconProps = {},
}: {
  iconName: string;
  iconProps?: object;
}) => {
  const Component = iconList[iconName as keyof typeof iconList];

  return (
    <span>{iconName && Component ? <Component {...iconProps} /> : null}</span>
  );
};

export default Icon;
