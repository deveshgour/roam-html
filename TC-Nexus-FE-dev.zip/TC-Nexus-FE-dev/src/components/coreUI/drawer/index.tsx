import React from 'react';
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from '@components/coreUI/drawer/drawer';
import { Button } from '../button';
import Icon from '@components/coreUI/icon';

/**
 * Interface for SidePanel component props.
 */
interface SidePanelProps {
  open: boolean;
  onClose: () => void;
  title?: React.ReactNode;
  description?: string;
  header?: React.ReactNode;
  children?: React.ReactNode;
  footer?: React.ReactNode;
  rightActions?: React.ReactNode;
  maxWidth?: 'sm' | 'md' | 'lg' | 'xl' | '2xl' | string;
  showCloseButton?: boolean;
  primaryButton?: {
    text: string;
    onClick: () => void;
    loading?: boolean;
    disabled?: boolean;
  };
  secondaryButton?: {
    text: string;
    onClick: () => void;
    loading?: boolean;
    disabled?: boolean;
  };
}

/**
 * SidePanel component renders a customizable drawer with header, footer, and action buttons.
 */
const SidePanel: React.FC<SidePanelProps> = ({
  open,
  onClose,
  title,
  description,
  header,
  children,
  footer,
  rightActions,
  maxWidth = 'md',
  showCloseButton = true,
  primaryButton,
  secondaryButton,
}) => {
  // Define max width classes for different size options
  const maxWidthClasses = {
    sm: 'max-w-sm',
    md: 'max-w-md',
    lg: 'max-w-lg',
    xl: 'max-w-xl',
    xxl: 'max-w-2xl',
  };

  // Determine the width class based on maxWidth prop
  const widthClass =
    maxWidthClasses[maxWidth as keyof typeof maxWidthClasses] || maxWidth;

  // Render the SidePanel with the Drawer components
  return (
    <Drawer open={open} onOpenChange={onClose} direction="right">
      <DrawerContent className={`${widthClass} w-full`}>
        {/* Render header with title, right actions, and close button */}
        {header ? (
          <DrawerHeader>
            <DrawerTitle>{title}</DrawerTitle>
            <div className="flex items-center gap-x-3">
              {rightActions ? (
                <div className="hover:opacity-80 cursor-pointer">
                  {rightActions}
                </div>
              ) : null}
              {showCloseButton ? (
                <DrawerClose className="p-2.5 bg-red-100/50 rounded-full hover:bg-red-100">
                  <Icon
                    iconName="cross"
                    iconProps={{ className: `w-4 h-4 text-red-600` }}
                  />
                </DrawerClose>
              ) : null}
            </div>
            {description ? (
              <DrawerDescription>{description}</DrawerDescription>
            ) : null}
          </DrawerHeader>
        ) : null}

        {/* Render children content */}
        <div className="">{children}</div>

        {/* Render footer with buttons or custom footer content */}
        {(footer || primaryButton || secondaryButton) && (
          <DrawerFooter className="flex justify-end gap-2 border-t border-gray-100 p-6 m-0">
            {footer || (
              <>
                {secondaryButton && (
                  <Button
                    size="sm"
                    variant="outlineLight"
                    onClick={secondaryButton.onClick}
                    disabled={secondaryButton.disabled}
                  >
                    {secondaryButton.text}
                  </Button>
                )}
                {primaryButton && (
                  <Button
                    size="sm"
                    onClick={primaryButton.onClick}
                    disabled={primaryButton.disabled}
                    loading={primaryButton.loading}
                  >
                    {primaryButton.text}
                  </Button>
                )}
              </>
            )}
          </DrawerFooter>
        )}
      </DrawerContent>
    </Drawer>
  );
};

export default SidePanel;
