import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/coreUI/dialog/dialog';
import { Button } from '@/components/coreUI/button';
import Icon from '../icon';
import { ScrollArea } from '../scrollBar';

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  description?: string;
  header?: React.ReactNode;
  children?: React.ReactNode;
  footer?: React.ReactNode;
  maxWidth?: 'sm' | 'md' | 'lg' | 'xl' | '2xl' | string;
  showCloseButton?: boolean;
  primaryButton?: {
    text: string;
    onClick: () => void;
    loading?: boolean;
    disabled?: boolean;
  };
  secondaryButton?: {
    text: string;
    onClick: () => void;
    loading?: boolean;
    disabled?: boolean;
  };
  isScrollable?: boolean;
  hideBorder?: boolean;
}

const Modal: React.FC<ModalProps> = ({
  open,
  onClose,
  title,
  description,
  header,
  children,
  isScrollable = true,
  footer,
  maxWidth = 'md',
  showCloseButton = true,
  primaryButton,
  secondaryButton,
  hideBorder = false,
}) => {
  const maxWidthClasses = {
    sm: 'max-w-sm',
    md: 'max-w-md',
    lg: 'max-w-lg',
    xl: 'max-w-xl',
    '2xl': 'max-w-2xl',
  };

  const widthClass =
    maxWidthClasses[maxWidth as keyof typeof maxWidthClasses] || maxWidth;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent
        className={`${widthClass} w-full p-0`}
        onInteractOutside={(e) => e.preventDefault()}
      >
        {header ? (
          <div
            className={`flex justify-between items-center p-6 ${
              hideBorder ? '' : 'border-b border-gray-100'
            }`}
          >
            <DialogTitle className="sr-only">Dialog</DialogTitle>
            {header}

            {showCloseButton && (
              <Icon
                iconName="cross"
                iconProps={{
                  onClick: onClose,
                  className:
                    'cursor-pointer h-[18px] w-[18px] right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground',
                }}
              />
            )}
          </div>
        ) : (
          <DialogHeader>
            {title ? (
              <DialogTitle
                className={`flex justify-between items-center p-6 ${
                  hideBorder ? '' : 'border-b border-gray-100'
                }`}
              >
                {title}
              </DialogTitle>
            ) : (
              <DialogTitle className="sr-only">Dialog</DialogTitle>
            )}
            {description && (
              <DialogDescription>{description}</DialogDescription>
            )}
          </DialogHeader>
        )}

        {isScrollable ? (
          <ScrollArea className="max-h-[450px]">
            <div className="p-6">{children}</div>
          </ScrollArea>
        ) : (
          <div className="">
            <div className="p-6">{children}</div>
          </div>
        )}

        {(footer || primaryButton || secondaryButton) && (
          <DialogFooter className="flex justify-end gap-2 border-t border-gray-100 p-6">
            {footer || (
              <>
                {secondaryButton && (
                  <Button
                    variant="outlinePrimary"
                    onClick={secondaryButton.onClick}
                    disabled={secondaryButton.disabled}
                  >
                    {secondaryButton.text}
                  </Button>
                )}
                {primaryButton && (
                  <Button
                    onClick={primaryButton.onClick}
                    disabled={primaryButton.disabled}
                    loading={primaryButton.loading}
                  >
                    {primaryButton.text}
                  </Button>
                )}
              </>
            )}
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default Modal;
