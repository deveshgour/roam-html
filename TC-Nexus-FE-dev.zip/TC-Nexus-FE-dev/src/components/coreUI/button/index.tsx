import * as React from 'react';
import Icon from '@components/coreUI/icon';

// Base classes for the button
const buttonBaseClasses =
  'inline-flex items-center justify-center gap-2 whitespace-nowrap transition-colors focus-visible:outline-none focus-visible:ring-1  disabled:cursor-not-allowed disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0';

// Variant classes for the button
const variantClasses = {
  primary:
    'bg-primary-800 text-white shadow hover:brightness-90 focus-visible:ring-primary',
  secondary:
    'bg-primary-200 text-primary-800 hover:brightness-90 focus-visible:ring-primary',
  light:
    'bg-gray-200 text-gray shadow-sm hover:opacity-80 focus-visible:ring-gray-300',
  outlinePrimary:
    'border border-primary-800 text-primary-800 bg-transparent shadow-sm hover:opacity-80 focus-visible:ring-primary-800',
  outlineLight:
    'border border-gray-300 text-gray-600 bg-transparent hover:opacity-80 focus-visible:ring-gray-300',
  link: 'text-primary-800 underline-offset-4 hover:underline focus-visible:ring-transparent !p-0',
  ghost: 'hover:bg-gray-50 hover:opacity-80',
};

// Size classes for the button
const sizeClasses = {
  sm: 'py-2 rounded-lg px-4 text-xs xs:text-sm font-medium',
  md: 'py-3 rounded-lg px-4 text-xs xs:text-sm leading-4 font-medium',
  lg: 'py-4 rounded-xl px-8 text-sm xs:text-base font-bold',
  icon: 'h-9 w-9',
};

// Button component props interface
export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children?: React.ReactNode;
  variant?: keyof typeof variantClasses;
  size?: keyof typeof sizeClasses;
  disabled?: boolean;
  full?: boolean;
  loading?: boolean; // loading state
  loadingText?: string; // loading text
  icon?: React.ReactNode;
  iconOnly?: boolean; // icon only button
}

// Button component
const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      className = '',
      variant = 'primary',
      size = 'md',
      full = false,
      disabled = false,
      loading = false, // default loading state
      loadingText = 'Please wait', // Default loading text
      type = 'button', // Default button type
      icon, // Optional icons
      iconOnly = false,
      children,
      ...props
    },
    ref
  ) => {
    // Determine the size classes based on iconOnly prop
    const buttonSize = iconOnly ? 'w-8 h-8 rounded-lg' : sizeClasses[size];

    // Combine classes for the button element
    const buttonClasses = `${buttonBaseClasses} ${variantClasses[variant]} ${buttonSize} ${className} ${full ? 'w-full' : ''}`;

    return (
      <button
        className={buttonClasses}
        ref={ref}
        {...props}
        type={type}
        disabled={disabled || loading} // Disable button if loading
      >
        {loading ? (
          <span className="flex items-center ">
            <span className="animate-spin mr-2">
              <Icon iconName="loader" iconProps={{ className: `h-4 w-4` }} />
            </span>
            {loadingText}
          </span>
        ) : (
          <>
            {icon ? <span>{icon}</span> : null}
            {!iconOnly && children}
          </>
        )}
      </button>
    );
  }
);
Button.displayName = 'Button';

export { Button };
