import React, { useState } from 'react';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import {
  // Import the components for the select dropdown.
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../coreUI/select';
import NoDataFound from '../noDataFound';
import { TIME_PERIOD_TYPES } from '@/constants/configs';

/**
 * An interface for the options available in the timeframe select dropdown.
 */
interface TimeFrameOption {
  /**
   * The label of the option, which is the text that appears in the dropdown.
   */
  label: string;

  /**
   * The value of the option, which is the value that is passed when the option
   * is selected.
   */
  value: string;
}

/**
 * Props for the LineChart component.
 */
interface LineChartProps {
  /**
   * The title of the chart.
   */
  title: string;

  type?: string;

  /**
   * The series of the chart. Each series is an object with the following properties:
   * - name: The name of the series.
   * - data: The data points of the series. Each data point is an object with the following properties:
   *   - x: The x-coordinate of the data point.
   *   - y: The y-coordinate of the data point.
   */
  series: Highcharts.SeriesOptionsType[];
  /**
   * The categories of the chart. Each category is a string.
   */
  categories: string[];

  chartClassName?: string;

  height?: number;

  labelsFormatter?: () => string;

  secondaryLabelsFormatter?: () => string;
  /**
   * The time frame options of the chart. If not provided, the default time frame options will be used.
   */
  timeFrameOptions?: TimeFrameOption[];
  defaultTimeFrame?: string;
  yAxisMax?: number;
  yAxisTickInterval?: number;
  // eslint-disable-next-line no-unused-vars
  onTimeFrameChange?: (value: string) => void;
  legendAlign?: 'left' | 'center' | 'right';
  isLoading?: boolean;
  itemMarginBottom?: number;
  // eslint-disable-next-line no-unused-vars
  tooltipFormatter?: (this: any) => string;
  // eslint-disable-next-line no-unused-vars
  onClick?: (value: any) => void;

  useDualYAxis?: boolean;
}

const defaultTimeFrameOptions: TimeFrameOption[] = [
  { label: 'Weekly', value: 'weekly' },
  { label: 'Monthly', value: 'monthly' },
  { label: 'Quarterly', value: 'quarterly' },
  { label: 'Yearly', value: 'yearly' },
];

// Define the default tooltip formatter
// eslint-disable-next-line no-unused-vars
const defaultTooltipFormatter = function (this: any) {
  return `
  <div style="padding: 4px; min-width: 180px; background-color: #fff;">  
  <div style="display: flex; justify-content: space-between; font-size: 12px;">
    <span style="color: #6B7280;">Month</span>
    <span style="color: #4B5563;">Jan</span>
  </div>
  
  <div style="display: flex; justify-content: space-between; font-size: 12px; margin-top: 6px;">
    <span style="color: #6B7280;">Total Jobs</span>
    <span style="color: #4B5563;">22</span>
  </div>
  
  <div style="display: flex; justify-content: space-between; font-size: 12px; margin-top: 6px;">
    <span style="color: #6B7280;">Completed Jobs</span>
    <span style="color: #4B5563;">18</span>
  </div>
  
  <div style="display: flex; justify-content: space-between; font-size: 12px; margin-top: 6px;">
    <span style="color: #6B7280;">Completion Rate</span>
    <span style="color: #4B5563;">${this.y ? (this.y / 1000).toFixed(2) : 0}%</span>
  </div>
</div>


    ${
      (this as any).point.growth !== undefined
        ? `
      <span style="display: block; width: 100%; font-size: 12px; margin-top: 6px;">
        <span style="width: 80px; display: inline-block; color: #6B7280;">Growth Rate </span> 
        <span style="color: ${Number((this as any).point.growth) >= 0 ? (Number((this as any).point.growth) === 0 ? '#10B981' : '#10B981') : '#EF4444'}">
          ${Number((this as any).point.growth) > 0 ? '+' : ''}${(this as any).point.growth}%
        </span>
      </span>`
        : ''
    }
  </div>`;
};

const onPointDefaultClick = function (this: any, event: Event) {
  event?.preventDefault();
  event?.stopPropagation();
};

// eslint-disable-next-line no-unused-vars
export const defaultlabelformatter = function (this: any): string {
  return Number(this.value) / 1000 + 'K';
};
// eslint-disable-next-line no-unused-vars
export const defaultPercentageLabelFormatter = function (this: any): string {
  return `${this.value}%`;
};
// eslint-disable-next-line no-unused-vars
export const multipleOfEightLabelFormatter = function (this: any): string {
  const value = Number(this.value);
  return value % 8 === 0 && value <= 32 ? `${value}` : '';
};

const LineChart: React.FC<LineChartProps> = ({
  title,
  series,
  type = 'line',
  categories,
  chartClassName = '',
  timeFrameOptions = defaultTimeFrameOptions,
  defaultTimeFrame = TIME_PERIOD_TYPES.MONTHLY,
  yAxisMax,
  yAxisTickInterval,
  onTimeFrameChange,
  tooltipFormatter = defaultTooltipFormatter,
  legendAlign = 'left',
  isLoading = false,
  itemMarginBottom,
  height = 300,
  useDualYAxis = false,
  labelsFormatter = defaultlabelformatter,
  secondaryLabelsFormatter = defaultlabelformatter,
  onClick = onPointDefaultClick,
}) => {
  const [timeFrame, setTimeFrame] = useState(defaultTimeFrame);

  const handleTimeFrameChange = (value: string) => {
    setTimeFrame(value);
    onTimeFrameChange?.(value);
  };

  if (isLoading) {
    return (
      <div className={`p-6 bg-white rounded-2xl ${chartClassName}`}>
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-sm font-normal text-gray-800">{title}</h3>
          <Select
            disabled={true}
            value={timeFrame}
            onValueChange={handleTimeFrameChange}
          >
            <SelectTrigger className="w-32 !h-9">
              <SelectValue>{timeFrame}</SelectValue>
            </SelectTrigger>
            <SelectContent>
              {timeFrameOptions.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="h-[300px] relative">
          {/* Axis lines */}
          <div
            className="absolute inset-0 border-l border-b border-gray-200"
            style={{ left: '40px', bottom: '40px' }}
          />

          {/* Skeleton Lines */}
          <div
            className="absolute"
            style={{
              left: '40px',
              bottom: '40px',
              height: 'calc(100% - 40px)',
              width: 'calc(100% - 40px)',
            }}
          >
            {/* Multiple skeleton lines with different patterns */}
            <div className="relative h-full">
              {[1, 2, 3].map((index) => (
                <svg
                  key={index}
                  className="w-full h-full absolute top-0 left-0"
                >
                  <path
                    d={`M0,${150 + index * 20} Q100,${100 + index * 15} 200,${120 + index * 25} T400,${90 + index * 10}`}
                    fill="none"
                    stroke="#E5E7EB"
                    strokeWidth="2"
                    className="animate-pulse"
                    style={{ animationDelay: `${index * 0.2}s` }}
                  />
                </svg>
              ))}
            </div>
          </div>

          {/* Y-axis ticks */}
          <div className="absolute left-0 bottom-[40px] h-[calc(100%-40px)] flex flex-col justify-between">
            {[...Array(6)].map((_, i) => (
              <div
                key={i}
                className="h-4 w-8 bg-gray-200 rounded animate-pulse"
              />
            ))}
          </div>

          {/* X-axis ticks */}
          <div
            className="absolute bottom-0 left-[40px] right-0 flex justify-between"
            style={{ width: 'calc(100% - 40px)' }}
          >
            {[...Array(6)].map((_, i) => (
              <div
                key={i}
                className="h-4 w-12 bg-gray-200 rounded animate-pulse"
              />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!series?.length) {
    return (
      <div className="p-6 bg-white rounded-2xl">
        <h3 className="text-sm font-normal text-gray-800">{title}</h3>
        <NoDataFound
          icon="noChart"
          title="No Data"
          description="There is no data to show you right now"
        />
      </div>
    );
  }

  const updatedSeries = series.map((s, index) => ({
    ...(s as Highcharts.SeriesOptionsType),
    yAxis: useDualYAxis && index % 2 !== 0 ? 1 : 0, // Assign alternate series to second y-axis
  }));

  const options: Highcharts.Options = {
    chart: {
      type,
      backgroundColor: 'transparent',
      spacingTop: 0,
      height,
    },
    title: {
      text: '',
    },
    xAxis: {
      categories,
      gridLineWidth: 0,
      lineColor: '#D1D5DB',
      tickLength: 0,
      offset: 0,
      crosshair: false,
      lineWidth: 1,
    },
    yAxis: useDualYAxis
      ? [
          {
            title: {
              text: '',
            },
            labels: {
              formatter: function () {
                return labelsFormatter.call(this);
              },
            },
            lineWidth: 1,
            gridLineWidth: 1,
            gridLineDashStyle: 'Dash',
            lineColor: '#D1D5DB',
            max: yAxisMax,
            tickInterval: yAxisTickInterval,
            offset: 0,
            crosshair: false,
          },
          {
            title: {
              text: '',
            },
            labels: {
              formatter: function () {
                return secondaryLabelsFormatter.call(this);
              },
            },
            lineWidth: 1,
            opposite: true,
            gridLineWidth: 1,
            gridLineDashStyle: 'Dash',
            lineColor: '#D1D5DB',
            max: yAxisMax,
            min: 0,
            tickInterval: yAxisMax !== undefined && yAxisMax > 30 ? 30 : 4,
            crosshair: false,
          },
        ]
      : [
          {
            title: {
              text: '',
            },
            labels: {
              formatter: function () {
                return labelsFormatter.call(this);
              },
            },
            lineWidth: 1,
            gridLineWidth: 1,
            gridLineDashStyle: 'Dash',
            lineColor: '#D1D5DB',
            max: yAxisMax,
            tickInterval: yAxisTickInterval,
            offset: 0,
            crosshair: false,
          },
        ],
    series: updatedSeries as Highcharts.SeriesOptionsType[],
    tooltip: {
      formatter: function () {
        return tooltipFormatter.call(this);
      },
      borderRadius: 12,
      borderColor: '#E9EAEA',
      borderWidth: 1,
      padding: 10,
      backgroundColor: '#fff',
      shadow: false,
      useHTML: true,
    },
    legend: {
      align: legendAlign,
      verticalAlign: 'top',
      layout: 'horizontal',
      itemStyle: {
        fontWeight: 'normal',
        fontSize: '12px',
        color: '#6B7280',
      },
      labelFormatter: function () {
        return ` 
        <div style="display: flex; align-items: center; flex-wrap: wrap; gap: 4px">
          <div style="display: flex; align-items: center; font-size: 12px; color: #6B7280; cursor: pointer">
            <span style="width: 12px; height: 12px; display: inline-block; background-color: ${this.color}; border-radius: 100%; margin-right: 8px;"></span>
            <span>
              ${this.name}
            </span>
          </div>
        </div>
        `;
      },
      enabled: true,
      useHTML: true,
      symbolHeight: 0,
      symbolWidth: 0,
      itemDistance: 3,
      padding: 0,
      margin: 0,
      itemMarginTop: 0,
      itemMarginBottom: itemMarginBottom ?? 20,
      borderWidth: 0,
    },
    plotOptions: {
      series: {
        marker: {
          enabled: series.some((s) => (s as any).data?.length === 1),
          symbol: 'circle',
        },
        lineWidth: 1,
        states: {
          hover: {
            lineWidth: 1,
          },
        },
        events: {
          click: function (event: any) {
            return onClick.call(this, event);
          },
        },
      },
    },
    credits: {
      enabled: false,
    },
  };

  return (
    <div className={`p-6 bg-white rounded-2xl ${chartClassName}`}>
      <div className="flex justify-between items-center mb-5">
        <h3 className="text-sm font-normal text-gray-800">{title}</h3>
        <Select value={timeFrame} onValueChange={handleTimeFrameChange}>
          <SelectTrigger className="w-32 !h-9">
            <SelectValue>{timeFrame}</SelectValue>
          </SelectTrigger>
          <SelectContent>
            {timeFrameOptions.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <HighchartsReact highcharts={Highcharts} options={options} />
    </div>
  );
};

export default LineChart;
