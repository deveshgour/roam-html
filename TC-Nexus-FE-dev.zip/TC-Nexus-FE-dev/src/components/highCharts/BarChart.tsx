import React, { useState } from 'react';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../coreUI/select';
import NoDataFound from '../noDataFound';
import { TIME_PERIOD_OPTIONS, TIME_PERIOD_TYPES } from '@/constants/configs';

/**
 * An interface for the options available in the timeframe select dropdown.
 */
interface TimeFrameOption {
  /**
   * The label to display for the option.
   */
  label: string;
  /**
   * The value of the option.
   */
  value: string;
}

/**
 * The props for the BarChart component.
 */
interface BarChartProps {
  /**
   * The title of the chart.
   */
  title: string;
  showMultiColor?: boolean;
  /**
   * The series of data to display in the chart.
   */
  series: Highcharts.SeriesOptionsType[];
  /**
   * The categories to display on the x-axis.
   */
  categories: string[];
  /**
   * The options available in the timeframe select dropdown.
   * If not provided, this defaults to the following array:
   * [
   *   { label: 'Monthly', value: 'Monthly' },
   *   { label: 'Quarterly', value: 'Quarterly' },
   *   { label: 'Yearly', value: 'Yearly' },
   * ]
   */
  timeFrameOptions?: TimeFrameOption[];
  /**
   * The default selected option in the timeframe select dropdown.
   * If not provided, this defaults to 'Monthly'.
   */
  defaultTimeFrame?: string;
  /**
   * The maximum value of the y-axis.
   * If not provided, this defaults to 1200.
   */
  yAxisMax?: number;

  yAxisMin?: number;
  /**
   * The tick interval of the y-axis.
   * If not provided, this defaults to 200.
   */
  yAxisTickInterval?: number;
  /**
   * A callback function to trigger when the selected timeframe changes.
   */
  // eslint-disable-next-line no-unused-vars
  onTimeFrameChange?: (value: string) => void;
  /**
   * Whether the chart is loading.
   * If not provided, this defaults to false.
   */
  isLoading?: boolean;
  useDualYAxis?: boolean;

  type?: string;

  legend?: boolean;

  showTimeFrameSelect?: boolean;

  // eslint-disable-next-line no-unused-vars
  tooltipFormatter?: (this: void) => string;
  labelsFormatter?: () => string;
  chartClassName?: string;
  itemMarginTop?: number;
  align?: 'left' | 'center' | 'right';
  height?: number;
}

/**
 * The default options for the timeframe select dropdown.
 */
const defaultTimeFrameOptions: TimeFrameOption[] = [
  { label: 'Weekly', value: 'weekly' },
  { label: 'Monthly', value: 'monthly' },
  { label: 'Quarterly', value: 'quarterly' },
  { label: 'Yearly', value: 'yearly' },
];

// shows time period in tooltip
const getFormattedTimeFrame = (timeFrame: string) => {
  switch (timeFrame) {
    case TIME_PERIOD_TYPES.WEEKLY:
      return TIME_PERIOD_OPTIONS.WEEKLY;
    case TIME_PERIOD_TYPES.MONTHLY:
      return TIME_PERIOD_OPTIONS.MONTHLY;
    case TIME_PERIOD_TYPES.QUARTERLY:
      return TIME_PERIOD_OPTIONS.QUARTERLY;
    case TIME_PERIOD_TYPES.YEARLY:
      return TIME_PERIOD_OPTIONS.YEARLY;
    default:
      return TIME_PERIOD_OPTIONS.MONTHLY; // Default to 'Month' if no match is found
  }
};

const defaultTooltipFormatter = function (this: any, timeFrame: string) {
  return `
    <div style="padding: 4px; min-width: 170px;">  
      <span style="display: block; width: 100%; font-size: 12px;">
        <span style="width: 80px; display: inline-block; color: #6B7280;">${getFormattedTimeFrame(timeFrame)} </span> 
        <span style="color: #4B5563;">${this.category}</span>
      </span>
      <span style="display: block; width: 100%; font-size: 12px; margin-top: 6px;">
        <span style="width: 80px; display: inline-block; color: #6B7280;">${this.series.name} </span> 
        <span style="color: #4B5563;">${this.y}K</span>
      </span>
      ${
        (this as any).point.growth !== undefined
          ? `
        <span style="width: 80px; display: inline-block; margin-top: 6px; font-size: 12px; color: #6B7280;">Growth Rate </span> 
        <span style="color: ${Number((this as any).point.growth) >= 0 ? (Number((this as any).point.growth) === 0 ? '#10B981' : '#10B981') : '#EF4444'}">
      ${Number((this as any).point.growth) > 0 ? '+' : ''}${(this as any).point.growth}%
    </span>
      `
          : ''
      }
    </div>`;
};

// eslint-disable-next-line no-unused-vars
const defaultlabelformatter = function (this: any): string {
  return Number(this.value) + 'K';
};
/**
 * The BarChart component.
 */
const BarChart: React.FC<BarChartProps> = ({
  title,
  series,
  showMultiColor = false,
  type = 'column',
  categories,
  timeFrameOptions = defaultTimeFrameOptions,
  defaultTimeFrame = 'monthly',
  showTimeFrameSelect = true,
  yAxisMax,
  yAxisMin,
  yAxisTickInterval = 100,
  onTimeFrameChange,
  tooltipFormatter = defaultTooltipFormatter,
  isLoading = false,
  labelsFormatter = defaultlabelformatter,
  useDualYAxis = false,
  legend = false,
  chartClassName,
  itemMarginTop = -10,
  align = 'left',
  height = 300,
}) => {
  const [timeFrame, setTimeFrame] = useState(defaultTimeFrame);

  const handleTimeFrameChange = (value: string) => {
    setTimeFrame(value);
    if (onTimeFrameChange) {
      onTimeFrameChange(value);
    }
  };

  const updatedSeries = series.map((s, index) => ({
    ...s,
    yAxis: useDualYAxis && index % 2 !== 0 ? 1 : 0,
  })) as Highcharts.SeriesOptionsType[];

  const options: Highcharts.Options = {
    chart: {
      type: type as any,
      backgroundColor: 'transparent',
      height,
      className: 'highcharts-scrolling',
      scrollablePlotArea: {
        minWidth: categories.length * 50,
        scrollPositionX: 0,
      },
      spacingRight: 30,
    },

    title: {
      text: '',
    },
    plotOptions: {
      column: {
        stacking: showMultiColor ? 'normal' : undefined,
        minPointLength: 3,
      },
      series: {
        borderWidth: 0,
        dataLabels: {
          enabled: false,
          inside: false,
          crop: false,
          overflow: 'allow',
        },
      },
    },
    xAxis: {
      categories,
      gridLineWidth: 0,
      lineColor: '#D1D5DB',
      tickLength: 0,
      labels: {
        step: 1,
        formatter: function () {
          const value = String(this.value);
          return value.length > 16 ? value.slice(0, 16) + '...' : value;
        },
      },
      scrollbar: {
        enabled: true,
      },
    },
    yAxis: useDualYAxis
      ? [
          {
            title: { text: '' },
            max: yAxisMax,
            min: 0,
            tickInterval:
              yAxisMax !== undefined && yAxisMax > 1000 ? 1000 : 100,
            startOnTick: true,
            endOnTick: true,
            minPadding: 0,
            lineWidth: 1,
            gridLineWidth: 1,
            gridLineDashStyle: 'Dash',
            lineColor: '#D1D5DB',
            offset: 10, // Add spacing from the chart
            alignTicks: false, // Prevent alignment with left yAxis
            labels: {
              formatter: function () {
                const value = String(this.value);
                return value.length > 16 ? value.slice(0, 16) + '...' : value;
              },
            },
          } as Highcharts.YAxisOptions,
          {
            title: { text: '' },
            opposite: true,
            max: yAxisMax,
            min: 0,
            tickInterval: yAxisMax !== undefined && yAxisMax > 30 ? 30 : 4,
            lineWidth: 1,
            gridLineWidth: 0,
            gridLineDashStyle: 'Dash',
            lineColor: '#D1D5DB',
            offset: 10, // Add spacing from the chart
            alignTicks: true, // Prevent alignment with left yAxis
            labels: {
              formatter: function () {
                const value = String(this.value);
                return value.length > 16 ? value.slice(0, 16) + '...' : value;
              },
            },
          } as Highcharts.YAxisOptions,
        ]
      : [
          {
            title: { text: ' ' },
            max: yAxisMax,
            min: yAxisMin,
            tickInterval: yAxisTickInterval,
            startOnTick: true,
            endOnTick: true,
            lineWidth: 1,
            gridLineWidth: 1,
            gridLineDashStyle: 'Dash',
            lineColor: '#D1D5DB',
            minPadding: 0,
            offset: 10, // Add spacing from the chart
            alignTicks: false, // Prevent alignment with left yAxis
            labels: {
              formatter: function () {
                return labelsFormatter.call(this);
              },
            },
          } as Highcharts.YAxisOptions,
        ],
    series: updatedSeries,
    tooltip: {
      formatter: function () {
        return tooltipFormatter.call(this, timeFrame);
      },
      borderRadius: 12,
      borderColor: '#E9EAEA',
      borderWidth: 1,
      padding: 10,
      backgroundColor: '#fff',
      shadow: false,
      useHTML: true,
    },
    legend: {
      enabled: legend || showMultiColor,
      verticalAlign: 'top',
      itemMarginBottom: 10,
      align: align,
      itemMarginTop: itemMarginTop,
    },
    credits: {
      enabled: false,
    },
  };

  if (isLoading) {
    // Simplified skeleton data with fewer points
    const skeletonData = [0.8, 1.2, 0.9, 1.5, 1.1, 0.7];

    return (
      <div className={`p-6 bg-white rounded-2xl ${chartClassName}`}>
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-sm font-normal text-gray-800">{title}</h3>
          {showTimeFrameSelect ? (
            <Select
              disabled={true}
              value={timeFrame}
              onValueChange={handleTimeFrameChange}
            >
              <SelectTrigger className="w-32 !h-9">
                <SelectValue>{timeFrame}</SelectValue>
              </SelectTrigger>
              <SelectContent>
                {timeFrameOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          ) : null}
        </div>

        <div className="h-[300px] relative">
          {/* Axis lines */}
          <div
            className="absolute inset-0 border-l border-b border-gray-200"
            style={{ left: '40px', bottom: '40px' }}
          />

          {/* Skeleton Bars */}
          <div
            className="absolute inset-0 flex items-end gap-4 px-12"
            style={{
              left: '40px',
              bottom: '40px',
              height: 'calc(100% - 40px)',
            }}
          >
            {skeletonData.map((height, index) => (
              <div
                key={index}
                className="w-32 bg-gray-200 rounded-t animate-pulse"
                style={{ height: `${height * 60}%` }}
              />
            ))}
          </div>
          {/* Y-axis ticks */}
          <div className="absolute left-0 bottom-[40px] h-[calc(100%-40px)] flex flex-col justify-between">
            {[...Array(6)].map((_, i) => (
              <div
                key={i}
                className="h-4 w-8 bg-gray-200 rounded animate-pulse"
              />
            ))}
          </div>

          {/* X-axis ticks */}
          <div
            className="absolute bottom-0 left-[40px] right-0 flex justify-between"
            style={{ width: 'calc(100% - 40px)' }}
          >
            {[...Array(6)].map((_, i) => (
              <div
                key={i}
                className="h-4 w-12 bg-gray-200 rounded animate-pulse"
              />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!series?.length || !categories?.length) {
    return (
      <div className="p-6 bg-white rounded-2xl">
        <h3 className="text-sm font-normal text-gray-800">{title}</h3>
        <NoDataFound
          icon="noChart"
          title="No Data"
          description="There is no data to show you right now"
        />
      </div>
    );
  }

  return (
    <div className={`p-6 bg-white rounded-2xl ${chartClassName}`}>
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-sm font-normal text-gray-800">{title}</h3>
        {showTimeFrameSelect ? (
          <Select value={timeFrame} onValueChange={handleTimeFrameChange}>
            <SelectTrigger className="w-32 !h-9">
              <SelectValue defaultValue={TIME_PERIOD_TYPES.MONTHLY}>
                {timeFrame}
              </SelectValue>
            </SelectTrigger>
            <SelectContent>
              {timeFrameOptions.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        ) : null}
      </div>
      <HighchartsReact highcharts={Highcharts} options={options} />
    </div>
  );
};

export default BarChart;
