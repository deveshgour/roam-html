import React, { useState, useEffect, useRef } from 'react';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import { Popover, PopoverContent, PopoverTrigger } from '../coreUI/popover';
import { Button } from '../coreUI/button';
import NoDataFound from '../noDataFound';
import useColors from '@/hooks/useColors';

interface PieDataPoint {
  name: string;
  y: number;
  color?: string;
}

/**
 * A pie chart component that displays a pie chart with a legend.
 * The chart will show all the data points in the pie chart.
 * The legend will show the names of the data points with a color swatch.
 * When the user clicks on a legend item, the corresponding pie slice will be shown or hidden.
 *
 * @param {string} title - The title of the chart.
 * @param {PieDataPoint[]} data - The data points to display in the chart.
 * @param {string} [seriesName='Revenue'] - The name of the series.
 * @param {boolean} [showDataLabels=false] - Whether to show data labels on the chart.
 * @param {string} [dataLabelFormat='{point.name}'] - The format string for the data labels.
 * @param {string} [legendPosition='right'] - The position of the legend.
 */
interface ServicePieChartProps {
  title: string;
  data: PieDataPoint[];
  seriesName?: string;
  showDataLabels?: boolean;
  dataLabelFormat?: string;
  legendClassName?: string;
  isLoading?: boolean;
  legendPosition?: 'right' | 'bottom';
}

const ServicePieChart: React.FC<ServicePieChartProps> = ({
  title,
  data,
  seriesName = 'Revenue',
  showDataLabels = false,
  legendClassName,
  dataLabelFormat = '{point.name}',
  isLoading = false,
  legendPosition = 'right',
}) => {
  // use unique colors based on the number of data points
  const colors = useColors(data.length);

  const [showDropdown, setShowDropdown] = useState(false);
  /**
   * Tracks visibility of slices in the pie chart.
   * This is used to toggle the visibility of slices when the user clicks on the legend.
   */
  const [visibility, setVisibility] = useState<boolean[]>(data.map(() => true));
  /**
   * The Highcharts chart object.
   * We use a ref to keep a reference to the chart object so we can update it when the data changes.
   */
  const chartRef = useRef<HighchartsReact.RefObject>(null);

  /**
   * Updates the chart and colors when the data changes.
   */

  useEffect(() => {
    if (chartRef.current) {
      chartRef.current.chart.series[0].setData(
        data.map((point, index) => ({
          ...point,
          color: colors[index % colors.length],
        }))
      );
    }
    // Ensure visibility state is updated when data changes
    setVisibility(data.map(() => true));
    // Ensure showDropdown is reset when data changes
    setShowDropdown(false);
  }, [data, colors]);

  /**
   * Toggles the visibility of a series in the pie chart.
   * @param index The index of the series to toggle.
   */
  const toggleSeriesVisibility = (index: number) => {
    if (chartRef.current) {
      const { chart } = chartRef.current;
      const series = chart.series[0];

      if (series && series.data[index]) {
        const point = series.data[index];
        point.setVisible(!point.visible);
        setVisibility((prev) => {
          const newVisibility = [...prev];
          newVisibility[index] = !newVisibility[index]; // Toggle visibility state
          return newVisibility;
        });
      }
    }
  };

  const options: Highcharts.Options = {
    chart: {
      type: 'pie',
      backgroundColor: 'transparent',
      spacingBottom: 0,
      height: 300,
    },
    title: { text: '' },
    series: [
      {
        name: seriesName,
        data: data.map((point, index) => ({
          ...point,
          color: colors[index % colors.length],
        })),
        type: 'pie',
        size: '100%',
        innerSize: '0%',
      },
    ],
    tooltip: {
      formatter: function () {
        const point = this as any;
        return `
          <div style="padding: 4px; min-width: 160px;">  
            <span style="display: block; width: 100%; font-size: 12px;">
              <span style="width: 10px; height: 10px; display: inline-block; background-color: ${point?.color}; border-radius: 50%; margin-right: 6px;"></span>
              <span style="display: inline-block; color: #6B7280;">${point?.name} </span> 
              <span style="color: #4B5563; display: inline-block; margin-left: 10px;">$${point?.tooltip_value || this?.y}K</span>
            </span>
          </div>`;
      },
      borderRadius: 10,
      borderColor: '#E9EAEA',
      borderWidth: 1,
      padding: 10,
      backgroundColor: '#fff',
      shadow: false,
      useHTML: true,
    },
    plotOptions: {
      pie: {
        allowPointSelect: true,
        cursor: 'pointer',
        dataLabels: {
          enabled: showDataLabels,
          format: dataLabelFormat,
          style: {
            fontWeight: 'normal',
            fontSize: '12px',
            color: '#6B7280',
          },
        },
        showInLegend: false,
      },
    },
    legend: { enabled: false },
    credits: { enabled: false },
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-2xl">
        <div className="flex justify-between items-center p-6 border-b border-gray-200">
          <div className="h-4 w-48 bg-gray-200 rounded animate-pulse" />
        </div>
        <div className="p-6">
          {/* Pie Chart Skeleton */}
          <div className="relative h-[250px] flex items-center justify-center">
            <div className="w-[250px] h-[250px] rounded-full bg-gray-100 animate-pulse">
              {/* Create pie segments effect */}
              <svg className="w-full h-full">
                <circle
                  cx="125"
                  cy="125"
                  r="120"
                  fill="none"
                  stroke="#E5E7EB"
                  strokeWidth="2"
                  strokeDasharray="5,5"
                  className="animate-spin"
                  style={{ animationDuration: '3s' }}
                />
              </svg>
            </div>
          </div>
          {/* Legend Skeleton */}
          <div className="flex flex-wrap gap-3 mt-6">
            {[...Array(6)].map((_, index) => (
              <div key={index} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-gray-200 animate-pulse" />
                <div className="h-4 w-20 bg-gray-200 rounded animate-pulse" />
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!data?.length) {
    return (
      <div className="p-6 bg-white rounded-2xl">
        <h3 className="text-sm font-normal text-gray-800">{title}</h3>
        <NoDataFound
          icon="noChart"
          title="No Data"
          description="There is no data to show you right now"
        />
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl">
      <div className="flex justify-between items-center p-6 border-b border-gray-200">
        <h3 className="text-sm font-normal text-gray-800">{title}</h3>
      </div>
      <div
        className={`flex ${legendPosition === 'bottom' ? 'flex-col' : 'items-center'}`}
      >
        <div
          className={`${legendPosition === 'bottom' ? 'w-full' : 'w-1/2'} h-[280px]`}
        >
          <HighchartsReact
            ref={chartRef}
            highcharts={Highcharts}
            options={options}
          />
        </div>

        <div
          className={`${legendPosition === 'bottom' ? 'w-full px-6 pb-6 mt-8' : 'w-1/2'} flex flex-wrap items-center gap-4 overflow-hidden`}
        >
          {/* Check if data exists and is an array */}
          {Array.isArray(data) && data.length > 0 ? (
            <>
              {/* Render available data (max 10 items) */}
              {data.slice(0, 10).map((legend, index) => (
                <div
                  key={index}
                  className={`flex items-center text-gray-600 cursor-pointer`}
                  onClick={() => toggleSeriesVisibility(index)}
                >
                  <span
                    className={`{h-2 w-2 rounded-full mr-1 shrink-0 ${legendClassName}`}
                    style={{
                      backgroundColor: !visibility?.[index]
                        ? '#6f6f6f'
                        : legend?.color ||
                          colors?.[index % (colors?.length || 1)],
                    }}
                  ></span>
                  <span
                    className={
                      !visibility?.[index]
                        ? 'text-[10px] line-through'
                        : 'text-[10px]'
                    }
                  >
                    {legend?.name || 'Unknown'}
                  </span>
                </div>
              ))}

              {/* Show +more only if data.length > 10 */}
              {data.length > 10 && (
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      className="!text-[10px]"
                      variant="link"
                      onClick={() => setShowDropdown(!showDropdown)}
                    >
                      +{data.length - 10} more
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent
                    className="w-[200px] p-0 max-h-[300px] overflow-y-auto"
                    align="end"
                  >
                    {data.slice(10).map((legend, index) => (
                      <Button
                        key={index}
                        variant="ghost"
                        className="!justify-start w-full text-xs rounded-none px-4 font-normal hover:bg-gray-100 text-gray-600 text-left !whitespace-normal"
                        onClick={() => toggleSeriesVisibility(index + 10)}
                      >
                        <span
                          className="w-2 h-2 rounded-full mr-1 shrink-0"
                          style={{
                            backgroundColor: !visibility?.[index + 10]
                              ? '#6f6f6f'
                              : legend?.color ||
                                colors?.[(index + 10) % (colors?.length || 1)],
                          }}
                        ></span>
                        <span
                          className={
                            !visibility?.[index + 10]
                              ? 'text-[10px] line-through'
                              : 'text-[10px]'
                          }
                        >
                          {legend?.name || 'Unknown'}
                        </span>
                      </Button>
                    ))}
                  </PopoverContent>
                </Popover>
              )}
            </>
          ) : null}{' '}
          {/* Do not render anything if data is empty */}
        </div>
      </div>
    </div>
  );
};

export default ServicePieChart;
