/* eslint-disable no-unused-vars */
/**
 * A component that displays a table with pagination and optional
 * sorting, row actions, and a footer.
 *
 * @param {DataTableWithCardProps<T>} props - The props of the component.
 * @returns {JSX.Element} - The element to render.
 */
import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/coreUI/table/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/coreUI/select';
import { Pagination } from '../coreUI/table/pagination';
import { SORTING_TYPES } from '../coreUI/table/constants';
import Icon from '../coreUI/icon';
import { DataTableWithCardSkeleton } from './skeleton';
import NoDataFound from '../noDataFound';
import { ScrollArea } from '@components/coreUI/scrollBar';
import { Button } from '../coreUI/button';

interface ColumnDef {
  header: string;
  accessorKey: string;
  cell?: (row: any) => React.ReactNode;
  sortable?: boolean;
  footer?: () => React.ReactNode;
  onSortingChange?: () => React.ReactNode;
}

type SortingDirection = 'asc' | 'desc' | null;

interface DataTableWithCardProps<T> {
  data: T[];
  columns: ColumnDef[];
  // Pagination props
  page: number;
  pageSize: number;
  totalItems: number;
  pageSizeOptions?: number[];
  onPageChange: (value: number) => void;
  onPageSizeChange?: (value: number) => void;
  onRowClick?: (row: T) => void;
  // Display options
  showTitle?: React.ReactNode;
  showPagination?: boolean;
  showPageSize?: boolean;
  showFooter?: boolean;
  headerClassName?: string;
  cardClassName?: string;
  scrollAreaClassName?: string;
  actions?: {
    label: string | ((row: T) => string);
    onClick?: (row: T) => void;
    href?: string | (() => string);
    icon?: React.ReactNode;
  }[];
  headerActions?: React.ReactNode;
  sorting?: {
    field: string;
    direction:
      | (typeof SORTING_TYPES.ASC)[keyof typeof SORTING_TYPES.DESC]
      | null;
  };
  isLoading?: boolean;
  skeletonClassName?: string;
  onSortingChange?: (field: string, direction: SortingDirection) => void;
}

export function DataTableWithCard<T>({
  data,
  columns,
  page,
  pageSize,
  onRowClick,
  totalItems,
  pageSizeOptions = [5, 10, 25, 50, 100],
  onPageChange,
  onPageSizeChange,
  showTitle = true,
  headerClassName = '',
  cardClassName = '',
  scrollAreaClassName = '',
  showPagination = true,
  showPageSize = true,
  actions = [],
  showFooter = true,
  headerActions,
  sorting,
  isLoading = false,
  skeletonClassName = '',
  onSortingChange,
}: DataTableWithCardProps<T>) {
  const handleSort = (column: ColumnDef) => {
    if (!column.sortable || !onSortingChange) return;
    const isCurrentColumn = sorting?.field === column.accessorKey;
    let newDirection:
      | typeof SORTING_TYPES.ASC
      | typeof SORTING_TYPES.DESC
      | null = SORTING_TYPES.ASC;

    if (isCurrentColumn && sorting.direction === SORTING_TYPES.ASC) {
      newDirection = SORTING_TYPES.DESC;
    }
    onSortingChange(column.accessorKey, newDirection as SortingDirection);
  };
  if (isLoading) {
    return (
      <DataTableWithCardSkeleton
        skeletonClassName={skeletonClassName}
        rows={pageSize}
        columns={columns.length}
      />
    );
  }

  if (data?.length === 0) {
    return (
      <div className="rounded-2xl bg-white w-full h-full">
        <div className="px-6 py-8 h-full">
          <div className="flex items-center gap-2 w-full justify-between">
            {showTitle && (
              <h3 className="text-sm text-gray-800 w-full text-left">
                {showTitle}
              </h3>
            )}
            {headerActions && <>{headerActions}</>}
          </div>
          <NoDataFound
            icon="noTable"
            title="No Record Found"
            description="There is no record to show you right now"
          />
        </div>
      </div>
    );
  }

  return (
    <div className={`rounded-2xl bg-white w-full ${cardClassName}`}>
      <div
        className={`flex items-center justify-between p-6 pb-2 flex-wrap gap-4 ${headerClassName}`}
      >
        <div className="flex items-center gap-4 justify-between flex-auto">
          {showTitle && (
            <h3 className="text-sm text-gray-800 w-full text-left">
              {showTitle}
            </h3>
          )}
        </div>
        <div className="flex items-center gap-3">
          {showPageSize && (
            <>
              <span className="text-sm text-gray-500">Show:</span>
              <Select
                value={String(pageSize)}
                onValueChange={(value) => {
                  onPageSizeChange?.(Number(value));
                }}
              >
                <SelectTrigger className="w-20 !h-9">
                  <SelectValue placeholder="Rows per page" />
                </SelectTrigger>
                <SelectContent>
                  {pageSizeOptions.map((size) => (
                    <SelectItem key={size} value={String(size)}>
                      {size}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </>
          )}
          {headerActions}
        </div>
      </div>
      <ScrollArea className={`${scrollAreaClassName}`}>
        <Table theme="striped" className="min-w-full">
          {/* Sticky Header */}
          <TableHeader className="sticky top-0 z-10">
            <TableRow>
              {columns.map((column) => (
                <TableHead
                  key={column.accessorKey}
                  className={` ${column.sortable ? 'select-none' : ''}`}
                  onClick={() => column.sortable}
                >
                  <div className={`flex items-center gap-2 min-w-[82px]`}>
                    {column.header}
                    {column.sortable && (
                      <div className="flex flex-col">
                        <Icon
                          iconName="arrowUp"
                          iconProps={{
                            onClick: () => handleSort(column),
                            className: `h-3 w-3 transition-colors rotate-180 cursor-pointer ${
                              sorting?.field === column.accessorKey &&
                              sorting.direction === SORTING_TYPES.ASC
                                ? 'text-foreground'
                                : 'text-muted-foreground/30'
                            }`,
                          }}
                        />
                        <Icon
                          iconName="arrowUp"
                          iconProps={{
                            onClick: () => handleSort(column),
                            className: `h-3 w-3 transition-colors cursor-pointer ${
                              sorting?.field === column.accessorKey &&
                              sorting.direction === SORTING_TYPES.DESC
                                ? 'text-foreground'
                                : 'text-muted-foreground/30'
                            }`,
                          }}
                        />
                      </div>
                    )}
                  </div>
                </TableHead>
              ))}
              {actions.length > 0 && (
                <TableHead className="sticky top-0 bg-white z-10 w-[70px]">
                  Action
                </TableHead>
              )}
            </TableRow>
          </TableHeader>

          {/* Table Body */}
          <TableBody>
            {data.map((row: any, rowIndex) => (
              <TableRow
                key={rowIndex}
                onClick={() => onRowClick?.(row)}
                className={onRowClick ? 'cursor-pointer hover:bg-gray-50' : ''}
              >
                {columns.map((column) => (
                  <TableCell key={column.accessorKey}>
                    {column.cell ? column.cell(row) : row[column.accessorKey]}
                  </TableCell>
                ))}
                {actions.length > 0 && (
                  <TableCell className="w-[70px] text-center">
                    {actions.map((action, index) => (
                      <Button
                        key={index}
                        variant="link"
                        className="!text-gray underline text-xs"
                        onClick={(e) => {
                          e.stopPropagation();
                          action.onClick?.(row);
                        }}
                      >
                        {typeof action.label === 'function'
                          ? action.label(row)
                          : action.label}
                      </Button>
                    ))}
                  </TableCell>
                )}
              </TableRow>
            ))}
          </TableBody>

          {/* Sticky Footer */}
          {showFooter && data.length > 0 && (
            <TableFooter className="sticky bottom-0">
              <TableRow>
                {columns.map((column) => (
                  <TableCell key={column.accessorKey} className="font-semibold">
                    {column.footer ? column.footer() : null}
                  </TableCell>
                ))}
                {actions.length > 0 && (
                  <TableCell className="w-[70px]"></TableCell>
                )}
              </TableRow>
            </TableFooter>
          )}
        </Table>
      </ScrollArea>

      {/* Pagination */}
      {showPagination && data.length > 0 && (
        <Pagination
          page={page}
          totalItems={totalItems}
          pageSize={pageSize}
          onPageChange={onPageChange}
        />
      )}
    </div>
  );
}
