import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableHead,
  TableRow,
} from '@/components/coreUI/table/table';
import { ScrollArea } from '../coreUI/scrollBar';

interface DataTableSkeletonProps {
  columns: number;
  rows?: number;
  showTitle?: boolean;
  showPageSize?: boolean;
  showActions?: boolean;
  skeletonClassName?: string;
}

export function DataTableWithCardSkeleton({
  columns,
  rows = 5,
  showTitle = true,
  showPageSize = true,
  showActions = false,
  skeletonClassName = '',
}: DataTableSkeletonProps) {
  return (
    <div
      className={`${skeletonClassName ? skeletonClassName + ' overflow-hidden' : 'h-full overflow-hidden'}`}
    >
      <div className="flex items-center justify-between p-6 pb-2 gap-4">
        <div className="flex items-center gap-4 w-full max-w-sm">
          {showTitle && <div className="h-4 bg-gray-200 rounded w-32"></div>}
        </div>
        <div className="flex items-center gap-3">
          {showPageSize && (
            <>
              <div className="h-4 bg-gray-200 rounded w-10"></div>
              <div className="h-9 bg-gray-200 rounded w-20"></div>
            </>
          )}
        </div>
      </div>
      <div>
        <ScrollArea className={`h-[400px] w-full`}>
          <Table theme="striped">
            <TableHeader>
              <TableRow>
                {Array.from({ length: columns }).map((_, index) => (
                  <TableHead key={index}>
                    <div className="h-4 bg-gray-200 rounded w-24"></div>
                  </TableHead>
                ))}
                {showActions && (
                  <TableCell className="w-[70px]">
                    <div className="h-8 bg-gray-200 rounded w-8 mx-auto"></div>
                  </TableCell>
                )}
              </TableRow>
            </TableHeader>
            <TableBody>
              {Array.from({ length: rows }).map((_, rowIndex) => (
                <TableRow key={rowIndex}>
                  {Array.from({ length: columns }).map((_, colIndex) => (
                    <TableCell key={colIndex}>
                      <div className="h-4 bg-gray-200 rounded w-full max-w-[120px]"></div>
                    </TableCell>
                  ))}
                  {showActions && (
                    <TableCell className="w-[70px]">
                      <div className="h-8 bg-gray-200 rounded w-8 mx-auto"></div>
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </ScrollArea>
        <div className="p-4 flex justify-between items-center">
          <div className="h-8 bg-gray-200 rounded w-24"></div>
          <div className="flex gap-2">
            {Array.from({ length: 3 }).map((_, index) => (
              <div key={index} className="h-8 bg-gray-200 rounded w-8"></div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
