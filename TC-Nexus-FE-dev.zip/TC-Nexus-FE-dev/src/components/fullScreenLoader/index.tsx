import React from 'react';
import Icon from '@components/coreUI/icon';

function FullScreenLoader() {
  return (
    <div className="fixed z-50 inset-0 flex items-center justify-center bg-[#0000006e]">
      <span className="animate-spin mr-2">
        <Icon iconName="loader" iconProps={{ className: `h-12 w-12` }} />
      </span>
    </div>
  );
}

export default FullScreenLoader;
