import React from 'react';

interface InfoItem {
  label: string;
  value: string | number;
}

interface ItemsCardProps {
  title: string;
  items: InfoItem[];
  className?: string;
}

const ItemsCard: React.FC<ItemsCardProps> = ({
  title,
  items,
  className = '',
}) => {
  return (
    <div className={`bg-white rounded-lg shadow-sm ${className}`}>
      <h3 className="text-[16px] text-gray-900 px-6 py-[18px]">{title}</h3>
      <hr></hr>

      <div className="space-y-3 pb-8 mt-5">
        {items.map((item, index) => (
          <div key={index} className="flex px-6 justify-between items-center">
            <span className="text-gray-600 text-[14px]">{item.label}</span>
            <span className="text-gray-900 text-[14px] font-medium">
              {item.value}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ItemsCard;
