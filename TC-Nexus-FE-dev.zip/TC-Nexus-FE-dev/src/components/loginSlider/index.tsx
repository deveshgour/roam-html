'use client';

import * as React from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, Pagination } from 'swiper/modules';
import 'swiper/swiper-bundle.css';
import Image from 'next/image';
import OperationsSlide from '@/app/assets/images/slide.svg';
import MarketingSlide from '@/app/assets/images/slide-2.svg';
import SecureSlide from '@/app/assets/images/slide-3.svg';

const SwiperSlider: React.FC = () => {
  return (
    <Swiper
      slidesPerView={1}
      spaceBetween={0}
      pagination={{
        clickable: true,
      }}
      autoplay={{
        delay: 3000,
        disableOnInteraction: false,
      }}
      modules={[Pagination, Autoplay]}
      className="w-full max-w-[600px] !mx-8 loginSlider"
    >
      <SwiperSlide className="!flex !h-auto items-center justify-center">
        <div className="flex flex-col justify-between items-center h-full">
          <div className="lg:min-h-[600px] sm:min-h-[500px] flex items-center max-h-full">
            <Image
              src={OperationsSlide}
              alt="Operations KPIs"
              width={500}
              height={500}
            />
          </div>
          <div className="text-center text-white mb-6">
            <h2 className="font-medium text-2xl mb-3 text-white">
              Operations KPIs
            </h2>
            <p className="text-sm text-white/60">
              Track job progress, team productivity, and service efficiency to
              optimize performance.
            </p>
          </div>
        </div>
      </SwiperSlide>
      <SwiperSlide className="!flex !h-auto items-center justify-center">
        <div className="flex flex-col justify-between h-full items-center">
          <div className="lg:min-h-[600px] sm:min-h-[500px] flex items-center max-h-full">
            <Image
              src={MarketingSlide}
              alt="Marketing Performance Insights"
              width={500}
              height={500}
            />
          </div>
          <div className="text-center text-white mb-6">
            <h2 className="font-medium text-2xl mb-3 text-white">
              Marketing Performance Insights
            </h2>
            <p className="text-sm text-white/60">
              Analyze campaign effectiveness, lead generation, and customer
              engagement in real time.
            </p>
          </div>
        </div>
      </SwiperSlide>
      <SwiperSlide className="!flex !h-auto items-center justify-center">
        <div className="flex flex-col justify-between h-full items-center">
          <div className="lg:min-h-[600px] sm:min-h-[500px] flex items-center max-h-full">
            <Image
              src={SecureSlide}
              alt="Secure Access"
              width={500}
              height={500}
            />
          </div>
          <div className="text-center text-white mb-6">
            <h2 className="font-medium text-2xl mb-3 text-white">
              Secure Access
            </h2>
            <p className="text-sm text-white/60">
              Monitor earnings, expenses, and profitability to drive smarter
              financial decisions.
            </p>
          </div>
        </div>
      </SwiperSlide>
    </Swiper>
  );
};

export default SwiperSlider;
