import Icon from '../coreUI/icon';

interface NoDataProps {
  title?: string;
  description?: string;
  containerClassName?: string;
  icon?: string;
}

const NoDataFound = ({
  icon = '',
  title = '',
  description = '',
  containerClassName,
}: NoDataProps) => {
  return (
    <div
      className={`flex flex-col items-center justify-center gap-2 p-8 h-full ${containerClassName}`}
    >
      {Icon && (
        <div className="">
          <Icon
            iconName={icon}
            iconProps={{ className: '!w-32 !h-32 text-gray-200' }}
          />
        </div>
      )}
      <div className="flex flex-col items-center gap-2 text-center mt-2">
        <h3 className="text-base font-medium text-gray">{title}</h3>
        <p className="text-xs font-normal text-gray-600">{description}</p>
      </div>
    </div>
  );
};

export default NoDataFound;
