'use client';

import * as React from 'react';
import * as TooltipPrimitive from '@radix-ui/react-tooltip';

/**
 * A component that wraps all the other tooltip components.
 * It provides context for the tooltip components and handles the
 * keyboard navigation and auto-focus.
 */
const TooltipProvider: React.FC<
  React.ComponentProps<typeof TooltipPrimitive.Provider>
> = ({ children, ...props }) => {
  return (
    <TooltipPrimitive.Provider {...props}>{children}</TooltipPrimitive.Provider>
  );
};

/**
 * The root component of the tooltip.
 * It wraps the trigger and the content components.
 */
const Tooltip: React.FC<React.ComponentProps<typeof TooltipPrimitive.Root>> = ({
  children,
  ...props
}) => {
  return <TooltipPrimitive.Root {...props}>{children}</TooltipPrimitive.Root>;
};

/**
 * The trigger component of the tooltip.
 * It wraps the element that will trigger the tooltip.
 */
const TooltipTrigger: React.FC<
  React.ComponentProps<typeof TooltipPrimitive.Trigger>
> = ({ children, ...props }) => {
  return (
    <TooltipPrimitive.Trigger {...props}>{children}</TooltipPrimitive.Trigger>
  );
};

/**
 * The content component of the tooltip.
 * It wraps the content of the tooltip.
 */
const TooltipContent = React.forwardRef<
  React.ElementRef<typeof TooltipPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof TooltipPrimitive.Content>
>(({ className, sideOffset = 4, ...props }, ref) => (
  <TooltipPrimitive.Portal>
    <TooltipPrimitive.Content
      ref={ref}
      sideOffset={sideOffset}
      className={`
        "z-50 overflow-hidden rounded-md bg-primary-800 px-3 py-1.5 text-xs text-white animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2" ${className}`}
      {...props}
    />
  </TooltipPrimitive.Portal>
));
TooltipContent.displayName = TooltipPrimitive.Content.displayName;

export { Tooltip, TooltipTrigger, TooltipContent, TooltipProvider };
