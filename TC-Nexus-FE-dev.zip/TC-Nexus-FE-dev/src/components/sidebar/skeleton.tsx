/**
 * A skeleton component that can be used to display a loading state.
 *
 * @param {React.HTMLAttributes<HTMLDivElement>} props - The props for the component.
 * @returns {React.ReactElement} - The skeleton component.
 */
function Skeleton({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>): React.ReactElement {
  return (
    <div
      className={`animate-pulse rounded-md bg-primary/10" ${className}`}
      {...props}
    />
  );
}

export { Skeleton };
