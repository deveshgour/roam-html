'use client';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/sidebar/collapsible';
import {
  SidebarGroup,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
} from '@/components/sidebar/sidebar';
import { NavItem } from '@/constants/configs';
import { useUserProfile } from '@/contexts/userProfileContext';
import Icon from '@components/coreUI/icon';
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import { useCallback, useState } from 'react';
import { checkMenuPermissions } from '@/utils/permissions';

/**
 * Renders the navigation menu for the sidebar.
 *
 * @param items - An array of objects with the following properties:
 *   - `title`: The title of the menu item.
 *   - `url`: The URL of the menu item.
 *   - `icon`: An optional icon to display next to the menu item.
 *   - `isActive`: An optional boolean indicating whether the menu item is active.
 *   - `items`: An optional array of sub-menu items.
 */

export function NavMain({ items }: { items: NavItem[] }) {
  const pathname = usePathname();
  const router = useRouter();
  const { permission } = useUserProfile();
  const [openItems, setOpenItems] = useState<{ [key: string]: boolean }>({});

  const handleNavigate = (
    e: React.MouseEvent<HTMLAnchorElement>,
    url: string
  ) => {
    e.preventDefault();
    router.push(url);
  };

  const checkItemPermissions = useCallback(
    (item: NavItem) => {
      if (!item.permissions) return true;
      return checkMenuPermissions(permission, item.permissions);
    },
    [permission]
  );

  // Check if any child items are accessible
  const hasAccessibleChildren = useCallback(
    (items?: NavItem[]) => {
      if (!items) return false;
      return items.some((item) => checkItemPermissions(item));
    },
    [checkItemPermissions]
  );

  // Check if menu item should be visible
  const shouldShowMenuItem = useCallback(
    (item: NavItem) => {
      const hasDirectAccess = checkItemPermissions(item);
      const hasChildAccess = hasAccessibleChildren(item.items);
      return hasDirectAccess || hasChildAccess;
    },
    [checkItemPermissions, hasAccessibleChildren]
  );

  const toggleItem = (title: string) => {
    setOpenItems((prev) => ({
      ...prev,
      [title]: !prev[title],
    }));
  };

  return (
    <SidebarGroup>
      <SidebarMenu>
        {items.map((item, index) => {
          // Only render if user has permission
          if (!shouldShowMenuItem(item)) return null;

          const isItemOpen = openItems[item.title] || false;

          return (
            <Collapsible
              key={index}
              asChild
              defaultOpen={item.isActive || pathname.startsWith(item.url)}
              className="group/collapsible"
            >
              <SidebarMenuItem>
                {item.items && item.items.length > 0 ? (
                  <>
                    <CollapsibleTrigger asChild>
                      <SidebarMenuButton
                        tooltip={item.title}
                        className={
                          pathname === item.url ? 'bg-gray-100' : 'text-gray'
                        }
                        onClick={() => toggleItem(item.title)}
                      >
                        {item.icon && (
                          <Icon
                            iconName={item.icon}
                            iconProps={{ className: `h-6 w-6 text-gray-600` }}
                          />
                        )}
                        <span>{item.title}</span>
                        <span className="ml-auto">
                          <Icon
                            iconName="angleDown"
                            iconProps={{
                              className: `w-5 h-5 transition-transform duration-200 ${
                                isItemOpen ? 'rotate-180' : 'rotate-0'
                              }`,
                            }}
                          />
                        </span>
                      </SidebarMenuButton>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <SidebarMenuSub>
                        {item.items?.map((subItem) => {
                          // Only render submenu items if user has permission
                          if (!checkItemPermissions(subItem)) return null;

                          const isActive = pathname === subItem.url;
                          return (
                            <SidebarMenuSubItem key={subItem.title}>
                              <SidebarMenuSubButton
                                asChild
                                className={
                                  isActive ? 'text-primary-800' : 'text-gray'
                                }
                              >
                                <Link
                                  href={subItem.url}
                                  onClick={(e) =>
                                    handleNavigate(e, subItem.url)
                                  }
                                >
                                  {subItem.title}
                                </Link>
                              </SidebarMenuSubButton>
                            </SidebarMenuSubItem>
                          );
                        })}
                      </SidebarMenuSub>
                    </CollapsibleContent>
                  </>
                ) : (
                  <Link
                    href={item.url}
                    onClick={(e) => handleNavigate(e, item.url)}
                    className="block"
                  >
                    <SidebarMenuButton
                      tooltip={item.title}
                      className={
                        pathname === item.url ? 'bg-gray-100' : 'text-gray'
                      }
                    >
                      {item.icon && (
                        <Icon
                          iconName={item.icon}
                          iconProps={{ className: `h-6 w-6 text-gray-600` }}
                        />
                      )}
                      <span>{item.title}</span>
                    </SidebarMenuButton>
                  </Link>
                )}
              </SidebarMenuItem>
            </Collapsible>
          );
        })}
      </SidebarMenu>
    </SidebarGroup>
  );
}
