'use client';

import * as React from 'react';
import { NavMain } from '@/components/sidebar/nav-main';
import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarRail,
} from '@/components/sidebar/sidebar';
import Image from 'next/image';
import { SIDEBAR_MENU } from '@/constants/configs';
import Logo from '@/app/assets/images/tcbacker.svg';

export function NavigationSidebar({
  ...props
}: React.ComponentProps<typeof Sidebar>) {
  return (
    <Sidebar collapsible="icon" {...props}>
      <SidebarHeader className="pt-4">
        <Image src={Logo} alt="TcBacker" width={170} height={40} />
      </SidebarHeader>
      <SidebarContent>
        <NavMain items={SIDEBAR_MENU} />
      </SidebarContent>
      <SidebarRail />
    </Sidebar>
  );
}
