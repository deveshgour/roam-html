/**
 * InfoCard component
 *
 * This component is used to display a single piece of information
 * with an icon, title, value, and an optional percentage.
 */
import React, { ReactNode } from 'react';
import Icon from '../coreUI/icon';

/**
 * Props for the InfoCard component
 */
interface InfoCardProps {
  /**
   * The title of the info card
   */
  title?: string;
  helping_text?: string;
  /**
   * The value of the info card
   */
  value?: ReactNode;
  /**
   * The percentage of the info card (optional)
   */
  percentage?: ReactNode;
  /**
   * Whether the percentage is positive or negative (optional)
   * Defaults to true
   */
  isPositive?: boolean;
  /**
   * The icon of the info card
   */
  icon?: string;
  /**
   * The background color of the icon (optional)
   * Defaults to 'bg-amber-50'
   */
  iconBgColor?: string;
  /**
   * The color of the icon (optional)
   * Defaults to 'text-amber-600'
   */
  iconColor?: string;
  /**
   * The border color of the info card (optional)
   * Defaults to 'border-amber-600'
   */
  borderColor?: string;
  /**
   * Whether the card is in loading state
   */
  isLoading?: boolean;
  /**
   * The onClick handler for the card
   */
  onClick?: () => void;
}

/**
 * InfoCard component
 *
 * @param {InfoCardProps} props The props of the component
 * @returns {JSX.Element} The component
 */
const InfoCard: React.FC<InfoCardProps> = ({
  title = '',
  value = '',
  percentage = '',
  isPositive = true,
  helping_text = '',
  icon = '',
  iconBgColor = '',
  iconColor = '',
  borderColor = '',
  isLoading = false,
  onClick,
}) => {
  if (isLoading) {
    return (
      <div className="rounded-xl bg-white w-full border border-gray-100">
        <div className="p-6">
          <div className="flex items-start space-x-4">
            <div className="rounded-xl bg-gray-100 animate-pulse p-3 w-12 h-12" />
            <div className="space-y-2 flex-1">
              <div className="h-4 bg-gray-100 rounded animate-pulse w-28" />
              <div className="h-4 bg-gray-100 rounded animate-pulse w-20" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`rounded-xl bg-white w-full border ${borderColor} border-opacity-0 hover:border-opacity-100 cursor-pointer hover:shadow-md transition-shadow`}
      onClick={onClick}
    >
      <div className="p-6">
        <div className="flex items-start space-x-4">
          <div className={`rounded-xl ${iconBgColor} p-3 w-12 h-12`}>
            <Icon
              iconName={icon}
              iconProps={{ className: `h-6 w-6 ${iconColor}` }}
            />
          </div>
          <div className="space-y-1">
            <p className="text-xs font-medium text-gray-500">{title}</p>
            <div className="flex items-center space-x-3">
              <h3 className="text-lg font-bold tracking-tight text-gray-900">
                {value}
                <span className="text-sm font-normal">{helping_text}</span>
              </h3>
              {percentage ? (
                <span
                  className={`inline-flex items-center rounded-md text-xs font-medium ${
                    isPositive ? 'text-emerald-600' : 'text-red-600'
                  }`}
                >
                  {isPositive ? '+' : ''}
                  {percentage}
                </span>
              ) : null}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

InfoCard.displayName = 'InfoCard';

export type { InfoCardProps };
export default InfoCard;
