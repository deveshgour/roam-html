/**
 * @package
 * @description
 * A component to render a list of least performing sales representatives
 * with their details.
 */
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from '@/components/coreUI/avatar';
/**
 * @description
 * A component to render a scrollable area. This is used to render the
 * list of sales reps in a scrollable container.
 */
import { ScrollArea } from '../coreUI/scrollBar';
import NoDataFound from '../noDataFound';

/**
 * @description
 * An interface to represent a sales representative with their details.
 */
interface SalesRep {
  /**
   * @description
   * The ID of the sales representative.
   */
  id: string;
  /**
   * @description
   * The name of the sales representative.
   */
  name: string;
  /**
   * @description
   * The avatar of the sales representative.
   */
  avatar: string;
  /**
   * @description
   * The sales amount of the sales representative.
   */
  sales: number;
}

interface LeastPerformingListProps {
  salesReps: SalesRep[] | null;
  isLoading?: boolean;
}

/**
 * Component to render a list of least performing sales representatives.
 * Displays each sales rep's avatar, name, and sales amount.
 */
export function LeastPerformingList({
  salesReps,
  isLoading = false,
}: LeastPerformingListProps) {
  if (isLoading) {
    return (
      <div className="w-full mx-auto rounded-2xl bg-white w-full h-full">
        <h3 className="text-sm text-gray-800 pb-5 border-b border-gray-200 p-6">
          Least Performing Sales Rep
        </h3>
        <div className="h-[320px] px-6">
          {[...Array(4)].map((_, index) => (
            <div
              key={index}
              className="flex items-center justify-between gap-2 py-3"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-gray-200 animate-pulse" />
                <div className="w-24 h-4 bg-gray-200 rounded animate-pulse" />
              </div>
              <div className="w-20 h-4 bg-gray-200 rounded animate-pulse" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="w-full mx-auto rounded-2xl bg-white w-full h-full">
      <h3 className="text-sm text-gray-800 pb-5 border-b border-gray-200 p-6">
        Least Performing Sales Rep
      </h3>
      <ScrollArea className="h-[400px] my-1">
        <div className="">
          {!salesReps?.length ? (
            <div className="flex items-center justify-center w-full h-full">
              <NoDataFound
                icon="noTable"
                title="No Record Found"
                description="There is no record to show you right now"
              />
            </div>
          ) : (
            salesReps.map((rep) => (
              <div
                key={rep.id}
                className="flex items-center justify-between gap-2 hover:bg-gray-50 px-6 py-3"
              >
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage
                      src={rep.avatar}
                      alt={rep.name}
                      className="w-8 h-8"
                    />
                    <AvatarFallback>
                      {rep.name
                        .split(' ')
                        .map((n) => n[0])
                        .join('')}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-[13px] font-normal text-gray">
                    {rep.name}
                  </span>
                </div>
                <span className="text-sm font-medium text-gray ml-2">
                  ${rep.sales.toLocaleString()}
                </span>
              </div>
            ))
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
