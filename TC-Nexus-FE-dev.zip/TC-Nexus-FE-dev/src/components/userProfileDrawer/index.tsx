'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from '@/components/coreUI/avatar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/coreUI/popover';
import { Button } from '@/components/coreUI/button';
import {
  TC_BACKER_USER_DATA,
  TC_BACKER_USER_PERMISSIONS,
} from '@/constants/configs';
import { APP_ROUTE } from '@/constants/routes';
import { logoutUser } from '@/services/auth';
import { deleteCookie } from '@/utils/cookies';
import FullScreenLoader from '../fullScreenLoader';
import { showSuccessMsg } from '@/utils/notifications';
// import UserProfileInfo from '@/components/userProfileInfo';
import { UserProfileInfoProps } from '@/components/userProfileInfo/types';
import { useUserProfile } from '@/contexts/userProfileContext';
import UserProfileInfo from '../userProfileInfo';

export function UserProfilePopover({ loading }: UserProfileInfoProps) {
  // hooks
  const { push } = useRouter();

  // State
  const [isOpen, setIsOpen] = useState(false);
  const [isLoaderVisible, setIsLoaderVisible] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const { user } = useUserProfile(); // Use the context

  /**
   * Logs out the user by calling the logout API and redirects them to the login page.
   * @async
   */
  const handleLogoutUser = async () => {
    try {
      setIsLoaderVisible(true);
      // Close the popover
      setIsOpen(false);

      // API CALL TO LOGOUT USER
      const { message = '' } = await logoutUser();

      // Delete session data
      deleteCookie(TC_BACKER_USER_DATA);
      deleteCookie(TC_BACKER_USER_PERMISSIONS);

      // Redirect the user to the login page and show a success message
      push(APP_ROUTE.AUTH.LOGIN);
      showSuccessMsg(message);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoaderVisible(false);
    }
  };

  return (
    <>
      {isLoaderVisible ? <FullScreenLoader /> : null}
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <button className="flex items-center gap-2 rounded-lg p-2 text-sm font-medium transition-colors">
            <Avatar className="!h-9 !w-9 hover:ring-2 hover:ring-offset-1 hover:ring-gray-200">
              {loading ? (
                <div className="h-9 w-9 bg-gray-200 animate-pulse rounded-full"></div>
              ) : (
                <>
                  <AvatarImage src={user?.img} alt={user?.name} />
                  <AvatarFallback className="uppercase">
                    {user?.name
                      ?.split(' ')
                      .map((word: string) => word.charAt(0))
                      .join('')}
                  </AvatarFallback>
                </>
              )}
            </Avatar>
          </button>
        </PopoverTrigger>
        <PopoverContent className="w-[200px] p-0" align="end">
          <div className="p-4 py-2 border-b border-gray-100">
            {loading ? (
              <div className="w-36 h-4 bg-gray-200 animate-pulse rounded"></div>
            ) : (
              <>
                <p className="font-medium capitalize">{user?.name}</p>
                <p className="text-sm text-muted-foreground">{user?.email}</p>
              </>
            )}
          </div>
          <div className="flex flex-col">
            <Button
              variant="ghost"
              className="!justify-start rounded-none px-4 font-normal hover:bg-gray-100 text-gray-500"
              onClick={() => setIsProfileOpen(true)}
            >
              My Profile
            </Button>
            <Button
              variant="ghost"
              className="!justify-start rounded-none px-4 font-normal hover:bg-gray-100 text-gray-500"
              onClick={(e) => {
                e.stopPropagation();
              }}
            >
              Account Settings
            </Button>
            <Button
              variant="ghost"
              className="!justify-start rounded-none px-4 py-1 font-normal hover:bg-gray-100 border-t border-gray-100 text-gray-500"
              onClick={handleLogoutUser}
            >
              Sign Out
            </Button>
          </div>
        </PopoverContent>
      </Popover>
      {/*
        Render the user profile info modal if the user is logged in and
        the userProfile state is not empty.
      */}
      {isProfileOpen && user && (
        <UserProfileInfo
          isOpen={isProfileOpen}
          onClose={() => setIsProfileOpen(false)}
          userProfile={user}
          loading={loading}
        />
      )}
    </>
  );
}
