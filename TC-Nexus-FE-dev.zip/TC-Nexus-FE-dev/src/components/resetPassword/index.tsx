import Modal from '@/components/coreUI/dialog';
import { TextInput } from '@/components/coreUI/textInput';
import { Formik, FormikProps } from 'formik';
import * as Yup from 'yup';
import React from 'react';
import { Button } from '@/components/coreUI/button';
import { VALIDATION_MESSAGES } from '@/constants/messages';
import { useUserProfile } from '@/contexts/userProfileContext';

interface ResetPasswordModalProps {
  open: boolean;
  onClose: () => void;
  // eslint-disable-next-line no-unused-vars
  onSubmit: (values: ResetPasswordFormValues) => void;
  isSubmitting: boolean;
}

interface ResetPasswordFormValues {
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}

const ResetPasswordModal = ({
  open = false,
  onClose = () => {},
  onSubmit = () => {},
  isSubmitting = false,
}: ResetPasswordModalProps) => {
  const formikRef = React.useRef<FormikProps<ResetPasswordFormValues>>(null);
  const [isSubmitted, setIsSubmitted] = React.useState(false);
  const { user } = useUserProfile(); // Use the context

  const UserRole = Boolean(user?.UserRole);

  const validationSchema = Yup.object().shape({
    currentPassword: UserRole
      ? Yup.string().optional()
      : Yup.string().required(VALIDATION_MESSAGES.CURRENT_PASSWORD.REQUIRED),
    newPassword: Yup.string()
      .required(VALIDATION_MESSAGES.NEW_PASSWORD.REQUIRED)
      .min(8, VALIDATION_MESSAGES.NEW_PASSWORD.MIN_LENGTH),
    confirmPassword: Yup.string()
      .required(VALIDATION_MESSAGES.CONFIRM_PASSWORD.REQUIRED)
      .oneOf(
        [Yup.ref('newPassword')],
        VALIDATION_MESSAGES.CONFIRM_PASSWORD.MATCH
      ),
  });

  const initialValues: ResetPasswordFormValues = {
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  };

  const handleSubmit = async () => {
    if (formikRef.current) {
      const { validateForm, submitForm, setTouched } = formikRef.current;

      setIsSubmitted(true);
      setTouched({
        currentPassword: true,
        newPassword: true,
        confirmPassword: true,
      });

      const errors = await validateForm();

      if (Object.keys(errors).length === 0) {
        await submitForm();
      }
    }
  };

  return (
    <Modal
      maxWidth="xl"
      open={open}
      onClose={onClose}
      header="Reset Password"
      footer={
        <div className="flex items-center gap-4 w-full">
          <Button
            size="lg"
            onClick={onClose}
            variant="outlineLight"
            full
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            size="lg"
            onClick={handleSubmit}
            variant="primary"
            full
            disabled={isSubmitting}
          >
            Reset
          </Button>
        </div>
      }
    >
      <Formik
        innerRef={formikRef}
        initialValues={initialValues}
        validationSchema={validationSchema}
        validateOnMount={false}
        onSubmit={(values) => {
          onSubmit(values);
        }}
      >
        {({
          values,
          errors,
          touched,
          setFieldValue,
          setFieldTouched,
          validateField,
        }) => (
          <form className="mx-auto mb-10">
            <div className="space-y-6">
              {!UserRole && (
                <TextInput
                  size="sm"
                  className="!bg-gray-50"
                  label="Current Password"
                  name="currentPassword"
                  type="password"
                  placeholder="Enter New Password"
                  error={
                    isSubmitted &&
                    touched.currentPassword &&
                    errors.currentPassword
                      ? errors.currentPassword
                      : ''
                  }
                  value={values.currentPassword}
                  onChange={async (e) => {
                    await setFieldValue('currentPassword', e.target.value);
                    setFieldTouched('currentPassword', true);
                    validateField('currentPassword');
                  }}
                  onBlur={() => setFieldTouched('confirmPassword', true)}
                />
              )}
              <div>
                <TextInput
                  size="sm"
                  className="!bg-gray-50"
                  label="New Password"
                  name="newPassword"
                  type="password"
                  placeholder="Enter New Password"
                  error={
                    isSubmitted && touched.newPassword && errors.newPassword
                      ? errors.newPassword
                      : ''
                  }
                  value={values.newPassword}
                  onChange={async (e) => {
                    await setFieldValue('newPassword', e.target.value);
                    setFieldTouched('newPassword', true);
                    validateField('newPassword');
                  }}
                  onBlur={() => setFieldTouched('newPassword', true)}
                />
              </div>
              <div>
                <TextInput
                  size="sm"
                  className="!bg-gray-50"
                  label="Confirm New Password"
                  name="confirmPassword"
                  type="password"
                  placeholder="Enter New Password"
                  error={
                    isSubmitted &&
                    touched.confirmPassword &&
                    errors.confirmPassword
                      ? errors.confirmPassword
                      : ''
                  }
                  value={values.confirmPassword}
                  onChange={async (e) => {
                    await setFieldValue('confirmPassword', e.target.value);
                    setFieldTouched('confirmPassword', true);
                    validateField('confirmPassword');
                  }}
                  onBlur={() => setFieldTouched('confirmPassword', true)}
                />
              </div>
            </div>
          </form>
        )}
      </Formik>
    </Modal>
  );
};

export default ResetPasswordModal;
