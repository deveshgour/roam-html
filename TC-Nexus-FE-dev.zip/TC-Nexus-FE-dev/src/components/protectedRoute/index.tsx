'use client';

import { APP_ROUTE } from '@/constants/routes';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

interface ProtectedRouteProps {
  children: React.ReactNode;
}

const ProtectedRoute = ({ children }: ProtectedRouteProps) => {
  const router = useRouter();

  useEffect(() => {
    const getCookie = (name: string) => {
      const value = `; ${document.cookie}`;
      const parts = value.split(`; ${name}=`);
      if (parts.length === 2) return parts.pop()?.split(';').shift();
      return undefined;
    };

    const accessToken = getCookie('access_token');
    if (!accessToken) {
      router.push(APP_ROUTE.AUTH.LOGIN);
    }
  }, [router]);

  return <>{children}</>;
};

export default ProtectedRoute;
