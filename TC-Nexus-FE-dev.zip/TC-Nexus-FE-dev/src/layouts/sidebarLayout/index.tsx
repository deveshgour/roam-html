import { NavigationSidebar } from '@/components/sidebar';
import {
  SidebarProvider,
  SidebarInset,
  SidebarTrigger,
} from '@/components/sidebar/sidebar';
import { getRouteTitle, showBreadcrumb } from '@/constants/routeTitles';
import { usePathname } from 'next/navigation';
import { UserProfilePopover } from '@/components/userProfileDrawer';
import Icon from '@/components/coreUI/icon';

/**
 * Props for SidebarLayout component
 */
interface SidebarLayoutProps {
  children: React.ReactNode; // Children nodes to be rendered within the layout
  userProfile: any;
}

/**
 * SidebarLayout component that provides a sidebar with a collapsible trigger and main content area.
 *
 * @param {SidebarLayoutProps} props - The props for the SidebarLayout component.
 * @returns {JSX.Element} The rendered SidebarLayout component.
 */

const SidebarLayout: React.FC<SidebarLayoutProps> = ({
  children,
  userProfile,
}: SidebarLayoutProps) => {
  const pathname = usePathname();
  return (
    <SidebarProvider>
      {/* Main navigation sidebar */}
      <NavigationSidebar />
      <SidebarInset>
        {/* Header section with a trigger button for the sidebar */}
        <header className="z-50 mr-0 right-0 flex border-b border-gray-100 h-20 px-6 shrink-0 bg-white w-full items-center justify-between gap-2 transition-[width,height] ease-linear group-has-[[data-collapsible=icon]]/sidebar-wrapper:h-12">
          <div className="flex items-center gap-2 text-xs xs:text-[20px] text-black">
            <SidebarTrigger className="md:hidden">Trigger</SidebarTrigger>
            {showBreadcrumb(pathname) ? (
              <>
                <span className="text-base">Dashboard /</span>
                <span>{getRouteTitle(pathname).title}</span>
              </>
            ) : (
              <span>{getRouteTitle(pathname).title}</span>
            )}
          </div>
          <div className="ml-auto flex gap-x-2 items-center">
            <Icon
              iconName="bell"
              iconProps={{ className: `h-5 w-5 text-gray-500` }}
            />
            <UserProfilePopover
              isOpen={true}
              onClose={() => {}}
              userProfile={userProfile}
              loading={false}
            />
          </div>
        </header>
        {/* Main content area */}
        <div className="flex flex-1 flex-col gap-5 p-6 overflow-y-auto bg-[#F8FAFC]">
          {children}
        </div>
      </SidebarInset>
    </SidebarProvider>
  );
};

export default SidebarLayout;
