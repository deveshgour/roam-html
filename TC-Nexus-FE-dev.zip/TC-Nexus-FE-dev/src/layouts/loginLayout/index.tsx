import * as React from 'react';
import SwiperSlider from '@/components/loginSlider';
/**
 * A layout component for login pages.
 *
 * This component renders a full-screen layout with a left section containing a
 * swiper slider and a right section containing the login form.
 */
interface LoginLayoutProps {
  /**
   * The children elements to render inside the right section of the layout.
   */
  children: React.ReactNode;
}

/**
 * The LoginLayout component.
 *
 * @param {LoginLayoutProps} props The props for the component.
 * @returns {React.ReactElement} The rendered component.
 */
const LoginLayout: React.FC<LoginLayoutProps> = ({ children }) => {
  return (
    <main className="min-h-screen flex">
      {/* Left Section */}
      <div className="hidden sm:flex sm:w-1/2 bg-primary-800 text-white p-8 flex-col justify-between relative overflow-hidden">
        <div className="flex h-full items-center justify-center">
          <SwiperSlider />
        </div>
      </div>
      {/* Right Section */}
      <div className="w-full sm:w-1/2 flex p-7 flex-col">{children}</div>
    </main>
  );
};

export default LoginLayout;
