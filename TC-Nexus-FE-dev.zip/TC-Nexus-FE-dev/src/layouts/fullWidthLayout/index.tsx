import React from 'react';

interface FullWidthLayoutProps {
  children: React.ReactNode;
}

export default function FullWidthLayout({ children }: FullWidthLayoutProps) {
  return (
    <div className="min-h-screen w-full">
      <main className="w-full">{children}</main>
    </div>
  );
}
