'use client';

import {
  AUTH_ROUTES,
  PUBLIC_ROUTES,
  PROTECTED_ROUTES,
} from '@/constants/configs';
import LoginLayout from '@/layouts/loginLayout';
import SidebarLayout from '@/layouts/sidebarLayout';
import FullWidthLayout from '@/layouts/fullWidthLayout';
import { usePathname } from 'next/navigation';
import { UserProfileProvider } from '@/contexts/userProfileContext';

export default function LayoutWrapper({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();

  // Helper function to check if path matches route pattern
  const matchRoute = (path: string, pattern: string) => {
    // Convert route pattern to regex
    const regexPattern = pattern
      // Replace dynamic segments [id] with regex pattern
      .replace(/\[([^\]]+)\]/g, '[^/]+')
      // Escape forward slashes
      .replace(/\//g, '\\/');

    // Create regex that matches the entire path
    const regex = new RegExp(`^${regexPattern}`);
    return regex.test(path);
  };

  const isLoginPage = AUTH_ROUTES.some((route) => matchRoute(pathname, route));
  const isFullWidthPage = PUBLIC_ROUTES.some((route) =>
    matchRoute(pathname, route)
  );
  const isSidebarPage = PROTECTED_ROUTES.some((route) =>
    matchRoute(pathname, route)
  );

  if (isLoginPage) {
    return <LoginLayout>{children}</LoginLayout>;
  }

  if (isFullWidthPage) {
    return <FullWidthLayout>{children}</FullWidthLayout>;
  }

  if (isSidebarPage) {
    return (
      <UserProfileProvider>
        <SidebarLayout userProfile>{children}</SidebarLayout>
      </UserProfileProvider>
    );
  }

  return <>{children}</>;
}
