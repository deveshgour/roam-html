const ERROR_MESSAGES = {
  internalError: 'Something went wrong please try later',
};

const AUTH_MSG = {
  sessionExpired: 'Session expired',
  loginSuccess: 'You are successfully logged in.',
};

const FORGOT_PASSWORD_MSG = {
  mailSentSuccess: 'Sent reset password link successfully.',
};
const RESET_PASSWORD_MSG = {
  passwordResetSuccess: 'Password reset successfully.',
};

const CONFIRMATION_MESSAGES = {
  APPROVE_SALES_REPORT: 'Are you sure you want to approve this sales report?',
  DISAPPROVE_SALES_REPORT:
    'Are you sure you want to disapprove this sales report?',
  DELETE_SALES_REPORT:
    'Are you sure you want to permanently delete this sales report?',
  CANNOT_BE_UNDONE: 'This action cannot be undone.',
};

const VALIDATION_MESSAGES = {
  REQUIRED: '*Required.',
  VALID_EMAIL: 'Please enter a valid email address.',
  PASSWORD: {
    REQUIRED: 'Password is required',
    MIN_LENGTH: 'Password must be at least 8 characters',
    MATCH: 'Passwords must match',
  },
  CURRENT_PASSWORD: {
    REQUIRED: 'Current password is required',
  },
  NEW_PASSWORD: {
    REQUIRED: 'New password is required',
    MIN_LENGTH: 'Password must be at least 8 characters',
  },
  CONFIRM_PASSWORD: {
    REQUIRED: 'Confirm password is required',
    MATCH: 'Passwords must match',
  },
  NAME: {
    FIRST_REQUIRED: 'First name is required',
    LAST_REQUIRED: 'Last name is required',
    FIRST_MIN_LENGTH: 'First Name must be at least 3 characters.',
    FIRST_MAX_LENGTH: 'first Name cannot exceed 100 characters',
    LAST_MIN_LENGTH: 'Last Name must be at least 3 characters',
    LAST_MAX_LENGTH: 'Last Name cannot exceed 100 characters',
  },
  PHONE: {
    REQUIRED: 'Phone number is required',
    INVALID: 'Please enter a valid phone number',
  },
  EMAIL: {
    REQUIRED: 'Email is required',
    INVALID: 'Invalid email',
  },
  STATUS: {
    REQUIRED: 'Status is required',
  },
  ROLE: {
    REQUIRED: 'Role is required',
  },
  LOCATION: {
    REQUIRED: 'Location is required',
  },
  ROLE_LOCATION_PAIR: 'Duplicate role location combination not allowed',
  TEAM: {
    REQUIRED: 'Team is required',
    TEAM_NAME_REQUIRED: 'Team name is required',
    USER_REQUIRED: 'User is required',
    USER_SELECTED: 'Please select at least one user',
  },
  SALES_REP_NAME: {
    REQUIRED: 'Sales rep name is required',
  },
  DATE: {
    REQUIRED: 'Date is required',
  },
  LEAD_SCHEDULED: {
    REQUIRED: 'Lead scheduled is required',
  },
  LEADS_RAN: {
    REQUIRED: 'Leads ran is required',
  },
  APPOINTMENT_SCHEDULED: {
    REQUIRED: 'Follow up appointments scheduled is required',
  },
  JOBS_SOLD: {
    REQUIRED: 'Jobs sold is required',
  },
  ORDER_SOLD: {
    REQUIRED: 'Change orders sold/supplements is required',
  },
  TOTAL_SALES_AMOUNT: {
    REQUIRED: 'Total sales amount is required',
  },
  HOME_CANVASSED: {
    REQUIRED: 'Home canvassed is required',
  },
  DOORS_KNOCKED: {
    REQUIRED: 'Numbers of doors knocked is required',
  },
  DOORS_TO_DOORS_ENGAGE: {
    REQUIRED: 'Appointment from door-to-door engagements is required',
  },
  GOOGLE_REVIEWS: {
    REQUIRED: 'How many Google reviews did you receive? is required',
  },
  REFERRAL_EXISTING_CLIENT: {
    REQUIRED: 'Referral you receive from existing clients? is required',
  },
  YARD_SIGNS: {
    REQUIRED: 'How many yard signs did you put out? is required',
  },
  LOIS_SIGNED: {
    REQUIRED: 'Numbers of LOIs (Letters of Intent) signed is required',
  },
  CLAIMS_FILED: {
    REQUIRED: 'Number of claims filed is required',
  },
  ADJUSTER_MEETING: {
    REQUIRED: 'Numbers of adjuster meetings is required',
  },
  VALUE_MUST_BE_NUMBER: {
    REQUIRED: 'Value must be a number',
  },
  VALUE_MUST_BE_GREATER_THAN_ZERO: {
    REQUIRED: 'Value must be greater than 0',
  },
  NEW_CONSTRUCTION_BID: {
    COMMUNITY_REQUIRED: 'Community is required',
    BUILDERS_REQUIRED: 'Builders is required',
    TRADERS_REQUIRED: 'Trades required',
    PROJECTED_START_DATE_REQUIRED: 'Projected Start Date is required',
    PROJECTED_START_DATE_FORMAT: 'Date must be in YYYY-MM-DD format',
    NUMBER_OF_HOMES_REQUIRED: 'Number of Homes is required',
    NUMBER_OF_HOMES_INVALID: 'Must be a valid number',
    HOMES_POSITIVE: 'Homes must be a positive number',
    BID_PER_HOME_REQUIRED: 'Bid Per Home is required',
    BID_PER_HOME_INVALID: 'Must be a valid amount',
    BID_PER_HOME_POSITIVE: 'Bid per home must be a positive number',
    PROJECTED_BID_TOTAL_POSITIVE:
      'Projected bid total must be a positive number',
    PROJECTED_BID_TOTAL_REQUIRED: 'Projected bid total is required',
    PROFIT_BID_AT_REQUIRED: 'Profit Bid At is required',
    PROFIT_BID_AT_INVALID: 'Must be a valid percentage',
    PROFIT_PERCENT_MIN: 'Profit percentage must be at least 0',
    PROFIT_PERCENT_MAX: 'Profit percentage cannot exceed 100',
    PROFIT_PERCENT_REQUIRED: 'Profit percentage is required',
    PROJECTED_PROFIT_POSITIVE: 'Projected profit must be a positive number',
    PROJECTED_PROFIT_REQUIRED: 'Projected profit is required',
  },
} as const;

const TOAST_MESSAGES = {
  USER_STATUS_SUCCESS: 'User status updated successfully',
  USER_STATUS_ERROR: 'Failed to update user status',
  USER_DELETE_SUCCESS: 'User deleted successfully',
  USER_DELETE_ERROR: 'Failed to delete user',
  USER_UPDATE_SUCCESS: 'User updated successfully',
  USER_ADD_SUCCESS: 'User added successfully',
  USER_MODIFY_ERROR: 'Failed to add/update user',
  PASSWORD_RESET_SUCCESS: 'Password reset successfully',
  PASSWORD_RESET_ERROR: 'Failed to reset password',
  FILTER_UPDATE_ERROR: 'Failed to update search filters',
  DOWNLOAD_REPORT_ERROR: 'Failed to download report',
  REPORT_DELETE_SUCCESS: 'Report deleted successfully',
  REPORT_DELETE_ERROR: 'Failed to delete report',
  FETCH_REPORT_ERROR: 'Failed to fetch sales report details',
  UPDATE_REPORT_ERROR: 'Failed to update sales report details',
  ADD_REPORT_ERROR: 'Failed to add sales report details',
  UPDATE_REPORT_SUCCESS: 'Sales report details updated successfully',
  ADD_REPORT_SUCCESS: 'Sales report details added successfully',
  ROLE_DELETE_SUCCESS: 'Role deleted successfully',
  ROLE_DELETE_ERROR: 'Failed to delete Role',
  ROLE_UPDATE_SUCCESS: 'Role updated successfully',
  ROLE_ADD_SUCCESS: 'Role added successfully',
  ROLE_MODIFY_ERROR: 'Failed to add/update Role',
  ROLE_FETCH_ERROR: 'Failed to fetch role details',
  SALES_REPORT_STATUS_SUCCESS: 'Sales report status updated successfully',
  SALES_REPORT_STATUS_ERROR: 'Failed to update sales report status',
  TEAM_DELETE_SUCCESS: 'Team deleted successfully',
  TEAM_DELETE_ERROR: 'Failed to delete team',
  TEAM_ADD_SUCCESS: 'Team added successfully',
  TEAM_MODIFY_ERROR: 'Failed to add/update team',
  TEAM_UPDATE_SUCCESS: 'Team updated successfully',
  UPDATE_SUCCESS: 'Bid updated successfully',
  CREATE_SUCCESS: 'Bid created successfully',
  OPERATION_ERROR: 'Operation failed',
  DELETE_SUCCESS: 'Bid deleted successfully',
  DELETE_ERROR: 'Failed to delete bid',
  EXPORT_SUCCESS: 'Export successful',
  EXPORT_ERROR: 'Export failed',
  // Marketing Leads Messages
  MARKETING_LEAD_DELETE_SUCCESS: 'Marketing lead deleted successfully',
  MARKETING_LEAD_DELETE_ERROR: 'Failed to delete marketing lead',
  MARKETING_LEAD_UPDATE_SUCCESS: 'Marketing lead updated successfully',
  MARKETING_LEAD_ADD_SUCCESS: 'Marketing lead added successfully',
  MARKETING_LEAD_MODIFY_ERROR: 'Failed to add/update marketing lead',
  MARKETING_LEAD_FETCH_ERROR: 'Failed to fetch marketing lead details',
} as const;

export {
  ERROR_MESSAGES,
  AUTH_MSG,
  VALIDATION_MESSAGES,
  TOAST_MESSAGES,
  FORGOT_PASSWORD_MSG,
  RESET_PASSWORD_MSG,
  CONFIRMATION_MESSAGES,
};
