export const APP_ROUTE = {
  ROOT: '/',
  AUTH: {
    LOGIN: '/auth/login',
    FORGOT_PASSWORD: '/auth/forgot-password',
    RESET_PASSWORD: '/auth/reset-password',
    VERIFY_EMAIL: '/auth/verify-email',
  },
  DASHBOARD: '/dashboard',
  FINANCIAL: {
    SALES: '/financial/sales',
    PROFIT: '/financial/profit',
  },
  MARKETING: {
    LEADS: '/marketing/leads',
    CAC: '/marketing/cac',
  },
  OPERATIONS: {
    JOBS: '/operations',
  },
  COMPONENTS: '/components',
  USERS: {
    MANAGEMENT: '/users/management',
  },
  TEAMS: {
    MANAGEMENT: '/teams/management',
  },
  DATA_FORM: {
    SALES_REPORT: '/data-form/sales-report',
    ADD_SALES_REPORT: '/data-form/sales-report/add',
    EDIT_SALES_REPORT: '/data-form/sales-report/[...params]',
    EDIT_REPORT: (id: string) => `/data-form/sales-report/edit/${id}`,
    NEW_CONSTRUCTION_BID: '/data-form/new-construction-bid',
    ADD_NEW_CONSTRUCTION_BID: '/data-form/new-construction-bids/add',
    // MARKETING_LEAD_FORM: '/data-form/marketing-lead-form',
    MARKETING_LEADS: '/data-form/marketing-leads',
  },
  UNAUTHORISED: '/unauthorised',
  ROLES: {
    MANAGEMENT: '/roles/management',
  },
};
