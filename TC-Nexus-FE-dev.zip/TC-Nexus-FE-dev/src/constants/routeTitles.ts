import { APP_ROUTE } from './routes';

const routeTitles: Record<string, { title: string; showBreadcrumb: boolean }> =
  {
    [APP_ROUTE.DASHBOARD]: {
      title: 'Dashboard',
      showBreadcrumb: false,
    },
    [APP_ROUTE.USERS.MANAGEMENT]: {
      title: 'User Management',
      showBreadcrumb: false,
    },
    [APP_ROUTE.ROLES.MANAGEMENT]: {
      title: 'Role Management',
      showBreadcrumb: false,
    },
    [APP_ROUTE.FINANCIAL.SALES]: {
      title: 'Sales Revenue',
      showBreadcrumb: true,
    },
    [APP_ROUTE.OPERATIONS.JOBS]: {
      title: 'Operations',
      showBreadcrumb: false,
    },
    [APP_ROUTE.FINANCIAL.PROFIT]: {
      title: 'Profit Margins',
      showBreadcrumb: true,
    },
    [APP_ROUTE.MARKETING.LEADS]: {
      title: 'Leads & Conversion',
      showBreadcrumb: true,
    },
    [APP_ROUTE.MARKETING.CAC]: {
      title: 'Customer Acquisition Cost (CAC)',
      showBreadcrumb: true,
    },
    [APP_ROUTE.DATA_FORM.SALES_REPORT]: {
      title: 'Master Sales Report',
      showBreadcrumb: false,
    },
    [APP_ROUTE.DATA_FORM.ADD_SALES_REPORT]: {
      title: 'Add Sales Report',
      showBreadcrumb: false,
    },
    [APP_ROUTE.DATA_FORM.EDIT_SALES_REPORT]: {
      title: 'Update Sales Master Report',
      showBreadcrumb: false,
    },
    [APP_ROUTE.DATA_FORM.NEW_CONSTRUCTION_BID]: {
      title: 'New Construction Bids Outlook',
      showBreadcrumb: false,
    },
    [APP_ROUTE.DATA_FORM.MARKETING_LEADS]: {
      title: 'Marketing Lead',
      showBreadcrumb: false,
    },
    [APP_ROUTE.UNAUTHORISED]: {
      title: 'Access Denied',
      showBreadcrumb: false,
    },
    [APP_ROUTE.TEAMS.MANAGEMENT]: {
      title: 'Team Management',
      showBreadcrumb: false,
    },
  };

export const getRouteTitle = (path: string) => {
  // First try exact match
  if (routeTitles[path]) {
    return routeTitles[path];
  }

  // If no exact match, try matching dynamic routes
  const dynamicRoute = Object.keys(routeTitles).find((route) => {
    const dynamicPattern = route
      .replace(/\[\.\.\.params\]/g, '.*') // Handle [...params]
      .replace(/\[(\w+)\]/g, '[^/]+'); // Handle [id] or other dynamic segments

    return new RegExp(`^${dynamicPattern}$`).test(path);
  });

  return dynamicRoute
    ? routeTitles[dynamicRoute]
    : { title: path, showBreadcrumb: false };
};

export const showBreadcrumb = (path: string): boolean => {
  return routeTitles[path]?.showBreadcrumb || false;
};
