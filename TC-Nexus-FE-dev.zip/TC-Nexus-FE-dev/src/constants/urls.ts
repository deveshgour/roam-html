/**
 * Base URL for API requests
 * @constant
 */
const API_BASE_URL = 'https://api.dev.tcb-dashboard.com/';
// const API_BASE_URL = 'http://localhost:8000/';

/**
 * URLs for authentication API endpoints
 * @constant
 */
const AUTH_API_URLS = {
  /**
   * Login endpoint
   * @constant
   */
  login: `/users/login`,
  authLogin: `/auth/login`,
  /**
   * Logout endpoint
   * @constant
   */
  logout: `/users/logout`,
  forgotPassword: `/users/forgot-password`,
  resetPassword: `/users/reset-password`,
};

const USER_API_URLS = {
  getUsers: '/users/list',
  updateUserStatus: (userId: string) => `/users/activate/${userId}`,
  updateUser: (userId: string) => `/users/update/${userId}`,
  resetPassword: (userId: string) => `/users/force-reset-password/${userId}`,
  verifyEmail: (encodedEmail: string) =>
    `/auth/verify-email?email=${encodedEmail}`,
  deleteUser: (userId: string) => `/users/delete/${userId}`,
  addUser: '/users/register',
  userProfile: '/users/me',
  getUserRoleDetails: (userId: string) => `/roles/user/${userId}`,
  getLocationsList: '/users/all-locations-list',
  getRolesList: 'users/all-roles-list',
};

const ROLE_API_URLS = {
  getRoles: '/roles/list',
  updateRole: (roleId: string) => `/roles/update/${roleId}`,
  deleteRole: (roleId: string) => `/roles/delete/${roleId}`,
  addRole: '/roles/register',
  getRoleById: (roleId: string) => `/roles/list/${roleId}`,
};

const COMMON_API_URLS = {
  locations: '/jobs/locations',
  salesReps: '/jobs/representatives',
  allLocations: '/users/all-locations-list',
};

const TEAM_API_URLS = {
  getTeams: '/teams',
  addTeam: '/teams/',
  updateTeam: (teamId: string) => `/teams/${teamId}`,
  deleteTeam: (teamId: string) => `/teams/${teamId}`,
};
const NEW_CONSTRUCTION_BIDS = {
  listConstructionBid: '/construction-bids/list',
  addConstructionBid: '/construction-bids/register',
  updateConstructionBid: (id: string) => `/construction-bids/update/${id}`,
  deleteConstructionBid: (id: string) => `/construction-bids/delete/${id}`,
  exportConstructionBids: '/construction-bids/export',
  allTraders: '/construction-bids/trades/list',
  allBuilders: '/construction-bids/builder/list',
  allCommunities: '/construction-bids/community/list',
};

const FINANCIAL_API_URLS = {
  highNumbers: '/jobs/sales-revenue/high-numbers',
  salesRevenueBarChart: '/jobs/sales-revenue/bar-chart-data',
  salesRevenueLineChart: '/jobs/sales-revenue/line-chart-data',
  salesRevenuePieChart: '/jobs/sales-revenue/pie-chart-data',
  leastPerforming: '/jobs/sales-revenue/least-performance',
  revenueType: '/jobs/revenue-types',
  downloadReport: 'jobs/sales-revenue/export',
  performanceReport: '/jobs/sales-revenue/performance',
  jobListing: '/jobs/sales-revenue/job-listing',
  downloadPerformanceReport: 'jobs/sales-reps/export',
  manualSalesReport: '/leads/sales-manual',
  downloadManualSalesReport: 'leads/sales-manual/export',
  deleteSalesReport: (id: string) => `/leads/sales-manual/${id}`,
  createSalesReport: '/leads/sales-manual',
  updateSalesReport: (id: string) => `/leads/sales-manual/${id}`,
  getSalesReportById: (id: string) => `/leads/sales-manual/report/${id}`,
  exploreDataReport: '/jobs/explore-data',
  exploreDownloadReport: 'jobs/explore-data/export',
  toggleSalesReportApprovalById: (id: string) =>
    `/leads/sales-manual/${id}/approve`,
};

/**
 * URLs for marketing API endpoints
 * @constant
 */
const MARKETING_API_URLS = {
  highNumbers: '/leads/high-numbers',
  performanceReport: '/leads/performance',
  salesFunnelChart: '/leads/funnel-chart',
  leadSourceReport: '/leads/source-details',
  SourceJobDetailReport: '/leads/source-job-details',
  downloadSourceReport: 'leads/source-details/export',
  downloadPerformanceReport: 'leads/performance/export',
  downloadSourceDetailReport: 'leads/source-job-details/export',
  exploreDataReport: '/leads/explore-data',
  exploreDownloadReport: 'leads/explore-data/export',
  downloadReport: 'leads/export',
};

const MARKETING_LEAD_API_URLS = {
  getMarketingLead: '/marketing-lead/list',
  createMarketingLead: '/marketing-lead/register',
  updateMarketingLead: (id: string) => `/marketing-lead/update/${id}`,
  deleteMarketingLead: (id: string) => `/marketing-lead/delete/${id}`,
  getAllLeadSources: '/marketing-lead/source/list',
  getAllLocations: '/users/all-locations-list',
  downloadMarketingLeads: '/marketing-lead/export',
};

/**
 * URLs for marketing CAC API endpoints
 * @constant
 */
const MARKETING_CAC_API_URLS = {
  highNumbers: '/cac/high-numbers',
  barChartData: '/cac/bar-chart-data',
  lineChartData: '/cac/line-chart-data',
  sourceBarChartData: '/cac/customers-by-source',
  sourcePerformanceData: '/cac/source-performance-data',
  downloadSourceReport: 'cac/source-performance-data/export',
  sourceDetailData: 'cac/customer-details',
  downloadSourceViewReport: 'cac/customer-details/export',
  downloadReport: 'cac/export',
  exploreDownloadReport: 'cac/explore-data/export',
  barChartPopupData: '/cac/bar-chart-data/popup',
  exploreDataReport: '/cac/explore-data',
};

/**
 * URLs for Operations API endpoints
 * @constant
 */
const OPERATIONS_API_URLS = {
  highNumbers: '/operations/high-numbers',
};

/**
 * Exports the API base URL and authentication API URLs
 * @export
 */
export {
  ROLE_API_URLS,
  API_BASE_URL,
  AUTH_API_URLS,
  USER_API_URLS,
  COMMON_API_URLS,
  FINANCIAL_API_URLS,
  NEW_CONSTRUCTION_BIDS,
  MARKETING_API_URLS,
  MARKETING_CAC_API_URLS,
  MARKETING_LEAD_API_URLS,
  TEAM_API_URLS,
  OPERATIONS_API_URLS,
};
