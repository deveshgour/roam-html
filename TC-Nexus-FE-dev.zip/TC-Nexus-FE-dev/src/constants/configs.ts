import { APP_ROUTE } from './routes';
import { userPermissions } from '@/components/userProfileInfo/types';

const TC_BACKER_USER_DATA = 'tc_backer_user_data';
const TC_BACKER_USER_PERMISSIONS = 'tc_backer_user_permissions';

const DEFAULT_DATE_FORMAT = 'MMM d, yyyy';

export interface NavItem {
  title: string;
  url: string;
  icon?: string;
  isActive?: boolean;
  items?: NavItem[];
  permissions?: {
    anyOf?: (keyof userPermissions)[];
    allOf?: (keyof userPermissions)[];
  };
}

const SIDEBAR_MENU: NavItem[] = [
  {
    title: 'Dashboard',
    url: APP_ROUTE.DASHBOARD,
    icon: 'dashboard',
  },
  {
    title: 'Financial Overview',
    url: APP_ROUTE.FINANCIAL.SALES,
    icon: 'dollarSignOutline',
    isActive: true,
    permissions: {
      anyOf: ['sales_revenue', 'profit_margin_retail', 'profit_margin_nc'],
    },
    items: [
      {
        title: 'Sales Revenue',
        url: APP_ROUTE.FINANCIAL.SALES,
        permissions: {
          anyOf: ['sales_revenue'],
        },
      },
      {
        title: 'Profit Margins',
        url: APP_ROUTE.FINANCIAL.PROFIT,
        permissions: {
          anyOf: ['profit_margin_retail', 'profit_margin_nc'],
        },
      },
    ],
  },
  {
    title: 'Marketing Analytics',
    url: APP_ROUTE.MARKETING.LEADS,
    icon: 'lineChart',
    isActive: true,
    permissions: {
      anyOf: ['lead_conversion', 'cac'],
    },
    items: [
      {
        title: 'Leads & Conversion',
        url: APP_ROUTE.MARKETING.LEADS,
        permissions: {
          anyOf: ['lead_conversion'],
        },
      },
      {
        title: 'Customer Acquisition Cost (CAC)',
        url: APP_ROUTE.MARKETING.CAC,
        permissions: {
          anyOf: ['cac'],
        },
      },
    ],
  },
  {
    title: 'Operations',
    url: APP_ROUTE.OPERATIONS.JOBS,
    icon: 'operations',
    permissions: {
      anyOf: ['operations'],
    },
  },
  {
    title: 'Teams & Permissions',
    url: APP_ROUTE.USERS.MANAGEMENT,
    icon: 'lineChart',
    isActive: true,
    permissions: {
      anyOf: ['system_administration'],
    },
    items: [
      {
        title: 'User Management',
        url: APP_ROUTE.USERS.MANAGEMENT,
        permissions: {
          anyOf: ['system_administration'],
        },
      },
      {
        title: 'Role Management',
        url: APP_ROUTE.ROLES.MANAGEMENT,
        permissions: {
          anyOf: ['system_administration'],
        },
      },
      {
        title: 'Team Management',
        url: APP_ROUTE.TEAMS.MANAGEMENT,
        permissions: {
          anyOf: ['system_administration'],
        },
      },
    ],
  },
  {
    title: 'Data Forms',
    url: APP_ROUTE.DATA_FORM.SALES_REPORT,
    icon: 'rotateOutline',
    isActive: true,
    permissions: {
      anyOf: ['sales_report', 'new_construction_bids', 'marketing_lead'],
    },
    items: [
      {
        title: 'Sales Report',
        url: APP_ROUTE.DATA_FORM.SALES_REPORT,
        permissions: {
          anyOf: ['sales_report'],
        },
      },
      {
        title: 'New Construction Bids',
        url: APP_ROUTE.DATA_FORM.NEW_CONSTRUCTION_BID,
        permissions: {
          anyOf: ['new_construction_bids'],
        },
      },
      {
        title: 'Marketing Lead Form',
        url: APP_ROUTE.DATA_FORM.MARKETING_LEADS,
        permissions: {
          anyOf: ['marketing_lead'],
        },
      },
    ],
  },
];

const AUTH_ROUTES = [APP_ROUTE.AUTH.LOGIN];
const PUBLIC_ROUTES = [APP_ROUTE.COMPONENTS];
const PROTECTED_ROUTES = [
  APP_ROUTE.DASHBOARD,
  APP_ROUTE.USERS.MANAGEMENT,
  APP_ROUTE.ROLES.MANAGEMENT,
  APP_ROUTE.TEAMS.MANAGEMENT,
  APP_ROUTE.FINANCIAL.SALES,
  APP_ROUTE.FINANCIAL.PROFIT,
  APP_ROUTE.MARKETING.LEADS,
  APP_ROUTE.MARKETING.CAC,
  APP_ROUTE.OPERATIONS.JOBS,
  APP_ROUTE.DATA_FORM.SALES_REPORT,
  APP_ROUTE.DATA_FORM.ADD_SALES_REPORT,
  APP_ROUTE.DATA_FORM.EDIT_SALES_REPORT,
  APP_ROUTE.DATA_FORM.NEW_CONSTRUCTION_BID,
  APP_ROUTE.DATA_FORM.MARKETING_LEADS,
  APP_ROUTE.UNAUTHORISED,
];

const LOCATIONS = [
  { value: 'ny', label: 'New York' },
  { value: 'sf', label: 'San Francisco' },
  { value: 'la', label: 'Los Angeles' },
];

const PAGE_SIZE = [5, 10, 20, 50];

const SORTING_TYPES = {
  ASC: 'asc',
  DESC: 'desc',
  NONE: 'none',
};

const TIME_PERIOD_TYPES = {
  WEEKLY: 'weekly',
  MONTHLY: 'monthly',
  QUARTERLY: 'quarterly',
  YEARLY: 'yearly',
};

const TIME_PERIOD_OPTIONS = {
  WEEKLY: 'Week',
  MONTHLY: 'Month',
  QUARTERLY: 'Quarter',
  YEARLY: 'Year',
};

const SCREEN_NAME = {
  FINANCIAL_OVERVIEW: 'sales_revenue',
  CAC: 'cac',
  MARKETING_LEADS: 'lead_conversion',
  MARKETING_ANALYTICS: 'sales_analytics',
  SALES_REPORT: 'sales_report',
  OPERATIONS: 'operations',
};

const ROLE_TYPE = {
  SALES_REP: 'sales_rep',
  MANAGER: 'manager',
  ADMIN: 'admin',
};

export {
  TC_BACKER_USER_DATA,
  DEFAULT_DATE_FORMAT,
  SIDEBAR_MENU,
  AUTH_ROUTES,
  PUBLIC_ROUTES,
  PROTECTED_ROUTES,
  LOCATIONS,
  PAGE_SIZE,
  SORTING_TYPES,
  SCREEN_NAME,
  TC_BACKER_USER_PERMISSIONS,
  TIME_PERIOD_TYPES,
  TIME_PERIOD_OPTIONS,
  ROLE_TYPE,
};
