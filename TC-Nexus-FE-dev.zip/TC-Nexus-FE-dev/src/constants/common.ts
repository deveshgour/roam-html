const EMAIL_PATTERN = /^[\w\-.]+(\+\w+)?@([\w-]+\.)+[\w-]{2,}$/;
const PHONE_PATTERN = /^\d{10}$/;

export { EMAIL_PATTERN, PHONE_PATTERN };
