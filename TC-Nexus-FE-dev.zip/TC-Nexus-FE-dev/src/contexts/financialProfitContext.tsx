import {
  BarChartData,
  ErrorStates,
  InfoCardProps,
  LoadingData,
} from '@/app/financial/profit/newConstruction/types';
import {
  transformBarChartData,
  transformInfoCardsData,
  tooltipFormatter,
} from '@/utils/profitConstructionTransformData';
import {
  useContext,
  createContext,
  useState,
  ReactNode,
  useEffect,
} from 'react';

interface FinancialProfitContextType {
  infoCards: InfoCardProps[] | null;
  loading: LoadingData;
  errors: ErrorStates | null;
  barChartData: BarChartData | null;
  tooltipFormatter: () => string;
}

// Create context
export const FinancialProfitContext = createContext<
  FinancialProfitContextType | undefined
>(undefined);

export const FinancialProfitProvider: React.FC<{
  children: ReactNode;
  // eslint-disable-next-line react/prop-types
}> = ({ children }) => {
  // states
  const [infoCardsData, setInfoCardsData] = useState<InfoCardProps[] | null>(
    null
  );
  const [barChartData, setBarChartData] = useState<BarChartData | null>(null);

  // loading states
  const [loadingStates, setLoadingStates] = useState<LoadingData>({
    infoCards: true,
    barChart: true,
  });

  const [errors, setErrors] = useState<ErrorStates>({
    infoCards: null,
    barChart: null,
  });

  // Mock API function to return dummy data
  const getHighNumbers = async () => {
    // Simulating API delay
    await new Promise((resolve) => setTimeout(resolve, 500));

    return {
      data: {
        revenue: `$8,850,000`,
        profit: `$3,710,000`,
        paymentsReceived: `$7,965,000`,
        accountsPayable: `$885,000`,
        credits: `$270,000`,
        commission: `$442,500`,
        completedJobs: `882`,
        inProgressJobs: `307`,
      },
    };
  };

  // Mock API function to return bar chart dummy data
  const getBarChartData = async () => {
    // Simulating API delay
    await new Promise((resolve) => setTimeout(resolve, 500));
    return {
      data: [
        { expense: 'Bel Air Pro.', revenue: 8000, profit: 1500 },
        { expense: 'BrookField', revenue: 2000, profit: 1200 },
        { expense: 'Five Homes', revenue: 4500, profit: 1000 },
        { expense: 'Evergreen', revenue: 6000, profit: 2000 },
        { expense: 'Gem Craft', revenue: 5000, profit: 4500 },
        { expense: 'Inch&Co', revenue: 4500, profit: 4500 },
        { expense: 'Keller Construction', revenue: 7500, profit: 5000 },
        { expense: 'Khov', revenue: 3000, profit: 1000 },
        { expense: 'Lennar', revenue: 1500, profit: 8000 },
        { expense: 'Richmar', revenue: 8500, profit: 7500 },
        { expense: 'Ryan Homes', revenue: 3000, profit: 1500 },
        { expense: 'Steel Work', revenue: 6000, profit: 1000 },
        { expense: 'Stony Brooke', revenue: 5000, profit: 2000 },
        { expense: 'Pinnacle', revenue: 5500, profit: 3500 },
        { expense: 'TOA', revenue: 6000, profit: 3000 },
      ],
    };
  };

  // Fetch info cards data
  const fetchInfoCards = async () => {
    try {
      setLoadingStates((prev) => ({ ...prev, infoCards: true }));
      const response = await getHighNumbers();
      const transformedData = transformInfoCardsData(response?.data);
      setInfoCardsData(transformedData);
      setErrors((prev) => ({ ...prev, infoCards: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, infoCards: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, infoCards: false }));
    }
  };

  // Fetch bar chart data
  const fetchBarChartData = async () => {
    try {
      setLoadingStates((prev) => ({ ...prev, barChart: true }));
      const response = await getBarChartData();
      const transformedData = transformBarChartData(
        response?.data
      ) as BarChartData | null;
      setBarChartData(transformedData);
      setErrors((prev) => ({ ...prev, barChart: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, barChart: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, barChart: false }));
    }
  };

  useEffect(() => {
    fetchInfoCards();
    fetchBarChartData();
  }, []);

  return (
    <FinancialProfitContext.Provider
      value={{
        infoCards: infoCardsData,
        loading: loadingStates,
        errors: errors,
        barChartData: barChartData,
        tooltipFormatter,
      }}
    >
      {children}
    </FinancialProfitContext.Provider>
  );
};

export const useFinancialProfitContext = () => {
  const context = useContext(FinancialProfitContext);
  if (!context) {
    throw new Error(
      'useFinancialProfitContext must be used within a FinancialProfitProvider'
    );
  }
  return context;
};
