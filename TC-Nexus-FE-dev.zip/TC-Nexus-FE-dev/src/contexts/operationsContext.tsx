import {
  ErrorStates,
  FilterOptions,
  FilterState,
  InfoCardProps,
  LoadingData,
} from '@/app/operations/types';
import { SCREEN_NAME } from '@/constants/configs';
import { getLocations, getSalesReps } from '@/services/common';
import { getHighNumbers } from '@/services/operationReport';
import { transformInfoCardsData } from '@/utils/operationTransformData';
import {
  useContext,
  createContext,
  useState,
  ReactNode,
  useEffect,
  useRef,
} from 'react';

interface OperationContextType {
  infoCards: InfoCardProps[] | null;
  loading: LoadingData;
  errors: ErrorStates | null;
  filters: FilterState;
  isFilterLoading: boolean;
  // eslint-disable-next-line no-unused-vars
  updateFilters: (newFilters: Partial<FilterState>) => void;
  filterOptions: FilterOptions | null;
}

// Create context
export const OperationContext = createContext<OperationContextType | undefined>(
  undefined
);

export const OperationProvider: React.FC<{
  children: ReactNode;
  // eslint-disable-next-line react/prop-types
}> = ({ children }) => {
  const isMounted = useRef(false);
  const [isFilterLoading, setIsFilterLoading] = useState(false);
  // states
  const [infoCardsData, setInfoCardsData] = useState<InfoCardProps[] | null>(
    null
  );

  // loading states
  const [loadingStates, setLoadingStates] = useState<LoadingData>({
    infoCards: true,
  });

  const [errors, setErrors] = useState<ErrorStates>({
    infoCards: null,
  });

  // Filter states
  const [filters, setFilters] = useState<FilterState>({
    dateRange: null,
    location: [],
    salesRep: [],
  });

  const [filterOptions, setFilterOptions] = useState<FilterOptions>({
    locations: [],
    salesReps: [],
  });

  // Filter update handler
  const updateFilters = (newFilters: Partial<FilterState>) => {
    setIsFilterLoading(false);
    setFilters((prev) => ({ ...prev, ...newFilters }));
  };

  // Fetch filter options
  const fetchFilterOptions = async () => {
    try {
      setLoadingStates((prev) => ({ ...prev, filterOptions: true }));
      const results = await Promise.allSettled([
        getLocations(SCREEN_NAME.OPERATIONS),
        getSalesReps(SCREEN_NAME.OPERATIONS),
      ]);
      const [locationsResult, salesRepsResult] = results;
      setFilterOptions({
        locations:
          locationsResult?.status === 'fulfilled' ? locationsResult?.value : [],
        salesReps:
          salesRepsResult?.status === 'fulfilled' ? salesRepsResult?.value : [],
      });

      // Set error if either request failed
      if (results.some((result) => result.status === 'rejected')) {
        const error = new Error('Failed to fetch some filter options');
        setErrors((prev) => ({ ...prev, filterOptions: error }));
      } else {
        setErrors((prev) => ({ ...prev, filterOptions: null }));
      }
    } catch (error) {
      setErrors((prev) => ({ ...prev, filterOptions: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, filterOptions: false }));
    }
  };

  const getQueryParams = (filters: FilterState): string => {
    const queryParams = new URLSearchParams();

    // Check if location is not empty before appending
    if (filters.location && filters.location.length > 0) {
      queryParams.append('location_id', filters.location.toString());
    }

    if (filters.salesRep && filters.salesRep.length > 0) {
      queryParams.append('sales_rep_id', filters.salesRep.toString());
    }

    if (filters?.dateRange && filters?.dateRange[0] && filters.dateRange[1]) {
      queryParams.append(
        'start_date',
        filters?.dateRange[0]?.toLocaleDateString('en-CA')
      );
      queryParams.append(
        'end_date',
        filters?.dateRange[1]?.toLocaleDateString('en-CA')
      );
    }
    return queryParams.toString();
  };

  // Fetch info cards data
  const fetchInfoCards = async () => {
    try {
      setLoadingStates((prev) => ({ ...prev, infoCards: true }));
      const queryString = getQueryParams(filters);
      const response = await getHighNumbers(queryString);
      const transformedData = transformInfoCardsData(response?.data);
      setInfoCardsData(transformedData);
      setErrors((prev) => ({ ...prev, infoCards: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, infoCards: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, infoCards: false }));
      setIsFilterLoading(false);
    }
  };

  // Update the initial effect to use the mount ref
  useEffect(() => {
    if (!isMounted.current) {
      fetchFilterOptions();
      isMounted.current = true;
    }
  }, []);

  // eslint-disable-next-line consistent-return
  useEffect(() => {
    if (isMounted.current) {
      const timeoutId = setTimeout(() => {
        fetchInfoCards();
      }, 1000); // Adjust the delay as needed

      return () => clearTimeout(timeoutId); // Cleanup function to clear the timeout
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters]);

  return (
    <OperationContext.Provider
      value={{
        infoCards: infoCardsData,
        loading: loadingStates,
        errors: errors,
        filters,
        isFilterLoading,
        updateFilters,
        filterOptions,
      }}
    >
      {children}
    </OperationContext.Provider>
  );
};

export const useOperationContext = () => {
  const context = useContext(OperationContext);
  if (!context) {
    throw new Error(
      'useOperationContext must be used within a OperationProvider'
    );
  }
  return context;
};
