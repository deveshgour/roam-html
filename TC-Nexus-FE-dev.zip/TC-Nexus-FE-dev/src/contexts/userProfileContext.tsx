import React, { createContext, useContext, useEffect, useState } from 'react';
import { getUserProfile } from '@/services/user'; // Import your API call
import {
  ProfileData,
  userPermissions,
} from '@/components/userProfileInfo/types'; // Import your ProfileData type
import {
  formatUserPermissionsData,
  formatUserProfileData,
} from '@/types/utils/apiFormatters';
import { getUserRoles } from '@/services/role';
import { setCookie } from '@/utils/cookies';
import { TC_BACKER_USER_PERMISSIONS } from '@/constants/configs';

// Define the context shape
interface UserProfileContextType {
  user: ProfileData | null;
  permission: userPermissions | null;
  loading: boolean;
  fetchUserProfile: () => Promise<void>;
}

// Create context
export const UserProfileContext = createContext<
  UserProfileContextType | undefined
>(undefined);

// Provider Component
export const UserProfileProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [userProfile, setUserProfile] = useState<ProfileData | null>(null);
  const [userPermission, setUserPermission] = useState<userPermissions | null>(
    null
  );
  const [loading, setLoading] = useState<boolean>(true);

  // Fetch user profile

  const fetchUserProfile = async () => {
    setLoading(true);
    try {
      const response = await getUserProfile(); // API call

      setUserProfile(formatUserProfileData(response));
    } catch (error) {
      console.error('Error fetching user profile:', error);
      setUserProfile(null);
    } finally {
      setLoading(false);
    }
  };

  const getUserRolesDetails = async () => {
    const userId = userProfile?.userId;
    try {
      if (userId) {
        const response = await getUserRoles(userId); // API call
        setUserPermission(
          formatUserPermissionsData(response?.data?.permissions_summary)
        );
      }
    } catch (error) {
      console.error('Error fetching user roles details:', error);
      setUserPermission(null);
    } finally {
    }
  };

  if (userPermission) {
    // Set the user data in local storage
    setCookie(TC_BACKER_USER_PERMISSIONS, JSON.stringify(userPermission));
  }

  useEffect(() => {
    fetchUserProfile();
  }, []);

  useEffect(() => {
    if (!userProfile) {
      return;
    }
    getUserRolesDetails();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userProfile]);

  return (
    <UserProfileContext.Provider
      value={{
        user: userProfile,
        permission: userPermission,
        loading,
        fetchUserProfile,
      }}
    >
      {children}
    </UserProfileContext.Provider>
  );
};

// Custom Hook to Use Context
export const useUserProfile = () => {
  const context = useContext(UserProfileContext);
  if (!context) {
    throw new Error('useUserProfile must be used within a UserProfileProvider');
  }
  return context;
};
