import React, {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react';
import {
  ErrorStates,
  InfoCardData,
  LoadingData,
  BarChartData,
  LineChartData,
  SourceBarChartData,
  LeadSourceTableData,
  PaginationState,
  LeadSourceDetailData,
  FilterState,
  FilterOptions,
  ExploreTableData,
} from '@/app/marketing/cac/types';
import {
  getBarChartData,
  getBarChartPopupData,
  getDownloadReport,
  getDownloadSourceReport,
  getDownloadSourceViewReport,
  getExploreData,
  getExploreDownloadReport,
  getHighNumbers,
  getLineChartData,
  getSourceBarChartData,
  getSourceDetailData,
  getSourcePerformanceData,
} from '@/services/cacReport';
import {
  transformBarChartData,
  transformInfoCardsData,
  tooltipFormatter,
  transformTrendChartData,
  labelsFormatter,
  secondaryLabelsFormatter,
  trendTooltipFormatter,
  transformSourceBarChartData,
  sourceTooltipFormatter,
  transformLeadSourceTableData,
  transformSourceDetailData,
  transformBarChartPopupData,
  popupTooltipFormatter,
  transformExploreData,
} from '@/utils/cacTransformData';
import { SortingState, SortingTypes, TimePeriod } from '@/types/common';
import { SCREEN_NAME, SORTING_TYPES } from '@/constants/configs';
import { showErrorMsg } from '@/utils/notifications';
import { TOAST_MESSAGES } from '@/constants/messages';
import { getLocations } from '@/services/common';

// Define the context shape
interface MarketingCACContextType {
  infoCards: InfoCardData[] | null;
  loading: LoadingData;
  errors: ErrorStates | null;
  barChartData: BarChartData | null;
  tooltipFormatter: () => string;
  trendChartData: LineChartData | null;
  labelsFormatter: () => string;
  secondaryLabelsFormatter: () => string;
  // eslint-disable-next-line no-unused-vars
  setTrendChartTimePeriod: (newPeriod: TimePeriod) => void;
  trendChartTimePeriod: TimePeriod;
  trendTooltipFormatter: () => string;
  sourceBarChartData: SourceBarChartData | null;
  sourceTooltipFormatter: () => string;
  leadSourceTableData: LeadSourceTableData | null;
  // eslint-disable-next-line no-unused-vars
  handleSourcePageChange: (newPage: number) => void;
  // eslint-disable-next-line no-unused-vars
  handleSourcePageSizeChange: (newPageSize: number) => void;
  sourcePagination: PaginationState;
  // eslint-disable-next-line no-unused-vars
  handleSortingChange: (field: string, direction: SortingTypes) => void;
  handleSourceViewSortingChange: (
    // eslint-disable-next-line no-unused-vars
    field: string,
    // eslint-disable-next-line no-unused-vars
    direction: SortingTypes
  ) => void;
  sorting: SortingState;
  exploreSorting: SortingState;
  sourceViewSorting: SortingState;
  fetchSourceReport: () => void;
  sourceDetailModal: LeadSourceDetailData[] | null;
  // eslint-disable-next-line no-unused-vars
  handleSourceModal: (source: string) => void;
  // eslint-disable-next-line no-unused-vars
  handleSourceViewPageChange: (newPage: number) => void;
  // eslint-disable-next-line no-unused-vars
  handleSourceViewPageSizeChange: (newPageSize: number) => void;
  sourceViewPagination: PaginationState;
  // eslint-disable-next-line no-unused-vars
  fetchSourceViewReport: (source?: string) => void;
  fetchDownloadReport: () => void;
  fetchExploreDownloadReport: () => void;
  // eslint-disable-next-line no-unused-vars
  updateFilters: (newFilters: Partial<FilterState>) => void;
  filterOptions: FilterOptions | null;
  filters: FilterState;
  popupTooltipFormatter: () => string;
  barChartPopupData: BarChartData | null;
  isFilterLoading: boolean;
  // eslint-disable-next-line no-unused-vars
  handleExplorePageSizeChange: (newPageSize: number) => void;
  explorePagination: PaginationState;
  // eslint-disable-next-line no-unused-vars
  handleExploreSortingChange: (field: string, direction: SortingTypes) => void;
  // eslint-disable-next-line no-unused-vars
  handleExplorePageChange: (newPage: number) => void;
  exploreTableData: ExploreTableData[] | null;
  fetchExploreData: (
    // eslint-disable-next-line no-unused-vars
    pageNumber?: number,
    // eslint-disable-next-line no-unused-vars
    pageSize?: number,
    // eslint-disable-next-line no-unused-vars
    field?: string,
    // eslint-disable-next-line no-unused-vars
    direction?: SortingTypes
  ) => void;
  hasAnyEmptyData: boolean;
  selectedSource: string;
  // eslint-disable-next-line no-unused-vars
  setSelectedSource: (source: string) => void;
  // eslint-disable-next-line no-unused-vars
  setSourceViewSorting: (sorting: SortingState) => void;
}

// Create context
export const MarketingCACContext = createContext<
  MarketingCACContextType | undefined
>(undefined);

// Provider Component
export const MarketingCACProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const isMounted = useRef(false);
  const [isFilterLoading, setIsFilterLoading] = useState(false);

  // states
  const [infoCardsData, setInfoCardsData] = useState<InfoCardData[] | null>(
    null
  );
  const [barChartData, setBarChartData] = useState<BarChartData | null>(null);
  const [barChartPopupData, setBarChartPopupData] =
    useState<BarChartData | null>(null);

  const [trendChartData, setTrendChartData] = useState<LineChartData | null>(
    null
  );
  const [sourceBarChartData, setSourceBarChartData] =
    useState<SourceBarChartData | null>(null);
  const [leadSourceTableData, setLeadSourceTableData] =
    useState<LeadSourceTableData | null>(null);
  const [sourceDetailModal, setSourceDetailModal] = useState<
    LeadSourceDetailData[] | null
  >(null);
  const [exploreTableData, setExploreTableData] = useState<
    ExploreTableData[] | null
  >(null);
  const [trendChartTimePeriod, setTrendChartTimePeriod] =
    useState<TimePeriod>('monthly');
  const [selectedSource, setSelectedSource] = useState<string>('');
  const [sourcePagination, setSourcePagination] = useState<PaginationState>({
    page: 1,
    pageSize: 10,
    total: 0,
  });
  const [sourceViewPagination, setSourceViewPagination] =
    useState<PaginationState>({
      page: 1,
      pageSize: 10,
      total: 0,
    });
  const [explorePagination, setExplorePagination] = useState<PaginationState>({
    page: 1,
    pageSize: 10,
    total: 0,
  });

  // loading states
  const [loadingStates, setLoadingStates] = useState<LoadingData>({
    infoCards: true,
    barChart: true,
    trendLineChart: true,
    sourceBarChart: true,
    leadSourceTable: true,
    sourceDetailTable: true,
    filterOptions: true,
    barChartPopupData: true,
    exploreTable: true,
  });
  // Update the errors state initialization
  const [errors, setErrors] = useState<ErrorStates>({
    infoCards: null,
    barChart: null,
    trendLineChart: null,
    sourceBarChart: null,
    leadSourceTable: null,
    sourceDetailTable: null,
    filterOptions: null,
    barChartPopupData: null,
    exploreTable: null,
  });
  const [sorting, setSorting] = useState<SortingState>({
    field: 'name',
    direction: null,
  });

  const [sourceViewSorting, setSourceViewSorting] = useState<SortingState>({
    field: 'name',
    direction: null,
  });

  const [exploreSorting, setExploreSorting] = useState<SortingState>({
    field: 'name',
    direction: null,
  });

  const [filters, setFilters] = useState<FilterState>({
    dateRange: null,
    location: [],
  });

  const [filterOptions, setFilterOptions] = useState<FilterOptions>({
    locations: [],
  });

  const handleTrendChartTimePeriodChange = (newPeriod: TimePeriod) => {
    setTrendChartTimePeriod(newPeriod);
    fetchTrendLineChartData(newPeriod);
  };
  const handleSourcePageChange = (newPage: number) => {
    setSourcePagination((prev) => ({ ...prev, page: newPage }));
    fetchLeadSourcePerformanceTable(
      newPage,
      sourcePagination.pageSize,
      sorting.field,
      sorting.direction
    );
  };
  const handleSourcePageSizeChange = (newPageSize: number) => {
    setSourcePagination((prev) => ({
      ...prev,
      pageSize: newPageSize,
      page: 1,
    }));
    fetchLeadSourcePerformanceTable(
      1,
      newPageSize,
      sorting.field,
      sorting.direction
    );
  };
  const handleSourceViewPageChange = (newPage: number) => {
    setSourceViewPagination((prev) => ({ ...prev, page: newPage }));
    fetchSourceViewTable(
      newPage,
      sourceViewPagination.pageSize,
      sourceViewSorting.field,
      sourceViewSorting.direction
    );
  };
  const handleSourceViewPageSizeChange = (newPageSize: number) => {
    setSourceViewPagination((prev) => ({
      ...prev,
      pageSize: newPageSize,
      page: 1,
    }));
    fetchSourceViewTable(
      1,
      newPageSize,
      sourceViewSorting.field,
      sourceViewSorting.direction
    );
  };
  const handleExplorePageChange = (newPage: number) => {
    setExplorePagination((prev) => ({ ...prev, page: newPage }));
  };
  const handleExplorePageSizeChange = (newPageSize: number) => {
    setExplorePagination((prev) => ({
      ...prev,
      pageSize: newPageSize,
      page: 1,
    }));
    // Fetch explore data with the new page size and reset to the first page
    fetchExploreData(
      1,
      newPageSize,
      exploreSorting.field,
      exploreSorting.direction
    );
  };

  const handleSortingChange = (field: string, direction: SortingTypes) => {
    setSorting((prev) => ({ ...prev, field, direction }));
    setSourcePagination((prev) => ({ ...prev, page: 1 }));
    fetchLeadSourcePerformanceTable(
      1,
      sourcePagination.pageSize,
      field,
      direction
    );
  };

  const handleSourceViewSortingChange = (
    field: string,
    direction: SortingTypes
  ) => {
    setSourceViewSorting((prev) => ({ ...prev, field, direction }));
    setSourceViewPagination((prev) => ({ ...prev, page: 1 }));
    fetchSourceViewTable(1, sourceViewPagination.pageSize, field, direction);
  };

  const handleExploreSortingChange = (
    field: string,
    direction: SortingTypes
  ) => {
    setExploreSorting((prev) => ({ ...prev, field, direction }));
    setExplorePagination((prev) => ({ ...prev, page: 1 }));
    fetchExploreData(1, explorePagination.pageSize, field, direction);
  };

  const getQueryParams = (
    filters: FilterState,
    timePeriod: TimePeriod | null,
    includePagination: boolean = false,
    currentPage?: number | null,
    pageSize?: number | null,
    source?: string
  ): string => {
    const queryParams = new URLSearchParams();
    // Add parameter
    if (timePeriod) queryParams.append('cac_trends_by', timePeriod);
    if (source) queryParams.append('source', source);

    // Check if location is not empty before appending
    if (filters.location && filters.location.length > 0) {
      queryParams.append('location_id', filters.location.toString());
    }

    if (filters?.dateRange && filters?.dateRange[0] && filters.dateRange[1]) {
      queryParams.append(
        'start_date',
        filters?.dateRange[0]?.toLocaleDateString('en-CA')
      );
      queryParams.append(
        'end_date',
        filters?.dateRange[1]?.toLocaleDateString('en-CA')
      );
    }

    // Add pagination params if needed
    if (includePagination) {
      queryParams.append(
        'page',
        (currentPage || sourcePagination.page).toString()
      );
      queryParams.append(
        'page_size',
        (pageSize || sourcePagination.pageSize).toString()
      );
    }

    return queryParams.toString();
  };

  // Filter update handler
  const updateFilters = (newFilters: Partial<FilterState>) => {
    setIsFilterLoading(false);
    setFilters((prev) => ({ ...prev, ...newFilters }));
  };

  // Fetch filter options
  const fetchFilterOptions = async () => {
    try {
      setLoadingStates((prev) => ({ ...prev, filterOptions: true }));
      const results = await Promise.allSettled([getLocations(SCREEN_NAME.CAC)]);

      const [locationsResult] = results;

      setFilterOptions({
        locations:
          locationsResult?.status === 'fulfilled' ? locationsResult?.value : [],
      });

      // Set error if either request failed
      if (results.some((result) => result.status === 'rejected')) {
        const error = new Error('Failed to fetch some filter options');
        setErrors((prev) => ({ ...prev, filterOptions: error }));
      } else {
        setErrors((prev) => ({ ...prev, filterOptions: null }));
      }
    } catch (error) {
      setErrors((prev) => ({ ...prev, filterOptions: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, filterOptions: false }));
    }
  };

  // Fetch info cards data
  const fetchInfoCards = async () => {
    try {
      setLoadingStates((prev) => ({ ...prev, infoCards: true }));
      const queryString = getQueryParams(filters, null);
      const response = await getHighNumbers(queryString);
      const transformedData = transformInfoCardsData(response?.data);
      setInfoCardsData(transformedData);
      setErrors((prev) => ({ ...prev, infoCards: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, infoCards: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, infoCards: false }));
      setIsFilterLoading(false);
    }
  };

  // Fetch bar chart data
  const fetchBarChartData = async () => {
    try {
      setLoadingStates((prev) => ({ ...prev, barChart: true }));
      const queryString = getQueryParams(filters, null);
      const response = await getBarChartData(queryString);
      const transformedData = transformBarChartData(
        response?.data
      ) as BarChartData | null;
      setBarChartData(transformedData);
      setErrors((prev) => ({ ...prev, barChart: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, barChart: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, barChart: false }));
      setIsFilterLoading(false);
    }
  };

  // Fetch bar chart data
  const fetchSourceViewChartData = async (source?: string) => {
    try {
      setLoadingStates((prev) => ({ ...prev, barChartPopupData: true }));
      let queryString = getQueryParams(filters, null);
      // Add source to query string if provided
      if (source || selectedSource) {
        queryString += `&source=${source || selectedSource}`;
      }
      const response = await getBarChartPopupData(queryString);
      const transformedData = transformBarChartPopupData(
        response?.data
      ) as BarChartData | null;
      setBarChartPopupData(transformedData);
      setErrors((prev) => ({ ...prev, barChartPopupData: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, barChartPopupData: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, barChartPopupData: false }));
      setIsFilterLoading(false);
    }
  };

  // fetch trend line chart data
  const fetchTrendLineChartData = async (timePeriod?: TimePeriod) => {
    try {
      setLoadingStates((prev) => ({ ...prev, trendLineChart: true }));
      const queryString = getQueryParams(
        filters,
        timePeriod || trendChartTimePeriod
      );
      const response = await getLineChartData(queryString);
      const transformedData = transformTrendChartData(
        response.data,
        timePeriod || trendChartTimePeriod
      );
      setTrendChartData(transformedData);
      setErrors((prev) => ({ ...prev, trendLineChart: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, trendLineChart: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, trendLineChart: false }));
      setIsFilterLoading(false);
    }
  };

  // Fetch bar chart data
  const fetchSourceBarChartData = async () => {
    try {
      setLoadingStates((prev) => ({ ...prev, sourceBarChart: true }));
      const queryString = getQueryParams(filters, null);
      const response = await getSourceBarChartData(queryString);

      const generatedColors: string[] = []; // Replace with actual generated colors if available
      const transformedData = transformSourceBarChartData(
        response?.data,
        generatedColors
      );

      setSourceBarChartData(transformedData);
      setErrors((prev) => ({ ...prev, sourceBarChart: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, sourceBarChart: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, sourceBarChart: false }));
      setIsFilterLoading(false);
    }
  };

  // fetch lead source performance data
  const fetchLeadSourcePerformanceTable = async (
    pageNumber?: number,
    pageSize?: number,
    field?: string,
    direction?: SortingTypes
  ) => {
    try {
      setLoadingStates((prev) => ({ ...prev, leadSourceTable: true }));
      let queryString = getQueryParams(
        filters,
        null,
        true,
        pageNumber || sourcePagination.page,
        pageSize || sourcePagination.pageSize
      );

      // Add sorting parameters if they exist, regardless of filters
      if (field && direction) {
        const fieldName = field as keyof LeadSourceDetailData;
        const orderingValue =
          direction === SORTING_TYPES.DESC ? `-${fieldName}` : fieldName;
        queryString += `&ordering=${orderingValue}`;
      } else if (sorting.field && sorting.direction) {
        // If no new sorting provided but we have existing sorting, use that
        const fieldName = sorting.field as keyof LeadSourceDetailData;
        const orderingValue =
          sorting.direction === SORTING_TYPES.DESC
            ? `-${fieldName}`
            : fieldName;
        queryString += `&ordering=${orderingValue}`;
      }

      const response = await getSourcePerformanceData(queryString);

      setLeadSourceTableData(
        transformLeadSourceTableData(response?.data, response?.total)
      );

      setSourcePagination((prev) => ({
        ...prev,
        total: response?.meta_data?.total_count,
      }));
      setErrors((prev) => ({ ...prev, leadSourceTable: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, leadSourceTable: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, leadSourceTable: false }));
      setIsFilterLoading(false);
    }
  };

  /**
   * Downloads the source report from the server.
   * @async
   * @returns {Promise<void>}
   */
  const fetchSourceReport = async (): Promise<void> => {
    try {
      const queryString = getQueryParams(filters, null);
      // Download the report from the server
      await getDownloadSourceReport(queryString);
    } catch (error) {
      console.error('Download error:', error);
      // If the error is an instance of Error, log the error details
      if (error instanceof Error) {
        console.error('Error details:', {
          message: error.message,
          stack: error.stack,
        });
      }
      // Update the error state
      setErrors((prev) => ({ ...prev, sourceReport: error as Error }));
      // Show an error message to the user
      showErrorMsg(TOAST_MESSAGES.DOWNLOAD_REPORT_ERROR);
    }
  };

  /**
   * Fetches the source view report from the server.
   * @async
   * @param {string} source - The source to filter the report by.
   * @returns {Promise<void>}
   */
  const fetchSourceViewReport = async (source?: string): Promise<void> => {
    try {
      const queryString = getQueryParams(filters, null);
      // Download the report from the server with the source included
      await getDownloadSourceViewReport(`${queryString}&source=${source}`);
    } catch (error) {
      console.error('Download error:', error);
      // If the error is an instance of Error, log the error details
      if (error instanceof Error) {
        console.error('Error details:', {
          message: error.message,
          stack: error.stack,
        });
      }
      // Update the error state
      setErrors((prev) => ({ ...prev, sourceViewReport: error as Error }));
      // Show an error message to the user
      showErrorMsg(TOAST_MESSAGES.DOWNLOAD_REPORT_ERROR);
    }
  };

  const fetchDownloadReport = async (): Promise<void> => {
    try {
      const queryString = getQueryParams(filters, null);
      // Download the report from the server
      await getDownloadReport(queryString);
    } catch (error) {
      console.error('Download error:', error);
      // If the error is an instance of Error, log the error details
      if (error instanceof Error) {
        console.error('Error details:', {
          message: error.message,
          stack: error.stack,
        });
      }
      // Update the error state
      setErrors((prev) => ({ ...prev, downloadReport: error as Error }));
      // Show an error message to the user
      showErrorMsg(TOAST_MESSAGES.DOWNLOAD_REPORT_ERROR);
    }
  };

  const fetchExploreDownloadReport = async (): Promise<void> => {
    try {
      const queryString = getQueryParams(filters, null);
      // Download the report from the server
      await getExploreDownloadReport(queryString);
    } catch (error) {
      console.error('Download error:', error);
      // If the error is an instance of Error, log the error details
      if (error instanceof Error) {
        console.error('Error details:', {
          message: error.message,
          stack: error.stack,
        });
      }
      // Update the error state
      setErrors((prev) => ({ ...prev, exploreDownloadReport: error as Error }));
      // Show an error message to the user
      showErrorMsg(TOAST_MESSAGES.DOWNLOAD_REPORT_ERROR);
    }
  };

  // fetch lead source performance data
  const fetchSourceViewTable = async (
    pageNumber?: number,
    pageSize?: number,
    field?: string,
    direction?: SortingTypes,
    source?: string
  ) => {
    try {
      setLoadingStates((prev) => ({ ...prev, sourceDetailTable: true }));
      let queryString = getQueryParams(
        filters,
        null,
        true,
        pageNumber || sourceViewPagination.page,
        pageSize || sourceViewPagination.pageSize
      );

      // Add source to query string if provided
      if (source || selectedSource) {
        queryString += `&source=${source || selectedSource}`;
      }

      if (field && direction) {
        const fieldName = field as keyof LeadSourceDetailData;
        const orderingValue =
          direction === SORTING_TYPES.DESC ? `-${fieldName}` : fieldName;
        queryString += `&ordering=${orderingValue}`;
      }
      const response = await getSourceDetailData(queryString);
      const transformedData = transformSourceDetailData(response?.data);
      setSourceDetailModal(transformedData);
      setSourceViewPagination((prev) => ({
        ...prev,
        total: response?.meta_data?.total_count,
      }));
      setErrors((prev) => ({ ...prev, sourceDetailTable: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, sourceDetailTable: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, sourceDetailTable: false }));
    }
  };

  const handleSourceModal = async (source?: string) => {
    // Update selectedSource if provided
    if (source) {
      setSelectedSource(source);
    }
    try {
      // Fetch funnel chart data with source
      await fetchSourceViewChartData(source || selectedSource);
      // Fetch source job detail table with source
      await fetchSourceViewTable(
        1,
        sourceViewPagination.pageSize,
        undefined,
        null,
        source || selectedSource
      );
    } catch (error) {
      console.error('Error in handleFunnelChartDetail:', error);
    }
  };

  /**
   * Fetches the explore table data
   * @param pageNumber - the page number to fetch
   * @param pageSize - the page size to fetch
   * @param field - the field to sort by
   * @param direction - the direction to sort (asc or desc)
   */
  const fetchExploreData = async (
    pageNumber?: number,
    pageSize?: number,
    field?: string,
    direction?: SortingTypes
  ) => {
    try {
      setLoadingStates((prev) => ({ ...prev, exploreTable: true }));
      let queryString = getQueryParams(
        filters,
        null,
        true,
        pageNumber || explorePagination.page,
        pageSize || explorePagination.pageSize
      );

      // Add sorting parameters if they exist, regardless of filters
      if (field && direction) {
        const fieldName = field as keyof ExploreTableData;
        const orderingValue =
          direction === SORTING_TYPES.DESC ? `-${fieldName}` : fieldName;
        queryString += `&ordering=${orderingValue}`;
      } else if (exploreSorting.field && exploreSorting.direction) {
        // If no new sorting provided but we have existing sorting, use that
        const fieldName = exploreSorting.field as keyof ExploreTableData;
        const orderingValue =
          exploreSorting.direction === SORTING_TYPES.DESC
            ? `-${fieldName}`
            : fieldName;
        queryString += `&ordering=${orderingValue}`;
      }

      const response = await getExploreData(queryString);
      const transformedData = transformExploreData(response?.data);
      setExploreTableData(transformedData);
      setExplorePagination((prev) => ({
        ...prev,
        total: response?.meta_data?.total_count,
      }));
      setErrors((prev) => ({ ...prev, exploreTable: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, exploreTable: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, exploreTable: false }));
      setIsFilterLoading(false);
    }
  };

  // Add a value to check if there's any data
  const hasAnyEmptyData = Boolean(
    leadSourceTableData?.data?.length ||
      0 ||
      sourceDetailModal?.length ||
      0 ||
      sourceBarChartData?.series?.[0]?.data?.length ||
      0 ||
      trendChartData?.series?.[0]?.data?.length ||
      0 ||
      barChartPopupData?.series?.[0]?.data?.length ||
      0 ||
      exploreTableData?.length ||
      0 ||
      (Array.isArray(barChartData) &&
        barChartData.some(({ value }) => /\d/.test(value))) ||
      false
  );

  // Update the initial effect to use the mount ref
  useEffect(() => {
    if (!isMounted.current) {
      fetchFilterOptions();
      isMounted.current = true;
    }
  }, []);

  useEffect(() => {
    if (isMounted.current) {
      const timeoutId = setTimeout(() => {
        setSourcePagination((prev) => ({ ...prev, page: 1 }));
        setSourceViewPagination((prev) => ({ ...prev, page: 1 }));
        setExplorePagination((prev) => ({ ...prev, page: 1 }));
        fetchInfoCards();
        fetchBarChartData();
        fetchTrendLineChartData();
        fetchSourceBarChartData();
        fetchLeadSourcePerformanceTable(1);
        fetchExploreData(1);
      }, 1000); // Adjust the delay as needed

      return () => clearTimeout(timeoutId); // Cleanup function to clear the timeout
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters]);

  return (
    <MarketingCACContext.Provider
      value={{
        infoCards: infoCardsData,
        loading: loadingStates,
        errors: errors,
        barChartData: barChartData,
        trendChartData: trendChartData,
        tooltipFormatter,
        labelsFormatter,
        secondaryLabelsFormatter,
        setTrendChartTimePeriod: handleTrendChartTimePeriodChange,
        trendChartTimePeriod,
        trendTooltipFormatter,
        sourceTooltipFormatter,
        sourceBarChartData: sourceBarChartData,
        leadSourceTableData: leadSourceTableData,
        handleSourcePageChange,
        handleSourcePageSizeChange,
        handleSortingChange,
        sourcePagination,
        sorting,
        exploreSorting,
        sourceViewSorting,
        fetchSourceReport,
        sourceDetailModal: sourceDetailModal,
        handleSourceModal,
        handleSourceViewPageChange,
        handleSourceViewPageSizeChange,
        sourceViewPagination,
        handleSourceViewSortingChange,
        fetchSourceViewReport,
        fetchDownloadReport,
        fetchExploreDownloadReport,
        updateFilters,
        filterOptions,
        filters,
        popupTooltipFormatter,
        barChartPopupData,
        isFilterLoading,
        handleExplorePageSizeChange,
        explorePagination,
        handleExploreSortingChange,
        handleExplorePageChange,
        exploreTableData,
        fetchExploreData,
        hasAnyEmptyData,
        selectedSource,
        setSelectedSource,
        setSourceViewSorting,
      }}
    >
      {children}
    </MarketingCACContext.Provider>
  );
};

// Custom Hook to Use Context
export const useMarketingCACContext = () => {
  const context = useContext(MarketingCACContext);
  if (!context) {
    throw new Error(
      'useMarketingCACContext must be used within a MarketingCACProvider'
    );
  }
  return context;
};
