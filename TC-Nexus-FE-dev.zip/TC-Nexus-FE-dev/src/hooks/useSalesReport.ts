import { getAllLocations, getSalesReps } from '@/services/common';
import { useState, useEffect } from 'react';
import { Location, SalesRep } from './useSalesRevenue';
import {
  createSalesReport,
  deleteSalesReport,
  downloadManualSalesReport,
  getManualSalesReport,
  updateSalesReport,
  salesReportApproval,
} from '@/services/salesReport';
import { SCREEN_NAME } from '@/constants/configs';

export interface TransformedSalesRep {
  id: number | null;
  sales_rep: string;
  date: string;
  leads_scheduled: number;
  leads_ran: number;
  follow_up_appointments_scheduled: number;
  jobs_sold: number;
  change_orders_sold: number | null;
  total_sales_amount: number;
  homes_canvassed: number;
  doors_knocked: number;
  appointments_from_door_to_door_engagements: number;
  google_reviews: number;
  referrals_from_clients: number;
  yard_signs: number;
  lois: number;
  claim_filed: number;
  adjuster_meeting: number;
  auto_door_knocked: number;
  auto_home_canvassed: number;
  auto_leads_generated: number;
  auto_loi: number;
  auto_sold: number;
  is_auto_processed: boolean;
  auto_insurance_claim_filed: number;
  highlight: boolean;
}

interface SalesRepTable {
  salesReportData: TransformedSalesRep[];
  total: {
    total_leads_scheduled: number;
    total_leads_ran: number;
    total_follow_up_appointments_scheduled: number;
    total_jobs_sold: number;
    total_change_orders_sold: number | null;
    total_total_sales_amount: number;
    total_homes_canvassed: number;
    total_doors_knocked: number;
    total_appointments_from_door_to_door_engagements: number;
    total_google_reviews: number;
    total_referrals_from_clients: number;
    total_yard_signs: number;
    total_lois: number;
    total_claim_filed: number;
    total_adjuster_meeting: number;
  };
}

export interface SalesReportPayload {
  loc_id: string;
  rep_id: number;
  team: string;
  entry_date: string;
  door_knocked: number;
  home_canvassed: number;
  leads_generated: number;
  leads_ran: number;
  change_order: number;
  amount: number;
  google_reviews: number;
  referral: number;
  yard_signed: number;
  appointments: number;
  insurance_claim_filed: number;
  loi: number;
  adjuster_meetings: number;
  followup_appointments: number;
  sold: number;
  is_approved?: boolean;
}

export interface SalesReportFilters {
  page?: number;
  pageSize?: number;
  ordering?: string;
  rep_id?: string | string[];
  loc_id?: string;
  start_date?: string | null;
  end_date?: string | null;
  approval_status?: string;
}
interface UseUsersProps {
  initialFilters?: SalesReportFilters;
  autoFetch?: boolean;
}

// First, let's add interfaces for the API response
interface SalesReportApiItem {
  id: number | null;
  sales_rep: string;
  entry_date: string;
  leads_generated: number;
  leads_ran: number;
  followup_appointments: number;
  sold: number;
  change_order: number | null;
  amount: number;
  home_canvassed: number;
  door_knocked: number;
  appointments: number;
  google_reviews: number;
  referral: number;
  yard_signed: number;
  loi: number;
  insurance_claim_filed: number;
  adjuster_meetings: number;
  auto_door_knocked: number;
  auto_home_canvassed: number;
  auto_leads_generated: number;
  auto_loi: number;
  auto_sold: number;
  auto_insurance_claim_filed: number;
  is_approved: boolean;
  is_auto_processed: boolean;
  approved_by: string | null;
}

interface SalesReportApiResponse {
  data: SalesReportApiItem[];
  total: {
    leads_generated: number;
    leads_ran: number;
    followup_appointments: number;
    jobs_sold: number;
    change_order: number | null;
    amount: number;
    home_canvassed: number;
    door_knocked: number;
    appointments: number;
    google_reviews: number;
    referral: number;
    yard_signed: number;
    loi: number;
    insurance_claim_filed: number;
    adjuster_meetings: number;
  };
  meta_data: {
    total_count: number;
  };
}

const transformSalesReport = (
  response: SalesReportApiResponse
): SalesRepTable => {
  const transformedData =
    response?.data?.map((item) => {
      const baseConditions = item.is_auto_processed && !item.approved_by;

      // Then check if any values mismatch
      const hasMismatch =
        (item.auto_door_knocked ?? 0) !== (item.door_knocked ?? 0) ||
        (item.auto_home_canvassed ?? 0) !== (item.home_canvassed ?? 0) ||
        (item.auto_leads_generated ?? 0) !== (item.leads_generated ?? 0) ||
        (item.auto_loi ?? 0) !== (item.loi ?? 0) ||
        (item.auto_sold ?? 0) !== (item.sold ?? 0);
      // Check if auto fields don't match their corresponding non-auto fields
      const hasAutoMismatch = baseConditions && hasMismatch; // Only highlight if is_auto_processed is 1

      return {
        id: item?.id ?? null,
        sales_rep: item?.sales_rep ?? '',
        date: item?.entry_date ?? '',
        leads_scheduled: item?.leads_generated ?? 0,
        leads_ran: item?.leads_ran ?? 0,
        follow_up_appointments_scheduled: item?.followup_appointments ?? 0,
        jobs_sold: item?.sold ?? 0,
        change_orders_sold: item?.change_order ?? null,
        total_sales_amount: item?.amount ?? 0,
        homes_canvassed: item?.home_canvassed ?? 0,
        doors_knocked: item?.door_knocked ?? 0,
        appointments_from_door_to_door_engagements: item?.appointments ?? 0,
        google_reviews: item?.google_reviews ?? 0,
        referrals_from_clients: item?.referral ?? 0,
        yard_signs: item?.yard_signed ?? 0,
        lois: item?.loi ?? 0,
        claim_filed: item?.insurance_claim_filed ?? 0,
        adjuster_meeting: item?.adjuster_meetings ?? 0,
        auto_door_knocked: item?.auto_door_knocked ?? 0,
        auto_home_canvassed: item?.auto_home_canvassed ?? 0,
        auto_leads_generated: item?.auto_leads_generated ?? 0,
        auto_loi: item?.auto_loi ?? 0,
        auto_sold: item?.auto_sold ?? 0,
        auto_insurance_claim_filed: item?.auto_insurance_claim_filed ?? 0,
        highlight: hasAutoMismatch, // Set highlight based on our condition
        is_approved: item?.is_approved ?? false,
        is_auto_processed: item?.is_auto_processed ?? false,
      };
    }) || [];

  return {
    salesReportData: transformedData,
    total: {
      total_leads_scheduled: response.total?.leads_generated ?? 0,
      total_leads_ran: response.total?.leads_ran ?? 0,
      total_follow_up_appointments_scheduled:
        response.total?.followup_appointments ?? 0,
      total_jobs_sold: response.total?.jobs_sold ?? 0,
      total_change_orders_sold: response.total?.change_order ?? null,
      total_total_sales_amount: response.total?.amount ?? 0,
      total_homes_canvassed: response.total?.home_canvassed ?? 0,
      total_doors_knocked: response.total?.door_knocked ?? 0,
      total_appointments_from_door_to_door_engagements:
        response.total?.appointments ?? 0,
      total_google_reviews: response.total?.google_reviews ?? 0,
      total_referrals_from_clients: response.total?.referral ?? 0,
      total_yard_signs: response.total?.yard_signed ?? 0,
      total_lois: response.total?.loi ?? 0,
      total_claim_filed: response.total?.insurance_claim_filed ?? 0,
      total_adjuster_meeting: response.total?.adjuster_meetings ?? 0,
    },
  };
};

const fieldMap: Record<string, string> = {
  sales_rep: 'sales_rep',
  date: 'entry_date',
  leads_scheduled: 'leads_generated',
  leads_ran: 'leads_ran',
  follow_up_appointments_scheduled: 'followup_appointments',
  jobs_sold: 'sold',
  change_orders_sold: 'change_order',
  total_sales_amount: 'amount',
  homes_canvassed: 'home_canvassed',
  doors_knocked: 'door_knocked',
  appointments_from_door_to_door_engagements: 'appointments',
  google_reviews: 'google_reviews',
  referrals_from_clients: 'referral',
  yard_signs: 'yard_signed',
  lois: 'loi',
  claim_filed: 'insurance_claim_filed',
  adjuster_meeting: 'adjuster_meetings',
};

export const getApiFieldName = (transformedField: string): string => {
  return fieldMap[transformedField] || transformedField;
};

export const useSalesReport = ({
  initialFilters = {},
  autoFetch = true,
}: UseUsersProps = {}) => {
  const [salesReport, setSalesReport] = useState<SalesRepTable | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [totalCount, setTotalCount] = useState(5);
  const [filters, setFilters] = useState<SalesReportFilters>({
    page: 1,
    pageSize: 10,
    ...initialFilters,
  });
  const [salesRepresentatives, setSalesRepresentatives] = useState<SalesRep[]>(
    []
  );
  const [locations, setLocations] = useState<Location[]>([]);
  const [isFilterLoading, setIsFilterLoading] = useState(true);

  const fetchManualSalesReport = async (
    currentFilters: SalesReportFilters = filters
  ) => {
    try {
      setIsLoading(true);
      const params = new URLSearchParams({
        ...(currentFilters.rep_id && {
          rep_id: Array.isArray(currentFilters.rep_id)
            ? currentFilters.rep_id.join(',')
            : currentFilters.rep_id,
          page: '1', // Reset page to 1 when rep_id filter changes
        }),
        ...(currentFilters.start_date && {
          start_date: String(currentFilters.start_date),
          page: '1', // Reset page to 1 when start_date filter changes
        }),
        ...(currentFilters.end_date && {
          end_date: String(currentFilters.end_date),
          page: '1', // Reset page to 1 when end_date filter changes
        }),
        ...(!currentFilters.rep_id &&
          !currentFilters.start_date &&
          !currentFilters.end_date && {
            page: String(currentFilters.page ? currentFilters.page : 1),
          }),
        page_size: String(currentFilters.pageSize || 10),
        ...(currentFilters.approval_status && {
          approval_status: String(currentFilters.approval_status),
          page: '1', // Reset page to 1 when approval_status filter changes
        }),
        ...(currentFilters.ordering && {
          ordering: currentFilters.ordering,
          page: '1', // Reset page to 1 when ordering filter changes
        }),
        ...(currentFilters.loc_id && {
          loc_id: String(currentFilters.loc_id),
          page: '1', // Reset page to 1 when loc_id filter changes
        }),
      });
      const response = await getManualSalesReport(`${params.toString()}`);
      const transformedData = transformSalesReport(response);
      setSalesReport(transformedData);
      setTotalCount(response?.meta_data?.total_count || 0);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
      setIsFilterLoading(false);
    }
  };

  const downloadSalesReport = async () => {
    try {
      const params = new URLSearchParams();
      if (filters.rep_id) {
        params.append(
          'rep_id',
          Array.isArray(filters.rep_id)
            ? filters.rep_id.join(',')
            : filters.rep_id
        );
      }
      if (filters.start_date) {
        params.append('start_date', filters.start_date);
      }
      if (filters.end_date) {
        params.append('end_date', filters.end_date);
      }
      if (filters.loc_id) {
        params.append('loc_id', filters.loc_id);
      }
      await downloadManualSalesReport(`${params.toString()}`);
    } catch (err) {
      console.error(err);
    }
  };
  const fetchSalesRepresentatives = async (locationId: string = '') => {
    try {
      const response = await getSalesReps(SCREEN_NAME.SALES_REPORT, locationId);
      setSalesRepresentatives(response || []);
    } catch (err) {
      console.error(err);
    }
  };
  useEffect(() => {
    const fetchLocations = async () => {
      try {
        const response = await getAllLocations();
        setLocations(response || []);
      } catch (err) {
        console.error(err);
      }
    };
    fetchSalesRepresentatives();
    fetchLocations();
  }, []);

  useEffect(() => {
    fetchSalesRepresentatives(filters.loc_id);
  }, [filters.loc_id]);

  useEffect(() => {
    if (!autoFetch) return;
    const timeoutId = setTimeout(() => {
      fetchManualSalesReport();
    }, 1500);
    return () => clearTimeout(timeoutId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    filters.page,
    filters.pageSize,
    filters.start_date,
    filters.end_date,
    filters.rep_id,
    filters.ordering,
    filters.loc_id,
    filters.approval_status,
  ]);

  const updateFilters = (newFilters: Partial<SalesReportFilters>) => {
    setIsFilterLoading(true);
    setFilters((prev) => ({
      ...prev,
      ...newFilters,
      page: newFilters.page || 1,
    }));
  };

  const createReport = async (payload: SalesReportPayload) => {
    try {
      await createSalesReport(payload);
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  const updateReport = async (id: string, payload: SalesReportPayload) => {
    try {
      await updateSalesReport(id, payload);
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  const deleteManualSalesReport = async (id: string) => {
    try {
      await deleteSalesReport(id);
      setFilters({ page: 1, pageSize: filters.pageSize || 10 });
      fetchManualSalesReport();
    } catch (err) {
      console.error(err);
    }
  };

  const toggleSalesReportApproval = async (row: any) => {
    try {
      await salesReportApproval(row?.id, { is_approved: !row?.is_approved });
      fetchManualSalesReport();
    } catch (err) {
      console.error(err);
    }
  };
  return {
    salesReport,
    locations,
    totalCount,
    filters,
    isLoading,
    updateFilters,
    deleteManualSalesReport,
    salesRepresentatives,
    downloadSalesReport,
    createReport,
    updateReport,
    toggleSalesReportApproval,
    isFilterLoading,
  };
};
