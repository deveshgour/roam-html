import { useState, useEffect } from 'react';
import {
  getRoles,
  createRole,
  deleteRoleById,
  editRole,
} from '@/services/role';
import { format, parseISO } from 'date-fns';
import { RoleFormValues } from '@/app/roles/management/components/addRoleModal';

export interface Role {
  id: string;
  name: string;
  description: string;
  access_levels: string;
  users_assigned: string;
  created_at: string;
  updated_at: string;
}

export interface RoleFilters {
  name?: string;
  page?: number;
  pageSize?: number;
  ordering?: string;
}

interface RoleTable {
  id: string;
  name: string;
  description: string;
  createdOn: string;
}

interface UseRolesProps {
  initialFilters?: RoleFilters;
  autoFetch?: boolean;
}

export const useRoles = ({
  initialFilters = {},
  autoFetch = true,
}: UseRolesProps = {}) => {
  const [roles, setRoles] = useState<RoleTable[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [totalCount, setTotalCount] = useState(0);
  const [filters, setFilters] = useState<RoleFilters>({
    page: 1,
    pageSize: 10,
    ...initialFilters,
  });

  const transformRole = (role: Role[]) => {
    return role.map((item: Role) => ({
      id: item.id,
      name: item.name,
      description: item.description || '-',
      access_levels: item.access_levels,
      users_assigned: item.users_assigned,
      createdOn: item.created_at
        ? format(parseISO(item.created_at), 'yyyy-MM-dd')
        : '-',
    }));
  };

  const getFieldName = (fieldName: string) => {
    const isDescending = fieldName.startsWith('-');
    const cleanFieldName = isDescending ? fieldName.slice(1) : fieldName;

    const fieldMappings: Record<string, string> = {
      name: 'name',
      description: 'description',
      createdOn: 'created_at',
      id: 'id',
    };

    const mappedField = fieldMappings[cleanFieldName] || cleanFieldName;
    return isDescending ? `-${mappedField}` : mappedField;
  };

  const fetchRoles = async (currentFilters: RoleFilters = filters) => {
    try {
      setIsLoading(true);
      const params = new URLSearchParams({
        ...(currentFilters.name && { search_str: currentFilters.name }),
        ...(currentFilters.ordering && {
          ordering: getFieldName(currentFilters.ordering),
        }),
        page: String(currentFilters.page || 1),
        page_size: String(currentFilters.pageSize || 10),
      });

      const response = await getRoles(`?${params.toString()}`);
      setRoles(transformRole(response.data));
      setTotalCount(response.meta_data.total_count);
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (!autoFetch) return;

    fetchRoles();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters.page, filters.pageSize, filters.name, filters.ordering]);

  const updateFilters = (newFilters: Partial<RoleFilters>) => {
    setFilters((prev) => ({
      ...prev,
      ...newFilters,
      page: newFilters.page || 1,
    }));
  };

  const prepareRolePayload = (roleData: RoleFormValues) => {
    // If all_screens_access is 1, set all other permissions (except system_administration) to 1
    if (roleData.all_screens_access === 1) {
      return {
        name: roleData.name,
        description: roleData.description,
        system_administration: roleData.system_administration ? 1 : 0,
        all_screens_access: 1,
        sales_revenue: 1,
        profit_margin_retail: 1,
        profit_margin_nc: 1,
        lead_conversion: 1,
        cac: 1,
        operations: 1,
        sales_report: 1,
        new_construction_bids: 1,
        marketing_lead: 1,
        role_type: roleData.role_type,
      };
    }

    // If all_screens_access is not 1, use the original values
    return {
      name: roleData.name,
      description: roleData.description,
      system_administration: roleData.system_administration ? 1 : 0,
      all_screens_access: roleData.all_screens_access ? 1 : 0,
      sales_revenue: roleData.sales_revenue ? 1 : 0,
      profit_margin_retail: roleData.profit_margin_retail ? 1 : 0,
      profit_margin_nc: roleData.profit_margin_nc ? 1 : 0,
      lead_conversion: roleData.lead_conversion ? 1 : 0,
      cac: roleData.cac ? 1 : 0,
      operations: roleData.operations ? 1 : 0,
      sales_report: roleData.sales_report ? 1 : 0,
      new_construction_bids: roleData.new_construction_bids ? 1 : 0,
      marketing_lead: roleData.marketing_lead ? 1 : 0,
      role_type: roleData.role_type,
    };
  };

  const addRole = async (roleData: RoleFormValues) => {
    try {
      const payload = prepareRolePayload(roleData);
      const response = await createRole(payload);

      setRoles((prevRoles) => [
        ...prevRoles,
        transformRole([response.data])[0],
      ]);
      setTotalCount((prevCount) => prevCount + 1);
      fetchRoles();

      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    }
  };

  const updateRoleById = async (id: string, roleData: RoleFormValues) => {
    try {
      const payload = prepareRolePayload(roleData);
      const response = await editRole(payload, id);
      setRoles((prevRoles) =>
        prevRoles.map((role) =>
          role.id === id
            ? { ...role, ...transformRole([response.data])[0] }
            : role
        )
      );
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    }
  };

  const deleteRole = async (id: string) => {
    try {
      await deleteRoleById(id);
      setRoles((prevRoles) => prevRoles.filter((role) => role.id !== id));
      setFilters({ page: 1, pageSize: filters.pageSize || 10 });
      fetchRoles();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    }
  };
  const getRoleById = async (roleId: string) => {
    try {
      const response = await getRoles(`/${roleId}`);
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    }
  };

  return {
    roles,
    error,
    totalCount,
    filters,
    isLoading,
    updateFilters,
    fetchRoles,
    addRole,
    getRoleById,
    updateRole: updateRoleById,
    deleteRole,
  };
};
