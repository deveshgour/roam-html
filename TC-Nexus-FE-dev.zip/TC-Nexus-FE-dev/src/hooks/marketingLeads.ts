import { useState, useEffect } from 'react';
import { format, parseISO } from 'date-fns';
import {
  createMarketingLead,
  deleteMarketingLeadById,
  getExpenses,
  getAllLeadSources,
  getAllLocations,
  editMarketingLead,
  exportMarketingLeadsCSV,
} from '@/services/marketingLeads';

export interface Expense {
  id: number;
  source: string;
  expense_date: string;
  loc_id: number;
  amount: number;
  location: string;
}

export interface ExpenseFilters {
  page?: number;
  pageSize?: number;
  ordering?: string;
  start_date?: string;
  end_date?: string;
  location_id?: number;
}

export interface ExpenseTable {
  id: number;
  source: string;
  expenseDate: string;
  locId: number;
  amount: number;
  location: string;
}

interface UseExpensesProps {
  initialFilters?: ExpenseFilters;
  autoFetch?: boolean;
}

export const useExpenses = ({
  initialFilters = {},
  autoFetch = true,
}: UseExpensesProps = {}) => {
  const [expenses, setExpenses] = useState<ExpenseTable[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [totalCount, setTotalCount] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);
  const [filters, setFilters] = useState<ExpenseFilters>({
    page: 1,
    pageSize: 10,
    ...initialFilters,
  });

  const transformExpense = (expense: Expense[]) => {
    return expense?.map((item: Expense) => ({
      id: item?.id,
      source: item?.source,
      expenseDate: item?.expense_date
        ? format(parseISO(item?.expense_date), 'yyyy-MM-dd')
        : '-',
      locId: item?.loc_id,
      amount: item?.amount,
      location: item?.location,
    }));
  };

  const getFieldName = (fieldName: string) => {
    const isDescending = fieldName.startsWith('-');
    const cleanFieldName = isDescending ? fieldName.slice(1) : fieldName;

    const fieldMappings: Record<string, string> = {
      id: 'id',
      source: 'source',
      expenseDate: 'expense_date',
      locId: 'loc_id',
      amount: 'amount',
      location: 'location',
    };

    const mappedField = fieldMappings[cleanFieldName] || cleanFieldName;
    return isDescending ? `-${mappedField}` : mappedField;
  };

  const deleteLead = async (id: string) => {
    setIsDeleting(true);
    setError(null);

    try {
      await deleteMarketingLeadById(id);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setIsDeleting(false);
    }
  };

  const fetchExpenses = async (currentFilters: ExpenseFilters = filters) => {
    try {
      setIsLoading(true);
      const params = new URLSearchParams({
        ...(currentFilters?.start_date && {
          start_date: currentFilters.start_date,
        }),
        ...(currentFilters?.end_date && { end_date: currentFilters.end_date }),
        ...(currentFilters?.location_id && {
          location_id: String(currentFilters.location_id),
        }),
        ...(currentFilters?.ordering && {
          ordering: getFieldName(currentFilters.ordering),
        }),
        page: String(currentFilters?.page || 1),
        page_size: String(currentFilters?.pageSize || 10),
      });

      const response = await getExpenses(`?${params.toString()}`);

      if (!response?.data) {
        throw new Error('Invalid response from API');
      }

      const transformedData = transformExpense(response?.data);

      setExpenses(transformedData);
      setTotalCount(response?.meta_data?.total_count || 0);
      return response?.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const createExpense = async (data: Omit<Expense, 'id'>) => {
    try {
      setIsLoading(true);
      const response = await createMarketingLead(data);
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const editExpense = async (id: string, data: Omit<Expense, 'id'>) => {
    try {
      setIsLoading(true);
      const response = await editMarketingLead(data, id);
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (!autoFetch) return;

    fetchExpenses();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    filters.page,
    filters.pageSize,
    filters.ordering,
    filters.start_date,
    filters.end_date,
    filters.location_id,
  ]);

  return {
    deleteLead,
    isDeleting,
    expenses,
    isLoading,
    error,
    totalCount,
    filters,
    setFilters,
    refetch: fetchExpenses,
    createExpense,
    editExpense,
  };
};

export interface LeadSource {
  id: string;
  name: string;
}

export interface Location {
  id: number;
  name: string;
}

export const useLeadSources = () => {
  const [leadSources, setLeadSources] = useState<LeadSource[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchLeadSources = async () => {
    try {
      setIsLoading(true);
      const response = await getAllLeadSources();

      if (response?.data && Array.isArray(response.data)) {
        // Transform the string array into LeadSource objects
        const validSources = response.data
          .filter(
            (source: unknown): source is string =>
              source !== null &&
              typeof source === 'string' &&
              source.trim() !== ''
          )
          .map((source: string) => ({
            id: source,
            name: source,
          }));

        setLeadSources(validSources);
      } else {
        setLeadSources([]);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      setLeadSources([]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchLeadSources();
  }, []);

  return { leadSources, isLoading, error, refetch: fetchLeadSources };
};

export interface MarketingLeadsFilters {
  start_date?: string;
  end_date?: string;
  location_id?: number;
  representative_id?: string;
  ordering?: string;
}

export const useExportMarketingLeads = () => {
  const [isExporting, setIsExporting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const exportLeads = async (filters: MarketingLeadsFilters) => {
    try {
      setIsExporting(true);
      setError(null);
      await exportMarketingLeadsCSV(filters);
    } catch (err) {
      const errorMessage =
        err instanceof Error
          ? err.message
          : 'An error occurred while exporting';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setTimeout(() => {
        setIsExporting(false);
      }, 1000);
    }
  };

  return {
    exportLeads,
    isExporting,
    error,
  };
};

export const useLocations = () => {
  const [locations, setLocations] = useState<Location[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchLocations = async () => {
    try {
      setIsLoading(true);
      const response = await getAllLocations();

      if (response?.data && Array.isArray(response?.data)) {
        // Transform and validate the location data in a single pass
        const validLocations = response?.data?.reduce(
          (acc: Location[], item: any) => {
            if (
              item &&
              typeof item === 'object' &&
              'id' in item &&
              typeof item?.id === 'number' &&
              'name' in item &&
              typeof item?.name === 'string' &&
              item?.name?.trim() !== ''
            ) {
              acc.push({
                id: item?.id,
                name: item?.name?.trim(),
              });
            }
            return acc;
          },
          []
        );

        setLocations(validLocations);
      } else {
        setLocations([]);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      setLocations([]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchLocations();
  }, []);

  return { locations, isLoading, error, refetch: fetchLocations };
};
