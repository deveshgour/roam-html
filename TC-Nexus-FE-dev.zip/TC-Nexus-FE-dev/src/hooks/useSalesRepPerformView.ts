import { getJobListing } from '@/services/salesReport';
import { useState } from 'react';
import { format, parseISO } from 'date-fns';
import { showErrorMsg } from '@/utils/notifications';
import { ERROR_MESSAGES } from '@/constants/messages';
import { PAGE_SIZE } from '@/constants/configs';

interface TransformedJobListing {
  customer: string;
  job_name: string;
  contract_signed_date: string;
  job_price: string;
  change_order: string;
  total_amount: string;
}
// Add these interfaces at the top with other interfaces
interface PaginationState {
  page: number;
  pageSize: number;
  total: number;
}

interface FilterState {
  dateRange: [Date | null, Date | null] | null;
  location: string;
  revenueType: string;
  salesRep: string;
}
// Add new state for chart-specific time periods
export type TimePeriod = 'monthly' | 'quarterly' | 'yearly' | 'weekly';

export const useSalesRepView = (filters: any) => {
  const [jobs, setJobs] = useState<TransformedJobListing[] | []>([]);
  const [salesRepId, setSalesRepId] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  // Add pagination state
  const [pagination, setPagination] = useState<PaginationState>({
    page: 1,
    pageSize: 5,
    total: 0,
  });

  const fetchSalesRepTableViewData = async (
    pageNumber?: number,
    pageSize?: number,
    id?: any
  ) => {
    try {
      setIsLoading(true);
      let queryString = getQueryParams(
        filters,
        null,
        true,
        pageNumber || pagination.page,
        pageSize || pagination.pageSize
      );
      if (id) {
        queryString += `&representative_id=${id}`;
      }
      const response = await getJobListing(queryString);
      let transformedData = transformJobListingTableData(response?.data) || [];

      setJobs(transformedData);

      setPagination((prev) => ({
        ...prev,
        total: response.meta_data.total_count,
      }));
    } catch (err: any) {
      showErrorMsg(err.message || ERROR_MESSAGES.internalError);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSalesRepView = (id: any) => {
    setPagination((prev) => ({
      ...prev,
      page: 1,
      pageSize: PAGE_SIZE[0],
      total: 0,
    }));
    setSalesRepId(id);
    fetchSalesRepTableViewData(1, PAGE_SIZE[0], id);
  };

  // Fetch info cards data
  // Update getQueryParams to include pagination
  const getQueryParams = (
    filters: FilterState,
    timePeriod: TimePeriod | null,
    includePagination: boolean = false,
    currentPage?: number,
    pageSize?: number
  ): string => {
    const queryParams = new URLSearchParams();
    // ... existing filter params logic ...
    if (filters?.dateRange && filters?.dateRange[0] && filters?.dateRange[1]) {
      queryParams.append(
        'start_date',
        filters?.dateRange[0]?.toLocaleDateString('en-CA')
      );
      queryParams.append(
        'end_date',
        filters?.dateRange[1]?.toLocaleDateString('en-CA')
      );
    }

    if (filters.location)
      queryParams.append('location_id', filters.location.toString());
    if (filters.salesRep)
      queryParams.append('representative_id', filters.salesRep.toString());
    if (filters.revenueType)
      queryParams.append('revenue_type_id', filters.revenueType.toString());

    // Add pagination params if needed
    if (includePagination) {
      queryParams.append('page', (currentPage || pagination.page).toString());
      queryParams.append(
        'page_size',
        (pageSize || pagination.pageSize).toString()
      );
    }

    return queryParams.toString();
  };

  function transformJobListingTableData(data: any): TransformedJobListing[] {
    return (
      data.map((item: any) => ({
        customer: item?.customer_name ? item?.customer_name : '--',
        job_name: item?.job_name ? item?.job_name : '--',
        contract_signed_date: item.contract_signed_date
          ? format(parseISO(item.contract_signed_date), 'MM/dd/yyyy')
          : '--',

        job_price: `$${item?.job_price}`,
        change_orders:
          item?.change_order == 0 ? '- -' : `$${item?.change_order}`,
        total_amount: `$${item?.total_amount}`,
      })) || []
    );
  }

  // Add pagination handlers
  const handlePageChange = (newPage: number) => {
    setPagination((prev) => ({ ...prev, page: newPage }));
    fetchSalesRepTableViewData(newPage, pagination.pageSize, salesRepId);
  };

  const handlePageSizeChange = (newPageSize: number) => {
    setPagination((prev) => ({ ...prev, pageSize: newPageSize, page: 1 }));
    fetchSalesRepTableViewData(1, newPageSize, salesRepId);
  };

  return {
    isLoading,
    jobs,
    pagination,
    handlePageChange,
    handlePageSizeChange,
    setPagination,
    handleSalesRepView,
  };
};
