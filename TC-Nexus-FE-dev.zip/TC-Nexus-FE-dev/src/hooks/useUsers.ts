import { useState, useEffect } from 'react';
import {
  getUsers,
  updateUserStatus,
  deleteUserById,
  createUser,
  editUser,
  resetPassword,
  getLocationsList,
  getRolesList,
} from '@/services/user';
import { format, parseISO } from 'date-fns';
import { UserFormValues } from '@/app/users/management/components/addUserModal';
import { getTeams } from '@/services/team';

export interface User {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
  phone_number: string;
  is_active: boolean;
  is_superuser: boolean;
  last_login: string | null;
  created_at: string;
  updated_at: string;
  role_and_location: {
    role_id: string;
    loc_id: string;
  }[];
}

export interface UserFilters {
  email?: string;
  page?: number;
  pageSize?: number;
  ordering?: string;
}

interface UserTable {
  id: string;
  name: string;
  email: string;
  status: 'active' | 'inactive';
  phone: string;
  role_and_location: {
    role_id: string;
    loc_id: string;
  }[];
  createdOn: string;
  lastLogin: string;
}

interface UseUsersProps {
  initialFilters?: UserFilters;
  autoFetch?: boolean;
}
interface LocationType {
  value: string;
  label: string;
}
interface RoleType {
  value: string;
  label: string;
}

interface TeamType {
  value: string;
  label: string;
}
export const useUsers = ({
  initialFilters = {},
  autoFetch = true,
}: UseUsersProps = {}) => {
  const [users, setUsers] = useState<UserTable[]>([]);
  const [locations, setLocations] = useState<LocationType[]>([]);
  const [roles, setRoles] = useState<RoleType[]>([]);
  const [teams, setTeams] = useState<TeamType[]>([]);
  const [isRoleLoading, setIsRoleLoading] = useState(true);
  const [isTeamLoading, setIsTeamLoading] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const [isLocationLoading, setIsLocationLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [totalCount, setTotalCount] = useState(0);
  const [filters, setFilters] = useState<UserFilters>({
    page: 1,
    pageSize: 10,
    ...initialFilters,
  });

  const transformUser = (users: User[]) => {
    return users.map((user: User) => {
      // Group by role_id to handle multiple locations
      const roleGroups = user.role_and_location.reduce(
        (acc, item) => {
          if (!acc[item.role_id]) {
            acc[item.role_id] = [];
          }
          acc[item.role_id].push(item);
          return acc;
        },
        {} as Record<string, any[]>
      );

      const transformedRoleAndLocation = Object.values(roleGroups).flatMap(
        (group) => {
          const firstItem = group[0];

          // Check if this role has all available locations
          const allLocationIds = locations
            .filter((loc) => loc.value !== 'all')
            .map((loc) => loc.value.toString());

          const userLocationIds = group.map((item) => item.loc_id.toString());
          const hasAllLocations =
            allLocationIds.length > 0 &&
            allLocationIds.every((locId) => userLocationIds.includes(locId));

          if (hasAllLocations) {
            return [
              {
                key: `${firstItem.role_id}-all`,
                role_id: firstItem.role_id,
                loc_id: 'all',
                team_id: firstItem.team_id || '',
                role_type: firstItem.role_type || '',
              },
            ];
          }

          // Return individual entries for each location
          return group.map((item) => ({
            key: `${item.role_id}-${item.loc_id}`,
            role_id: item.role_id,
            loc_id: item.loc_id,
            team_id: item.team_id || '',
            role_type: item.role_type || '',
          }));
        }
      );

      return {
        id: user.id,
        name: `${user.first_name} ${user.last_name}`,
        email: user.email || '-',
        phone: user.phone_number || '-',
        role_and_location: transformedRoleAndLocation,
        status: user.is_active ? ('active' as const) : ('inactive' as const),
        createdOn: user.created_at
          ? format(parseISO(user.created_at), 'yyyy-MM-dd')
          : '-',
        lastLogin: user.last_login
          ? format(parseISO(user.last_login), 'yyyy-MM-dd HH:mm')
          : '-',
      };
    });
  };

  const getFieldName = (fieldName: string) => {
    // Extract minus sign if present
    const isDescending = fieldName.startsWith('-');
    const cleanFieldName = isDescending ? fieldName.slice(1) : fieldName;

    const fieldMappings: Record<string, string> = {
      name: 'first_name',
      email: 'email',
      phone: 'phone_number',
      createdOn: 'created_at',
      lastLogin: 'last_login',
      id: 'id',
    };

    // Get mapped field name and reapply minus sign if present
    const mappedField = fieldMappings[cleanFieldName] || cleanFieldName;
    return isDescending ? `-${mappedField}` : mappedField;
  };

  const fetchUsers = async (currentFilters: UserFilters = filters) => {
    try {
      setIsLoading(true);
      const params = new URLSearchParams({
        ...(currentFilters.email && { search_str: currentFilters.email }),
        ...(currentFilters.ordering && {
          ordering: getFieldName(currentFilters.ordering),
        }),
        page: String(currentFilters.page || 1),
        page_size: String(currentFilters.pageSize || 10),
      });

      const response = await getUsers(`?${params.toString()}`);

      let userArr: UserTable[] = transformUser(response.data);
      setUsers(userArr);
      setTotalCount(response.meta_data.total_count);
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const transformLocations = (data: any) => {
    return data.map((item: any) => ({
      value: item.id.toString(),
      label: item.name,
    }));
  };

  const transformRoles = (data: any) => {
    return data.map((item: any) => ({
      value: item.id.toString(),
      label: item.name,
      role_type: item.role_type,
    }));
  };

  const fetchLocations = async () => {
    try {
      setIsLocationLoading(true);
      const response = await getLocationsList();
      let locationsArr = transformLocations(response.data);
      setLocations([{ value: 'all', label: 'All' }, ...locationsArr]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    } finally {
      setIsLocationLoading(false);
    }
  };

  const fetchRoles = async () => {
    try {
      setIsRoleLoading(true);
      const response = await getRolesList();
      let RolesArr = transformRoles(response.data);
      setRoles(RolesArr);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    } finally {
      setIsRoleLoading(false);
    }
  };

  const fetchTeams = async () => {
    try {
      setIsTeamLoading(true);
      const response = await getTeams();
      let teamsArr = transformRoles(response.data);
      setTeams(teamsArr);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    } finally {
      setIsTeamLoading(false);
    }
  };

  useEffect(() => {
    fetchLocations();
    fetchRoles();
    fetchTeams();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!autoFetch) return;

    fetchUsers();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    filters.page,
    filters.pageSize,
    filters.email,
    filters.ordering,
    isLocationLoading,
  ]);

  const updateFilters = (newFilters: Partial<UserFilters>) => {
    setFilters((prev) => ({
      ...prev,
      ...newFilters,
      page: newFilters.page || 1,
    }));
  };

  const prepareUserPayload = (userData: UserFormValues) => {
    return {
      first_name: userData.firstName,
      last_name: userData.lastName,
      email: userData.email,
      phone_number: userData.phone,
      is_active: userData.status === 'active',
      password: userData.password,
      role_and_location: (userData.roleLocations || []).flatMap(
        (rolLocation) => {
          if (rolLocation.location == 'all') {
            return locations
              .filter((item) => item.value !== 'all')
              .map((item: any) => {
                return {
                  role_id: rolLocation.role || '',
                  loc_id: item.value || '',
                  ...(rolLocation.team && { team_id: rolLocation.team }),
                };
              });
          } else {
            return {
              role_id: rolLocation.role || '',
              loc_id: rolLocation.location || '',
              ...(rolLocation.team && { team_id: rolLocation.team }),
            };
          }
        }
      ),
    };
  };

  const addUser = async (userData: UserFormValues) => {
    try {
      const payload = prepareUserPayload(userData);
      const response = await createUser(payload);
      fetchUsers();
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    }
  };

  const prepareEditUserPayload = (userData: UserFormValues) => {
    return {
      first_name: userData.firstName,
      last_name: userData.lastName,
      email: userData.email,
      phone_number: userData.phone,
      is_active: userData.status === 'active',
      role_and_location: (userData.roleLocations || []).flatMap((item) => {
        if (item.location === 'all') {
          return locations
            .filter((loc) => loc.value !== 'all')
            .map((loc) => ({
              role_id: item.role || '',
              loc_id: loc.value || '',
              ...(item.team && { team_id: item.team }),
            }));
        } else {
          return [
            {
              role_id: item.role || '',
              loc_id: item.location || '',
              ...(item.team && { team_id: item.team }),
            },
          ];
        }
      }),
    };
  };

  const updateUser = async (id: string, userData: UserFormValues) => {
    try {
      const payload = prepareEditUserPayload(userData);
      const response = await editUser(payload, id);

      const transformedUser = transformUser([
        { ...response.data, role_and_location: response.data.roles },
      ]);

      setUsers((prevUsers) =>
        prevUsers.map((user) =>
          user.id === id
            ? {
                ...user,
                ...transformedUser[0],
                role_and_location: response.data.roles,
              }
            : user
        )
      );
      fetchUsers();

      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    }
  };

  const activateDeactivateUser = async (userId: string, status: boolean) => {
    try {
      const response = await updateUserStatus(userId, status);
      // Update the user's status in the local state
      setUsers((prevUsers) =>
        prevUsers.map((user) =>
          user.id === userId
            ? { ...user, status: status ? 'active' : 'inactive' }
            : user
        )
      );
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    }
  };

  const deleteUser = async (id: string) => {
    try {
      await deleteUserById(id);
      setUsers((prevUsers) => prevUsers.filter((user) => user.id !== id));
      setFilters({ page: 1, pageSize: filters.pageSize || 10 });
      fetchUsers();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    }
  };

  const resetUserPassword = async (userId: string, password: string) => {
    try {
      await resetPassword(userId, password);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    }
  };

  return {
    users,
    error,
    totalCount,
    filters,
    isLoading,
    locations,
    isLocationLoading,
    roles,
    isRoleLoading,
    isTeamLoading,
    teams,
    updateFilters,
    fetchUsers,
    addUser,
    updateUser,
    deleteUser,
    activateDeactivateUser,
    resetUserPassword,
  };
};
