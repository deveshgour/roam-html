import { SCREEN_NAME, SORTING_TYPES } from '@/constants/configs';
import { getLocations } from '@/services/common';
import { SortingState, SortingTypes } from '@/types/common';
import { useEffect, useRef, useState } from 'react';
interface FilterState {
  dateRange: [Date | null, Date | null] | null;
  location: string;
}

interface FilterOptions {
  locations: Location[];
}

interface InfoCardData {
  title: string;
  value: string;
  icon: string;
  iconBgColor: string;
  iconColor: string;
  borderColor: string;
}

interface ChartData {
  title: string;
  categories: string[];
  series: {
    name: string;
    data: { y: number }[];
    color: string;
    type: 'column' | 'bar';
    borderRadius: number;
    pointWidth: number;
  }[];
}

interface ChartDataPoint {
  customers_acquired: number;
  marketing_spend: number;
  category: string;
}

interface BarChartDataPoint {
  category: string;
  customer: number;
}
interface LeadSourceResponseData {
  id: string;
  source: string;
  marketingCost: number;
  customers: number;
  cac: number;
}

interface TrendChartData {
  title: string;
  categories: string[];
  series: {
    name: string;
    data: { y: number; growth: number }[];
    color: string;
    type: any;
  }[];
  yAxisMax: number;
  yAxisMin: number; // Added yAxisMin property
  type: string;
  yAxisTickInterval: number;
  useDualYAxis: boolean; // Added useDualYAxis property
  marker?: { enabled: boolean; symbol: string }; // Added marker property
}

interface PaginationState {
  page: number;
  pageSize: number;
  total: number;
}

interface HighNumbersResponse {
  average_cac: number;
  total_customers: number;
  best_performing_source: number;
}

// Add at the top with other interfaces
interface ErrorStates {
  filterOptions: Error | null;
  infoCards: Error | null;
  barChart: Error | null;
  trendChart: Error | null;
  sourceBarChart: Error | null;
}

// Add new state for chart-specific time periods
export type TimePeriod = 'monthly' | 'quarterly' | 'yearly' | 'weekly';
interface TrendChartDataPoint {
  week?: string;
  month?: string;
  quarter?: string;
  year?: string;
  total_revenue?: number;
  trend?: string;
}

export interface TransformLeadSource {
  id: string;
  source: string;
  marketingCost: number;
  customers: number;
  cac: number;
}

export interface TransformedSalesRep {
  id: string;
  source: string;
  marketingCost: number;
  customers: number;
  cac: number;
}

export interface TransformSourceDetail {
  id: string;
  job_name: string;
  customer: string;
  total_amount: number;
}

export interface Location {
  id: number;
  name: string;
}

const trendColors = {
  Customers: '#4CAF50',
  CAC: '#FFC107',
};

const transformInfoCardsData = (
  data: HighNumbersResponse[]
): InfoCardData[] => {
  return [
    {
      title: 'Average CAC',
      value:
        data?.length > 0 && data[0]?.average_cac !== undefined
          ? `${data[0]?.average_cac}`
          : '--',
      icon: 'dollarSign',
      iconBgColor: 'bg-amber-50',
      iconColor: 'text-amber-400',
      borderColor: 'border-amber-200',
    },
    {
      title: 'Total Customers',
      value:
        data?.length > 0 && data[1]?.total_customers !== undefined
          ? `${data[1]?.total_customers}`
          : '--',
      icon: 'userGroup',
      iconBgColor: 'bg-blue-50',
      iconColor: 'text-blue-600',
      borderColor: 'border-blue-200',
    },
    {
      title: 'Best Performing Source',
      value:
        data?.length > 0 && data[2]?.best_performing_source !== undefined
          ? `${data[2]?.best_performing_source}`
          : '--',
      icon: 'history',
      iconBgColor: 'bg-pink-50',
      iconColor: 'text-pink-600',
      borderColor: 'border-pink-200',
    },
  ];
};

export const useMarketingCAC = () => {
  const isMounted = useRef(false);

  // Regular filters
  const [filters, setFilters] = useState<FilterState>({
    dateRange: null,
    location: '',
  });

  // Filter update handler
  const updateFilters = (newFilters: Partial<FilterState>) => {
    setFilters((prev) => ({ ...prev, ...newFilters }));
  };

  // Data states
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({
    locations: [],
  });
  const [trendChartTimePeriod, setTrendChartTimePeriod] =
    useState<TimePeriod>('monthly');

  // states
  const [infoCardsData, setInfoCardsData] = useState<InfoCardData[] | null>(
    null
  );
  const [barChartData, setBarChartData] = useState<ChartData | null>(null);

  const [trendChartData, setTrendChartData] = useState<TrendChartData | null>(
    null
  );

  const [sourceBarChartData, setSourceBarChartData] =
    useState<ChartData | null>(null);

  const [leadSourceTableData, setLeadSourceTableData] = useState<
    LeadSourceResponseData[] | null
  >(null);

  // Loading states
  const [loadingStates, setLoadingStates] = useState({
    filterOptions: true,
    infoCards: true,
    barChart: true,
    trendChart: true,
    sourceBarChart: true,
    leadSourceTable: true,
  });

  // Update the errors state initialization
  const [errors, setErrors] = useState<ErrorStates>({
    filterOptions: null,
    infoCards: null,
    barChart: null,
    trendChart: null,
    sourceBarChart: null,
  });

  const [sourcePagination, setSourcePagination] = useState<PaginationState>({
    page: 1,
    pageSize: 10,
    total: 0,
  });

  const [sorting, setSorting] = useState<SortingState>({
    field: 'name',
    direction: null,
  });

  const handleTrendChartTimePeriodChange = (newPeriod: TimePeriod) => {
    setTrendChartTimePeriod(newPeriod);
    fetchTrendChart();
  };

  // Add pagination handlers
  const handleSourcePageChange = (newPage: number) => {
    setSourcePagination((prev) => ({ ...prev, page: newPage }));
    fetchLeadSourceTable(
      newPage,
      sourcePagination.pageSize,
      sorting.field,
      sorting.direction
    );
  };

  const handlePageSizeChange = (newPageSize: number) => {
    setSourcePagination((prev) => ({
      ...prev,
      pageSize: newPageSize,
      page: 1,
    }));
    fetchLeadSourceTable(1, newPageSize, sorting.field, sorting.direction);
  };

  const handleSortingChange = (field: string, direction: SortingTypes) => {
    setSorting((prev) => ({ ...prev, field, direction }));
    setSourcePagination((prev) => ({ ...prev, page: 1 }));
    fetchLeadSourceTable(1, sourcePagination.pageSize, field, direction);
  };

  const transformChartData = (data: ChartDataPoint[]) => {
    if (!data || data.length === 0) {
      return {
        title: 'Spend Vs. Customer Acquired',
        categories: [],
        yAxisMax: 0,
        yAxisTickInterval: 20,
        useDualYAxis: true,
        series: [
          {
            name: 'Customers Acquired',
            data: [],
            color: '#3498db',
            type: 'column' as const,
            borderRadius: 8,
            pointWidth: 36,
            yAxis: 0, // Left Y-axis
          },
          {
            name: 'Marketing Spends',
            data: [],
            color: '#2c5e4b',
            type: 'column' as const,
            borderRadius: 8,
            pointWidth: 36,
            yAxis: 1, // Right Y-axis
          },
        ],
      };
    }

    // Check if all values are zero
    const isAllZero = data.every(
      (item) => item.customers_acquired === 0 && item.marketing_spend === 0
    );
    if (isAllZero) {
      return null;
    }

    // Find max values for Y-axes
    const maxCustomers = Math.max(
      ...data.map((item) => item.customers_acquired)
    );
    const maxSpend = Math.max(...data.map((item) => item.marketing_spend));
    const yAxisMaxCustomers =
      maxCustomers > 0 ? Math.ceil(maxCustomers / 300) * 300 : 100;

    const yAxisMaxSpend = maxSpend > 0 ? Math.ceil(maxSpend / 300) * 300 : 100;

    return {
      title: 'Spend Vs. Customer Acquired',
      categories: data.map((item) => item.category),
      useDualYAxis: true, // ✅ Enables dual Y-axes
      type: 'column',
      legend: { enabled: true },
      series: [
        {
          name: 'Customers Acquired',
          data: data.map((item) => ({ y: item.customers_acquired })),
          color: '#3498db',
          type: 'column' as const,
          borderRadius: 8,
          pointWidth: 16,
          yAxis: 0, // Uses left Y-axis
        },
        {
          name: 'Marketing Spends',
          data: data.map((item) => ({ y: item.marketing_spend })),
          color: '#2c5e4b',
          type: 'column' as const,
          borderRadius: 8,
          pointWidth: 16,
          tickInterval: 300,
          yAxis: 1, // Uses right Y-axis
        },
      ],
      yAxis: [
        {
          title: { text: 'Customers Acquired' },
          max: yAxisMaxCustomers,
          labels: { format: '{value}' },
        },
        {
          title: { text: 'Marketing Spends ($)' },
          max: yAxisMaxSpend,
          tickInterval: 300,
          labels: { format: '${value}' },
          opposite: true, // Moves this axis to the right
        },
      ],
    };
  };

  const transformBarChartData = (data: BarChartDataPoint[]) => {
    if (!data || data.length === 0) {
      return {
        title: 'Spend Vs. Customer Acquired',
        categories: [],
        type: 'bar',
        yAxisMax: 0,
        yAxisTickInterval: 100,
        series: [
          {
            name: 'Customers Acquired',
            data: [],
            color: '#3498db',
            type: 'bar' as const,
            borderRadius: 0,
            pointWidth: 36,
            yAxis: 0, // Left Y-axis
          },
        ],
      };
    }

    // Check if all values are zero
    const isAllZero = data.every((item) => item.customer === 0);
    if (isAllZero) {
      return null;
    }

    // Find max values for Y-axes
    const maxSpend = Math.max(...data.map((item) => item.customer)) || 0;
    const yAxisMax = maxSpend > 0 ? maxSpend * 1.1 : 5000;

    return {
      title: 'Customers By Lead Source',
      categories: data.map((item) => item.category),
      yAxisTickInterval: 100,
      yAxisMax,

      series: [
        {
          name: 'Customers',
          data: data.map((item) => ({ y: item.customer })),
          color: '#3498db',
          type: 'bar' as const,
          borderRadius: 0,
          pointWidth: 16,
        },
      ],
    };
  };

  const transformTrendChartData = (
    data: TrendChartDataPoint[]
  ): TrendChartData | null => {
    if (!data || data.length === 0) {
      return {
        title: 'CAC Trends Over Time',
        type: 'spline',
        categories: [],
        series: [],
        yAxisMax: 0,
        yAxisMin: 0,
        yAxisTickInterval: 100,
        useDualYAxis: false,
      };
    }

    const categories = [...new Set(data.map((item) => item.month))]; // Unique months
    const series = [
      {
        name: 'Customers',
        type: 'spline',
        marker: { enabled: true, symbol: 'circleOutline' },
        data: categories.map((month) => {
          const point = data.find(
            (item) => item.trend === 'Customers' && item.month === month
          );
          return {
            y: point?.total_revenue !== undefined ? point.total_revenue : 0,
            growth: 0,
          }; // Ensure y is always a number
        }),
        color: trendColors.Customers, // Add color property
      },
      {
        name: 'CAC',
        type: 'spline',
        marker: { enabled: true, symbol: 'circleOutline' },
        data: categories.map((month) => {
          const point = data.find(
            (item) => item.trend === 'CAC' && item.month === month
          );
          return {
            y: point?.total_revenue !== undefined ? point.total_revenue : 0,
            growth: 0,
          }; // Add default growth value
        }),
        yAxis: 1, // Link to the second Y-axis
        color: trendColors.CAC, // Add color property
      },
    ];

    const yAxisMax =
      Math.max(...data.map((item) => item.total_revenue ?? 0), 0) * 1.1;

    return {
      title: 'CAC Trends Over Time',
      type: 'spline',
      categories: categories.filter(
        (category): category is string => category !== undefined
      ),
      series,
      yAxisMax,
      yAxisTickInterval: 100,
      yAxisMin: 0,
      useDualYAxis: false,
    };
  };

  /**
   * Transforms the lead source table data into the expected format for the component.
   * @param {any[]} data - The data from the API.
   * @returns {LeadSourceResponseData[]} - The transformed data.
   */
  const transformLeadSourceTableData = (
    data: any[]
  ): LeadSourceResponseData[] => {
    return (
      data?.map((item, index) => ({
        /**
         * The ID of the item.
         */
        id: (index + 1).toString(),
        /**
         * The source of the item.
         */
        source: item?.source || '',
        /**
         * The number of marketing cost.
         */
        marketingCost: item?.marketingCost || 0,
        /**
         * The number of customers.
         */
        customers: item?.customers || 0,
        /**
         * The number of cac items.
         */
        cac: item?.cac || 0,
      })) || []
    );
  };

  // Fetch filter options
  const fetchFilterOptions = async () => {
    try {
      // setLoadingStates((prev) => ({ ...prev, filterOptions: true }));
      const results = await Promise.allSettled([
        getLocations(SCREEN_NAME.MARKETING_ANALYTICS),
      ]);

      const [locationsResult] = results;

      setFilterOptions({
        locations:
          locationsResult?.status === 'fulfilled' ? locationsResult?.value : [],
      });

      // // Set error if either request failed
      if (results.some((result) => result.status === 'rejected')) {
        const error = new Error('Failed to fetch some filter options');
        setErrors((prev) => ({ ...prev, filterOptions: error }));
      } else {
        setErrors((prev) => ({ ...prev, filterOptions: null }));
      }
    } catch (error) {
      setErrors((prev) => ({ ...prev, filterOptions: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, filterOptions: false }));
    }
  };

  // Fetch info cards data
  const fetchInfoCards = async () => {
    try {
      setLoadingStates((prev) => ({ ...prev, infoCards: true }));

      // Dummy data
      const dummyResponse: HighNumbersResponse[] = [
        {
          average_cac: 85,
          total_customers: 0,
          best_performing_source: 0,
        },
        {
          total_customers: 390,
          average_cac: 0,
          best_performing_source: 0,
        },
        {
          best_performing_source: 1,
          average_cac: 0,
          total_customers: 0,
        },
      ];

      // Simulate an API delay
      await new Promise((resolve) => setTimeout(resolve, 1000));

      const transformedData = transformInfoCardsData(dummyResponse);
      setInfoCardsData(transformedData);
      setErrors((prev) => ({ ...prev, infoCards: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, infoCards: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, infoCards: false }));
    }
  };

  const fetchBarChart = async () => {
    try {
      setLoadingStates((prev) => ({ ...prev, barChart: true }));

      // Dummy data instead of API response
      const dummyChartData: ChartDataPoint[] = [
        {
          category: 'Google Ads',
          customers_acquired: 8800,
          marketing_spend: 12000,
        },
        {
          category: 'Facebook Ads',
          customers_acquired: 3000,
          marketing_spend: 3000,
        },
        {
          category: 'Google PPC',
          customers_acquired: 81440,
          marketing_spend: 8000,
        },
        {
          category: 'Referrals',
          customers_acquired: 90000,
          marketing_spend: 4000,
        },
        {
          category: 'Events',
          customers_acquired: 51110,
          marketing_spend: 3000,
        },
        {
          category: 'Yard Signs',
          customers_acquired: 71115,
          marketing_spend: 5000,
        },
        {
          category: 'Others',
          customers_acquired: 610005,
          marketing_spend: 7000,
        },
      ];
      // Transform the dummy data
      const transformedData = transformChartData(dummyChartData);

      setBarChartData(transformedData);
      setErrors((prev) => ({ ...prev, barChart: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, barChart: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, barChart: false }));
    }
  };

  const fetchSourceChart = async () => {
    try {
      setLoadingStates((prev) => ({ ...prev, sourceBarChart: true }));

      // Dummy data instead of API response
      const dummyChartData: BarChartDataPoint[] = [
        {
          category: 'Google Ads',
          customer: 120,
        },
        {
          category: 'Facebook Ads',
          customer: 300,
        },
        {
          category: 'Google PPC',
          customer: 814,
        },
        {
          category: 'Referrals',
          customer: 800,
        },
        {
          category: 'Events',
          customer: 511,
        },
        {
          category: 'Yard Signs',
          customer: 711,
        },
        {
          category: 'Others',
          customer: 610,
        },
      ];
      // Transform the dummy data
      const transformedData = transformBarChartData(dummyChartData);

      setSourceBarChartData(transformedData);
      setErrors((prev) => ({ ...prev, sourceBarChart: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, sourceBarChart: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, sourceBarChart: false }));
    }
  };

  const fetchTrendChart = async () => {
    try {
      setLoadingStates((prev) => ({ ...prev, trendChart: true }));

      // Dummy data based on the chart in the image
      const dummyData: TrendChartDataPoint[] = [
        { month: 'JAN', trend: 'Customers', total_revenue: 40 },
        { month: 'FEB', trend: 'Customers', total_revenue: 50 },
        { month: 'MAR', trend: 'Customers', total_revenue: 65 },
        { month: 'APR', trend: 'Customers', total_revenue: 70 },
        { month: 'MAY', trend: 'Customers', total_revenue: 90 },
        { month: 'JUN', trend: 'Customers', total_revenue: 120 },
        { month: 'JAN', trend: 'CAC', total_revenue: 95 },
        { month: 'FEB', trend: 'CAC', total_revenue: 85 },
        { month: 'MAR', trend: 'CAC', total_revenue: 70 },
        { month: 'APR', trend: 'CAC', total_revenue: 65 },
        { month: 'MAY', trend: 'CAC', total_revenue: 60 },
        { month: 'JUN', trend: 'CAC', total_revenue: 55 },
      ];

      // Transform the data to the required format
      const transformedData = transformTrendChartData(dummyData);

      // Update the state with the dummy data
      setTrendChartData(transformedData);

      // Clear any previous errors
      setErrors((prev) => ({ ...prev, trendChart: null }));
    } catch (error) {
      // Set the error state if something goes wrong
      setErrors((prev) => ({ ...prev, trendChart: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, trendChart: false }));
    }
  };

  // Add fetchLeadSourceTable function
  const fetchLeadSourceTable = async (
    pageNumber?: number,
    pageSize?: number,
    field?: string,
    direction?: SortingTypes
  ) => {
    try {
      setLoadingStates((prev) => ({ ...prev, teamPerformanceTable: true }));

      // Dummy data
      let dummyData = [
        {
          source: 'Facebook Ads',
          marketingCost: 200,
          appointments: 120,
          customers: 80,
          cac: 40,
        },
        {
          source: 'Google Ads',
          marketingCost: 150,
          appointments: 90,
          customers: 60,
          cac: 40,
        },
        {
          source: 'Referral',
          marketingCost: 100,
          appointments: 70,
          customers: 50,
          cac: 50,
        },
        {
          source: 'Door Knocking',
          marketingCost: 80,
          appointments: 40,
          customers: 30,
          cac: 38,
        },
        {
          source: 'LinkedIn Ads',
          marketingCost: 120,
          appointments: 60,
          customers: 45,
          cac: 37,
        },
        {
          source: 'Instagram Ads',
          marketingCost: 140,
          appointments: 85,
          customers: 50,
          cac: 36,
        },
        {
          source: 'YouTube Ads',
          marketingCost: 160,
          appointments: 100,
          customers: 65,
          cac: 41,
        },
        {
          source: 'Email Campaign',
          marketingCost: 110,
          appointments: 60,
          customers: 35,
          cac: 32,
        },
        {
          source: 'Cold Calling',
          marketingCost: 70,
          appointments: 30,
          customers: 20,
          cac: 28,
        },
        {
          source: 'TV Ads',
          marketingCost: 180,
          appointments: 110,
          customers: 75,
          cac: 42,
        },
      ];

      // Sorting logic
      if (field && direction) {
        const fieldName = field as keyof (typeof dummyData)[0];
        dummyData.sort((a, b) => {
          if (direction === SORTING_TYPES.DESC) {
            return b[fieldName] > a[fieldName] ? 1 : -1;
          } else {
            return a[fieldName] > b[fieldName] ? 1 : -1;
          }
        });
      }

      // Pagination logic
      const startIndex =
        ((pageNumber || sourcePagination.page) - 1) *
        (pageSize || sourcePagination.pageSize);
      const endIndex = startIndex + (pageSize || sourcePagination.pageSize);
      const paginatedData = dummyData.slice(startIndex, endIndex);

      // Transform and set data
      setLeadSourceTableData(transformLeadSourceTableData(paginatedData));

      setSourcePagination((prev) => ({
        ...prev,
        total: dummyData.length,
      }));

      setErrors((prev) => ({ ...prev, teamPerformanceTable: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, teamPerformanceTable: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, teamPerformanceTable: false }));
    }
  };

  // Update the initial effect to use the mount ref
  useEffect(() => {
    if (!isMounted.current) {
      fetchFilterOptions();
      isMounted.current = true;
    }
  }, []);

  // Update the filters effect to prevent unnecessary initial calls
  useEffect(() => {
    if (isMounted.current) {
      fetchInfoCards();
      fetchBarChart();
      fetchTrendChart();
      fetchSourceChart();
      fetchLeadSourceTable();
    }
  }, [filters]);

  // Refetch specific section
  const refetchSection = async (section: string) => {
    switch (section) {
      case 'infoCards':
        await fetchInfoCards();
        break;
      case 'barChart':
        await fetchBarChart();
        break;
      case 'trendChart':
        await fetchTrendChart();
        break;
      case 'sourceChart':
        await fetchSourceChart();
        break;
      case 'leadSourceTable':
        await fetchLeadSourceTable();

      // Add other cases
    }
  };

  return {
    filters,
    filterOptions,
    updateFilters,
    refetchSection,
    loadingStates,
    errors,
    infoCardsData,
    trendChartTimePeriod,
    setTrendChartTimePeriod: handleTrendChartTimePeriodChange,
    barChartData,
    trendChartData,
    sourceBarChartData,
    sourcePagination,
    handleSourcePageChange,
    handlePageSizeChange,
    sorting,
    handleSortingChange,
    leadSourceTableData,
  };
};
