import { getLocations, getSalesReps } from '@/services/common';
import {
  downloadPerformanceReport,
  downloadReport,
  exploreDownloadReport,
  getExploreData,
  getHighNumbers,
  getPerformanceReport,
  getRevenueType,
  leastPerforming,
  salesRevenueBarChart,
  salesRevenueLineChart,
  salesRevenuePieChart,
} from '@/services/salesReport';
import { addDays, addMonths, endOfMonth, format } from 'date-fns';
import { useState, useEffect, useRef } from 'react';
import { showErrorMsg } from '@/utils/notifications';
import { TOAST_MESSAGES } from '@/constants/messages';
import { SortingState } from '@/types/common';
import { SCREEN_NAME } from '@/constants/configs';
export interface Location {
  id: number;
  name: string;
}

export interface SalesRep {
  id: number;
  name: string;
}

export interface RevenueType {
  id: number;
  name: string;
}

interface FilterOptions {
  locations: Location[];
  salesReps: SalesRep[];
  revenueType: RevenueType[];
}

interface FilterState {
  dateRange: [Date | null, Date | null] | null;
  location: string;
  revenueType: Array<string | null> | string | string[];
  salesRep: string | string[];
  exploreTable: string;
}

// Add new state for chart-specific time periods
export type TimePeriod = 'monthly' | 'quarterly' | 'yearly' | 'weekly';

interface ChartDataPoint {
  week?: string;
  month?: string;
  quarter?: string;
  year?: string;
  total_revenue: number;
  growth_rate: number;
}

interface TradeRevenue {
  total_revenue: number;
  trades: string;
}

// Define types for each section's data
interface InfoCardData {
  title: string;
  value: string;
  percentage: string;
  isPositive: boolean;
  icon: string;
  iconBgColor: string;
  iconColor: string;
  borderColor: string;
}

// Add at the top with other interfaces
interface ErrorStates {
  filterOptions: Error | null;
  infoCards: Error | null;
  revenueChart: Error | null;
  locationChart: Error | null;
  serviceChart: Error | null;
  salesRepTable: Error | null;
  leastPerforming: Error | null;
}

interface HighNumbersResponse {
  total_revenue: number;
  new_business_revenue: number;
  recurring_business_revenue: number;
  average_job_value: number;
  growth_rate: number;
}

interface SalesRepResponseData {
  representative_id: string;
  representative: string;
  total_revenue: number;
  deals_closed: number;
  average_revenue: number;
  growth_rate: number;
}

interface TransformedLeastPerforming {
  id: string;
  name: string;
  avatar: string;
  sales: number;
}

interface ExploreTableData {
  id: string;
  customer: string;
  representative_name: string;
  job_id: string;
  job_name: string;
  contract_signed_date: string;
  total_amount: string;
  job_type: string;
  trades: string;
  location: string;
  last_sync_date: string;
}

export interface TransformedSalesRep {
  id: string;
  representative_id: string;
  sales_rep: {
    initials: string;
    name: string;
    avatar: string;
  };
  total_revenue: string;
  deals_closed: string;
  deal_size: string;
  growth: {
    value: string;
    isPositive: boolean;
  };
}

export interface TransformedExploreData {
  id: string;
  job_id: string;
  customer: string;
  representative_name: string;
  job_name: string;
  contract_signed_date: string;
  total_amount: string;
  job_type: string;
  trades: string;
  location: string;
  last_sync_date: string;
}
// Add these interfaces at the top with other interfaces
interface PaginationState {
  page: number;
  pageSize: number;
  total: number;
}

interface SalesRepTableData {
  representatives: TransformedSalesRep[];
  total: {
    total_revenue: number;
    deals_closed: number;
    average_revenue: number;
    growth_rate: number;
  };
}

const fieldMap = {
  sales_rep: 'representative',
  total_revenue: 'total_revenue',
  deals_closed: 'deals_closed',
  deal_size: 'average_revenue',
  growth: 'growth_rate',
};

const fieldExploreMap = {
  customer: 'customer',
  job_id: 'job_id',
  representative_name: 'representative_name',
  job_name: 'job_name',
  contract_signed_date: 'contract_signed_date',
  total_amount: 'total_amount',
  job_type: 'job_type',
  trades: 'trades',
  location: 'location',
  last_sync_date: 'last_sync_date',
};

const locationColors = {
  'York, PA': '#4E79A7',
  'Millsboro, DE': '#59A14F',
  'Greenville, SC': '#F28E2C',
  'Bluffton, SC': '#AF7AA1',
  'Charleston, SC': '#E15759',
};

const transformInfoCardsData = (
  data: HighNumbersResponse[]
): InfoCardData[] => {
  return [
    {
      title: 'Total Revenue',
      value:
        data.length > 0 && data[0]?.total_revenue !== undefined
          ? `$${(data[0].total_revenue / 1000).toFixed(2)}k`
          : '--',
      percentage:
        data.length > 0 && data[0]?.growth_rate !== undefined
          ? `${data[0].growth_rate}%`
          : '',
      isPositive:
        data.length > 0 && data[0]?.growth_rate !== undefined
          ? data[0].growth_rate >= 0
          : false,
      icon: 'shoppingCart',
      iconBgColor: 'bg-amber-50',
      iconColor: 'text-amber-400',
      borderColor: 'border-amber-200',
    },
    {
      title: 'New Business Revenue',
      value:
        data.length > 1 && data[1]?.new_business_revenue !== undefined
          ? `$${(data[1].new_business_revenue / 1000).toFixed(2)}k`
          : '--',
      percentage:
        data.length > 1 && data[1]?.growth_rate !== undefined
          ? `${data[1].growth_rate}%`
          : '',
      isPositive:
        data.length > 1 && data[1]?.growth_rate !== undefined
          ? data[1].growth_rate >= 0
          : false,
      icon: 'dollarSign',
      iconBgColor: 'bg-blue-50',
      iconColor: 'text-blue-600',
      borderColor: 'border-blue-200',
    },
    {
      title: 'Recurring Revenue',
      value:
        data.length > 2 && data[2]?.recurring_business_revenue !== undefined
          ? `$${(data[2].recurring_business_revenue / 1000).toFixed(2)}k`
          : '--',
      percentage:
        data.length > 2 && data[2]?.growth_rate !== undefined
          ? `${data[2].growth_rate}%`
          : '',
      isPositive:
        data.length > 2 && data[2]?.growth_rate !== undefined
          ? data[2].growth_rate >= 0
          : false,
      icon: 'history',
      iconBgColor: 'bg-pink-50',
      iconColor: 'text-pink-600',
      borderColor: 'border-pink-200',
    },
    {
      title: 'Average Job Value',
      value:
        data.length > 3 && data[3]?.average_job_value !== undefined
          ? `$${(data[3].average_job_value / 1000).toFixed(2)}k`
          : '--',
      percentage:
        data.length > 3 && data[3]?.growth_rate !== undefined
          ? `${data[3].growth_rate}%`
          : '',
      isPositive:
        data.length > 3 && data[3]?.growth_rate !== undefined
          ? data[3].growth_rate >= 0
          : false,
      icon: 'coin',
      iconBgColor: 'bg-blue-50',
      iconColor: 'text-blue-300',
      borderColor: 'border-blue-200',
    },
  ];
};

// Add this interface
interface ChartData {
  title: string;
  categories: string[];
  series: {
    name: string;
    data: { y: number; growth: number }[];
    color: string;
    type: 'column';
    borderRadius: number;
    pointWidth: number;
  }[];
}

interface LocationChartData {
  title: string;
  categories: string[];
  series: {
    name: string;
    data: { y: number; growth: number }[];
    color: string;
    type: 'line';
  }[];
  yAxisMax: number;
  yAxisTickInterval: number;
}

interface ServiceChartData {
  title: string;
  data: { name: string; y: number }[];
}

export const useSalesRevenue = () => {
  const isMounted = useRef(false);

  // Regular filters
  const [filters, setFilters] = useState<FilterState>({
    dateRange: null,
    location: '',
    revenueType: '',
    salesRep: '',
    exploreTable: '',
  });

  const [sorting, setSorting] = useState<SortingState>({
    field: 'name',
    direction: null,
  });

  // Separate states for chart time periods
  const [revenueChartTimePeriod, setRevenueChartTimePeriod] =
    useState<TimePeriod>('monthly');
  const [locationChartTimePeriod, setLocationChartTimePeriod] =
    useState<TimePeriod>('monthly');

  // Data states
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({
    locations: [],
    salesReps: [],
    revenueType: [],
  });
  const [infoCardsData, setInfoCardsData] = useState<InfoCardData[] | null>(
    null
  );
  const [revenueChartData, setRevenueChartData] = useState<ChartData | null>(
    null
  );
  const [locationChartData, setLocationChartData] =
    useState<LocationChartData | null>(null);
  const [serviceChartData, setServiceChartData] =
    useState<ServiceChartData | null>(null);
  const [salesRepTableData, setSalesRepTableData] =
    useState<SalesRepTableData | null>(null);
  const [leastPerformingData, setLeastPerformingData] = useState<
    TransformedLeastPerforming[] | null
  >(null);
  const [exploreTableData, setExploreTableData] = useState<
    ExploreTableData[] | null
  >(null);

  // Loading states
  const [loadingStates, setLoadingStates] = useState({
    filterOptions: true,
    infoCards: true,
    revenueChart: true,
    locationChart: true,
    serviceChart: true,
    salesRepTable: true,
    leastPerforming: true,
    performanceReport: true,
    exploreTable: true,
  });

  // Update the errors state initialization
  const [errors, setErrors] = useState<ErrorStates>({
    filterOptions: null,
    infoCards: null,
    revenueChart: null,
    locationChart: null,
    serviceChart: null,
    salesRepTable: null,
    leastPerforming: null,
  });

  // Add pagination state
  const [pagination, setPagination] = useState<PaginationState>({
    page: 1,
    pageSize: 10,
    total: 0,
  });

  const [explorePagination, setExplorePagination] = useState<PaginationState>({
    page: 1,
    pageSize: 10,
    total: 0,
  });

  const [isAllDataEmpty, setIsAllDataEmpty] = useState(false);

  const [isFilterLoading, setIsFilterLoading] = useState(false);

  const handleSortingChange = (
    field: string,
    direction: 'asc' | 'desc' | null
  ) => {
    setSorting((prev) => ({ ...prev, field, direction }));
    setPagination((prev) => ({ ...prev, page: 1 }));
    fetchSalesRepTable(1, pagination.pageSize, field, direction);
  };

  const handleExploreSortingChange = (
    field: string,
    direction: 'asc' | 'desc' | null
  ) => {
    setSorting((prev) => ({ ...prev, field, direction }));
    setExplorePagination((prev) => ({ ...prev, page: 1 }));
    fetchExploreData(1, explorePagination.pageSize, field, direction);
  };

  // Fetch filter options
  const fetchFilterOptions = async () => {
    try {
      setLoadingStates((prev) => ({ ...prev, filterOptions: true }));
      const results = await Promise.allSettled([
        getLocations(SCREEN_NAME.FINANCIAL_OVERVIEW),
        getSalesReps(SCREEN_NAME.FINANCIAL_OVERVIEW),
        getRevenueType(),
      ]);
      const [locationsResult, salesRepsResult, revenueTypeResult] = results;

      setFilterOptions({
        locations:
          locationsResult.status === 'fulfilled' ? locationsResult.value : [],
        salesReps:
          salesRepsResult.status === 'fulfilled' ? salesRepsResult.value : [],
        revenueType:
          revenueTypeResult.status === 'fulfilled'
            ? revenueTypeResult.value
            : [],
      });

      // Set error if either request failed
      if (results.some((result) => result.status === 'rejected')) {
        const error = new Error('Failed to fetch some filter options');
        setErrors((prev) => ({ ...prev, filterOptions: error }));
      } else {
        setErrors((prev) => ({ ...prev, filterOptions: null }));
      }
    } catch (error) {
      setErrors((prev) => ({ ...prev, filterOptions: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, filterOptions: false }));
    }
  };

  const fetchSalesRepresentatives = async (locationId: string = '') => {
    try {
      const response = await getSalesReps(SCREEN_NAME.SALES_REPORT, locationId);
      setFilterOptions((prev) => ({
        ...prev,
        salesReps: response || [],
      }));
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchSalesRepresentatives(filters.location);
  }, [filters.location]);

  // Fetch info cards data
  const fetchInfoCards = async () => {
    try {
      setLoadingStates((prev) => ({ ...prev, infoCards: true }));
      const queryString = getQueryParams(filters, null);
      const response = await getHighNumbers(queryString);
      const transformedData = transformInfoCardsData(response.data);
      setInfoCardsData(transformedData);
      setErrors((prev) => ({ ...prev, infoCards: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, infoCards: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, infoCards: false }));
      setIsFilterLoading(false);
    }
  };

  // Update getQueryParams to include pagination
  const getQueryParams = (
    filters: FilterState,
    timePeriod: TimePeriod | null,
    includePagination: boolean = false,
    currentPage?: number,
    pageSize?: number
  ): string => {
    const queryParams = new URLSearchParams();
    // ... existing filter params logic ...
    if (filters?.dateRange && filters?.dateRange[0] && filters?.dateRange[1]) {
      queryParams.append(
        'start_date',
        filters?.dateRange[0]?.toLocaleDateString('en-CA')
      );
      queryParams.append(
        'end_date',
        filters?.dateRange[1]?.toLocaleDateString('en-CA')
      );
    }

    if (filters.location)
      queryParams.append('location_id', filters.location.toString());
    if (filters.salesRep)
      queryParams.append('representative_id', filters.salesRep.toString());
    if (filters?.revenueType) {
      let revenueType = Array.isArray(filters?.revenueType)
        ? filters?.revenueType?.map((item: any) => {
            if (item === undefined) {
              item = 'null';
            }
            return item;
          })
        : filters?.revenueType;
      queryParams.append('revenue_type_id', revenueType.toString());
    }

    // Add time period parameter
    if (timePeriod) queryParams.append('total_revenue_by', timePeriod);

    // Add pagination params if needed
    if (includePagination) {
      queryParams.append('page', (currentPage || pagination.page).toString());
      queryParams.append(
        'page_size',
        (pageSize || pagination.pageSize).toString()
      );
    }

    return queryParams.toString();
  };

  const generateCategory = (item: ChartDataPoint, timePeriod: TimePeriod) => {
    switch (timePeriod) {
      case 'weekly': {
        const startDate = new Date(item.week!);
        const endDate = addDays(startDate, 6);
        return `${format(startDate, 'MMM d')} - ${format(endDate, 'MMM d')}`;
      }
      case 'monthly':
        return format(new Date(item.month!), 'MMM');
      case 'quarterly': {
        const startDate = new Date(item.quarter!);
        const endDate = endOfMonth(addMonths(startDate, 2));
        return `${format(startDate, 'MMM d')} - ${format(endDate, 'MMM d')}`;
      }
      case 'yearly':
        return format(new Date(item.year!), 'yyyy');
      default:
        return '';
    }
  };

  const transformChartData = (
    data: ChartDataPoint[],
    timePeriod: TimePeriod
  ) => {
    if (!data || data.length === 0) {
      return {
        title: 'Total Revenue',
        categories: [],
        yAxisMax: 0,
        yAxisTickInterval: 100,

        series: [
          {
            name: 'Revenue',
            data: [],
            color: '#FBD5D5',
            type: 'column' as const,
            borderRadius: 8,
            pointWidth: 36,
          },
        ],
      };
    }

    const isAllZero = data.every((item) => item.total_revenue === 0);

    if (isAllZero) {
      return null;
    }

    // Find max revenue
    const maxRevenue =
      Math.max(...data.map((item) => item.total_revenue / 1000)) || 0;
    const yAxisMax = maxRevenue > 0 ? maxRevenue * 1.1 : 5000;

    return {
      title: 'Total Revenue',
      categories: data.map((item) => generateCategory(item, timePeriod)),
      yAxisMax,
      yAxisTickInterval: 100,

      series: [
        {
          name: 'Revenue',
          data: data.map((item) => ({
            y: Number((item.total_revenue / 1000).toFixed(2)),
            growth: item.growth_rate,
          })),
          color: '#FBD5D5',
          type: 'column' as const,
          borderRadius: 8,
          pointWidth: 36,
        },
      ],
    };
  };

  useEffect(() => {
    // Only proceed if all loading states are false
    if (
      !loadingStates.locationChart &&
      !loadingStates.serviceChart &&
      !loadingStates.revenueChart &&
      !loadingStates.infoCards &&
      !loadingStates.salesRepTable &&
      !loadingStates.leastPerforming &&
      !loadingStates.exploreTable
    ) {
      // Check if info cards data is empty
      const isCardsDataEmpty = infoCardsData?.some(
        (item) => item.value === '--'
      );

      // Check if all required data exists but indicates empty state
      const isAllEmpty = Boolean(
        // Ensure all data structures exist
        revenueChartData?.categories &&
          locationChartData?.categories &&
          serviceChartData?.data &&
          leastPerformingData &&
          // Check specific empty conditions
          salesRepTableData?.representatives.length === 0 &&
          isCardsDataEmpty
      );

      setIsAllDataEmpty(isAllEmpty);
    }
  }, [
    loadingStates.locationChart,
    loadingStates.serviceChart,
    loadingStates.revenueChart,
    loadingStates.infoCards,
    loadingStates.salesRepTable,
    loadingStates.leastPerforming,
    loadingStates.exploreTable,
    infoCardsData,
    revenueChartData?.categories,
    locationChartData?.categories,
    serviceChartData?.data,
    leastPerformingData,
    salesRepTableData?.representatives,
  ]);

  // Update fetch functions to use their specific time periods
  const fetchRevenueChart = async (timePeriod?: TimePeriod) => {
    try {
      setLoadingStates((prev) => ({ ...prev, revenueChart: true }));
      const queryString = getQueryParams(
        filters,
        timePeriod || revenueChartTimePeriod
      );
      const response = await salesRevenueBarChart(queryString);
      const transformedData = transformChartData(
        response.data,
        timePeriod || revenueChartTimePeriod
      );
      setRevenueChartData(transformedData);
      setErrors((prev) => ({ ...prev, revenueChart: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, revenueChart: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, revenueChart: false }));
      setIsFilterLoading(false);
    }
  };

  const fetchLocationChart = async (timePeriod?: TimePeriod) => {
    try {
      setLoadingStates((prev) => ({ ...prev, locationChart: true }));
      const queryString = getQueryParams(
        filters,
        timePeriod || locationChartTimePeriod
      );
      const response = await salesRevenueLineChart(queryString);
      const transformedData = transformLocationChartData(
        response.data,
        timePeriod || locationChartTimePeriod
      );
      //console.log(transformedData);
      setLocationChartData(transformedData);
      setErrors((prev) => ({ ...prev, locationChart: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, locationChart: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, locationChart: false }));
      setIsFilterLoading(false);
    }
  };

  const fetchDownloadReport = async () => {
    try {
      const queryString = getQueryParams(filters, null);
      await downloadReport(queryString);
    } catch (error) {
      console.error('Download error:', error);
      if (error instanceof Error) {
        console.error('Error details:', {
          message: error.message,
          stack: error.stack,
        });
      }
      setErrors((prev) => ({ ...prev, downloadReport: error as Error }));
      showErrorMsg(TOAST_MESSAGES.DOWNLOAD_REPORT_ERROR);
    }
  };

  const fetchExportDownloadReport = async () => {
    try {
      const queryString = getQueryParams(filters, null);
      await exploreDownloadReport(queryString);
    } catch (error) {
      console.error('Download error:', error);
      if (error instanceof Error) {
        console.error('Error details:', {
          message: error.message,
          stack: error.stack,
        });
      }
      setErrors((prev) => ({ ...prev, exploreDownloadReport: error as Error }));
      showErrorMsg(TOAST_MESSAGES.DOWNLOAD_REPORT_ERROR);
    }
  };

  const fetchPerformanceReport = async () => {
    try {
      const queryString = getQueryParams(filters, null);
      await downloadPerformanceReport(queryString);
    } catch (error) {
      setErrors((prev) => ({ ...prev, performanceReport: error as Error }));
      showErrorMsg(TOAST_MESSAGES.DOWNLOAD_REPORT_ERROR);
    }
  };

  const fetchServiceChart = async () => {
    try {
      setLoadingStates((prev) => ({ ...prev, serviceChart: true }));
      const queryString = getQueryParams(filters, null);
      const response = await salesRevenuePieChart(queryString);
      const transformedData = response.data.map((item: TradeRevenue) => ({
        name: item?.trades,
        y: Number(
          (
            (item?.total_revenue /
              response.data.reduce(
                (acc: number, curr: TradeRevenue) =>
                  acc + curr?.total_revenue || 0,
                0
              )) *
            100
          ).toFixed(1)
        ),
        tooltip_value: (item?.total_revenue / 1000)?.toFixed(2),
      }));

      setServiceChartData({
        title: 'Total Revenue By Service Type',
        data: transformedData,
      });
      setErrors((prev) => ({ ...prev, serviceChart: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, serviceChart: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, serviceChart: false }));
      setIsFilterLoading(false);
    }
  };

  const fetchLeastPerforming = async () => {
    try {
      setLoadingStates((prev) => ({ ...prev, leastPerforming: true }));
      const queryString = getQueryParams(filters, null);
      const response = await leastPerforming(queryString);
      const transformedData = transformLeastPerformingSalesRepData(
        response.data
      );
      setLeastPerformingData(transformedData);
      setErrors((prev) => ({ ...prev, leastPerforming: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, leastPerforming: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, leastPerforming: false }));
      setIsFilterLoading(false);
    }
  };
  /**
   * Fetches the explore table data
   * @param pageNumber - the page number to fetch
   * @param pageSize - the page size to fetch
   * @param field - the field to sort by
   * @param direction - the direction to sort (asc or desc)
   */
  const fetchExploreData = async (
    pageNumber?: number,
    pageSize?: number,
    field?: string,
    direction?: 'asc' | 'desc' | null
  ) => {
    try {
      // Set loading state for the explore table
      setLoadingStates((prev) => ({ ...prev, exploreTable: true }));
      // Build the query string for the API call
      let queryString = getQueryParams(
        filters,
        null,
        true,
        pageNumber || explorePagination.page,
        pageSize || explorePagination.pageSize
      );
      // If sorting is requested, add the sorting parameter to the query string
      if (field && direction) {
        const fieldName =
          fieldExploreMap[field as keyof typeof fieldExploreMap];
        const orderingValue =
          direction === 'desc' ? `-${fieldName}` : fieldName;
        queryString += `&ordering=${orderingValue}`;
      }
      // Call the API and get the response
      const response = await getExploreData(queryString);
      // Transform the API response data
      const transformedData = transformExploreData(response?.data);
      // Update the state with the new data
      setExploreTableData(transformedData);

      // Update the pagination state
      setExplorePagination((prev) => ({
        ...prev,
        total: response?.meta_data?.total_count,
      }));

      // Clear any errors
      setErrors((prev) => ({ ...prev, exploreTable: null }));
    } catch (error) {
      // Set the error state
      setErrors((prev) => ({ ...prev, exploreTable: error as Error }));
    } finally {
      // Set the loading state to false
      setLoadingStates((prev) => ({ ...prev, exploreTable: false }));
    }
  };

  // Update the initial effect to use the mount ref
  useEffect(() => {
    if (!isMounted.current) {
      fetchFilterOptions();
      isMounted.current = true;
    }
  }, []);

  // Update the filters effect to prevent unnecessary initial calls
  useEffect(() => {
    if (isMounted.current) {
      const timeoutId = setTimeout(() => {
        setPagination((prev) => ({ ...prev, page: 1 }));
        setExplorePagination((prev) => ({ ...prev, page: 1 }));
        fetchInfoCards();
        fetchRevenueChart();
        fetchLocationChart();
        fetchServiceChart();
        fetchLeastPerforming();
        fetchSalesRepTable(1);
        fetchExploreData(1);
      }, 2000); // Adjust the delay as needed

      return () => clearTimeout(timeoutId); // Cleanup function to clear the timeout
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters]);

  // Filter update handler
  const updateFilters = (newFilters: Partial<FilterState>) => {
    setIsFilterLoading(true);
    setFilters((prev) => ({ ...prev, ...newFilters }));
  };

  // Refetch specific section
  const refetchSection = async (section: string) => {
    switch (section) {
      case 'infoCards':
        await fetchInfoCards();
        break;
      case 'revenueChart':
        await fetchRevenueChart();
        break;
      case 'locationChart':
        await fetchLocationChart();
        break;
      case 'salesRepTable':
        await fetchSalesRepTable();
        break;
      case 'exploreTableData':
        await fetchExploreData();
      // Add other cases
    }
  };

  const getTimeKey = (timePeriod: TimePeriod): string => {
    switch (timePeriod) {
      case 'weekly':
        return 'week';
      case 'monthly':
        return 'month';
      case 'quarterly':
        return 'quarter';
      case 'yearly':
        return 'year';
      default:
        return 'month';
    }
  };

  const transformLocationChartData = (
    data: any[],
    timePeriod: TimePeriod
  ): LocationChartData | any => {
    if (!data || data.length === 0) {
      return {
        title: 'Total Revenue By Location',
        categories: [],
        series: [],
        yAxisMax: 0,
        yAxisMin: 0,
        yAxisTickInterval: 100000,
      };
    }

    // Get unique time points and sort them
    const timePoints = [
      ...new Set(data.map((item) => item[getTimeKey(timePeriod)])),
    ].sort();

    // Generate categories using existing function
    const categories = timePoints.map((timePoint) =>
      generateCategory(
        {
          week: timePeriod === 'weekly' ? timePoint : undefined,
          month: timePeriod === 'monthly' ? timePoint : undefined,
          quarter: timePeriod === 'quarterly' ? timePoint : undefined,
          year: timePeriod === 'yearly' ? timePoint : undefined,
          total_revenue: 0,
          growth_rate: 0,
        },
        timePeriod
      )
    );

    const isAllZero = data.every((item) => item.total_revenue === 0);

    if (isAllZero) {
      return null;
    }

    // Define locations and their colors

    // Create series for each location
    const series = Object.entries(locationColors).map(([location, color]) => ({
      name: location,
      type: 'line' as const,

      data: timePoints.map((timePoint) => {
        const point = data.find(
          (item) =>
            item?.location === location &&
            item[getTimeKey(timePeriod)] === timePoint
        );
        return point
          ? { y: point?.total_revenue, growth: point?.growth_rate }
          : { y: 0, growth: 0 };
      }),
      color,
    }));

    // Calculate yAxisMax
    const maxRevenue = Math.max(...data.map((item) => item.total_revenue)) || 0;
    const yAxisMax = maxRevenue > 0 ? maxRevenue * 1.1 : 5000;

    return {
      title: 'Total Revenue By Location',
      categories,
      series,
      yAxisMax,
      yAxisTickInterval: 100000,
    };
  };

  const transformSalesRepTableData = (
    data: SalesRepResponseData[]
  ): TransformedSalesRep[] => {
    const avatarUrls = [
      'https://img.freepik.com/free-psd/3d-illustration-with-online-avatar_23-2151303097.jpg?semt=ais_hybrid',
      'https://img.freepik.com/free-vector/young-prince-royal-attire_1308-176144.jpg?semt=ais_hybrid',
    ];
    return (
      data?.map((item, index) => {
        const representative = item?.representative || 'Unknown';
        const initials = representative
          .split(' ')
          .map((name) => name[0])
          .join('');

        const salesRepContent = {
          id: (index + 1).toString(),
          representative_id: item?.representative_id,
          sales_rep: {
            initials,
            name: item.representative,
            avatar: avatarUrls[index % 2],
          },
          total_revenue: `$${item?.total_revenue?.toLocaleString() || 0}`,
          deals_closed: item?.deals_closed?.toString() || '0',
          deal_size: `$${item?.average_revenue?.toLocaleString() || 0}`,
          growth: {
            value: `${Math?.abs(item?.growth_rate).toFixed(2)}%` || '0%',
            isPositive: item?.growth_rate >= 0,
          },
        };
        return salesRepContent;
      }) || []
    );
  };

  const transformLeastPerformingSalesRepData = (
    data: Record<string, number>
  ): TransformedLeastPerforming[] => {
    if (!data || Object.keys(data).length === 0) {
      return [];
    }

    const avatarUrls = [
      'https://img.freepik.com/free-psd/3d-illustration-with-online-avatar_23-2151303097.jpg?semt=ais_hybrid',
      'https://img.freepik.com/free-vector/young-prince-royal-attire_1308-176144.jpg?semt=ais_hybrid',
    ];

    return Object.entries(data).map(([name, sales], index) => ({
      id: (index + 1).toString(), // Generate sequential IDs
      name,
      avatar: avatarUrls[index % 2], // Alternates between the two avatar URLs
      sales: sales || 0,
    }));
  };
  /**
   * Transforms the explore data into the expected format for the component.
   * @param data - The data from the API.
   * @returns The transformed data.
   */
  const transformExploreData = (data: any[]): ExploreTableData[] => {
    return (
      data?.map((item) => ({
        /**
         * The ID of the item.
         */
        id: item?.id ? `${item?.id}` : '--',
        /**
         * The job ID of the item.
         */
        job_id: item?.job_id ? `${item?.job_id}` : '--',
        /**
         * The customer name.
         */
        customer: item?.customer ? `${item?.customer}` : '--',
        /**
         * The representative name.
         */
        representative_name: item?.representative_name
          ? `${item?.representative_name}`
          : '--',
        /**
         * The job name.
         */
        job_name: item?.job_name ? `${item?.job_name}` : '--',
        /**
         * The contract signed date.
         */
        contract_signed_date: item?.contract_signed_date
          ? `${item?.contract_signed_date}`
          : '--',
        /**
         * The total amount.
         */
        total_amount: item?.total_amount
          ? `$${item?.total_amount.toLocaleString()}`
          : '--',
        /**
         * The job type.
         */
        job_type: item?.job_type ? `${item?.job_type}` : 'None',
        /**
         * The trades.
         */
        trades: item?.trades ? `${item?.trades}` : '--',
        /**
         * The location.
         */
        location: item?.location ? `${item?.location}` : '--',
        /**
         * The last sync date.
         */
        last_sync_date: item?.last_sync_date ? `${item?.last_sync_date}` : '--',
      })) || []
    );
  };

  // Add fetchSalesRepTable function
  const fetchSalesRepTable = async (
    pageNumber?: number,
    pageSize?: number,
    field?: string,
    direction?: 'asc' | 'desc' | null
  ) => {
    try {
      setLoadingStates((prev) => ({ ...prev, salesRepTable: true }));
      let queryString = getQueryParams(
        filters,
        null,
        true,
        pageNumber || pagination.page,
        pageSize || pagination.pageSize
      );
      if (field && direction) {
        const fieldName = fieldMap[field as keyof typeof fieldMap];
        const orderingValue =
          direction === 'desc' ? `-${fieldName}` : fieldName;
        queryString += `&ordering=${orderingValue}`;
      }
      const response = await getPerformanceReport(queryString);
      setSalesRepTableData({
        representatives: transformSalesRepTableData(response.data),
        total: response?.total || {},
      });

      setPagination((prev) => ({
        ...prev,
        total: response.meta_data.total_count,
      }));

      setErrors((prev) => ({ ...prev, salesRepTable: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, salesRepTable: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, salesRepTable: false }));
    }
  };

  const handleRevenueChartTimePeriodChange = (newPeriod: TimePeriod) => {
    setRevenueChartTimePeriod(newPeriod);
    fetchRevenueChart(newPeriod);
  };

  const handleLocationChartTimePeriodChange = (newPeriod: TimePeriod) => {
    setLocationChartTimePeriod(newPeriod);
    fetchLocationChart(newPeriod);
  };

  // Add pagination handlers
  const handlePageChange = (newPage: number) => {
    setPagination((prev) => ({ ...prev, page: newPage }));
    fetchSalesRepTable(
      newPage,
      pagination.pageSize,
      sorting.field,
      sorting.direction
    );
  };

  const handleExplorePageChange = (newPage: number) => {
    setExplorePagination((prev) => ({ ...prev, page: newPage }));
  };

  const handlePageSizeChange = (newPageSize: number) => {
    setPagination((prev) => ({ ...prev, pageSize: newPageSize, page: 1 }));
    fetchSalesRepTable(1, newPageSize, sorting.field, sorting.direction);
  };

  const handleExplorePageSizeChange = (newPageSize: number) => {
    // Only update if the new page size is different
    if (newPageSize !== explorePagination.pageSize) {
      setExplorePagination((prev) => ({
        ...prev,
        pageSize: newPageSize,
        page: 1,
      }));
      // Fetch explore data with the new page size and current sorting
      fetchExploreData(1, newPageSize, sorting.field, sorting.direction);
    }
  };

  return {
    // States
    filters,
    filterOptions,
    infoCardsData,
    revenueChartData,
    locationChartData,
    serviceChartData,
    salesRepTableData,
    exploreTableData,
    leastPerformingData,
    loadingStates,
    errors,
    updateFilters,
    refetchSection,
    revenueChartTimePeriod,
    locationChartTimePeriod,
    setRevenueChartTimePeriod: handleRevenueChartTimePeriodChange,
    setLocationChartTimePeriod: handleLocationChartTimePeriodChange,
    fetchDownloadReport,
    fetchExportDownloadReport,
    fetchPerformanceReport,
    pagination,
    explorePagination,
    handlePageChange,
    handlePageSizeChange,
    handleExplorePageSizeChange,
    handleExplorePageChange,
    sorting,
    handleSortingChange,
    handleExploreSortingChange,
    isAllDataEmpty,
    fetchExploreData,
    isFilterLoading,
  };
};
