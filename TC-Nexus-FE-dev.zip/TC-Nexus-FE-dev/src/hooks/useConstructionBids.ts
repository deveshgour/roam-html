import {
  getBidsList,
  addBid as addBidService,
  updateBid as updateBidService,
  deleteBid as deleteBidService,
  exportBids as exportBidsService,
} from '@/services/constructionBid';
import { useEffect, useState } from 'react';
import { PAGE_SIZE } from '@/constants/configs';

export interface BidFilters {
  trades?: string | string[];
  builder?: string | string[];
  community?: string;
  page?: number;
  page_size?: number;
  ordering?: string;
  total?: {
    homes: number;
    bid_per_home: number;
    projected_bid_total: number;
    profit_bid: number;
    projected_profit_generated: number;
  };
}

interface UseBidProps {
  initialFilters?: BidFilters;
  autoFetch?: boolean;
}

export interface ConstructionBid {
  id: string;
  community: string;
  builders: string;
  traders: string;
  trade_names: string[];
  projectedStartDate: string;
  numberOfHomes: number;
  bidPerHome: number;
  projectedBidTotal: number;
  profitBidAt: number;
  projectedProfitGenerated: number;
}

export interface ConstructionBidFormData {
  id?: string;
  community: string;
  builder: string;
  trades: number[];
  projected_start_date: string;
  homes: number;
  bid_per_home: number;
  projected_bid_total: number;
  profit_bid: number;
  projected_profit_generated: number;
}

export interface ExportFilters {
  builder?: string;
  community?: string;
  trades?: string[];
}

// Transform API response to frontend format
const transformBidResponse = (data: any): ConstructionBid => ({
  id: data.id,
  community: data.community,
  builders: data.builder,
  traders: Array.isArray(data.trades) ? data.trades.join(',') : '',
  trade_names: data.trade_names,
  projectedStartDate: data.projected_start_date,
  numberOfHomes: data.homes,
  bidPerHome: data.bid_per_home,
  projectedBidTotal: data.projected_bid_total,
  profitBidAt: data.profit_bid,
  projectedProfitGenerated: data.projected_profit_generated,
});

// ✅ Function to construct query string
const constructQueryString = (params: Record<string, any>) => {
  return Object.entries(params)
    .map(([key, value]) => {
      if (value === undefined || value === null) return '';
      if (Array.isArray(value)) {
        // Format as comma-separated values (trades=1,45)
        return `${key}=${value.map((v) => encodeURIComponent(v)).join(',')}`;
      }
      // Handle number values
      if (typeof value === 'number') {
        return `${key}=${value}`;
      }
      return `${key}=${encodeURIComponent(value)}`;
    })
    .filter(Boolean) // Remove empty values
    .join('&');
};

export const useBids = ({
  initialFilters = {},
  autoFetch = true,
}: UseBidProps = {}) => {
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [totalCount, setTotalCount] = useState(0);
  const [bids, setBids] = useState<ConstructionBid[]>([]);
  const [filters, setFilters] = useState<BidFilters>({
    page: 1,
    page_size: PAGE_SIZE[0],
    ...initialFilters,
  });
  const [totals, setTotals] = useState<BidFilters['total']>({
    homes: 0,
    bid_per_home: 0,
    projected_bid_total: 0,
    profit_bid: 0,
    projected_profit_generated: 0,
  });
  // const [builders, setBuilders] = useState<string[]>([]);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars, no-unused-vars
  const [traders, setTraders] = useState<string[]>([]);
  // const [communities, setCommunities] = useState<string[]>([]);

  const fetchBidList = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const queryString = constructQueryString(filters);
      const response = await getBidsList(`?${queryString}`);

      if (response?.data) {
        setBids(response?.data?.map(transformBidResponse));
        setTotalCount(response?.meta_data?.total_count || 0);

        // Update totals from the API response
        if (response?.total) {
          setTotals({
            homes: response?.total?.homes || 0,
            bid_per_home: response?.total?.bid_per_home || 0,
            projected_bid_total: response?.total?.projected_bid_total || 0,
            profit_bid: response?.total?.profit_bid || 0,
            projected_profit_generated:
              response?.total?.projected_profit_generated || 0,
          });
        }
      } else {
        setError('Invalid API response');
      }
    } catch (error) {
      setError(error instanceof Error ? error.message : 'An error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const addBid = async (bidData: ConstructionBidFormData) => {
    setIsLoading(true);
    setError(null);

    try {
      // Use the service function
      await addBidService(bidData);

      // After successful addition, refresh the list
      await fetchBidList();
      return true;
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to add bid');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const updateBid = async (id: string, bidData: ConstructionBidFormData) => {
    setIsLoading(true);
    setError(null);

    try {
      // Use the service function
      await updateBidService(id, bidData);

      // After successful update, refresh the list
      await fetchBidList();
      return true;
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to update bid');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const deleteBid = async (id: string) => {
    setIsLoading(true);
    setError(null);

    try {
      // Use the service function
      await deleteBidService(id);

      // After successful deletion, refresh the list
      await fetchBidList();
      return true;
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to delete bid');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const exportBids = async (filters?: ExportFilters) => {
    try {
      const params = new URLSearchParams();
      if (filters?.builder) {
        params.append('builder', filters.builder);
      }
      if (filters?.community) {
        params.append('community', filters.community);
      }
      if (filters?.trades) {
        params.append('trades', filters.trades?.join(','));
      }
      await exportBidsService(`?${params.toString()}`);
      return true;
    } catch (error) {
      throw error;
    }
  };

  useEffect(() => {
    if (!autoFetch) return;
    fetchBidList();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters]); // Fetch data when filters change

  return {
    bids,
    isLoading,
    error,
    totalCount,
    filters,
    setFilters,
    totals,
    fetchBidList,
    addBid,
    updateBid,
    deleteBid,
    exportBids,
    // builders,
    traders,
    // communities,
  };
};
