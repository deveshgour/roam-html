import { SORTING_TYPES } from '@/components/coreUI/table/constants';
import {
  SCREEN_NAME,
  TIME_PERIOD_OPTIONS,
  TIME_PERIOD_TYPES,
} from '@/constants/configs';
import { TOAST_MESSAGES } from '@/constants/messages';
import { getLocations, getSalesReps } from '@/services/common';
import {
  getHighNumbers,
  getPerformanceReport,
  salesFunnelLineChart,
  getLeadSourceReport,
  getDownloadSourceReport,
  getDownloadPerformanceReport,
  getSourceJobDetailReport,
  getDownloadSourceDetailReport,
  exploreDownloadReport,
  getExploreData,
  downloadReport,
} from '@/services/leadsReport';
import { SortingState, SortingTypes, TimePeriod } from '@/types/common';
import { showErrorMsg } from '@/utils/notifications';
import {
  addDays,
  addMonths,
  endOfMonth,
  format,
  parse,
  startOfMonth,
  startOfQuarter,
  endOfQuarter,
} from 'date-fns';
import { useState, useEffect, useRef } from 'react';

export interface Location {
  id: number;
  name: string;
}

export interface SalesRep {
  id: number;
  name: string;
}

interface FilterOptions {
  locations: Location[];
  salesReps: SalesRep[];
}

interface FilterState {
  dateRange: [Date | null, Date | null] | null;
  location: string;
  salesRep: string | string[];
  exploreTable: string;
}

interface ChartDataPoint {
  week?: string;
  month?: string;
  quarter?: string;
  year?: string;
  total_revenue: number;
  growth_rate: number;
}
// Define types for each section's data
interface InfoCardData {
  title: string;
  value: string;
  icon: string;
  iconBgColor: string;
  iconColor: string;
  borderColor: string;
}

// Add at the top with other interfaces
interface ErrorStates {
  filterOptions: Error | null;
  infoCards: Error | null;
  teamPerformanceTable: Error | null;
  funnelChart: Error | null;
  leadSourceTable: Error | null;
  leadSourceDetailTable: Error | null;
  modalViewFunnelChart: Error | null;
}

interface HighNumbersResponse {
  total_leads: number;
  total_appointments: number;
  total_sold: number;
  avg_conversion_rate: number;
  door_knocked: number;
  home_canvassed: number;
  insurance_claims_filed: number;
  adjuster_meetings_attented: number;
  followup_appointments: number;
  lois_signed: number;
}

interface TeamPerformanceResponseData {
  sales_rep: string;
  doors_knocked: number;
  homes_canvassed: number;
  leads_generated: number;
  appointments_booked: number;
  insurance_claims_filed: number;
  adjuster_meetings_attented: number;
  followup_appointments: number;
  sold: number;
  conversion_rate: string;
}

interface LeadSourceResponseData {
  id: string;
  source: string;
  leads_generated: number;
  appointments: number;
  sold: number;
  conversion_rate: string;
}

interface SourceDetailResponseData {
  id: string;
  job_name: string;
  customer: string;
  total_amount: string;
}

interface ExploreTableData {
  id: string;
  lead_source: string;
  lead_date: string;
  representative_name: string;
  contact_name: string;
  contact_number: string;
  first_appointment_date: string;
  contract_signed_date: string;
  status: string;
  total_amount: string;
}

export interface TransformSourceDetail {
  id: string;
  job_name: string;
  customer: string;
  total_amount: string;
}

export interface TransformLeadSource {
  id: string;
  source: string;
  leads_generated: number;
  appointments: number;
  sold: number;
  conversion_rate: string;
}

export interface TransformedTeamPerformance {
  id: string;
  sales_rep: {
    initials: string;
    name: string;
    avatar: string;
  };
  doors_knocked: number;
  homes_canvassed: number;
  leads_generated: number;
  appointments_booked: number;
  insurance_claims_filed: number;
  adjuster_meetings_attented: number;
  followup_appointments: number;
  sold: number;
  conversion_rate: string;
}

export interface TransformedExploreData {
  id: string;
  lead_source: string;
  lead_date: string;
  representative_name: string;
  contact_name: string;
  contact_number: string;
  first_appointment_date: string;
  contract_signed_date: string;
  status: string;
  total_amount: string;
}

// Add these interfaces at the top with other interfaces
interface PaginationState {
  page: number;
  pageSize: number;
  total: number;
}

interface TeamPerformanceTableData {
  representatives: TransformedTeamPerformance[];
  total: {
    doors_knocked: number;
    homes_canvassed: number;
    leads_generated: number;
    appointments_booked: number;
    insurance_claims_filed: number;
    adjuster_meetings_attented: number;
    followup_appointments: number;
    sold: number;
    conversion_rate: number;
  };
}

interface LeadSourceTableData {
  data: LeadSourceResponseData[];
  total: {
    leads_generated: number;
    appointments: number;
    sold: number;
    conversion_rate: number;
  };
}
interface SourceDetailTableData {
  data: SourceDetailResponseData[];
}

interface ConvertedItem {
  id: number; // Adjust type according to actual data structure
  type: 'Appointments' | 'Leads' | 'Sold';
  [key: string]: any; // To allow additional properties
}

interface ResponseData {
  appointments?: any[];
  leads?: any[];
  sold?: any[];
}

const funnelColors = {
  Appointments: '#4CAF50',
  Sold: '#FFC107',
  Leads: '#2196F3',
};

const transformInfoCardsData = (data: HighNumbersResponse): InfoCardData[] => {
  return [
    {
      title: 'Total Leads',
      value: data?.total_leads?.toString() || '--',
      icon: 'shoppingCart',
      iconBgColor: 'bg-amber-50',
      iconColor: 'text-amber-400',
      borderColor: 'border-amber-200',
    },
    {
      title: 'Total Appointments',
      value: data?.total_appointments?.toString() || '--',
      icon: 'calendarOutline',
      iconBgColor: 'bg-blue-50',
      iconColor: 'text-blue-600',
      borderColor: 'border-blue-200',
    },
    {
      title: 'Total Sold',
      value: data?.total_sold?.toString() || '--',
      icon: 'dataExchange',
      iconBgColor: 'bg-green-50',
      iconColor: 'text-green-400',
      borderColor: 'border-green-200',
    },
    {
      title: 'Avg. Conversion Rate',
      value: data?.avg_conversion_rate?.toString() || '--',
      icon: 'percentage',
      iconBgColor: 'bg-pink-50',
      iconColor: 'text-pink-500',
      borderColor: 'border-pink-200',
    },
    {
      title: 'Door Knocked',
      value: data?.door_knocked?.toString() || '--',
      icon: 'door',
      iconBgColor: 'bg-orange-100',
      iconColor: 'text-orange-400',
      borderColor: 'border-orange-200',
    },
    {
      title: 'Home Canvassed',
      value: data?.home_canvassed?.toString() || '--',
      icon: 'home',
      iconBgColor: 'bg-teal-50',
      iconColor: 'text-teal-400',
      borderColor: 'border-teal-200',
    },
    {
      title: 'Insurance Claims Filed',
      value: data?.insurance_claims_filed?.toString() || '--',
      icon: 'document',
      iconBgColor: 'bg-purple-50',
      iconColor: 'text-purple-500',
      borderColor: 'border-purple-200',
    },
    {
      title: 'Adjuster Meetings attended',
      value: data?.adjuster_meetings_attented?.toString() || '--',
      icon: 'webCam',
      iconBgColor: 'bg-red-50',
      iconColor: 'text-red-500',
      borderColor: 'border-red-200',
    },
    {
      title: 'Follow Up Appointments',
      value: data?.followup_appointments?.toString() || '--',
      icon: 'calendarOutline',
      iconBgColor: 'bg-gray-100',
      iconColor: 'text-gray-600',
      borderColor: 'border-gray-200',
    },
    {
      title: 'LOIs Signed',
      value: data?.lois_signed?.toString() || '--',
      icon: 'sign',
      iconBgColor: 'bg-blue-100',
      iconColor: 'text-blue-800',
      borderColor: 'border-blue-200',
    },
  ];
};

interface FunnelChartData {
  title: string;
  categories: string[];
  series: {
    name: string;
    data: { y: number; growth: number }[];
    color: string;
    type: any;
  }[];
  yAxisMax: number;
  type: string;
  yAxisTickInterval: number;
}

export const useMarketingLeads = () => {
  const isMounted = useRef(false);
  const [isFilterLoading, setIsFilterLoading] = useState(false);

  // Regular filters
  const [filters, setFilters] = useState<FilterState>({
    dateRange: null,
    location: '',
    salesRep: '',
    exploreTable: '',
  });

  const [leadSourceFilters, setLeadSourceFilters] = useState<FilterState>({
    dateRange: null,
    location: '',
    salesRep: '',
    exploreTable: '',
  });

  const [sorting, setSorting] = useState<SortingState>({
    field: 'name',
    direction: null,
  });

  const [exploreSorting, setExploreSorting] = useState<SortingState>({
    field: 'name',
    direction: null,
  });
  // Separate states for chart time periods
  const [funnelChartTimePeriod, setFunnelChartTimePeriod] =
    useState<TimePeriod>(TIME_PERIOD_TYPES.MONTHLY as TimePeriod);

  const [modalViewFunnelChartTimePeriod, setModalViewFunnelChartTimePeriod] =
    useState<TimePeriod>(TIME_PERIOD_TYPES.MONTHLY as TimePeriod);

  // Data states
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({
    locations: [],
    salesReps: [],
  });
  const [infoCardsData, setInfoCardsData] = useState<InfoCardData[] | null>(
    null
  );
  const [funnelChartData, setFunnelChartData] =
    useState<FunnelChartData | null>(null);

  const [modalViewFunnelChartData, setModalViewFunnelChartData] =
    useState<FunnelChartData | null>(null);

  const [teamPerformanceTableData, setTeamPerformanceTableData] =
    useState<TeamPerformanceTableData | null>(null);

  const [leadSourceTableData, setLeadSourceTableData] =
    useState<LeadSourceTableData | null>(null);

  const [sourceDetailTableData, setSourceDetailTableData] =
    useState<SourceDetailTableData | null>(null);

  const [exploreTableData, setExploreTableData] = useState<
    ExploreTableData[] | null
  >(null);

  // Loading states
  const [loadingStates, setLoadingStates] = useState({
    filterOptions: true,
    infoCards: true,
    teamPerformanceTable: true,
    funnelChart: true,
    leadSourceTable: true,
    leadSourceDetailTable: true,
    modalViewFunnelChart: true,
    sourceDetailTable: false,
    exploreTable: true,
  });

  // Update the errors state initialization
  const [errors, setErrors] = useState<ErrorStates>({
    filterOptions: null,
    infoCards: null,
    teamPerformanceTable: null,
    funnelChart: null,
    leadSourceTable: null,
    leadSourceDetailTable: null,
    modalViewFunnelChart: null,
  });

  // Add pagination state
  const [sourcePagination, setSourcePagination] = useState<PaginationState>({
    page: 1,
    pageSize: 10,
    total: 0,
  });

  const [sourceDetailPagination, setSourceDetailPagination] =
    useState<PaginationState>({
      page: 1,
      pageSize: 10,
      total: 0,
    });

  const [explorePagination, setExplorePagination] = useState<PaginationState>({
    page: 1,
    pageSize: 10,
    total: 0,
  });

  const [performancePagination, setPerformancePagination] =
    useState<PaginationState>({
      page: 1,
      pageSize: 10,
      total: 0,
    });

  // Add selectedSource state
  const [selectedSource, setSelectedSource] = useState<string>('');

  const handleSortingChange = (field: string, direction: SortingTypes) => {
    setSorting((prev) => ({ ...prev, field, direction }));
    setPerformancePagination((prev) => ({ ...prev, page: 1 }));
    fetchTeamPerformanceTable(
      1,
      performancePagination.pageSize,
      field,
      direction
    );
  };

  const handleSourceSortingChange = (
    field: string,
    direction: SortingTypes
  ) => {
    setSorting((prev) => ({ ...prev, field, direction }));
    setSourcePagination((prev) => ({ ...prev, page: 1 }));
    fetchLeadSourceTable(1, sourcePagination.pageSize, field, direction);
  };
  const handleSourceDetailSortingChange = (
    field: string,
    direction: SortingTypes
  ) => {
    setSorting((prev) => ({ ...prev, field, direction }));
    setSourceDetailPagination((prev) => ({ ...prev, page: 1 }));
    fetchSourceJobDetailTable(
      1,
      sourceDetailPagination.pageSize,
      field,
      direction
    );
  };

  const handleExploreSortingChange = (
    field: string,
    direction: SortingTypes
  ) => {
    setExploreSorting((prev) => ({ ...prev, field, direction }));
    setExplorePagination((prev) => ({ ...prev, page: 1 }));
    fetchExploreData(1, explorePagination.pageSize, field, direction);
  };

  // Fetch filter options
  const fetchFilterOptions = async () => {
    try {
      setLoadingStates((prev) => ({ ...prev, filterOptions: true }));
      const results = await Promise.allSettled([
        getLocations(SCREEN_NAME.MARKETING_LEADS),
        getSalesReps(SCREEN_NAME.MARKETING_LEADS),
      ]);

      const [locationsResult, salesRepsResult] = results;

      setFilterOptions({
        locations:
          locationsResult?.status === 'fulfilled' ? locationsResult?.value : [],
        salesReps:
          salesRepsResult?.status === 'fulfilled' ? salesRepsResult?.value : [],
      });

      // Set error if either request failed
      if (results.some((result) => result.status === 'rejected')) {
        const error = new Error('Failed to fetch some filter options');
        setErrors((prev) => ({ ...prev, filterOptions: error }));
      } else {
        setErrors((prev) => ({ ...prev, filterOptions: null }));
      }
    } catch (error) {
      setErrors((prev) => ({ ...prev, filterOptions: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, filterOptions: false }));
    }
  };

  const fetchSalesRepresentatives = async (locationId: string = '') => {
    try {
      const response = await getSalesReps(SCREEN_NAME.SALES_REPORT, locationId);
      setFilterOptions((prev) => ({
        ...prev,
        salesReps: response || [],
      }));
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchSalesRepresentatives(filters.location);
  }, [filters.location]);

  // Fetch info cards data
  const fetchInfoCards = async () => {
    try {
      setLoadingStates((prev) => ({ ...prev, infoCards: true }));
      const queryString = getQueryParams(filters, null);
      const response = await getHighNumbers(queryString);
      const transformedData = transformInfoCardsData(response?.data);
      setInfoCardsData(transformedData);
      setErrors((prev) => ({ ...prev, infoCards: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, infoCards: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, infoCards: false }));
      setIsFilterLoading(false);
    }
  };

  // Update getQueryParams to include pagination
  const getQueryParams = (
    filters: FilterState,
    timePeriod: TimePeriod | null,
    includePagination: boolean = false,
    currentPage?: number | null,
    pageSize?: number | null,
    source?: string
  ): string => {
    const queryParams = new URLSearchParams();
    // ... existing filter params logic ...
    if (filters?.dateRange && filters?.dateRange[0] && filters.dateRange[1]) {
      queryParams.append(
        'start_date',
        filters?.dateRange[0]?.toLocaleDateString('en-CA')
      );
      queryParams.append(
        'end_date',
        filters?.dateRange[1]?.toLocaleDateString('en-CA')
      );
    }

    if (filters.location)
      queryParams.append('location_id', filters.location.toString());
    if (filters.salesRep)
      queryParams.append('representative_id', filters.salesRep.toString());

    // Add time period parameter
    if (timePeriod) queryParams.append('sales_funnel_by', timePeriod);
    if (source) queryParams.append('source', source);

    // Add pagination params if needed
    if (includePagination) {
      queryParams.append(
        'page',
        (currentPage || sourcePagination.page).toString()
      );
      queryParams.append(
        'page_size',
        (pageSize || sourcePagination.pageSize).toString()
      );
    }

    return queryParams.toString();
  };

  const generateCategory = (item: ChartDataPoint, timePeriod: TimePeriod) => {
    switch (timePeriod) {
      case TIME_PERIOD_TYPES.WEEKLY: {
        const startDate = new Date(item.week!);
        const endDate = addDays(startDate, 6);
        return `${format(startDate, 'MMM d')} - ${format(endDate, 'MMM d')}`;
      }
      case TIME_PERIOD_TYPES.MONTHLY:
        return format(new Date(item.month!), 'MMM');
      case TIME_PERIOD_TYPES.QUARTERLY: {
        const startDate = new Date(item.quarter!);
        const endDate = endOfMonth(addMonths(startDate, 2));
        return `${format(startDate, 'MMM d')} - ${format(endDate, 'MMM d')}`;
      }
      case TIME_PERIOD_TYPES.YEARLY:
        return format(new Date(item.year!), 'yyyy');
      default:
        return '';
    }
  };

  /**
   * Fetches the sales funnel chart data from the marketing API.
   * @param timePeriod The time period to fetch the data for.
   * If not provided, the current funnelChartTimePeriod state will be used.
   */
  const fetchFunnelChart = async (timePeriod?: TimePeriod | null) => {
    try {
      setLoadingStates((prev) => ({ ...prev, funnelChart: true }));
      // Generate query string based on the current filters and time period
      const queryString = getQueryParams(
        filters,
        timePeriod || funnelChartTimePeriod
      );
      // Fetch the data from the marketing API
      const response = await salesFunnelLineChart(queryString);
      // Transform the data to the required format
      const transformedData = transformFunnelChartData(
        getConvertedResponse(response.data),
        timePeriod || funnelChartTimePeriod
      );
      // Update the state with the new data
      setFunnelChartData(transformedData);
      // Clear any previous errors
      setErrors((prev) => ({ ...prev, funnelChart: null }));
    } catch (error) {
      // Set the error state if the request fails
      setErrors((prev) => ({ ...prev, funnelChart: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, funnelChart: false }));
      setIsFilterLoading(false);
    }
  };

  const fetchModalViewFunnelChart = async (
    timePeriod?: TimePeriod,
    source?: string
  ) => {
    try {
      setLoadingStates((prev) => ({ ...prev, modalViewFunnelChart: true }));
      // Generate query string based on the current filters and time period
      const queryString = getQueryParams(
        filters,
        timePeriod || modalViewFunnelChartTimePeriod,
        undefined,
        null,
        null,
        source
      );
      // Fetch the data from the marketing API
      const response = await salesFunnelLineChart(queryString);
      // Transform the data to the required format
      const transformedData = transformFunnelChartData(
        getConvertedResponse(response.data),
        timePeriod || modalViewFunnelChartTimePeriod
      );
      // Update the state with the new data
      setModalViewFunnelChartData(transformedData);
      // Clear any previous errors
      setErrors((prev) => ({ ...prev, modalViewFunnelChart: null }));
    } catch (error) {
      // Set the error state if the request fails
      setErrors((prev) => ({ ...prev, modalViewFunnelChart: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, modalViewFunnelChart: false }));
      setIsFilterLoading(false);
    }
  };

  const handleFunnelChartDetail = async (
    timePeriod?: TimePeriod,
    source?: string
  ) => {
    // Update selectedSource if provided
    if (source) {
      setSelectedSource(source);
    }
    if (timePeriod) {
      setModalViewFunnelChartTimePeriod(timePeriod);
    }

    try {
      // Fetch funnel chart data with source
      await fetchModalViewFunnelChart(
        timePeriod || modalViewFunnelChartTimePeriod,
        source || selectedSource
      );

      // Fetch source job detail table with source
      await fetchSourceJobDetailTable(
        1,
        sourceDetailPagination.pageSize,
        null,
        null,
        undefined,
        source || selectedSource
      );
    } catch (error) {
      console.error('Error in handleFunnelChartDetail:', error);
    }
  };

  // Update fetchSourceJobDetailTable to accept source parameter
  const fetchSourceJobDetailTable = async (
    pageNumber?: number | null,
    pageSize?: number | null,
    field?: string | null,
    direction?: SortingTypes,
    dateRange?: Array<Date> | Array<null>,
    source?: string
  ) => {
    try {
      setLoadingStates((prev) => ({ ...prev, leadSourceDetailTable: true }));

      let appliedFilters = {
        ...filters,
      };

      if (dateRange) {
        appliedFilters = {
          ...appliedFilters,
          dateRange: [dateRange[0] || null, dateRange[1] || null],
        };
      }

      let queryString = getQueryParams(
        appliedFilters,
        null,
        true,
        pageNumber || sourceDetailPagination.page,
        pageSize || sourceDetailPagination.pageSize
      );

      // Add source to query string if provided
      if (source || selectedSource) {
        queryString += `&source=${source || selectedSource}`;
      }

      if (field && direction) {
        const fieldName = field as keyof LeadSourceTableData;
        const orderingValue =
          direction === SORTING_TYPES.DESC ? `-${fieldName}` : fieldName;
        queryString += `&ordering=${orderingValue}`;
      }

      const response = await getSourceJobDetailReport(queryString);
      setSourceDetailTableData({
        data: transformSourceJobDetailTableData(response?.data),
      });
      setSourceDetailPagination((prev) => ({
        ...prev,
        total: response?.meta_data?.total_count,
      }));

      setErrors((prev) => ({ ...prev, leadSourceDetailTable: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, leadSourceDetailTable: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, leadSourceDetailTable: false }));
      setIsFilterLoading(false);
    }
  };

  // Add a value to check if there's any data
  const hasAnyEmptyData = Boolean(
    teamPerformanceTableData?.representatives?.length ||
      0 ||
      leadSourceTableData?.data?.length ||
      0 ||
      sourceDetailTableData?.data?.length ||
      0 ||
      funnelChartData?.series?.[0]?.data?.length ||
      0 ||
      infoCardsData?.some(({ value }) => /\d/.test(value)) ||
      false
  );

  // Update the initial effect to use the mount ref
  useEffect(() => {
    if (!isMounted.current) {
      fetchFilterOptions();
      isMounted.current = true;
    }
  }, []);

  // Update the filters effect to prevent unnecessary initial calls
  useEffect(() => {
    if (isMounted.current) {
      const timeoutId = setTimeout(() => {
        setSourcePagination((prev) => ({ ...prev, page: 1 }));
        setSourceDetailPagination((prev) => ({ ...prev, page: 1 }));
        setPerformancePagination((prev) => ({ ...prev, page: 1 }));
        setExplorePagination((prev) => ({ ...prev, page: 1 }));
        fetchInfoCards();
        fetchTeamPerformanceTable(1);
        fetchFunnelChart();
        fetchLeadSourceTable(1);
        fetchExploreData(1);
      }, 2000); // Adjust the delay as needed

      return () => clearTimeout(timeoutId); // Cleanup function to clear the timeout
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters]);

  // Filter update handler
  const updateFilters = (newFilters: Partial<FilterState>) => {
    setIsFilterLoading(true);
    setFilters((prev) => ({ ...prev, ...newFilters }));
  };

  const handleResetFilter = () => {
    setLeadSourceFilters({
      ...leadSourceFilters,
      dateRange: null, // Reset date filter
    });

    fetchLeadSourceTable(1); // Fetch data with reset filters
  };

  const handleModalResetFilter = () => {
    setLeadSourceFilters({
      ...leadSourceFilters,
      dateRange: null, // Reset date filter
    });

    fetchSourceJobDetailTable(1); // Fetch data with reset filters
  };

  // Refetch specific section
  const refetchSection = async (section: string) => {
    switch (section) {
      case 'infoCards':
        await fetchInfoCards();
        break;
      case 'funnelChart':
        await fetchFunnelChart();
        break;
      case 'teamPerformanceTable':
        await fetchTeamPerformanceTable();
        break;
      case 'leadSourceTable':
        await fetchLeadSourceTable();
      case 'leadSourceDetailTable':
        await fetchSourceJobDetailTable();
      case 'exploreTableData':
        await fetchExploreData();
      // Add other cases
    }
  };

  const getTimeKey = (timePeriod: TimePeriod): string => {
    switch (timePeriod) {
      case TIME_PERIOD_TYPES.WEEKLY:
        return TIME_PERIOD_OPTIONS.WEEKLY.toLowerCase();
      case TIME_PERIOD_TYPES.MONTHLY:
        return TIME_PERIOD_OPTIONS.MONTHLY.toLowerCase();
      case TIME_PERIOD_TYPES.QUARTERLY:
        return TIME_PERIOD_OPTIONS.QUARTERLY.toLowerCase();
      case TIME_PERIOD_TYPES.YEARLY:
        return TIME_PERIOD_OPTIONS.YEARLY.toLowerCase();
      default:
        return TIME_PERIOD_OPTIONS.MONTHLY.toLowerCase();
    }
  };

  const getConvertedResponse = (data: ResponseData): ConvertedItem[] => {
    return Object.entries({
      Appointments: 'total_leads_scheduled',
      Leads: 'total_leads_generated',
      Sold: 'total_sold',
    }).flatMap(([type, totalKey]) =>
      ((data as any)[type.toLowerCase()] || []).map(
        (item: { [x: string]: any }) => {
          return {
            ...item,
            type,
            total: item[totalKey as keyof typeof item] || 0,
          };
        }
      )
    );
  };

  // eslint-disable-next-line no-unused-vars
  const tooltipFormatter = function (this: any) {
    const { category, series, point } = this;
    const timePeriodLabel =
      TIME_PERIOD_OPTIONS[
        funnelChartTimePeriod?.toUpperCase() as keyof typeof TIME_PERIOD_OPTIONS
      ] || 'Period';
    const fields = [
      { label: timePeriodLabel, value: category },
      { label: `Total ${series?.name}`, value: point?.y },
      point?.growth !== undefined
        ? {
            label: '% Change from last ' + timePeriodLabel,
            value: `${point?.growth}%`,
            color: '#0E9F6E',
          }
        : null,
      point?.conversion !== undefined
        ? {
            label:
              series?.name === 'Sold'
                ? 'Leads to Sales Conversion Rate'
                : 'Conversion Rate',
            value: `${point?.conversion}%`,
          }
        : null,

      point?.revenue !== undefined
        ? {
            label: series?.name === 'Sold' ? 'Revenue Generated' : '',
            value: `$${point?.revenue / 1000}K`,
          }
        : null,
    ].filter(
      (field): field is { label: string; value: string; color?: string } =>
        field !== null
    );

    return `
      <div style="padding: 0 4px 4px 4px; min-width: 250px; background-color: #fff;">
        ${fields
          .map(
            ({ label, value, color }) => `
            <span style="display: block; width: 100%; font-size: 12px; margin-top: 6px;">
              <span style="width: 180px; display: inline-block; color: #6B7280;">${label}</span>
              <span style="color: ${color || '#4B5563'};">${value}</span>
            </span>`
          )
          .join('')}
      </div>
    `;
  };

  const labelsFormatter = function (
    // eslint-disable-next-line no-unused-vars
    this: any
  ) {
    return this.value;
  };

  // eslint-disable-next-line no-unused-vars
  const modalViewTooltipFormatter = function (this: any) {
    const { category, series, point } = this;
    const timePeriodLabel =
      TIME_PERIOD_OPTIONS[
        modalViewFunnelChartTimePeriod?.toUpperCase() as keyof typeof TIME_PERIOD_OPTIONS
      ] || 'Period';
    const fields = [
      { label: timePeriodLabel, value: category },
      { label: `Total ${series?.name}`, value: point?.y },
      point?.growth !== undefined
        ? {
            label: '% Change from last ' + timePeriodLabel,
            value: `${point?.growth}%`,
            color: '#0E9F6E',
          }
        : null,
      point?.conversion !== undefined
        ? {
            label:
              series?.name === 'Sold'
                ? 'Leads to Sales Conversion Rate'
                : 'Conversion Rate',
            value: `${point?.conversion}%`,
          }
        : null,
    ].filter(
      (field): field is { label: string; value: string; color?: string } =>
        field !== null
    );

    return `
      <div style="padding: 0 4px 4px 4px; min-width: 250px; background-color: #fff;">
        ${fields
          .map(
            ({ label, value, color }) => `
            <span style="display: block; width: 100%; font-size: 12px; margin-top: 6px;">
              <span style="width: 180px; display: inline-block; color: #6B7280;">${label}</span>
              <span style="color: ${color || '#4B5563'};">${value}</span>
            </span>`
          )
          .join('')}
      </div>
    `;
  };

  /**
   * Event handler for clicking on a point in the funnel chart.
   * Will fetch more detailed data for the selected time period.
   * @param event The point click event
   * @param chartType The type of chart that was clicked. Can be "leadSourceTable" or "sourceDetailModal".
   */
  const onPointClick = function (
    this: any,
    event: Highcharts.PointClickEventObject,
    chartType: 'leadSourceTable' | 'sourceDetailModal'
  ): void {
    const category: string = String(event?.point?.category); // Contains month, quarter, year, or week info
    const selectedView: string = funnelChartTimePeriod; // Use state for selected time period
    const selectedViewModal: string = modalViewFunnelChartTimePeriod;
    const currentYear: number = new Date().getFullYear();

    let startDate: Date;
    let endDate: Date;

    // Update the filters to include the selected year from the date picker
    const yearFromFilters =
      filters.dateRange && filters.dateRange[0]
        ? filters?.dateRange[0]?.getFullYear()
        : currentYear;

    /**
     * Helper function to get start & end dates for a month
     * @param month The month to get a range for
     * @return An object with start and end dates for the month
     */
    const getMonthRange = (month: string): { start: Date; end: Date } => {
      const parsedDate = parse(
        `${month} 1, ${yearFromFilters}`,
        'MMM d, yyyy',
        new Date()
      );
      return {
        start: startOfMonth(parsedDate),
        end: endOfMonth(parsedDate),
      };
    };

    /**
     * Helper function to get start & end dates for a quarter using date-fns
     * @param quarterLabel The quarter label to get a range for
     * @return An object with start and end dates for the quarter or null if invalid
     */
    const getQuarterRange = (
      quarterLabel: string
    ): { start: Date; end: Date } | null => {
      const startDate = parse(
        quarterLabel.split(' - ')[0],
        'MMM d',
        new Date()
      );
      return {
        start: startOfQuarter(startDate),
        end: endOfQuarter(startDate),
      };
    };

    /**
     * Helper function to get start & end dates for a week
     * @param weekLabel The week label to get a range for
     * @return An object with start and end dates for the week or null if invalid
     */
    const getWeekRange = (
      weekLabel: string
    ): { start: Date; end: Date } | null => {
      const match: RegExpMatchArray | null = weekLabel?.match(
        /([A-Za-z]+ \d+) - ([A-Za-z]+ \d+)/
      );
      if (!match) return null;

      const [, startStr, endStr] = match;
      const parseDate = (dateStr: string): Date =>
        parse(`${dateStr}, ${yearFromFilters}`, 'MMM d, yyyy', new Date());

      let start = parseDate(startStr);
      let end = parseDate(endStr);

      // Handle weeks spanning across years
      if (format(start, 'MMM') === 'Dec' && startStr.startsWith('Jan')) {
        start = addMonths(start, 12);
      }
      if (format(end, 'MMM') === 'Jan' && endStr.startsWith('Dec')) {
        end = addMonths(end, -12);
      }

      return { start, end };
    };

    function getDateRange(
      view: string,
      category: string
    ): { start: Date; end: Date } | null {
      switch (view) {
        case TIME_PERIOD_TYPES.MONTHLY:
          return getMonthRange(category);
        case TIME_PERIOD_TYPES.QUARTERLY:
          const quarter = getQuarterRange(category);
          if (!quarter) {
            console.error('Invalid quarter:', category);
            return null;
          }
          return quarter;
        case TIME_PERIOD_TYPES.YEARLY:
          return {
            start: new Date(Date.UTC(yearFromFilters, 0, 1)),
            end: new Date(Date.UTC(yearFromFilters, 11, 31)),
          };
        case TIME_PERIOD_TYPES.WEEKLY:
          const weekRange = getWeekRange(category);
          if (!weekRange) {
            console.error('Invalid week format:', category);
            return null;
          }
          return weekRange;
        default:
          console.error('Invalid time period:', view);
          return null;
      }
    }

    // 🔹 Determine Date Range Based on Selected View
    let dateRange =
      chartType === 'leadSourceTable'
        ? getDateRange(selectedView, category)
        : getDateRange(selectedViewModal, category);

    if (!dateRange) return;
    ({ start: startDate, end: endDate } = dateRange);
    // Conditionally Call API Based on `chartType`
    if (chartType === 'leadSourceTable') {
      fetchLeadSourceTable(1, sourcePagination.pageSize, '', null, [
        startDate,
        endDate,
      ]);
    } else if (chartType === 'sourceDetailModal') {
      fetchSourceJobDetailTable(1, sourceDetailPagination.pageSize, '', null, [
        startDate,
        endDate,
      ]);
    }
  };

  const transformFunnelChartData = (
    data: any[],
    timePeriod: TimePeriod
  ): FunnelChartData => {
    if (!data.length) {
      return {
        title: 'Sales Funnel Progression',
        type: 'spline',
        categories: [],
        series: [],
        yAxisMax: 0,
        yAxisTickInterval: 100,
      };
    }

    // Get unique time points and sort them
    const timePoints = [
      ...new Set(data.map((item) => item[getTimeKey(timePeriod)])),
    ].sort();

    // Generate categories using existing function
    const categories = timePoints.map((timePoint) =>
      generateCategory(
        {
          week: timePeriod === TIME_PERIOD_TYPES.WEEKLY ? timePoint : undefined,
          month:
            timePeriod === TIME_PERIOD_TYPES.MONTHLY ? timePoint : undefined,
          quarter:
            timePeriod === TIME_PERIOD_TYPES.QUARTERLY ? timePoint : undefined,
          year: timePeriod === TIME_PERIOD_TYPES.YEARLY ? timePoint : undefined,
          total_revenue: 0,
          growth_rate: 0,
        },
        timePeriod
      )
    );

    // Create series for each status
    const series = Object.entries(funnelColors).map(([sale_status, color]) => ({
      name: sale_status,
      type: 'spline',
      marker: { enabled: true, symbol: 'circleOutline' },

      data: timePoints.map((timePoint) => {
        const point = data.find(
          (item) =>
            item?.type === sale_status &&
            item[getTimeKey(timePeriod)] === timePoint
        );

        return point
          ? {
              y: point?.total,
              growth: point?.growth_rate,
              conversion: point?.conversion_rate,
              revenue: point?.total_revenue,
            }
          : { y: 0, growth: 0 };
      }),
      color,
    }));

    // Calculate yAxisMax
    // const yAxisMax =
    //   Math.ceil(Math.max(...data.map((item) => item?.total)) / 200) * 200;

    const maxValue = Math.max(...data.map((item) => item?.total)) || 0;
    const yAxisMax = Math.max(maxValue * 1.1, 50);

    return {
      title: 'Sales Funnel Progression',
      type: 'spline',
      categories,
      series,
      yAxisMax,
      yAxisTickInterval: 100,
    };
  };

  const transformTeamPerformanceTableData = (
    data: TeamPerformanceResponseData[]
  ): TransformedTeamPerformance[] => {
    const avatarUrls = [
      'https://img.freepik.com/free-psd/3d-illustration-with-online-avatar_23-2151303097.jpg?semt=ais_hybrid',
      'https://img.freepik.com/free-vector/young-prince-royal-attire_1308-176144.jpg?semt=ais_hybrid',
    ];
    return (
      data?.map((item, index) => {
        const initials = item?.sales_rep
          ?.split(' ')
          ?.map((sales_rep) => sales_rep[0])
          ?.join('');

        const TeamPerformanceContent = {
          id: (index + 1).toString(),
          sales_rep: {
            initials,
            name: item?.sales_rep || '',
            avatar: avatarUrls[index % 2],
          },
          doors_knocked: item?.doors_knocked || 0,
          homes_canvassed: item?.homes_canvassed || 0,
          leads_generated: item?.leads_generated || 0,
          appointments_booked: item?.appointments_booked || 0,
          insurance_claims_filed: item?.insurance_claims_filed || 0,
          adjuster_meetings_attented: item?.adjuster_meetings_attented || 0,
          followup_appointments: item?.followup_appointments || 0,
          sold: item?.sold || 0,
          conversion_rate: item?.conversion_rate
            ? `${parseFloat(item.conversion_rate).toFixed(2)}%`
            : '0%',
        };
        return TeamPerformanceContent;
      }) || []
    );
  };

  /**
   * Transforms the lead source table data into the expected format for the component.
   * @param {any[]} data - The data from the API.
   * @returns {LeadSourceResponseData[]} - The transformed data.
   */
  const transformLeadSourceTableData = (
    data: any[]
  ): LeadSourceResponseData[] => {
    return (
      data?.map((item, index) => ({
        /**
         * The ID of the item.
         */
        id: (index + 1).toString(),
        /**
         * The source of the item.
         */
        source: item?.source || '',
        /**
         * The number of leads generated.
         */
        leads_generated: item?.leads_generated || 0,
        /**
         * The number of appointments.
         */
        appointments: item?.appointments || 0,
        /**
         * The number of sold items.
         */
        sold: item?.sold || 0,
        /**
         * The conversion rate.
         */
        conversion_rate: item?.conversion_rate
          ? `${parseFloat(item.conversion_rate).toFixed(2)}%`
          : '0%',
      })) || []
    );
  };

  /**
   * Transforms the lead source table data into the expected format for the component.
   * @param {any[]} data - The data from the API.
   * @returns {LeadSourceResponseData[]} - The transformed data.
   */
  const transformSourceJobDetailTableData = (
    data: any[]
  ): SourceDetailResponseData[] => {
    return (
      data?.map((item, index) => ({
        /**
         * The ID of the item.
         */
        id: (index + 1).toString(),

        job_name: item?.job_name || '',

        customer: item?.customer || '',

        total_amount: item?.total_amount
          ? `$${item?.total_amount.toLocaleString()}`
          : '0',
      })) || []
    );
  };

  /**
   * Transforms the explore data into the expected format for the component.
   * @param data - The data from the API.
   * @returns The transformed data.
   */
  /**
   * Transforms the explore data into the expected format for the component.
   * @param data - The data from the API.
   * @returns The transformed data as an array of ExploreTableData.
   */
  const transformExploreData = (data: any[]): ExploreTableData[] => {
    return (
      data?.map((item) => ({
        /**
         * The ID of the item.
         */
        id: item?.id ? `${item?.id}` : '--',

        /**
         * The lead source.
         */
        lead_source: item?.lead_source ? `${item?.lead_source}` : '--',

        /**
         * The lead date.
         */
        lead_date: item?.lead_date ? `${item?.lead_date}` : '--',

        /**
         * The representative name.
         */
        representative_name: item?.representative_name
          ? `${item?.representative_name}`
          : '--',

        /**
         * The contact name.
         */
        contact_name: item?.contact_name ? `${item?.contact_name}` : '--',

        /**
         * The contact number.
         */
        contact_number: item?.contact_number ? `${item?.contact_number}` : '--',

        /**
         * The first appointment date.
         */

        first_appointment_date: item?.first_appointment_date
          ? `${item?.first_appointment_date}`
          : '--',

        /**
         * The contract signed date.
         */
        contract_signed_date: item?.contract_signed_date
          ? `${item?.contract_signed_date}`
          : '--',

        /**
         * The status of the lead.
         */
        status: item?.status ? `${item?.status}` : '--',

        /**
         * The total amount.
         */
        total_amount: item?.total_amount ? `$${item?.total_amount}` : '--',
      })) || []
    );
  };

  // Add fetchTeamPerformanceTable function
  const fetchTeamPerformanceTable = async (
    pageNumber?: number,
    pageSize?: number,
    field?: string,
    direction?: SortingTypes
  ) => {
    try {
      setLoadingStates((prev) => ({ ...prev, teamPerformanceTable: true }));
      let queryString = getQueryParams(
        filters,
        null,
        true,
        pageNumber || performancePagination.page,
        pageSize || performancePagination.pageSize
      );

      if (field && direction) {
        const fieldName = field as keyof TeamPerformanceTableData;
        const orderingValue =
          direction === SORTING_TYPES.DESC ? `-${fieldName}` : fieldName;
        queryString += `&ordering=${orderingValue}`;
      }

      const response = await getPerformanceReport(queryString);
      setTeamPerformanceTableData({
        representatives: transformTeamPerformanceTableData(response?.data),
        total: response?.total || {},
      });

      setPerformancePagination((prev) => ({
        ...prev,
        total: response?.meta_data?.total_count,
      }));

      setErrors((prev) => ({ ...prev, teamPerformanceTable: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, teamPerformanceTable: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, teamPerformanceTable: false }));
      setIsFilterLoading(false);
    }
  };

  // Add fetchLeadSourceTable function
  const fetchLeadSourceTable = async (
    pageNumber?: number,
    pageSize?: number,
    field?: string,
    direction?: SortingTypes,
    dateRange?: Array<Date> | Array<null>
  ) => {
    try {
      setLoadingStates((prev) => ({ ...prev, leadSourceTable: true }));

      let appliedFilters = {
        ...filters,
      };

      if (dateRange) {
        appliedFilters = {
          ...appliedFilters,
          dateRange: [dateRange[0] || null, dateRange[1] || null],
        };
      }

      let queryString = getQueryParams(
        appliedFilters,
        null,
        true,
        pageNumber || sourcePagination.page,
        pageSize || sourcePagination.pageSize
      );

      if (field && direction) {
        const fieldName = field as keyof LeadSourceResponseData;
        const orderingValue =
          direction === SORTING_TYPES.DESC ? `-${fieldName}` : fieldName;
        queryString += `&ordering=${orderingValue}`;
      }
      const response = await getLeadSourceReport(queryString);
      setLeadSourceTableData({
        data: transformLeadSourceTableData(response?.data),
        total: response?.total || {},
      });
      setSourcePagination((prev) => ({
        ...prev,
        total: response?.meta_data?.total_count,
      }));

      setErrors((prev) => ({ ...prev, leadSourceTable: null }));
    } catch (error) {
      setErrors((prev) => ({ ...prev, leadSourceTable: error as Error }));
    } finally {
      setLoadingStates((prev) => ({ ...prev, leadSourceTable: false }));
      setIsFilterLoading(false);
    }
  };

  const handleFunnelChartTimePeriodChange = (newPeriod: TimePeriod) => {
    setFunnelChartTimePeriod(newPeriod);
    fetchFunnelChart(newPeriod);
  };

  const handleModalViewFunnelChartTimePeriodChange = (
    newPeriod: TimePeriod
  ) => {
    setModalViewFunnelChartTimePeriod(newPeriod);
    fetchModalViewFunnelChart(newPeriod, selectedSource);
  };

  // Add pagination handlers
  const handleSourcePageChange = (newPage: number) => {
    setSourcePagination((prev) => ({ ...prev, page: newPage }));
    fetchLeadSourceTable(
      newPage,
      sourcePagination.pageSize,
      sorting.field,
      sorting.direction
    );
  };

  const handlePerformancePageChange = (newPage: number) => {
    setPerformancePagination((prev) => ({ ...prev, page: newPage }));
    fetchTeamPerformanceTable(
      newPage,
      performancePagination.pageSize,
      sorting.field,
      sorting.direction
    );
  };

  const handleSourceDetailPageChange = (newPage: number) => {
    setSourceDetailPagination((prev) => ({ ...prev, page: newPage }));
    fetchSourceJobDetailTable(
      newPage,
      sourceDetailPagination.pageSize,
      sorting.field,
      sorting.direction
    );
  };

  const handleExplorePageChange = (newPage: number) => {
    setExplorePagination((prev) => ({ ...prev, page: newPage }));
  };

  const handlePageSizeChange = (newPageSize: number) => {
    setPerformancePagination((prev) => ({
      ...prev,
      pageSize: newPageSize,
      page: 1,
    }));

    fetchTeamPerformanceTable(1, newPageSize, sorting.field, sorting.direction);
  };

  const handleSourcePageSizeChange = (newPageSize: number) => {
    setSourcePagination((prev) => ({
      ...prev,
      pageSize: newPageSize,
      page: 1,
    }));
    fetchLeadSourceTable(1, newPageSize, sorting.field, sorting.direction);
  };
  const handleSourceDetailPageSizeChange = (newPageSize: number) => {
    setSourceDetailPagination((prev) => ({
      ...prev,
      pageSize: newPageSize,
      page: 1,
    }));
    fetchSourceJobDetailTable(1, newPageSize, sorting.field, sorting.direction);
  };

  const handleExplorePageSizeChange = (newPageSize: number) => {
    // Only update if the new page size is different
    if (newPageSize !== explorePagination.pageSize) {
      setExplorePagination((prev) => ({
        ...prev,
        pageSize: newPageSize,
        page: 1,
      }));
      // Fetch explore data with the new page size and current sorting
      fetchExploreData(
        1,
        newPageSize,
        exploreSorting.field,
        exploreSorting.direction
      );
    }
  };

  const fetchSourceReport = async () => {
    try {
      const queryString = getQueryParams(filters, null);
      await getDownloadSourceReport(queryString);
    } catch (error) {
      console.error('Download error:', error);
      if (error instanceof Error) {
        console.error('Error details:', {
          message: error.message,
          stack: error.stack,
        });
      }
      setErrors((prev) => ({ ...prev, downloadReport: error as Error }));
      showErrorMsg(TOAST_MESSAGES.DOWNLOAD_REPORT_ERROR);
    }
  };

  const fetchPerformanceReport = async () => {
    try {
      const queryString = getQueryParams(filters, null);
      await getDownloadPerformanceReport(queryString);
    } catch (error) {
      console.error('Download error:', error);
      if (error instanceof Error) {
        console.error('Error details:', {
          message: error.message,
          stack: error.stack,
        });
      }
      setErrors((prev) => ({ ...prev, downloadReport: error as Error }));
      showErrorMsg(TOAST_MESSAGES.DOWNLOAD_REPORT_ERROR);
    }
  };

  const fetchSourceDetailReport = async (source?: string) => {
    try {
      const queryString = getQueryParams(filters, null);
      // Download the report from the server with the source included
      await getDownloadSourceDetailReport(`${queryString}&source=${source}`);
    } catch (error) {
      console.error('Download error:', error);
      if (error instanceof Error) {
        console.error('Error details:', {
          message: error.message,
          stack: error.stack,
        });
      }
      setErrors((prev) => ({ ...prev, downloadReport: error as Error }));
      showErrorMsg(TOAST_MESSAGES.DOWNLOAD_REPORT_ERROR);
    }
  };

  const fetchExportDownloadReport = async () => {
    try {
      const queryString = getQueryParams(filters, null);
      await exploreDownloadReport(queryString);
    } catch (error) {
      console.error('Download error:', error);
      if (error instanceof Error) {
        console.error('Error details:', {
          message: error.message,
          stack: error.stack,
        });
      }
      setErrors((prev) => ({ ...prev, exploreDownloadReport: error as Error }));
      showErrorMsg(TOAST_MESSAGES.DOWNLOAD_REPORT_ERROR);
    }
  };

  /**
   * Fetches the explore table data
   * @param pageNumber - the page number to fetch
   * @param pageSize - the page size to fetch
   * @param field - the field to sort by
   * @param direction - the direction to sort (asc or desc)
   */
  const fetchExploreData = async (
    pageNumber?: number,
    pageSize?: number,
    field?: string,
    direction?: SortingTypes
  ) => {
    try {
      // Set loading state for the explore table
      setLoadingStates((prev) => ({ ...prev, exploreTable: true }));
      // Build the query string for the API call
      let queryString = getQueryParams(
        filters,
        null,
        true,
        pageNumber || explorePagination.page,
        pageSize || explorePagination.pageSize
      );
      // If sorting is requested, add the sorting parameter to the query string
      if (field && direction) {
        const fieldName = field as keyof ExploreTableData;
        const orderingValue =
          direction === SORTING_TYPES.DESC ? `-${fieldName}` : fieldName;
        queryString += `&ordering=${orderingValue}`;
      }
      // Call the API and get the response
      const response = await getExploreData(queryString);
      // Transform the API response data
      const transformedData = transformExploreData(response?.data);
      // Update the state with the new data
      setExploreTableData(transformedData);

      // Update the pagination state
      setExplorePagination((prev) => ({
        ...prev,
        total: response?.meta_data?.total_count,
      }));

      // Clear any errors
      setErrors((prev) => ({ ...prev, exploreTable: null }));
    } catch (error) {
      // Set the error state
      setErrors((prev) => ({ ...prev, exploreTable: error as Error }));
    } finally {
      // Set the loading state to false
      setLoadingStates((prev) => ({ ...prev, exploreTable: false }));
      setIsFilterLoading(false);
    }
  };

  const fetchDownloadReport = async () => {
    try {
      const queryString = getQueryParams(filters, null);
      await downloadReport(queryString);
    } catch (error) {
      console.error('Download error:', error);
      if (error instanceof Error) {
        console.error('Error details:', {
          message: error.message,
          stack: error.stack,
        });
      }
      setErrors((prev) => ({ ...prev, downloadReport: error as Error }));
      showErrorMsg(TOAST_MESSAGES.DOWNLOAD_REPORT_ERROR);
    }
  };

  return {
    // States
    filters,
    filterOptions,
    infoCardsData,
    teamPerformanceTableData,
    leadSourceTableData,
    sourceDetailTableData,
    funnelChartData,
    modalViewFunnelChartData,
    tooltipFormatter,
    modalViewTooltipFormatter,
    loadingStates,
    errors,
    updateFilters,
    refetchSection,
    funnelChartTimePeriod,
    modalViewFunnelChartTimePeriod,
    setFunnelChartTimePeriod: handleFunnelChartTimePeriodChange,
    setModalViewFunnelChartTimePeriod:
      handleModalViewFunnelChartTimePeriodChange,
    sourcePagination,
    performancePagination,
    sourceDetailPagination,
    handleSourcePageChange,
    handleSourceDetailPageChange,
    handlePerformancePageChange,
    handlePageSizeChange,
    handleSourcePageSizeChange,
    handleSourceDetailPageSizeChange,
    sorting,
    exploreSorting,
    handleSortingChange,
    handleSourceSortingChange,
    fetchSourceReport,
    fetchPerformanceReport,
    onPointClick,
    handleResetFilter,
    handleFunnelChartDetail,
    handleModalResetFilter,
    fetchSourceDetailReport,
    fetchDownloadReport,
    exploreTableData,
    explorePagination,
    fetchExportDownloadReport,
    handleExplorePageSizeChange,
    handleExplorePageChange,
    handleExploreSortingChange,
    selectedSource,
    setSelectedSource,
    fetchExploreData,
    hasAnyEmptyData,
    labelsFormatter,
    isFilterLoading,
    handleSourceDetailSortingChange,
  };
};
