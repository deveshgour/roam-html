import { generateColors } from '@/utils/color';
import { useState, useEffect } from 'react';

const useColors = (dataLength: number) => {
  const [colors, setColors] = useState<string[]>([]);

  useEffect(() => {
    setColors(generateColors(dataLength));
  }, [dataLength]);

  return colors;
};

export default useColors;
