import { useState, useEffect } from 'react';
import {
  getTeams,
  createTeam,
  editTeam,
  deleteTeamById,
} from '@/services/team';
import { TeamFormValues } from '@/app/teams/management/components/addTeamModal';
import { getUsers } from '@/services/user';
import { User } from './useUsers';

export interface Team {
  id: string;
  name: string;
  users: string[];
  manager: {
    id: string;
    first_name: string;
    last_name: string;
    email: string;
  } | null;
}

export interface TeamFilters {
  teamName?: string;
  page?: number;
  pageSize?: number;
  ordering?: string;
}

interface TeamTable {
  id: string;
  teamName: string;
  userList: string[];
}

interface UseTeamsProps {
  initialFilters?: TeamFilters;
  autoFetch?: boolean;
}

export const useTeams = ({
  initialFilters = {},
  autoFetch = true,
}: UseTeamsProps = {}) => {
  const [teams, setTeams] = useState<TeamTable[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState<Partial<TeamFilters>>({
    page: initialFilters.page,
    pageSize: initialFilters.pageSize,
  });
  const [users, setUsers] = useState<User[]>([]);
  const transformTeam = (team: Team[]) => {
    return team.map((item: Team) => ({
      id: item?.id || '',
      teamName: item?.name || '',
      userList: item?.users || [],
      manager: item?.manager || null,
    }));
  };

  const getFieldName = (fieldName: string) => {
    // Extract minus sign if present
    const isDescending = fieldName.startsWith('-');
    const cleanFieldName = isDescending ? fieldName.slice(1) : fieldName;

    const fieldMappings: Record<string, string> = {
      teamName: 'name',
    };

    // Get mapped field name and reapply minus sign if present
    const mappedField = fieldMappings[cleanFieldName] || cleanFieldName;
    return isDescending ? `-${mappedField}` : mappedField;
  };

  const fetchTeams = async (currentFilters: TeamFilters = filters) => {
    try {
      setIsLoading(true);
      const params = new URLSearchParams({
        ...(currentFilters.teamName && { search: currentFilters.teamName }),
        ...(currentFilters.ordering && {
          ordering: getFieldName(currentFilters.ordering),
        }),
        page: String(currentFilters.page || 1),
        page_size: String(currentFilters.pageSize || 10),
      });

      const response = await getTeams(`?${params.toString()}`);
      let teamArr: TeamTable[] = transformTeam(response?.data);
      setTeams(teamArr);
      setTotalCount(response?.meta_data?.total_count);
      return response?.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const fetchUsers = async () => {
    try {
      setIsLoading(true);
      const response = await getUsers();
      setUsers(response?.data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    }
  };

  useEffect(() => {
    if (!autoFetch) return;
    fetchTeams();
    fetchUsers();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters.page, filters.pageSize, filters.teamName, filters.ordering]);

  const updateFilters = (newFilters: Partial<TeamFilters>) => {
    setFilters((prev) => ({
      ...prev,
      ...newFilters,
      page: newFilters.page || 1,
    }));
  };

  const prepareTeamPayload = (teamData: TeamFormValues) => {
    const userIds = teamData.userList.map((user: any) => user.id);
    return {
      name: teamData.teamName,
      user_ids: userIds,
    };
  };

  const addTeam = async (teamData: TeamFormValues) => {
    try {
      const payload = prepareTeamPayload(teamData);
      const response = await createTeam(payload);
      fetchTeams();
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    }
  };

  const updateTeam = async (id: string, teamData: TeamFormValues) => {
    try {
      const payload = prepareTeamPayload(teamData);
      const response = await editTeam(payload, id);
      fetchTeams();
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    }
  };

  const deleteTeam = async (id: string) => {
    try {
      await deleteTeamById(id);
      setTeams((prevTeams) => prevTeams.filter((team) => team.id !== id));
      setFilters({ page: 1, pageSize: filters.pageSize || 10 });
      fetchTeams();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      throw err;
    }
  };

  return {
    users,
    teams,
    error,
    filters,
    isLoading,
    totalCount,
    updateFilters,
    fetchTeams,
    addTeam,
    updateTeam,
    deleteTeam,
  };
};
