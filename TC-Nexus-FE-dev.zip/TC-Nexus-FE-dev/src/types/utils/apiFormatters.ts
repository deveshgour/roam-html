import {
  ProfileData,
  userPermissions,
} from '@/components/userProfileInfo/types';
import { format, parseISO } from 'date-fns';

export const formatUserProfileData = (userProfile: any): ProfileData => {
  return {
    name:
      `${userProfile.data?.first_name} ${userProfile.data?.last_name}` || '-',
    email: userProfile?.data?.email || '-',
    phone: userProfile?.data?.phone_number || '-',
    location: userProfile?.data?.location || '-',
    userId: userProfile?.data?.id || '-',
    lastLogin: userProfile?.data?.last_login
      ? format(parseISO(userProfile?.data?.last_login), 'yyyy-MM-dd HH:mm')
      : '-',
    UserRole: userProfile?.data?.is_superuser || false,
    img: userProfile?.data?.avatar || '-',
    accessLevels: userProfile?.data?.accessLevels || [
      {
        name: 'Sales Revenue',
        description:
          'Access and analyze total monetary sales value across all channels and periods',
        enabled: true,
      },
      {
        name: 'Profit Margin',
        description:
          'Monitor and evaluate overall profitability percentages and financial performance metrics',
        enabled: true,
      },
      {
        name: 'Lead Conversion Rate',
        description:
          'Track and analyze the success rate of converting leads into closed sales',
        enabled: false,
      },
      {
        name: 'Customer Acquisition Cost (CAC)',
        description:
          'Monitor and evaluate costs associated with acquiring new customers across channels',
        enabled: false,
      },
      {
        name: 'Total Leads by Lead Source',
        description:
          'Access detailed breakdown of lead generation performance across marketing channels',
        enabled: false,
      },
    ],
    status: userProfile?.data?.is_active || false,
  };
};

export const formatUserPermissionsData = (
  permissions: any
): userPermissions => {
  // Direct 1:1 mapping with the new permission structure
  return {
    system_administration: permissions.system_administration || 0,
    all_screens_access: permissions.all_screens_access || 0,
    sales_revenue: permissions.sales_revenue || 0,
    profit_margin_retail: permissions.profit_margin_retail || 0,
    profit_margin_nc: permissions.profit_margin_nc || 0,
    lead_conversion: permissions.lead_conversion || 0,
    cac: permissions.cac || 0,
    operations: permissions.operations || 0,
    sales_report: permissions.sales_report || 0,
    new_construction_bids: permissions.new_construction_bids || 0,
    marketing_lead: permissions.marketing_lead || 0,
  };
};
