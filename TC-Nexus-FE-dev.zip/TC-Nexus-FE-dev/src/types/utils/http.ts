/**
 * Helper Params used in Request
 */

export interface HelperParams {
  // eslint-disable-next-line no-unused-vars
  callback?: ((cancel: () => void) => void) | null;
  hideError?: boolean;
  headers?: Record<string, string>;
  onUploadProgress?: () => void;
  responseType?: 'json' | 'blob' | 'text' | 'arraybuffer';
}

/**
 * Error Response
 */
export interface ErrorResponse {
  detail?: string;
  error?: string;
  message?: string;
  errors?: Record<string, string[]>;
}
