import { TIME_PERIOD_OPTIONS, TIME_PERIOD_TYPES } from '@/constants/configs';

export interface SortingState {
  field: string;
  direction: 'asc' | 'desc' | null;
}

export type SortingTypes = 'asc' | 'desc' | null;

export type TimePeriod = 'monthly' | 'weekly' | 'quarterly' | 'yearly';

const getTimeKey = (timePeriod: TimePeriod): string => {
  switch (timePeriod) {
    case TIME_PERIOD_TYPES.WEEKLY:
      return TIME_PERIOD_OPTIONS.WEEKLY.toLowerCase();
    case TIME_PERIOD_TYPES.MONTHLY:
      return TIME_PERIOD_OPTIONS.MONTHLY.toLowerCase();
    case TIME_PERIOD_TYPES.QUARTERLY:
      return TIME_PERIOD_OPTIONS.QUARTERLY.toLowerCase();
    case TIME_PERIOD_TYPES.YEARLY:
      return TIME_PERIOD_OPTIONS.YEARLY.toLowerCase();
    default:
      return TIME_PERIOD_OPTIONS.MONTHLY.toLowerCase();
  }
};

export { getTimeKey };
