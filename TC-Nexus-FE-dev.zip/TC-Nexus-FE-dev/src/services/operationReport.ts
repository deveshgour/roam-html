import { OPERATIONS_API_URLS } from '@/constants/urls';
import { httpGet } from '@/utils/http';

/**
 * Fetches the high numbers data from the marketing CAC API
 * @param {string} queryParams - The query parameters to append to the URL
 * @returns {Promise<any>} - The response from the API
 */
const getHighNumbers = async (queryParams: string) => {
  const response = await httpGet(
    `${OPERATIONS_API_URLS.highNumbers}${queryParams ? `?${queryParams}` : ''}`
  );
  return response;
};

export { getHighNumbers };
