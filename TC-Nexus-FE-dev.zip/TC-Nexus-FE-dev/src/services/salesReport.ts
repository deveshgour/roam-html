import { API_BASE_URL, FINANCIAL_API_URLS } from '@/constants/urls';
import { SalesReportPayload } from '@/hooks/useSalesReport';
import { httpDelete, httpGet, httpPost, httpPut } from '@/utils/http';

const getHighNumbers = async (queryParams: string) => {
  const response = await httpGet(
    `${FINANCIAL_API_URLS.highNumbers}${queryParams ? `?${queryParams}` : ''}`
  );
  return response;
};

const salesRevenueBarChart = async (queryParams: string) => {
  const response = await httpGet(
    `${FINANCIAL_API_URLS.salesRevenueBarChart}${queryParams ? `?${queryParams}` : ''}`
  );
  return response;
};

const salesRevenueLineChart = async (queryParams: string) => {
  const response = await httpGet(
    `${FINANCIAL_API_URLS.salesRevenueLineChart}${queryParams ? `?${queryParams}` : ''}`
  );
  return response;
};

const salesRevenuePieChart = async (queryParams: string) => {
  const response = await httpGet(
    `${FINANCIAL_API_URLS.salesRevenuePieChart}${queryParams ? `?${queryParams}` : ''}`
  );
  return response;
};

const leastPerforming = async (queryParams: string) => {
  const response = await httpGet(
    `${FINANCIAL_API_URLS.leastPerforming}${queryParams ? `?${queryParams}` : ''}`
  );
  return response;
};

const getRevenueType = async () => {
  const response = await httpGet(`${FINANCIAL_API_URLS.revenueType}`);
  return response.data;
};

const downloadReport = async (queryParams: string) => {
  window.open(
    `${API_BASE_URL}${FINANCIAL_API_URLS.downloadReport}${queryParams ? `?${queryParams}` : ''}`,
    '_blank'
  );
};

const getPerformanceReport = async (queryParams: string) => {
  const response = await httpGet(
    `${FINANCIAL_API_URLS.performanceReport}${queryParams ? `?${queryParams}` : ''}`
  );
  return response;
};

const getJobListing = async (queryParams: string) => {
  const response = await httpGet(
    `${FINANCIAL_API_URLS.jobListing}${queryParams ? `?${queryParams}` : ''}`
  );
  return response;
};

const downloadPerformanceReport = async (queryParams: string) => {
  window.open(
    `${API_BASE_URL}${FINANCIAL_API_URLS.downloadPerformanceReport}${queryParams ? `?${queryParams}` : ''}`,
    '_blank'
  );
};

const getManualSalesReport = async (queryParams: string) => {
  const response = await httpGet(
    `${FINANCIAL_API_URLS.manualSalesReport}${queryParams ? `?${queryParams}` : ''}`
  );
  return response;
};

const downloadManualSalesReport = async (queryParams: string) => {
  window.open(
    `${API_BASE_URL}${FINANCIAL_API_URLS.downloadManualSalesReport}${queryParams ? `?${queryParams}` : ''}`,
    '_blank'
  );
};

const deleteSalesReport = async (id: string) => {
  const response = await httpDelete(
    `${FINANCIAL_API_URLS.deleteSalesReport(id)}`
  );
  return response;
};

const createSalesReport = async (payload: SalesReportPayload) => {
  const response = await httpPost(
    `${FINANCIAL_API_URLS.createSalesReport}`,
    payload
  );
  return response;
};

const updateSalesReport = async (id: string, payload: SalesReportPayload) => {
  const response = await httpPut(
    `${FINANCIAL_API_URLS.updateSalesReport(id)}`,
    payload
  );
  return response;
};

const getSalesReportById = async (id: string) => {
  const response = await httpGet(
    `${FINANCIAL_API_URLS.getSalesReportById(id)}`
  );
  return response;
};
/**
 * Fetches the explore data from the sales report API.
 * @param {string} queryParams - The query parameters to append to the URL.
 * @returns {Promise<any>} - The response from the API.
 */
const getExploreData = async (queryParams: string) => {
  const response = await httpGet(
    `${FINANCIAL_API_URLS.exploreDataReport}${queryParams ? `?${queryParams}` : ''}`
  );
  return response;
};

/**
 * Downloads the explore data report from the sales report API.
 * @param {string} queryParams - The query parameters to append to the URL.
 */
const exploreDownloadReport = async (queryParams: string) => {
  window.open(
    `${API_BASE_URL}${FINANCIAL_API_URLS.exploreDownloadReport}${queryParams ? `?${queryParams}` : ''}`,
    '_blank'
  );
};

const salesReportApproval = async (id: string, payload: any) => {
  const response = await httpPut(
    `${FINANCIAL_API_URLS.toggleSalesReportApprovalById(id)}`,
    payload
  );
  return response;
};
export {
  getHighNumbers,
  salesRevenueBarChart,
  salesRevenueLineChart,
  salesRevenuePieChart,
  leastPerforming,
  getRevenueType,
  downloadReport,
  exploreDownloadReport,
  getPerformanceReport,
  downloadPerformanceReport,
  getManualSalesReport,
  downloadManualSalesReport,
  deleteSalesReport,
  createSalesReport,
  updateSalesReport,
  getSalesReportById,
  getJobListing,
  getExploreData,
  salesReportApproval,
};
