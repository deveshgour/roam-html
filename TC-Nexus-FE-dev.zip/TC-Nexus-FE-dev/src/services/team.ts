import { TEAM_API_URLS } from '@/constants/urls';
import { httpGet, httpPut, httpDelete, httpPost } from '@/utils/http';

const getTeams = async (params: string = '') => {
  const response = await httpGet(TEAM_API_URLS.getTeams + params);
  return response;
};

const createTeam = async (team: { name: string; user_ids: string[] }) => {
  const response = await httpPost(TEAM_API_URLS.addTeam, team);
  return response;
};

const editTeam = async (
  team: {
    name: string;
    user_ids: string[];
  },
  id: string
) => {
  const response = await httpPut(TEAM_API_URLS.updateTeam(id), team);
  return response;
};

const deleteTeamById = async (teamId: string) => {
  const response = await httpDelete(TEAM_API_URLS.deleteTeam(teamId));
  return response;
};

export { getTeams, createTeam, editTeam, deleteTeamById };
