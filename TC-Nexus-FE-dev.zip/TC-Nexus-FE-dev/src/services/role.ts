import { RoleFormValues } from '@/app/roles/management/components/addRoleModal';
import { ROLE_API_URLS, USER_API_URLS } from '@/constants/urls';
import { httpGet, httpPut, httpDelete, httpPost } from '@/utils/http';

const getRoles = async (params: string = '') => {
  const response = await httpGet(ROLE_API_URLS.getRoles + params);
  return response;
};

const createRole = async (roleData: RoleFormValues) => {
  const response = await httpPost(ROLE_API_URLS.addRole, roleData);
  return response;
};

const editRole = async (roleData: RoleFormValues, id: string) => {
  const response = await httpPut(ROLE_API_URLS.updateRole(id), roleData);
  return response;
};

const deleteRoleById = async (roleId: string) => {
  const response = await httpDelete(ROLE_API_URLS.deleteRole(roleId));
  return response;
};

const getRoleById = async (roleId: string) => {
  const response = await httpGet(ROLE_API_URLS.getRoleById(roleId));
  return response;
};

const getUserRoles = async (userId: string) => {
  const response = await httpGet(USER_API_URLS.getUserRoleDetails(userId));
  return response;
};

export {
  getRoles,
  createRole,
  editRole,
  deleteRoleById,
  getRoleById,
  getUserRoles,
};
