import { AUTH_API_URLS } from '@/constants/urls';
import { httpPost } from '@/utils/http';

/**
 * @typedef {Object} loginFormTypes
 * @property {string} email
 * @property {string} password
 */
interface loginFormTypes {
  email: string;
  password: string;
}

interface forgotPasswordFormType {
  email: string;
}
interface resetPasswordFormType {
  new_password: string;
}

/**
 * This method is used to perform API request for checking user identification
 *
 * @param {loginFormTypes} params
 * @returns {Promise}
 */
const loginUser = async (params: loginFormTypes) => {
  const response = await httpPost(AUTH_API_URLS.login, params);
  return response;
};

/**
 * This method is used to perform API request for user logout
 *
 * @returns {Promise}
 */
const logoutUser = async () => {
  const response = await httpPost(AUTH_API_URLS.logout, {});
  return response;
};

const forgotPassword = async (params: forgotPasswordFormType) => {
  const response = await httpPost(AUTH_API_URLS.forgotPassword, params);
  return response;
};

const resetUserPassword = async (
  queryParams: string,
  params: resetPasswordFormType
) => {
  const response = await httpPost(
    `${AUTH_API_URLS.resetPassword}${queryParams ? `?${queryParams}` : ''}`,
    params
  );
  return response;
};

/**
 * @exports
 */
export { loginUser, logoutUser, forgotPassword, resetUserPassword };
