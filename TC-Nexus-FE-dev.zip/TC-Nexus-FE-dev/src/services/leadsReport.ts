/**
 * This service provides functions to fetch data from the marketing API.
 * Currently, it only supports fetching the high numbers data.
 */

import { API_BASE_URL, MARKETING_API_URLS } from '@/constants/urls';
import { httpGet } from '@/utils/http';

/**
 * Fetches the high numbers data from the marketing API.
 * @param {string} queryParams - The query parameters to append to the URL.
 * @returns {Promise<any>} - The response from the API.
 */
const getHighNumbers = async (queryParams: string) => {
  const response = await httpGet(
    `${MARKETING_API_URLS.highNumbers}${queryParams ? `?${queryParams}` : ''}`
  );
  return response;
};

/**
 * Fetches the performance report data from the marketing API.
 * @param {string} queryParams - The query parameters to append to the URL.
 * @returns {Promise<any>} - The response from the API.
 */
const getPerformanceReport = async (queryParams: string): Promise<any> => {
  const url = `${MARKETING_API_URLS.performanceReport}${queryParams ? `?${queryParams}` : ''}`;
  const response = await httpGet(url);
  return response;
};

/**
 * Fetches the sales funnel chart data from the marketing API.
 * @param {string} queryParams - The query parameters to append to the URL.
 * @returns {Promise<any>} - The response from the API.
 */
const salesFunnelLineChart = async (queryParams: string) => {
  const response = await httpGet(
    `${MARKETING_API_URLS.salesFunnelChart}${queryParams ? `?${queryParams}` : ''}`
  );
  return response;
};
/**
 * Fetches the lead source report data from the marketing API.
 * @param {string} queryParams - The query parameters to append to the URL.
 * @returns {Promise<any>} - The response from the API.
 */
const getLeadSourceReport = async (queryParams: string): Promise<any> => {
  const url = `${MARKETING_API_URLS.leadSourceReport}${queryParams ? `?${queryParams}` : ''}`;
  // Make an HTTP GET request to the constructed URL
  const response = await httpGet(url);
  // Return the API response
  return response;
};

const getDownloadSourceReport = async (queryParams: string) => {
  window.open(
    `${API_BASE_URL}${MARKETING_API_URLS.downloadSourceReport}${queryParams ? `?${queryParams}` : ''}`,
    '_blank'
  );
};

const getDownloadPerformanceReport = async (queryParams: string) => {
  window.open(
    `${API_BASE_URL}${MARKETING_API_URLS.downloadPerformanceReport}${queryParams ? `?${queryParams}` : ''}`,
    '_blank'
  );
};

const getDownloadSourceDetailReport = async (queryParams: string) => {
  window.open(
    `${API_BASE_URL}${MARKETING_API_URLS.downloadSourceDetailReport}${queryParams ? `?${queryParams}` : ''}`,
    '_blank'
  );
};

const getSourceJobDetailReport = async (queryParams: string): Promise<any> => {
  const url = `${MARKETING_API_URLS.SourceJobDetailReport}${queryParams ? `?${queryParams}` : ''}`;
  // Make an HTTP GET request to the constructed URL
  const response = await httpGet(url);
  // Return the API response
  return response;
};

/**
 * Fetches the explore data from the sales report API.
 * @param {string} queryParams - The query parameters to append to the URL.
 * @returns {Promise<any>} - The response from the API.
 */
const getExploreData = async (queryParams: string) => {
  const response = await httpGet(
    `${MARKETING_API_URLS.exploreDataReport}${queryParams ? `?${queryParams}` : ''}`
  );
  return response;
};

/**
 * Downloads the explore data report from the sales report API.
 * @param {string} queryParams - The query parameters to append to the URL.
 */
const exploreDownloadReport = async (queryParams: string) => {
  window.open(
    `${API_BASE_URL}${MARKETING_API_URLS.exploreDownloadReport}${queryParams ? `?${queryParams}` : ''}`,
    '_blank'
  );
};

const downloadReport = async (queryParams: string) => {
  window.open(
    `${API_BASE_URL}${MARKETING_API_URLS.downloadReport}${queryParams ? `?${queryParams}` : ''}`,
    '_blank'
  );
};

export {
  getHighNumbers,
  getPerformanceReport,
  salesFunnelLineChart,
  getLeadSourceReport,
  getDownloadSourceReport,
  getDownloadPerformanceReport,
  getSourceJobDetailReport,
  getDownloadSourceDetailReport,
  getExploreData,
  exploreDownloadReport,
  downloadReport,
};
