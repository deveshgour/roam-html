/**
 * Service to fetch data from the marketing CAC API
 * @module services/cacReport
 */
import { API_BASE_URL, MARKETING_CAC_API_URLS } from '@/constants/urls';
import { httpGet } from '@/utils/http';

/**
 * Fetches the high numbers data from the marketing CAC API
 * @param {string} queryParams - The query parameters to append to the URL
 * @returns {Promise<any>} - The response from the API
 */
const getHighNumbers = async (queryParams: string) => {
  const response = await httpGet(
    `${MARKETING_CAC_API_URLS.highNumbers}${queryParams ? `?${queryParams}` : ''}`
  );
  return response;
};

/**
 * Fetches the bar chart data from the marketing CAC API
 * @param {string} queryParams - The query parameters to append to the URL
 * @returns {Promise<any>} - The response from the API
 */
const getBarChartData = async (queryParams: string) => {
  const response = await httpGet(
    `${MARKETING_CAC_API_URLS.barChartData}${queryParams ? `?${queryParams}` : ''}`
  );
  return response;
};

/**
 * Fetches the line chart data from the marketing CAC API.
 * @param {string} queryParams - The query parameters to append to the URL.
 * @returns {Promise<any>} - The response from the API.
 */
const getLineChartData = async (queryParams: string): Promise<any> => {
  // Construct the URL with query parameters if provided
  const url = `${MARKETING_CAC_API_URLS.lineChartData}${queryParams ? `?${queryParams}` : ''}`;
  const response = await httpGet(url);
  return response;
};

const getSourceBarChartData = async (queryParams: string): Promise<any> => {
  // Construct the URL with query parameters if provided
  const url = `${MARKETING_CAC_API_URLS.sourceBarChartData}${queryParams ? `?${queryParams}` : ''}`;
  const response = await httpGet(url);
  return response;
};

/**
 * Fetches the source performance data from the marketing CAC API.
 * @param {string} queryParams - The query parameters to append to the URL.
 * @returns {Promise<any>} - The response from the API.
 */
const getSourcePerformanceData = async (queryParams: string): Promise<any> => {
  const url = `${MARKETING_CAC_API_URLS.sourcePerformanceData}${queryParams ? `?${queryParams}` : ''}`;
  const response = await httpGet(url);
  return response;
};
/**
 * Opens a new browser window to download the source report.
 * @param {string} queryParams - The query parameters to append to the URL.
 */
const getDownloadSourceReport = async (queryParams: string) => {
  // Construct the full URL with query parameters if provided
  const url = `${API_BASE_URL}${MARKETING_CAC_API_URLS.downloadSourceReport}${queryParams ? `?${queryParams}` : ''}`;
  // Open the URL in a new browser tab
  window.open(url, '_blank');
};

const getSourceDetailData = async (queryParams: string): Promise<any> => {
  const url = `${MARKETING_CAC_API_URLS.sourceDetailData}${queryParams ? `?${queryParams}` : ''}`;
  const response = await httpGet(url);
  return response;
};

const getDownloadSourceViewReport = async (queryParams: string) => {
  const url = `${API_BASE_URL}${MARKETING_CAC_API_URLS.downloadSourceViewReport}${queryParams ? `?${queryParams}` : ''}`;
  window.open(url, '_blank');
};

const getDownloadReport = async (queryParams: string) => {
  const url = `${API_BASE_URL}${MARKETING_CAC_API_URLS.downloadReport}${queryParams ? `?${queryParams}` : ''}`;
  window.open(url, '_blank');
};

const getExploreDownloadReport = async (queryParams: string) => {
  const url = `${API_BASE_URL}${MARKETING_CAC_API_URLS.exploreDownloadReport}${queryParams ? `?${queryParams}` : ''}`;
  window.open(url, '_blank');
};

const getBarChartPopupData = async (queryParams: string): Promise<any> => {
  // Construct the URL with query parameters if provided
  const url = `${MARKETING_CAC_API_URLS.barChartPopupData}${queryParams ? `?${queryParams}` : ''}`;
  const response = await httpGet(url);
  return response;
};
const getExploreData = async (queryParams: string) => {
  const response = await httpGet(
    `${MARKETING_CAC_API_URLS.exploreDataReport}${queryParams ? `?${queryParams}` : ''}`
  );
  return response;
};
/**
 * Exports the getHighNumbers and getBarChartData functions
 * @exports
 */
export {
  getHighNumbers,
  getBarChartData,
  getLineChartData,
  getSourceBarChartData,
  getSourcePerformanceData,
  getDownloadSourceReport,
  getSourceDetailData,
  getDownloadSourceViewReport,
  getDownloadReport,
  getExploreDownloadReport,
  getBarChartPopupData,
  getExploreData,
};
