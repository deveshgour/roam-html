import { COMMON_API_URLS } from '@/constants/urls';
import { httpGet } from '@/utils/http';

const getLocations = async (screenName: string = '') => {
  const response = await httpGet(
    screenName
      ? `${COMMON_API_URLS.locations}?screen_name=${screenName}`
      : COMMON_API_URLS.locations
  );
  return response.data;
};

const getAllLocations = async () => {
  const response = await httpGet(COMMON_API_URLS.allLocations);
  return response.data;
};

const getSalesReps = async (
  screenName: string = '',
  locationId: string = ''
) => {
  const response = await httpGet(
    screenName
      ? `${COMMON_API_URLS.salesReps}?screen_name=${screenName}&location_id=${locationId}`
      : COMMON_API_URLS.salesReps
  );
  return response.data;
};

export { getLocations, getSalesReps, getAllLocations };
