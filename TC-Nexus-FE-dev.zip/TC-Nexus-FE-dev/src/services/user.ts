import { USER_API_URLS } from '@/constants/urls';
import { User } from '@/hooks/useUsers';
import { httpGet, httpPut, httpDelete, httpPost } from '@/utils/http';

const getUsers = async (params: string = '') => {
  const response = await httpGet(USER_API_URLS.getUsers + params);
  return response;
};

const updateUserStatus = async (userId: string, status: boolean) => {
  const response = await httpPut(USER_API_URLS.updateUserStatus(userId), {
    is_active: status,
  });
  return response;
};

const deleteUserById = async (userId: string) => {
  const response = await httpDelete(USER_API_URLS.deleteUser(userId));
  return response;
};

const createUser = async (
  user: Omit<
    User,
    | 'id'
    | 'created_at'
    | 'updated_at'
    | 'last_login'
    | 'is_superuser'
    | 'role_and_location'
  >
) => {
  const response = await httpPost(USER_API_URLS.addUser, user);
  return response;
};

const editUser = async (
  user: Omit<
    User,
    | 'created_at'
    | 'updated_at'
    | 'last_login'
    | 'is_superuser'
    | 'password'
    | 'id'
  >,
  id: string
) => {
  const response = await httpPut(USER_API_URLS.updateUser(id), user);
  return response;
};

const resetPassword = async (
  userId: string,
  password: string,
  oldPassword: string = ''
) => {
  const response = await httpPut(USER_API_URLS.resetPassword(userId), {
    current_password: oldPassword,
    new_password: password,
  });
  return response;
};

const getUserProfile = async () => {
  const response = await httpGet(USER_API_URLS.userProfile);
  return response;
};
const getLocationsList = async () => {
  const response = await httpGet(USER_API_URLS.getLocationsList);
  return response;
};

const getRolesList = async () => {
  const response = await httpGet(USER_API_URLS.getRolesList);
  return response;
};

export {
  getUsers,
  updateUserStatus,
  deleteUserById,
  createUser,
  editUser,
  resetPassword,
  getUserProfile,
  getLocationsList,
  getRolesList,
};
