import { API_BASE_URL, MARKETING_LEAD_API_URLS } from '@/constants/urls';
import { MarketingLeadsFilters } from '@/hooks/marketingLeads';
import { httpDelete, httpGet, httpPost, httpPut } from '@/utils/http';

export const getExpenses = async (params: string = '') => {
  const response = await httpGet(
    MARKETING_LEAD_API_URLS.getMarketingLead + params
  );
  return response;
};

export const createMarketingLead = async (data: Record<string, any>) => {
  const response = await httpPost(
    MARKETING_LEAD_API_URLS.createMarketingLead,
    data
  );
  return response;
};

export const editMarketingLead = async (
  data: Record<string, any>,
  id: string
) => {
  const response = await httpPut(
    MARKETING_LEAD_API_URLS.updateMarketingLead(id),
    data
  );
  return response;
};

export const deleteMarketingLeadById = async (id: string) => {
  const response = await httpDelete(
    MARKETING_LEAD_API_URLS.deleteMarketingLead(id)
  );
  return response;
};

export const getAllLeadSources = async () => {
  try {
    const response = await httpGet(MARKETING_LEAD_API_URLS.getAllLeadSources);
    return response;
  } catch (error) {
    console.error('Error fetching lead sources:', error);
    throw error;
  }
};

export const getAllLocations = async () => {
  try {
    const response = await httpGet(MARKETING_LEAD_API_URLS.getAllLocations);
    return response;
  } catch (error) {
    console.error('Error fetching locations:', error);
    throw error;
  }
};

export const getMarketingLeadById = async (id: string) => {
  const response = await httpGet(
    `${MARKETING_LEAD_API_URLS.getMarketingLead}/${id}`
  );
  return response;
};

export const exportMarketingLeadsCSV = async (
  filters: MarketingLeadsFilters
) => {
  try {
    // Build query parameters
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        params.append(key, value.toString());
      }
    });

    const queryString = params.toString() ? `?${params.toString()}` : '';
    const baseUrl = API_BASE_URL.endsWith('/')
      ? API_BASE_URL.slice(0, -1)
      : API_BASE_URL;
    const url = `${baseUrl}${MARKETING_LEAD_API_URLS.downloadMarketingLeads}${queryString}`;

    const response = await fetch(url, {
      method: 'GET',
      credentials: 'include',
      headers: {
        Accept: '*/*',
        'Content-Type': 'application/json',
        ...(localStorage.getItem('access_token') && {
          Authorization: `Bearer ${localStorage.getItem('access_token')}`,
        }),
      },
    });

    if (!response.ok) {
      throw new Error(
        `Export failed: ${response.status} ${response.statusText}`
      );
    }

    const blob = await response.blob();
    const downloadUrl = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = `marketing_leads_${new Date().toISOString().split('T')[0]}`;

    document.body.appendChild(link);
    link.click();

    setTimeout(() => {
      document.body.removeChild(link);
      window.URL.revokeObjectURL(downloadUrl);
    }, 100);
  } catch (error) {
    throw error instanceof Error ? error : new Error('Export failed');
  }
};
