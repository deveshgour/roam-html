import { NEW_CONSTRUCTION_BIDS } from '@/constants/urls';
import { httpGet, httpPost, httpPut, httpDelete } from '@/utils/http';
import { ConstructionBidFormData } from '@/hooks/useConstructionBids';

// Get list of construction bids
const getBidsList = async (params: string = '') => {
  const url = params
    ? `${NEW_CONSTRUCTION_BIDS.listConstructionBid}${params}`
    : NEW_CONSTRUCTION_BIDS.listConstructionBid;
  const response = await httpGet(url);
  return response;
};

// Get list of traders
const getTradersList = async () => {
  const response = await httpGet(NEW_CONSTRUCTION_BIDS.allTraders);
  return response;
};

// Get list of builders
const getBuildersList = async () => {
  const response = await httpGet(NEW_CONSTRUCTION_BIDS.allBuilders);
  return response;
};

// Get list of communities
const getCommunitiesList = async () => {
  const response = await httpGet(NEW_CONSTRUCTION_BIDS.allCommunities);
  return response;
};

// Add new construction bid
const addBid = async (
  bidData: ConstructionBidFormData,
  options?: { hideError?: boolean }
) => {
  const url = NEW_CONSTRUCTION_BIDS.addConstructionBid;
  const response = await httpPost(url, bidData, {
    hideError: options?.hideError,
  });
  return response;
};

// Update existing construction bid
const updateBid = async (id: string, bidData: ConstructionBidFormData) => {
  const url = NEW_CONSTRUCTION_BIDS.updateConstructionBid(id);
  const response = await httpPut(url, bidData);
  return response;
};

// Delete construction bid
const deleteBid = async (id: string) => {
  const url = NEW_CONSTRUCTION_BIDS.deleteConstructionBid(id);
  const response = await httpDelete(url);
  return response;
};

// Export construction bids
const exportBids = async (params: string = '') => {
  const url = params
    ? `${NEW_CONSTRUCTION_BIDS.exportConstructionBids}${params}`
    : NEW_CONSTRUCTION_BIDS.exportConstructionBids;
  const response = await httpGet(url, { responseType: 'blob' });

  // Create and trigger download
  const blob = new Blob([response], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const url2 = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url2;
  link.setAttribute(
    'download',
    `construction-bids-${new Date().toISOString().split('T')[0]}.xlsx`
  );
  document.body.appendChild(link);
  link.click();
  link.parentNode?.removeChild(link);
  window.URL.revokeObjectURL(url2);

  return true;
};

export {
  getBidsList,
  addBid,
  updateBid,
  deleteBid,
  exportBids,
  getTradersList,
  getBuildersList,
  getCommunitiesList,
};
