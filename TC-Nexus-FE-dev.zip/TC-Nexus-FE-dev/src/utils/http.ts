/* eslint-disable no-unused-vars */
import axios, { AxiosResponse, Canceler } from 'axios';
import { API_BASE_URL } from '@constants/urls';
import { ErrorResponse, HelperParams } from '@/types/utils/http';
import { showErrorMsg } from '@utils/notifications';
import { AUTH_MSG } from '@constants/messages';
import { deleteCookie } from '@utils/cookies';
import { TC_BACKER_USER_DATA } from '@/constants/configs';
import { APP_ROUTE } from '@/constants/routes';

/**
 * Cancel Token
 */
const { CancelToken } = axios;

/**
 * Use to cancel Http Requests
 */
let cancelHttpTokens: Canceler[] = [];

/**
 * Helper Params used in Request
 */
const HELPER_PARAMS: HelperParams = {
  callback: null,
  hideError: false,
  headers: {
    Accept: 'application/json',
  },
};

/**
 * Axios instance for all API requests
 */
const appAxios = axios.create({
  baseURL: API_BASE_URL,
  withCredentials: true,
});

/**
 * Get Common Headers for Request
 */
export const getCommonHeaders = (
  additionalHeaders: Record<string, string> = {}
): Record<string, string> => {
  return {
    Accept: 'application/json',
    ...additionalHeaders,
  };
};

/**
 * Perform a GET request.
 *
 * @param url - The URL for the PATCH request.
 * @param HelperParams - Additional helper parameters.
 * @returns A Promise that resolves to the response data.
 */
export const httpGet = async (
  url: string,
  { callback, headers, hideError, responseType }: HelperParams = HELPER_PARAMS
): Promise<any> => {
  try {
    if (!headers) ({ headers } = HELPER_PARAMS);

    return appAxios
      .get(url, {
        headers: getCommonHeaders(headers),
        responseType: responseType || 'json',
        cancelToken: new CancelToken((c) => {
          cancelHttpTokens.push(c);
          if (callback) callback(c);
        }),
      })
      .then((response) => {
        if (responseType === 'blob') {
          // For file downloads, return the blob directly
          return response.data;
        }
        return httpHandleResponse(response);
      })
      .catch((err) => httpHandleError(err, { hideError }));
  } catch (e) {
    console.error('-- HTTP GET -- ', e);
    return Promise.reject({});
  }
};

/**
 * Post Request
 * @param url
 * @param params
 * @param HelperParams
 */
export const httpPost = (
  url: string,
  params: any,
  {
    callback,
    headers,
    onUploadProgress,
    hideError,
  }: HelperParams = HELPER_PARAMS
): Promise<any> => {
  try {
    if (!headers) ({ headers } = HELPER_PARAMS);

    return appAxios
      .post(url, params, {
        onUploadProgress,
        headers: getCommonHeaders(headers),
        cancelToken: new CancelToken((c) => {
          cancelHttpTokens.push(c);
          if (callback) callback(c);
        }),
      })
      .then(httpHandleResponse)
      .catch((err) => httpHandleError(err, { hideError }));
  } catch (e) {
    console.error('-- HTTP POST -- ', e);
    return Promise.reject({});
  }
};

/**
 * Perform a PUT request.
 *
 * @param url - The URL for the PATCH request.
 * @param params - The parameters for the PATCH request.
 * @param HelperParams - Additional helper parameters.
 * @returns A Promise that resolves to the response data.
 */
export const httpPut = (
  url: string,
  params: any,
  { callback, headers }: HelperParams = HELPER_PARAMS
): Promise<any> => {
  try {
    if (!headers) ({ headers } = HELPER_PARAMS);

    return appAxios
      .put(url, params, {
        headers: getCommonHeaders(headers),
        cancelToken: new CancelToken((c) => {
          cancelHttpTokens.push(c);
          if (callback) callback(c);
        }),
      })
      .then(httpHandleResponse)
      .catch(httpHandleError);
  } catch (e) {
    console.error('-- HTTP PUT -- ', e);
    return Promise.reject({});
  }
};

/**
 * Perform a PATCH request.
 *
 * @param url - The URL for the PATCH request.
 * @param params - The parameters for the PATCH request.
 * @param HelperParams - Additional helper parameters.
 * @returns A Promise that resolves to the response data.
 */
export const httpPatch = (
  url: string,
  params: any,
  { callback, headers }: HelperParams = HELPER_PARAMS
): Promise<any> => {
  try {
    if (!headers) ({ headers } = HELPER_PARAMS);

    return appAxios
      .patch(url, params, {
        headers: getCommonHeaders(headers),
        cancelToken: new CancelToken((c) => {
          cancelHttpTokens.push(c);
          if (callback) callback(c);
        }),
      })
      .then(httpHandleResponse)
      .catch(httpHandleError);
  } catch (e) {
    console.error('-- HTTP PATCH -- ', e);
    return Promise.reject({});
  }
};

/**
 * Perform a PATCH request.
 *
 * @param url - The URL for the PATCH request.
 * @param HelperParams - Additional helper parameters.
 * @returns A Promise that resolves to the response data.
 */
export const httpDelete = (
  url: string,
  params?: any,
  { callback, headers }: HelperParams = HELPER_PARAMS
): Promise<any> => {
  try {
    if (!headers) ({ headers } = HELPER_PARAMS);

    return appAxios
      .delete(url, {
        data: params,
        headers: getCommonHeaders(headers),
        cancelToken: new CancelToken((c) => {
          cancelHttpTokens.push(c);
          if (callback) callback(c);
        }),
      })
      .then(httpHandleResponse)
      .catch(httpHandleError);
  } catch (e) {
    console.error('-- HTTP DELETE -- ', e);
    return Promise.reject({});
  }
};

/**
 * Handle Success Response
 */
export const httpHandleResponse = (res: AxiosResponse): object | null => {
  cancelHttpTokens = [];

  if (!res) return Promise.reject(null);

  /*handle any specific cases here*/

  return Promise.resolve(res.data);
};

/**
 * Handle Success Response
 */
export const httpHandleError = (
  error: any,
  { hideError }: { hideError?: boolean } = {}
): object | null => {
  try {
    if (hideError) return Promise.reject(error);
    if (!error) return Promise.reject({});

    const xhr = error.request;
    let err: ErrorResponse = {};
    if (xhr?.response) err = extractJSON(xhr.response);

    if (xhr) {
      switch (xhr.status) {
        case 400:
          if (err.errors && Object.values(err.errors).length > 0) {
            const firstErrorArray = Object.values(err.errors)[0];
            showErrorMsg(
              Array.isArray(firstErrorArray) ? firstErrorArray[0] : err.message
            );
          } else {
            showErrorMsg(err.message);
          }
          break;
        case 401:
          window.location.href = APP_ROUTE.AUTH.LOGIN;
          showErrorMsg(AUTH_MSG.sessionExpired);
          deleteCookie(TC_BACKER_USER_DATA);
          window.location.href = APP_ROUTE.AUTH.LOGIN;
          break;
        case 404:
          showErrorMsg(err.detail);
          break;
        case 500:
          showErrorMsg();
          break;
        default:
          showErrorMsg();
      }
    }
    return Promise.reject(error);
  } catch (e) {
    console.error('-- HTTP HANDLE ERROR -- ', e);
    return Promise.reject({});
  }
};

/**
 * Cancel Http Request
 */
export const httpCancel = (): void => {
  try {
    cancelHttpTokens.forEach((cancel) => cancel());
    cancelHttpTokens = [];
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
  } catch (e) {
    cancelHttpTokens = [];
  }
};

/**
 * Extract JSON Response
 */
export const extractJSON = (json: string): any => {
  try {
    const data = JSON.parse(json);
    if (typeof data == 'object' && data !== null) return data;
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
  } catch (e) {
    return {};
  }
  return {};
};
