import { HighNumbersResponse, InfoCardProps } from '@/app/operations/types';

/**
 * Transforms high numbers response data into a format suitable for displaying as info cards.
 *
 * @param {HighNumbersResponse} data - The response data from the API.
 * @returns {InfoCardData[]} - The transformed data for info cards.
 */
export const transformInfoCardsData = (
  data: HighNumbersResponse
): InfoCardProps[] => {
  return [
    {
      title: 'Job Completion Rate',
      value: `${data?.job_completion_rate?.toString()} %` || '--',
      icon: 'shoppingCart',
      iconBgColor: 'bg-amber-50',
      iconColor: 'text-amber-400',
      borderColor: 'border-amber-200',
    },
    {
      title: 'Google Reviews Requested',
      value: '120',
      icon: 'googleReviews',
      iconBgColor: 'bg-blue-50',
      iconColor: 'text-blue-600',
      borderColor: 'border-blue-200',
    },
    {
      title: 'Google Reviews Received',
      value: '95',
      icon: 'star',
      iconBgColor: 'bg-green-50',
      iconColor: 'text-green-400',
      borderColor: 'border-green-200',
    },
    {
      title: 'Response Rate of Reviews',
      value: '79%',
      icon: 'percentage',
      iconBgColor: 'bg-pink-50',
      iconColor: 'text-pink-500',
      borderColor: 'border-pink-200',
    },
    {
      title: 'Lead to Appointment',
      value:
        `${data?.lead_to_appointment} ${Number(data?.lead_to_appointment) < 2 ? 'Day' : 'Days'}` ||
        '--',
      helping_text: ' - Average time',
      icon: 'calendarOutline',
      iconBgColor: 'bg-teal-50',
      iconColor: 'text-teal-400',
      borderColor: 'border-teal-200',
    },
    {
      title: 'Lead to Conversion',
      value:
        `${data?.lead_to_conversion} ${Number(data?.lead_to_conversion) < 2 ? 'Day' : 'Days'}` ||
        '--',
      helping_text: ' - Average time',
      icon: 'dataExchange',
      iconBgColor: 'bg-purple-50',
      iconColor: 'text-purple-400',
      borderColor: 'border-purple-200',
    },
    {
      title: 'Conversion to Job Completion',
      value:
        `${data?.conversion_to_job_completion} ${Number(data?.conversion_to_job_completion) < 2 ? 'Day' : 'Days'}` ||
        '--',
      helping_text: ' - Average time',
      icon: 'tick',
      iconBgColor: 'bg-red-50',
      iconColor: 'text-red-500',
      borderColor: 'border-red-200',
    },
    {
      title: 'Repeat Customers',
      value: `${data?.repeat_customers} %` || '--',
      helping_text: '',
      icon: 'percentage',
      iconBgColor: 'bg-gray-50',
      iconColor: 'text-gray-500',
      borderColor: 'border-gray-200',
    },
  ];
};
