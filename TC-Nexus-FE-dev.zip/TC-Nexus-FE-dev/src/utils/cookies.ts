/**
 * Sets a cookie with the specified name, value, and options.
 * @param name - The name of the cookie.
 * @param value - The value of the cookie.
 * @param days - The number of days the cookie should persist. Defaults to session-only if not provided.
 */
export function setCookie(name: string, value: string, days?: number): void {
  let expires = '';
  if (days) {
    const date = new Date();
    date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
    expires = `; expires=${date.toUTCString()}`;
  }
  document.cookie = `${name}=${encodeURIComponent(value)}${expires}; path=/`;
}

/**
 * Retrieves the value of a cookie by name.
 * @param name - The name of the cookie to retrieve.
 * @returns The value of the cookie, or null if not found.
 */
export function getCookie(name: string): string | null {
  const nameEQ = `${name}=`;
  const cookies = document.cookie.split(';');
  for (let cookie of cookies) {
    cookie = cookie.trim();
    if (cookie.startsWith(nameEQ)) {
      return decodeURIComponent(cookie.substring(nameEQ.length));
    }
  }
  return null;
}

/**
 * Checks if a cookie exists by name.
 * @param name - The name of the cookie to check.
 * @returns True if the cookie exists, otherwise false.
 */
export function isCookieExists(name: string): boolean {
  return getCookie(name) !== null;
}

/**
 * Deletes a cookie by setting its expiration date to a past date.
 * @param name - The name of the cookie to delete.
 */
export const deleteCookie = (name: string): void => {
  document.cookie = `${name}=; expires=${new Date(0).toUTCString()}; path=/;`;
};
