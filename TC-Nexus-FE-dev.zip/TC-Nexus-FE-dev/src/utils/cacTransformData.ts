import {
  HighNumbersResponse,
  InfoCardData,
  ChartDataPoint,
  LineChartData,
  SourceChartDataPoint,
  TrendChartDataPoint,
  LeadSourceDetailData,
  ExploreTableData,
  LeadSourceTableData,
} from '@/app/marketing/cac/types';
import { getTimeKey, TimePeriod } from '@/types/common';
import { addDays, addMonths, endOfMonth, format } from 'date-fns';

/**
 * Generates a human-readable category label based on the given item and time period.
 *
 * @param {TrendChartDataPoint} item - The item to generate the category label for.
 * @param {TimePeriod} timePeriod - The time period to use for generating the label.
 * @returns {string} - The generated category label.
 */
const generateCategory = (
  item: TrendChartDataPoint,
  timePeriod: TimePeriod
) => {
  switch (timePeriod) {
    // Weekly labels are formatted as 'MMM d - MMM d'
    case 'weekly': {
      const startDate = new Date(item.week!);
      const endDate = addDays(startDate, 6);
      return `${format(startDate, 'MMM d')} - ${format(endDate, 'MMM d')}`;
    }
    // Monthly labels are formatted as 'MMM'
    case 'monthly':
      return format(new Date(item.month!), 'MMM');
    // Quarterly labels are formatted as 'MMM d - MMM d'
    case 'quarterly': {
      const startDate = new Date(item.quarter!);
      const endDate = endOfMonth(addMonths(startDate, 2));
      return `${format(startDate, 'MMM d')} - ${format(endDate, 'MMM d')}`;
    }
    // Yearly labels are formatted as 'yyyy'
    case 'yearly':
      return format(new Date(item.year!), 'yyyy');
    // Otherwise, return an empty string
    default:
      return '';
  }
};

/**
 * Transforms high numbers response data into a format suitable for displaying as info cards.
 *
 * @param {HighNumbersResponse} data - The response data from the API.
 * @returns {InfoCardData[]} - The transformed data for info cards.
 */
export const transformInfoCardsData = (
  data: HighNumbersResponse
): InfoCardData[] => {
  return [
    {
      title: 'Average CAC',
      value: data?.average_cac
        ? `$${data?.average_cac?.toLocaleString()}`
        : '--',
      icon: 'dollarSign',
      percentage: data?.growth_rate
        ? `${data?.growth_rate || '--'} vs last period`
        : '',
      iconBgColor: 'bg-amber-50',
      isPositive:
        typeof data?.growth_rate === 'number' && data?.growth_rate >= 0
          ? true
          : false,
      iconColor: 'text-amber-400',
      borderColor: 'border-amber-200',
    },
    {
      title: 'Total Customers',
      value: data?.total_customers?.toString() || '--',
      icon: 'userGroup',
      percentage: '',
      isPositive: false,
      iconBgColor: 'bg-blue-50',
      iconColor: 'text-blue-600',
      borderColor: 'border-blue-200',
    },
    {
      title: 'Best Performing Source',
      value: data?.best_performing_source?.toString() || '--',
      icon: 'history',
      isPositive: true,
      percentage: data?.cac ? `$${data?.cac} CAC` : ``,
      iconBgColor: 'bg-pink-50',
      iconColor: 'text-pink-600',
      borderColor: 'border-pink-200',
    },
  ];
};

/**
 * Transforms bar chart response data into a format suitable for displaying in a BarChart.
 *
 * @param {LineChartDataResponse} data - The response data from the API.
 * @returns {any} - The transformed data for the BarChart.
 */
export const transformBarChartData = (data: ChartDataPoint[]) => {
  if (!data || data.length === 0) {
    return {
      title: 'Spend Vs. Customer Acquired',
      categories: [],
      yAxisMaxSpend: 0,
      yAxisMaxCustomers: 0,
      yAxisTickInterval: 100,
      useDualYAxis: true,
      series: [
        {
          name: 'Marketing Spends',
          data: [],
          color: '#2c5e4b',
          type: 'column' as const,
          borderRadius: 8,
          pointWidth: 36,
          yAxis: 0, // Left Y-axis (Marketing Spends)
        },
        {
          name: 'Customers Acquired',
          data: [],
          color: '#3498db',
          type: 'column' as const,
          borderRadius: 8,
          pointWidth: 36,
          yAxis: 1, // Right Y-axis (Customers Acquired)
        },
      ],
    };
  }

  // Check if all values are zero
  const isAllZero = data.every(
    (item) => item.customers_acquired === 0 && item.marketing_spends === 0
  );
  if (isAllZero) {
    return null;
  }

  const maxCustomers =
    Math.max(...data.map((item) => item?.customers_acquired)) || 0;
  // Calculate yAxisMaxCustomers with 10% padding and round to next multiple of 10
  const yAxisMaxCustomers =
    maxCustomers > 0 ? Math.ceil((maxCustomers * 1.1) / 10) * 10 : 10;

  const maxSpend = Math.max(...data.map((item) => item?.marketing_spends)) || 0;
  const yAxisMaxSpend = Math.max(maxSpend * 1.1, 50);

  return {
    title: 'Spend Vs. Customer Acquired',
    categories: data.map((item) => item.source),
    useDualYAxis: true,
    type: 'column',
    legend: { enabled: true },
    yAxisMaxSpend,
    yAxisMaxCustomers,
    yAxisTickInterval: 1000,
    series: [
      {
        name: 'Marketing Spends',
        data: data.map((item) => ({
          y: item.marketing_spends,
          cac: item.cac,
          marketing_spends: `${item.marketing_spends.toLocaleString()}`,
          customers_acquired: item.customers_acquired,
        })),
        color: '#2c5e4b',
        type: 'column' as const,
        borderRadius: 0,
        pointWidth: 10,
        yAxis: 0, // Left Y-axis (Marketing Spends)
      },
      {
        name: 'Customers Acquired',
        data: data.map((item) => ({
          y: item.customers_acquired,
          cac: item.cac,
          marketing_spends: `${item.marketing_spends.toLocaleString()}`,
          customers_acquired: item.customers_acquired,
        })),
        color: '#3498db',
        type: 'column' as const,
        borderRadius: 0,
        pointWidth: 10,
        yAxis: 1, // Right Y-axis (Customers Acquired)
      },
    ],
    yAxis: [
      {
        // Left y-axis for Marketing Spends
        title: { text: 'Marketing Spends ($)' },
        max: yAxisMaxSpend,
        min: 0,
        labels: { format: '${value}' },
      },
      {
        // Right y-axis for Customers Acquired
        title: { text: 'Customers Acquired' },
        opposite: true,
        max: yAxisMaxCustomers,
        min: 0,
        labels: { format: '{value}' },
      },
    ],
  };
};

// eslint-disable-next-line no-unused-vars
export const tooltipFormatter = function (this: any) {
  const { category, point } = this;
  const fields = [
    {
      label: `<span class="font-semibold color: text-gray-900">${category}</span>`,
      value: '',
    },
    point?.marketing_spends !== undefined
      ? {
          label: 'Spend',
          value: `$${point?.marketing_spends?.toLocaleString()}`,
        }
      : null,
    point?.customers_acquired !== undefined
      ? {
          label: 'Customer Aquired',
          value: `${point?.customers_acquired?.toLocaleString()}`,
        }
      : null,
    point?.cac !== undefined
      ? {
          label: 'CAC',
          value: `$${point?.cac?.toLocaleString()}`,
        }
      : null,
  ].filter((field) => field !== null);

  return `
      <div style="padding: 0 4px 4px 4px; min-width: 200px; background-color: #fff;">
        ${fields
          .map(
            ({ label, value }) => `
            <span style="display: block; width: 100%; font-size: 13px; margin-top: 6px;">
              <span style="width: 180px; display: inline-block; color: #6B7280;">${label}</span>
              <span>${value}</span>
            </span>`
          )
          .join('')}
      </div>
    `;
};

/**
 * Transforms the given data into a format that can be used by the Highcharts library for rendering a line chart.
 * @param data The data to transform.
 * @param timePeriod The time period for the data.
 * @returns The transformed data.
 */
export const transformTrendChartData = (
  data: TrendChartDataPoint[],
  timePeriod: TimePeriod
): LineChartData => {
  if (!data || data.length === 0) {
    return {
      title: 'CAC Trends Over Time',
      type: 'spline',
      categories: [],
      series: [],
      yAxisMin: 0,
      yAxisTickInterval: 100,
      useDualYAxis: false,
    };
  }

  // Get unique time points and sort them
  const timePoints = [
    ...new Set(data.map((item) => item[getTimeKey(timePeriod)])),
  ].sort();

  // Generate categories using existing function
  const categories = timePoints.map((timePoint) =>
    generateCategory(
      {
        week: timePeriod === 'weekly' ? timePoint : undefined,
        month: timePeriod === 'monthly' ? timePoint : undefined,
        quarter: timePeriod === 'quarterly' ? timePoint : undefined,
        year: timePeriod === 'yearly' ? timePoint : undefined,
      },
      timePeriod
    )
  );

  // Generate series
  const series = [
    {
      name: 'CAC',
      type: 'spline',
      yAxis: 1,
      data: timePoints.map((timePoint) => {
        const point = data.find(
          (item) => item[getTimeKey(timePeriod)] === timePoint
        );
        return { y: Number(point?.cac) || 0 };
      }),
      color: '#2196F3',
    },
    {
      name: 'Customers Acquired',
      type: 'spline',
      yAxis: 0,
      data: timePoints.map((timePoint) => {
        const point = data.find(
          (item) => item[getTimeKey(timePeriod)] === timePoint
        );
        return { y: Number(point?.customers_acquired) || 0 };
      }),
      color: '#4CAF50',
    },
  ];
  // max values for Y-axes
  const maxCustomers = Math.max(
    ...data.map((item) => Number(item?.customers_acquired) || 0)
  );
  const yAxisMaxCustomers =
    maxCustomers > 0 ? Math.ceil(maxCustomers * 1.1) : 50;

  const maxCAC = Math.max(...data?.map((item) => Number(item?.cac) || 0));
  const yAxisMaxCAC = maxCAC > 0 ? Math.ceil(maxCAC * 1.1) : 50;

  return {
    title: 'CAC Trends Over Time',
    type: 'spline',
    categories,
    series,
    yAxisMaxCAC,
    yAxisMaxCustomers,
    yAxisTickInterval: 1000,
    yAxisMin: 0,
    useDualYAxis: true,
    yAxis: [
      {
        title: { text: 'CAC' },
        max: yAxisMaxCAC,
        labels: { format: '${value}' },
        opposite: true,
      },
      {
        title: { text: 'Customers Acquired' },
        max: yAxisMaxCustomers,
        labels: { format: '{value}' },
      },
    ],
  };
};
export const labelsFormatter = function (
  // eslint-disable-next-line no-unused-vars
  this: any
) {
  return `$${this.value}`;
};
export const secondaryLabelsFormatter = function (
  // eslint-disable-next-line no-unused-vars
  this: any
) {
  return this.value;
};

/**
 * Format the tooltip for the trend chart.
 * The tooltip is a container element that will be displayed when the user hovers over a data point.
 * The tooltip should display the month and the value of the data point.
 * The value should be formatted as a currency string if the series name is 'marketing_spends'.
 * @param this - The current data point.
 * @param category - The month of the data point.
 * @param series - The series of the data point.
 * @param point - The data point.
 * @returns A string representing the tooltip.
 */
// eslint-disable-next-line no-unused-vars
export const trendTooltipFormatter = function (this: any) {
  const { category, series, point } = this;
  const fields = [
    {
      label: 'Month',
      value: `${category}`,
    },
    {
      label: `${series?.name}`,
      // Format the value as a currency string if the series name is 'marketing_spends'.
      // Otherwise, just display the value as a string.
      value: series?.name === 'CAC' ? `$${point?.y}` : `${point?.y}`,
    },
  ].filter((field) => field !== null);

  return `
    <div style="padding: 0 4px 4px 4px; min-width: 180px; background-color: #fff;">
      ${fields
        .map(
          ({ label, value }) => `
          <span style="display: block; width: 100%; font-size: 13px; margin-top: 6px;">
            <span style="width: 140px; display: inline-block; color: #6B7280;">${label}</span>
            <span>${value}</span>
          </span>`
        )
        .join('')}
    </div>
    `;
};

/**
 * Transforms source data into a format suitable for displaying in a BarChart.
 *
 * @param {SourceChartDataPoint[]} data - The source data points.
 * @param {string[]} generatedColors - Array of colors for the bars.
 * @returns {object} - The transformed data for the BarChart.
 */
export const transformSourceBarChartData = (
  data: SourceChartDataPoint[],
  generatedColors: string[]
) => {
  // Return default structure if data is empty
  if (!data || data.length === 0) {
    return {
      title: 'Customers By Lead Source',
      categories: [],
      type: 'bar',
      yAxisMax: 0,
      yAxisTickInterval: 100,
      series: [
        {
          name: 'Source',
          data: [],
          color: generatedColors[0],
          type: 'bar' as const,
          borderRadius: 0,
          pointWidth: 24,
          yAxis: 0, // Left Y-axis
        },
      ],
      yAxis: [
        {
          title: { text: 'Customers' },
          max: 0,
          labels: { format: '{value}' },
        },
      ],
    };
  }

  // Calculate the maximum value for the Y-axis
  const maxCustomers = Math.max(...data.map((item) => item.customers)) || 0;
  const yAxisMax = maxCustomers > 0 ? Math.ceil(maxCustomers * 1.1) : 50;

  const calculateTickInterval = (yAxisMax: number) => {
    return yAxisMax <= 30 ? 4 : 25;
  };
  const yAxisTickIntervalCustomers = calculateTickInterval(yAxisMax);
  // Transform data into chart format
  return {
    title: 'Customers By Lead Source',
    categories: data.map((item) => item.source),
    type: 'bar',
    yAxisTickInterval: yAxisTickIntervalCustomers,
    yAxisMax,
    series: [
      {
        name: 'Customers',
        data: data.map((item, index) => ({
          y: item.customers,
          conversion: item.conversion_rate,
          color: generatedColors[index % generatedColors.length], // unique color based on index
        })),
        type: 'column' as const,
        borderRadius: 0,
        pointWidth: 12,
      },
    ],
    yAxis: [
      {
        title: { text: '' },
        max: yAxisMax,
        labels: { format: '{value}' },
      },
    ],
  };
};

/**
 * Format the tooltip for the source chart.
 * The tooltip is a container element that will be displayed when the user hovers over a data point.
 * The tooltip should display the source and the value of the data point.
 * The value should be formatted as a string.
 * If the 'conversion' property is present in the data point, it should also be displayed in the tooltip.
 * @param this - The current data point.
 * @param category - The source of the data point.
 * @param series - The series of the data point.
 * @param point - The data point.
 * @returns A string representing the tooltip.
 */
// eslint-disable-next-line no-unused-vars
export const sourceTooltipFormatter = function (this: any) {
  const { category, series, point } = this;

  const fields = [
    {
      label: `<span class="font-semibold color: text-gray-900">${category}</span>`,
      value: '',
    },
    {
      label: `${series?.name}`,
      value: `${point?.y}`,
    },

    point?.conversion !== undefined
      ? {
          label: 'Conversion Rate',
          value: `${point?.conversion}%`,
        }
      : null,
  ].filter((field) => field !== null);

  return `
    <div style="padding: 0 4px 4px 4px; min-width: 200px; background-color: #fff;">
      ${fields
        .map(
          ({ label, value }) => `
          <span style="display: block; width: 100%; font-size: 13px; margin-top: 6px;">
            <span style="width: 180px; display: inline-block; color: #6B7280;">${label}</span>
            <span>${value}</span>
          </span>`
        )
        .join('')}
    </div>
  `;
};

/**
 * Transforms the lead source data into an array of LeadSourceTableData objects.
 *
 * @param {any[]} data - The raw data array from the API.
 * @returns {LeadSourceTableData[]} - The transformed array of lead source table data.
 */
export const transformLeadSourceTableData = (
  data: any[],
  total?: { marketing_spends: number; customers_acquired: number; cac: number }
): LeadSourceTableData => {
  return {
    data:
      data?.map((item, index) => ({
        id: (index + 1).toString(),
        source: item?.source || '--',
        marketing_spends: item?.marketing_spends || 0,
        customers_acquired: item?.customers_acquired || 0,
        cac: item?.cac || 0,
      })) || [],
    total: total || { marketing_spends: 0, customers_acquired: 0, cac: 0 },
  };
};

export const transformSourceDetailData = (
  data: any[]
): LeadSourceDetailData[] => {
  return (
    data?.map((item, index) => ({
      id: (index + 1).toString(),
      customer: item?.customer || '',
      job_id: item?.job_id || '--',
      job_name: item?.job_name || '',
      lead_date: item?.lead_date || '--',
      contract_signed_date: item?.contract_signed_date || '--',
      total_amount: item?.total_amount
        ? `$${item?.total_amount.toLocaleString()}`
        : '0',
    })) || []
  );
};

export const transformBarChartPopupData = (data: ChartDataPoint[]) => {
  if (!data || data.length === 0) {
    return {
      title: 'Spend Vs. Customer Acquired',
      categories: [],
      yAxisMax: 0,
      yAxisTickInterval: 100,
      useDualYAxis: true,
      series: [
        {
          name: 'Customers Acquired',
          data: [],
          color: '#3498db',
          type: 'column' as const,
          borderRadius: 8,
          pointWidth: 36,
          yAxis: 0, // Left Y-axis
        },
        {
          name: 'Marketing Spends',
          data: [],
          color: '#2c5e4b',
          type: 'column' as const,
          borderRadius: 8,
          pointWidth: 36,
          yAxis: 1, // Right Y-axis
        },
      ],
    };
  }

  // Check if all values are zero
  const isAllZero = data.every(
    (item) => item.customers_acquired === 0 && item.marketing_spends === 0
  );
  if (isAllZero) {
    return null;
  }

  // Find max values for Y-axes
  const maxCustomers = Math.max(...data.map((item) => item.customers_acquired));
  const yAxisMaxCustomers =
    maxCustomers > 0 ? Math.ceil(maxCustomers * 1.1) : 50;

  const maxSpend = Math.max(...data.map((item) => item.marketing_spends));
  const yAxisMaxSpend = maxSpend > 0 ? Math.ceil(maxSpend * 1.1) : 50; // Convert to rounded 'k' format

  return {
    title: 'Spend Vs. Customer Acquired',
    categories: data.map(
      (item) => format(item.month, 'MMM') // Fallback for undefined values
    ),
    useDualYAxis: true, // ✅ Enables dual Y-axes
    type: 'column',
    legend: { enabled: true },
    yAxisMaxCustomers,
    yAxisMaxSpend,
    yAxisMin: 0,
    yAxisTickInterval: 1000,
    series: [
      {
        name: 'Marketing Spend',
        data: data.map((item) => ({
          y: item.marketing_spends,
          cac: item.cac,
          source: item.source,
        })),
        color: '#3498db',
        type: 'column' as const,
        borderRadius: 0,
        pointWidth: 10,
        yAxis: 0, // Uses left Y-axis
      },
      {
        name: 'Customers Acquired',
        data: data.map((item) => ({
          y: item.customers_acquired,
          cac: item.cac,
          source: item.source,
        })),
        color: '#2c5e4b',
        type: 'column' as const,
        borderRadius: 0,
        pointWidth: 10,
        tickInterval: 10,
        yAxis: 1, // Uses right Y-axis
      },
    ],
    yAxis: [
      {
        title: { text: 'Customers Acquired' },
        max: yAxisMaxCustomers,
        labels: { format: '{value}' },
      },
      {
        title: { text: 'Marketing Spends ($)' },
        max: yAxisMaxSpend,
        labels: { format: '${value}k' },
        opposite: true,
      },
    ],
  };
};

// eslint-disable-next-line no-unused-vars
export const popupTooltipFormatter = function (this: any) {
  const { series, point } = this;
  const fields = [
    {
      label: `<span class="font-semibold color: text-gray-900">${point?.source ? point.source : 'Source'}</span>`,
      value: '',
    },
    {
      label: `${series?.name}`,
      value:
        series?.name === 'Marketing Spend' ? `$${point?.y}` : `${point?.y}`,
    },

    point?.cac !== undefined
      ? {
          label: 'CAC',
          value: `$${point?.cac}`,
        }
      : null,
  ].filter((field) => field !== null);

  return `
      <div style="padding: 0 4px 4px 4px; min-width: 200px; background-color: #fff;">
        ${fields
          .map(
            ({ label, value }) => `
            <span style="display: block; width: 100%; font-size: 13px; margin-top: 6px;">
              <span style="width: 180px; display: inline-block; color: #6B7280;">${label}</span>
              <span>${value}</span>
            </span>`
          )
          .join('')}
      </div>
    `;
};

/**
 * Transforms the explore data into the expected format for the component.
 * @param data - The data from the API.
 * @returns The transformed data.
 */
/**
 * Transforms the explore data into the expected format for the component.
 * @param data - The data from the API.
 * @returns The transformed data as an array of ExploreTableData.
 */
export const transformExploreData = (data: any[]): ExploreTableData[] => {
  return (
    data?.map((item) => ({
      id: item?.id ? `${item?.id}` : '--',
      source: item?.source ? `${item?.source}` : '--',
      lead_date: item?.lead_date ? `${item?.lead_date}` : '--',
      representative_name: item?.representative_name
        ? `${item?.representative_name}`
        : '--',
      contact_name: item?.contact_name ? `${item?.contact_name}` : '--',
      contact_number: item?.contact_number ? `${item?.contact_number}` : '--',
      first_appointment_date: item?.first_appointment_date
        ? `${item?.first_appointment_date}`
        : '--',
      contract_signed_date: item?.contract_signed_date
        ? `${item?.contract_signed_date}`
        : '--',
      status: item?.status ? `${item?.status}` : '--',
      total_amount: item?.total_amount ? `$${item?.total_amount}` : '--',
    })) || []
  );
};
