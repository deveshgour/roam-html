import { userPermissions } from '@/components/userProfileInfo/types';
import { APP_ROUTE } from '@/constants/routes';
import { NavItem } from '@/constants/configs';

// Define system admin routes that require explicit system admin permission
const SYSTEM_ADMIN_ROUTES = new Set([
  APP_ROUTE.USERS.MANAGEMENT,
  APP_ROUTE.ROLES.MANAGEMENT,
]);

// Define route permission mappings with new permission keys
const ROUTE_PERMISSIONS: Record<string, keyof userPermissions> = {
  [APP_ROUTE.USERS.MANAGEMENT]: 'system_administration',
  [APP_ROUTE.ROLES.MANAGEMENT]: 'system_administration',
  [APP_ROUTE.FINANCIAL.SALES]: 'sales_revenue',
  [APP_ROUTE.DATA_FORM.SALES_REPORT]: 'sales_report',
  [APP_ROUTE.DATA_FORM.ADD_SALES_REPORT]: 'sales_report',
  [APP_ROUTE.DATA_FORM.EDIT_SALES_REPORT]: 'sales_report',
  [APP_ROUTE.MARKETING.LEADS]: 'lead_conversion',
  [APP_ROUTE.OPERATIONS.JOBS]: 'operations',
  [APP_ROUTE.TEAMS.MANAGEMENT]: 'system_administration',
  [APP_ROUTE.MARKETING.CAC]: 'cac',
  [APP_ROUTE.DATA_FORM.NEW_CONSTRUCTION_BID]: 'new_construction_bids',
  [APP_ROUTE.DATA_FORM.MARKETING_LEADS]: 'marketing_lead',
};

// Define always-accessible routes
const ALWAYS_ACCESSIBLE_ROUTES = new Set([APP_ROUTE.DASHBOARD]);

// Add this new type to define required permissions for menu items
export type MenuPermissionRequirement = {
  anyOf?: (keyof userPermissions)[]; // Any of these permissions should be present
  allOf?: (keyof userPermissions)[]; // All of these permissions should be present
};

// Add this new function to check menu permissions
export const checkMenuPermissions = (
  permissions: userPermissions | null,
  requirement: MenuPermissionRequirement
): boolean => {
  if (!permissions) return false;

  // If all_screens_access is true, allow access
  if (permissions.all_screens_access === 1) return true;

  // Check anyOf permissions - if any one permission is present
  if (requirement.anyOf) {
    return requirement.anyOf.some((perm) => permissions[perm] === 1);
  }

  // Check allOf permissions - all permissions must be present
  if (requirement.allOf) {
    return requirement.allOf.every((perm) => permissions[perm] === 1);
  }

  return false;
};

// Update existing checkPermission function to handle menu items with permission requirements
export const checkPermission = (
  pathOrItem: string | (NavItem & { permissions?: MenuPermissionRequirement }),
  permissions: userPermissions | null
): boolean => {
  try {
    // Handle NavItem object with custom permissions
    if (typeof pathOrItem !== 'string' && pathOrItem.permissions) {
      return checkMenuPermissions(permissions, pathOrItem.permissions);
    }

    // Rest of the existing function remains the same...
    const path = typeof pathOrItem === 'string' ? pathOrItem : pathOrItem.url;

    // Special case for Profit route
    if (path === APP_ROUTE.FINANCIAL.PROFIT) {
      return (
        permissions?.profit_margin_retail === 1 ||
        permissions?.profit_margin_nc === 1
      );
    }

    // Rest of the existing checks...
    if (ALWAYS_ACCESSIBLE_ROUTES.has(path)) return true;
    if (SYSTEM_ADMIN_ROUTES.has(path)) {
      return permissions?.system_administration === 1;
    }
    if (permissions?.all_screens_access === 1) return true;

    const requiredPermission = ROUTE_PERMISSIONS[path];
    if (requiredPermission) {
      return permissions?.[requiredPermission] === 1;
    }

    return true;
  } catch (error) {
    console.error('Error checking permission:', error);
    return false;
  }
};

// Alias for middleware to maintain existing imports
export const hasRouteAccess = checkPermission;
