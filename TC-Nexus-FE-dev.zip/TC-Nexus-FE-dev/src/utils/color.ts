/**
 * Generates an array of hex color strings with a specified length.
 * The colors are evenly spaced in the color wheel, starting from red.
 *
 * @param {number} numColors - The number of colors to generate.
 * @returns {string[]} - An array of hex color strings.
 */
export const generateColors = (numColors: number): string[] => {
  return Array.from({ length: numColors }, (_, index) => {
    const hue = (360 / numColors) * index;
    return `hsl(${hue}, 100%, 60%)`;
  });
};
