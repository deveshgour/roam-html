import {
  ChartDataPoint,
  HighNumbersResponse,
  InfoCardProps,
} from '@/app/financial/profit/newConstruction/types';

export const transformInfoCardsData = (
  data: HighNumbersResponse
): InfoCardProps[] => {
  return [
    {
      title: 'Revenue',
      value: data?.revenue,
      icon: 'money',
      iconBgColor: 'bg-amber-50',
      iconColor: 'text-amber-400',
      borderColor: 'border-amber-200',
    },
    {
      title: 'Profit',
      value: data.profit,
      icon: 'wealth',
      iconBgColor: 'bg-blue-50',
      iconColor: 'text-blue-600',
      borderColor: 'border-blue-200',
    },
    {
      title: 'Payments Received',
      value: data.paymentsReceived,
      icon: 'dollarSign',
      iconBgColor: 'bg-pink-50',
      iconColor: 'text-pink-600',
      borderColor: 'border-pink-200',
    },
    {
      title: 'Accounts Payable',
      value: data.accountsPayable,
      icon: 'handMoney',
      iconBgColor: 'bg-red-100',
      iconColor: 'text-red-600',
      borderColor: 'border-red-200',
    },
    {
      title: 'Credits',
      value: data.credits,
      icon: 'exchange',
      iconBgColor: 'bg-green-50',
      iconColor: 'text-green-600',
      borderColor: 'border-green-200',
    },
    {
      title: 'Commission',
      value: data.commission,
      icon: 'handMoney',
      iconBgColor: 'bg-teal-50',
      iconColor: 'text-teal-600',
      borderColor: 'border-teal-200',
    },
    {
      title: 'Completed Jobs',
      value: data.completedJobs,
      icon: 'bag',
      iconBgColor: 'bg-gray-100',
      iconColor: 'text-gray-600',
      borderColor: 'border-gray-200',
    },
    {
      title: 'In Progress Jobs',
      value: data.inProgressJobs,
      icon: 'bag',
      iconBgColor: 'bg-yellow-50',
      iconColor: 'text-yellow-600',
      borderColor: 'border-yellow-200',
    },
  ];
};

export const transformBarChartData = (data: ChartDataPoint[]) => {
  if (!data || data.length === 0) {
    return {
      title: 'Profit by Builders',
      categories: [],
      yAxisMax: 0,
      yAxisTickInterval: 200,
      series: [
        {
          name: 'Revenue',
          data: [],
          color: '#84cc16',
          type: 'column' as const,
          borderRadius: 4,
          pointWidth: 20,
        },
        {
          name: 'Profit',
          data: [],
          color: '#15803d',
          type: 'column' as const,
          borderRadius: 4,
          pointWidth: 20,
        },
      ],
    };
  }

  // Check if all values are zero
  const isAllZero = data.every(
    (item) => Number(item.revenue) === 0 && Number(item.profit) === 0
  );
  if (isAllZero) {
    return null;
  }

  const maxValue = Math.max(
    ...data.map((item) => Math.max(Number(item.revenue), Number(item.profit)))
  );

  return {
    title: 'Profit by Builders',
    categories: data.map((item) => item.expense),
    yAxisMax: maxValue,
    yAxisTickInterval: 4000,
    legend: { enabled: true },
    align: 'right',
    type: 'column',
    series: [
      {
        name: 'Revenue',
        data: data.map((item) => Number(item.revenue)),
        color: '#A6C91C',
        type: 'column' as const,
        borderRadius: 0,
        pointWidth: 20,
      },
      {
        name: 'Profit',
        data: data.map((item) => Number(item.profit)),
        color: '#15803d',
        type: 'column' as const,
        borderRadius: 0,
        pointWidth: 20,
      },
    ],
  };
};

// eslint-disable-next-line no-unused-vars
export const tooltipFormatter = function (this: any) {
  const { category, series, point } = this;
  const fields = [
    {
      label: `<span class="font-semibold color: text-gray-900">${category}</span>`,
      value: '',
    },
    {
      label: `${series?.name}`,
      value: `$${point?.y}`,
    },
  ].filter((field) => field !== null);

  return `
      <div style="padding: 0 4px 4px 4px; min-width: 200px; background-color: #fff;">
        ${fields
          .map(
            ({ label, value }) => `
            <span style="display: block; width: 100%; font-size: 13px; margin-top: 6px;">
              <span style="width: 180px; display: inline-block; color: #6B7280;">${label}</span>
              <span>${value}</span>
            </span>`
          )
          .join('')}
      </div>
    `;
};
