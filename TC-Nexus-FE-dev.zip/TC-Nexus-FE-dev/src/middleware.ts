import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { APP_ROUTE } from './constants/routes';
import {
  TC_BACKER_USER_DATA,
  TC_BACKER_USER_PERMISSIONS,
} from './constants/configs';
import { PROTECTED_ROUTES } from './constants/configs';
import { hasRouteAccess } from '@/utils/permissions';

//Only specify public routes - all other routes will be protected
const publicRoutes = [
  APP_ROUTE.AUTH.LOGIN,
  APP_ROUTE.AUTH.FORGOT_PASSWORD,
  APP_ROUTE.AUTH.RESET_PASSWORD,
  APP_ROUTE.AUTH.VERIFY_EMAIL,
  APP_ROUTE.ROOT,
  APP_ROUTE.COMPONENTS,
];

export default async function middleware(req: NextRequest) {
  try {
    const path = req.nextUrl.pathname;
    const isPublicRoute = publicRoutes.includes(path);

    // Get cookies once and handle potential JSON parse errors
    const cookieStore = await cookies();
    const userDataCookie = cookieStore.get(TC_BACKER_USER_DATA)?.value;
    const permissionCookie = cookieStore.get(TC_BACKER_USER_PERMISSIONS)?.value;

    let permissions = null;
    try {
      permissions = permissionCookie ? JSON.parse(permissionCookie) : null;
    } catch (e) {
      console.error('Error parsing permissions cookie:', e);
    }

    // Handle root route first
    if (path === APP_ROUTE.ROOT) {
      return NextResponse.redirect(new URL(APP_ROUTE.AUTH.LOGIN, req.nextUrl));
    }

    // Handle authenticated users trying to access public routes
    if (isPublicRoute && userDataCookie && !PROTECTED_ROUTES.includes(path)) {
      return NextResponse.redirect(new URL(APP_ROUTE.DASHBOARD, req.nextUrl));
    }

    // Handle unauthenticated users
    if (!isPublicRoute && !userDataCookie) {
      return NextResponse.redirect(new URL(APP_ROUTE.AUTH.LOGIN, req.nextUrl));
    }

    // Handle permission checks
    if (!isPublicRoute && !hasRouteAccess(path, permissions)) {
      return NextResponse.redirect(
        new URL(APP_ROUTE.UNAUTHORISED, req.nextUrl)
      );
    }

    return NextResponse.next();
  } catch (error) {
    console.error('Middleware error:', error);
    return NextResponse.redirect(new URL(APP_ROUTE.AUTH.LOGIN, req.nextUrl));
  }
}

// Routes Middleware should not run on
export const config = {
  matcher: ['/((?!api|_next/static|_next/image|favicon|assets|.*\\.[^/]*$).*)'],
};
