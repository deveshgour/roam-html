import type { Metadata } from 'next';
import { ToastContainer } from 'react-toastify';
import './globals.css';
import { Roboto } from 'next/font/google';
import LayoutWrapper from '@/layouts/LayoutWrapper';
import 'react-toastify/dist/ReactToastify.css';

const roboto = Roboto({
  weight: ['100', '300', '400', '500', '700', '900'],
  subsets: ['latin'],
});

export const metadata: Metadata = {
  title: 'TC Backer - Reporting Dashboard',
  description: 'TC Backer is a platform for all your needs',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={roboto.className} data-theme="light">
        <ToastContainer />
        <LayoutWrapper>{children}</LayoutWrapper>
      </body>
    </html>
  );
}
