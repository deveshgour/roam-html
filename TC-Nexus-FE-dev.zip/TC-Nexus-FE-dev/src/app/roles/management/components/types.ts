export interface Role {
  id: string;
  description?: string;
  value?: string;
  name: string;
  users_assigned: number;
}
