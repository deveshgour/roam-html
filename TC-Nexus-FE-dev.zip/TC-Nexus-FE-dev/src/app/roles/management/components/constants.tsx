export const columns = [
  { header: 'ROLE NAME', accessorKey: 'name' },
  { header: 'DESCRIPTION', accessorKey: 'description', sortable: true },
  { header: 'ACCESS LEVEL', accessorKey: 'access_levels', sortable: true },
  { header: 'USER ASSIGNED', accessorKey: 'users_assigned', sortable: true },
];

export const accessLevelsList = [
  { key: 'access_level', label: 'Admin', access_level: 'admin' },
  { key: 'access_level', label: 'Manager', access_level: 'manager' },
  {
    key: 'access_level',
    label: 'Sales Representative',
    access_level: 'sales_rep',
  },
];

export const permissionsList = [
  {
    key: 'system_administration',
    label: 'System Administer',
    description: 'Ability to add/remove users and create/remove roles',
  },
  {
    key: 'all_screens_access',
    label: 'All Screens Access',
    description: 'Access to view all screens and data in the system',
  },
  {
    key: 'sales_revenue',
    label: 'Sales Revenue',
    description: 'Access to Sales Revenue data',
  },
  {
    key: 'profit_margin_retail',
    label: 'Profit Margin Retail',
    description: 'Access to Profit Margin Retail data',
  },
  {
    key: 'profit_margin_nc',
    label: 'Profit Margin NC',
    description: 'Access to Profit Margin NC data',
  },
  {
    key: 'lead_conversion',
    label: 'Lead Conversion',
    description: 'Access to Lead Conversion data',
  },
  {
    key: 'cac',
    label: 'CAC',
    description: 'Access to CAC data',
  },
  {
    key: 'operations',
    label: 'Operations',
    description: 'Access to Operations data',
  },
  {
    key: 'sales_report',
    label: 'Sales Report',
    description: 'Access to Sales Report data',
  },
  {
    key: 'new_construction_bids',
    label: 'New Construction Bids',
    description: 'Access to New Construction Bids data',
  },
  {
    key: 'marketing_lead',
    label: 'Marketing Leads',
    description: 'Access to Marketing Leads data',
  },
];
