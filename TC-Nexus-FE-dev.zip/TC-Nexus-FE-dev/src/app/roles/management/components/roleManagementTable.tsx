import { DataTable } from '@/components/coreUI/table/dataTable';
import { useState, useCallback, useMemo } from 'react';
import { Button } from '@/components/coreUI/button';
import Modal from '@/components/coreUI/dialog';
import { showSuccessMsg, showErrorMsg } from '@/utils/notifications';
import AddRoleModal, {
  RoleFormValues,
} from '@/app/roles/management/components/addRoleModal';
import { Role } from '@/app/roles/management/components/types';
import { columns } from '@/app/roles/management/components/constants';
import { TOAST_MESSAGES } from '@/constants/messages';
import { PAGE_SIZE } from '@/constants/configs';
import Icon from '@/components/coreUI/icon';
import { SortingState } from '@/types/common';
import { useRoles } from '@/hooks/useRoles';

// Add this constant before the ModalType type definition
const MODAL_TYPES = {
  DELETE: 'delete',
  EDIT: 'edit',
  ADD: 'add',
} as const;

type ModalType = (typeof MODAL_TYPES)[keyof typeof MODAL_TYPES];

interface SelectedRoleState {
  type: ModalType;
  role: Role | RoleFormValues;
}

function RoleManagementTable() {
  const [selectedRoles, setSelectedRoles] = useState<string[]>([]);
  const [sorting, setSorting] = useState<SortingState>({
    field: 'name',
    direction: null,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [selectedRoleState, setSelectedRoleState] =
    useState<SelectedRoleState | null>(null);
  const [showModal, setShowModal] = useState<ModalType | null>(null);

  const {
    roles,
    deleteRole,
    totalCount,
    getRoleById,
    updateRole,
    updateFilters,
    filters,
    addRole,
    isLoading,
    fetchRoles,
  } = useRoles({
    initialFilters: {
      page: 1,
      pageSize: 10,
    },
    autoFetch: true,
  });

  // Action handlers
  const handleSearch = useCallback(
    (query: string) => {
      try {
        updateFilters({ name: query, page: 1 });
      } catch (error) {
        console.error('Error updating filters:', error);
        showErrorMsg(TOAST_MESSAGES.FILTER_UPDATE_ERROR);
      }
    },
    [updateFilters]
  );

  const debouncedSearch = useMemo(() => {
    let timeoutId: NodeJS.Timeout;
    return (query: string) => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        handleSearch(query);
      }, 500);
    };
  }, [handleSearch]);

  const handleSelectAll = (selected: boolean, ids: string[]) => {
    setSelectedRoles(selected ? ids : []);
  };

  const closeModal = () => {
    setShowModal(null);
    setSelectedRoleState(null);
  };

  const actions = [
    {
      label: 'Edit',
      onClick: async (row: Role) => {
        try {
          const roleData = await getRoleById(row.id);
          setSelectedRoleState({ type: MODAL_TYPES.EDIT, role: roleData });
          setShowModal(MODAL_TYPES.EDIT);
        } catch (error) {
          console.error('Error fetching role details:', error);
          showErrorMsg(TOAST_MESSAGES.ROLE_FETCH_ERROR);
        }
      },
    },
    {
      label: 'Permanent Delete',
      onClick: (row: Role) => {
        setSelectedRoleState({ type: MODAL_TYPES.DELETE, role: row });
        setShowModal(MODAL_TYPES.DELETE);
      },
    },
  ];

  const handleDelete = async () => {
    try {
      setIsSubmitting(true);
      if (selectedRoleState?.type === MODAL_TYPES.DELETE) {
        const role = selectedRoleState.role as Role;
        await deleteRole(role.id);
        showSuccessMsg(TOAST_MESSAGES.ROLE_DELETE_SUCCESS);
        closeModal();
      }
    } catch {
      // console.error('Error deleting role:', error);
      // showErrorMsg(TOAST_MESSAGES.ROLE_DELETE_ERROR);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAddRole = async (role: RoleFormValues) => {
    try {
      setIsSubmitting(true);
      if (selectedRoleState?.type === MODAL_TYPES.EDIT) {
        const editRole = selectedRoleState?.role as RoleFormValues;
        await updateRole(editRole.id!, role);
        showSuccessMsg(TOAST_MESSAGES.ROLE_UPDATE_SUCCESS);
        await fetchRoles();
      } else {
        await addRole(role);
        showSuccessMsg(TOAST_MESSAGES.ROLE_ADD_SUCCESS);
        await fetchRoles();
      }
      closeModal();
    } catch (error) {
      console.error('Error adding/updating role', error);
      showErrorMsg(TOAST_MESSAGES.ROLE_MODIFY_ERROR);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSortingChange = (
    field: string,
    direction: 'asc' | 'desc' | null
  ) => {
    const orderingValue = direction === 'desc' ? `-${field}` : field;
    updateFilters({ page: 1, ordering: orderingValue });
    setSorting({ field, direction });
  };

  return (
    <>
      <DataTable
        loading={isLoading}
        showSkeleton={true}
        data={roles as unknown as Role[]}
        columns={columns}
        page={filters.page || 1}
        pageSize={filters.pageSize || 10}
        totalItems={totalCount}
        onPageChange={(page) => updateFilters({ page })}
        onPageSizeChange={(pageSize) => updateFilters({ pageSize })}
        onSearch={debouncedSearch}
        selectedRows={selectedRoles}
        onSelectAll={handleSelectAll}
        actions={actions}
        getRowId={(row) => row.id}
        pageSizeOptions={PAGE_SIZE}
        sorting={sorting}
        onSortingChange={handleSortingChange}
        showSearch={true}
        showPagination={true}
        showPageSize={true}
        headerActions={
          <Button
            onClick={() => setShowModal(MODAL_TYPES.ADD)}
            variant="primary"
            className="!py-2.5"
          >
            <Icon iconName="plus" iconProps={{ className: `!h-5 !w-5` }} />
            Add Role
          </Button>
        }
      />

      {selectedRoleState?.type === MODAL_TYPES.DELETE && (
        <Modal
          open={showModal === MODAL_TYPES.DELETE}
          onClose={closeModal}
          title="Delete Role"
          primaryButton={{
            text: 'Delete',
            onClick: handleDelete,
            loading: isSubmitting,
            disabled:
              (selectedRoleState?.role?.users_assigned ?? 0) > 0 ||
              isSubmitting,
          }}
          secondaryButton={{
            text: 'Cancel',
            onClick: closeModal,
          }}
        >
          {selectedRoleState?.role?.users_assigned === 0 ? (
            <div className="text-left">
              <p className="text-gray-600">
                Are you sure you want to permanently delete{' '}
                <span className="font-semibold">
                  {(selectedRoleState.role as Role).name}
                </span>
                ?
              </p>
              <p className="mt-3 text-red-500">This action cannot be undone.</p>
            </div>
          ) : (
            <div className="text-left">
              <p className="text-gray-600">
                This role has {selectedRoleState?.role?.users_assigned} users.
                Please remove all users from this role before deleting.
              </p>
            </div>
          )}
        </Modal>
      )}

      <AddRoleModal
        onSubmit={handleAddRole}
        open={showModal === MODAL_TYPES.EDIT || showModal === MODAL_TYPES.ADD}
        onClose={closeModal}
        role={
          selectedRoleState?.type === MODAL_TYPES.EDIT
            ? (selectedRoleState.role as RoleFormValues)
            : undefined
        }
        isSubmitting={isSubmitting}
      />
    </>
  );
}

export default RoleManagementTable;
