import { Button } from '@/components/coreUI/button';
import Modal from '@/components/coreUI/dialog';
import { TextInput } from '@/components/coreUI/textInput';
import { TextArea } from '@/components/coreUI/textarea';
import { Formik, FormikProps } from 'formik';
import * as Yup from 'yup';
import React, { useEffect } from 'react';
import Icon from '@/components/coreUI/icon';
import { Switch } from '@/components/coreUI/switch';
import { permissionsList, accessLevelsList } from './constants';
import { VALIDATION_MESSAGES } from '@/constants/messages';

interface AddRoleModalProps {
  open: boolean;
  onClose: () => void;
  // eslint-disable-next-line no-unused-vars
  onSubmit: (values: RoleFormValues) => void;
  role?: RoleFormValues;
  isSubmitting?: boolean;
}

export interface RoleFormValues {
  id?: string;
  name: string;
  description: string;
  system_administration?: number;
  all_screens_access?: number;
  sales_revenue?: number;
  profit_margin_retail?: number;
  profit_margin_nc?: number;
  lead_conversion?: number;
  cac?: number;
  operations?: number;
  sales_report?: number;
  new_construction_bids?: number;
  marketing_lead?: number;
  role_type?: string;
  users_assigned?: number;
}

const AddRoleModal = ({
  open = false,
  onClose = () => {},
  onSubmit = () => {},
  role = undefined,
  isSubmitting = false,
}: AddRoleModalProps) => {
  const formikRef = React.useRef<FormikProps<RoleFormValues>>(null);
  const isEditing = Boolean(role);
  const [showPermissionError, setShowPermissionError] = React.useState(false);
  const [showAccessLevelError, setShowAccessLevelError] = React.useState(false);

  useEffect(() => {
    setShowPermissionError(false);
    setShowAccessLevelError(false);
  }, [open]);

  const initialValues: RoleFormValues = {
    name: role?.name || '',
    description: role?.description || '',
    system_administration: role?.system_administration ?? 0,
    all_screens_access: role?.all_screens_access ?? 0,
    sales_revenue: role?.sales_revenue ?? 0,
    profit_margin_retail: role?.profit_margin_retail ?? 0,
    profit_margin_nc: role?.profit_margin_nc ?? 0,
    lead_conversion: role?.lead_conversion ?? 0,
    cac: role?.cac ?? 0,
    operations: role?.operations ?? 0,
    sales_report: role?.sales_report ?? 0,
    new_construction_bids: role?.new_construction_bids ?? 0,
    marketing_lead: role?.marketing_lead ?? 0,
    role_type:
      accessLevelsList.find((level) => level.access_level === role?.role_type)
        ?.access_level || '',
  };

  const handleToggle = (key: keyof RoleFormValues, checked: boolean) => {
    if (formikRef.current) {
      // If toggling all_screens_access to true
      if (key === 'all_screens_access' && checked) {
        // Set all permissions except system_administration to 1
        formikRef.current.setFieldValue('all_screens_access', 1);
        formikRef.current.setFieldValue('sales_revenue', 1);
        formikRef.current.setFieldValue('profit_margin_retail', 1);
        formikRef.current.setFieldValue('profit_margin_nc', 1);
        formikRef.current.setFieldValue('lead_conversion', 1);
        formikRef.current.setFieldValue('cac', 1);
        formikRef.current.setFieldValue('operations', 1);
        formikRef.current.setFieldValue('sales_report', 1);
        formikRef.current.setFieldValue('new_construction_bids', 1);
        formikRef.current.setFieldValue('marketing_lead', 1);
      } else {
        // For other permissions or when unchecking all_screens_access
        formikRef.current.setFieldValue(key, checked ? 1 : 0);
      }
      setShowPermissionError(false);
    }
  };

  // const handleAccessToggle = (key: keyof RoleFormValues, checked: boolean) => {
  //   if (formikRef.current) {
  //     formikRef.current.setFieldValue(key, checked ? 1 : 0);
  //     setShowAccessLevelError(false); // Hide error when user selects a permission
  //   }
  // };

  const validationSchema = Yup.object().shape({
    name: Yup.string().required(VALIDATION_MESSAGES.REQUIRED),
    description: Yup.string().required(VALIDATION_MESSAGES.REQUIRED),
  });

  const hasAnyPermission = (values: RoleFormValues) => {
    return Object.entries(values)
      .filter(
        ([key]) => key !== 'name' && key !== 'description' && key !== 'id'
      )
      .some(([, val]) => val === 1);
  };

  const hasAnyAccessLevel = (values: RoleFormValues) => {
    return Object.entries(values)
      .filter(([key]) => key === 'role_type')
      .some(([, val]) => val !== '' && val !== undefined);
  };

  const handleSubmit = async () => {
    if (formikRef.current) {
      const { validateForm, values, submitForm, setTouched } =
        formikRef.current;

      // Set all fields as touched to show validation errors
      await setTouched({
        name: true,
        description: true,
      });

      const errors = await validateForm();
      const hasErrors = Object.keys(errors).length > 0;

      if (!hasAnyPermission(values)) {
        setShowPermissionError(true);
      }

      if (!hasAnyAccessLevel(values)) {
        setShowAccessLevelError(true);
      }

      // Only submit if there are no validation errors and at least one permission is selected
      if (!hasErrors && hasAnyPermission(values) && hasAnyAccessLevel(values)) {
        await submitForm();
      }
    }
  };

  return (
    <Modal
      maxWidth="2xl"
      header={
        <span className="text-lg inline-flex text-gray">
          {isEditing ? 'Edit Role' : 'Add Role'}
        </span>
      }
      open={open}
      onClose={onClose}
      footer={
        <div className="flex items-center gap-4 w-full">
          <Button
            size="lg"
            type="button"
            onClick={onClose}
            variant="outlineLight"
            full
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            size="lg"
            type="submit"
            onClick={handleSubmit}
            variant="primary"
            full
            loading={isSubmitting}
            disabled={isSubmitting}
          >
            {isEditing ? 'Update Role' : 'Add Role'}
          </Button>
        </div>
      }
    >
      <Formik
        innerRef={formikRef}
        initialValues={initialValues}
        validationSchema={validationSchema}
        validateOnMount={false}
        enableReinitialize={true}
        onSubmit={(values) => {
          const {
            name,
            description,
            system_administration,
            all_screens_access,
            sales_revenue,
            profit_margin_retail,
            profit_margin_nc,
            lead_conversion,
            cac,
            operations,
            sales_report,
            new_construction_bids,
            marketing_lead,
            role_type,
          } = values;
          onSubmit({
            name,
            description,
            system_administration,
            all_screens_access,
            sales_revenue,
            profit_margin_retail,
            profit_margin_nc,
            lead_conversion,
            cac,
            operations,
            sales_report,
            new_construction_bids,
            marketing_lead,
            role_type,
          });
        }}
      >
        {({
          values,
          errors,
          touched,
          setFieldValue,
          handleSubmit: formikHandleSubmit,
        }) => (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              formikHandleSubmit(e);
            }}
            className="mx-auto"
          >
            <div className="grid gap-y-5">
              <div>
                <TextInput
                  size="sm"
                  className="pl-10 !bg-gray-50"
                  label="Role Name"
                  name="name"
                  value={values.name}
                  placeholder="Enter Role Name"
                  error={touched.name && errors.name ? errors.name : ''}
                  onChange={(e) => setFieldValue('name', e.target.value)}
                  startAdornment={
                    <div className="absolute left-4 top-1/2 transform -translate-y-1/2">
                      <Icon
                        iconName="user"
                        iconProps={{ className: `w-4 h-4 text-gray-500` }}
                      />
                    </div>
                  }
                />
              </div>
              <div>
                <TextArea
                  height="6rem"
                  className="px-3 py-2 !bg-gray-50 rounded-lg text-xs"
                  label="Description"
                  name="description"
                  value={values.description}
                  placeholder="Write Description here..."
                  error={
                    touched.description && errors.description
                      ? errors.description
                      : ''
                  }
                  onChange={(e) => setFieldValue('description', e.target.value)}
                />
              </div>
              <div className="text-xs text-gray font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 mb-2 block">
                <h5 className="mb-1">Assign Access Levels</h5>

                <div className="flex gap-x-5 items-center justify-start">
                  {accessLevelsList.map(
                    ({ key, label, access_level }, index) => (
                      <div key={`role_type_${key}_${index}`} className="py-4">
                        <Switch
                          className="mt-1"
                          descriptionStyle="italic"
                          label={label}
                          checked={values.role_type === access_level}
                          onChange={(checked) => {
                            if (checked) {
                              // Set the selected one
                              setFieldValue('role_type', access_level);
                            } else {
                              // Clear if unchecking
                              setFieldValue('role_type', '');
                            }
                            setShowAccessLevelError(false);
                          }}
                        />
                      </div>
                    )
                  )}
                </div>
                {showAccessLevelError && (
                  <div className="text-red-500 text-xs">
                    Access level must be selected
                  </div>
                )}
              </div>
              <div>
                <div className="text-xs text-gray font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 mb-2 block">
                  <h5 className="mb-1">Permissions</h5>

                  {permissionsList.map(({ key, label, description }) => (
                    <div key={key} className="py-4">
                      <Switch
                        className="mt-1"
                        descriptionStyle="italic"
                        label={label}
                        description={description}
                        checked={
                          Number(values[key as keyof RoleFormValues]) === 1
                        }
                        onChange={(checked) =>
                          handleToggle(key as keyof RoleFormValues, checked)
                        }
                      />
                    </div>
                  ))}

                  {showPermissionError && (
                    <div className="text-red-500 text-xs mt-1">
                      At least one permission must be selected
                    </div>
                  )}
                </div>
              </div>
            </div>
          </form>
        )}
      </Formik>
    </Modal>
  );
};

export default AddRoleModal;
