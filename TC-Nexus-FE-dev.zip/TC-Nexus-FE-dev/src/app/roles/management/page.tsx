'use client';
import React from 'react';
import RoleManagementTable from './components/roleManagementTable';

const UsersManagementPage = () => {
  return (
    <div className="bg-white p-8">
      <RoleManagementTable />
    </div>
  );
};

export default UsersManagementPage;
