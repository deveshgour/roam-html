'use client';
import React from 'react';
import DashboardLayout from './DashboardLayout';

const DashboardPage = () => {
  return (
    <div>
      <DashboardLayout />
    </div>
  );
};

export default DashboardPage;
