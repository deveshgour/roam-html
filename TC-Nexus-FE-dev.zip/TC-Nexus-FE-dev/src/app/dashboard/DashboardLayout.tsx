import DateRangePickerWithSidebar from '@/components/coreUI/dateRangePicker';
import Icon from '@/components/coreUI/icon';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/coreUI/select';
import TotalCard from '@/components/coreUI/totalCard';
import { Button } from '@/components/coreUI/button';
import React, { useState } from 'react';
import ServicePieChart from '@/components/highCharts/ServicePieChart';
import BarChart from '@/components/highCharts/BarChart';
import ItemsCard from '@/components/ItemsCard';

const staticLocations = [
  { id: 1, name: 'New York' },
  { id: 2, name: 'Los Angeles' },
  { id: 3, name: 'Chicago' },
  { id: 4, name: 'Houston' },
  { id: 5, name: 'Phoenix' },
];

// Updated lead sources with more accurate data matching the image
const leadSources = [
  { name: 'Facebook', color: '#4E79A7', value: 5 },
  { name: 'Facebook Ads', color: '#59A14F', value: 10 },
  { name: 'Google PPC', color: '#F28E2C', value: 8 },
  { name: 'Google Local', color: '#B07AA1', value: 3 },
  { name: 'Google Ads', color: '#FF6B6B', value: 6 },
  { name: 'Google', color: '#4DC4B0', value: 10 },
  { name: 'BillBoard', color: '#EDC948', value: 3 },
  { name: 'Yard Signs', color: '#4B4B4B', value: 4 },
  { name: 'Referrals', color: '#A7D2E9', value: 5 },
  { name: 'Events', color: '#98D8A0', value: 6 },
  { name: 'Postcards', color: '#FFB6B6', value: 8 },
  { name: 'Others', color: '#FFE0A6', value: 3 },
];

const serviceChartProps = {
  title: 'Total Revenue By Service Type',
  data: [
    { name: 'Roofing', y: 20 },
    { name: 'Siding', y: 15 },
    { name: 'Solar', y: 12 },
    { name: 'Windows', y: 10 },
    { name: 'RS', y: 8 },
    { name: 'RG', y: 7 },
    { name: 'RW', y: 7 },
    { name: 'RS2', y: 7 },
    { name: 'SW', y: 7 },
    { name: 'RSGW', y: 7 },
  ],
};
// Static data for the bar chart
const barChartData = [
  {
    month: 'JAN',
    values: leadSources.map((source) => ({
      source: source.name,
      value: Math.floor(source.value * 3.8),
      color: source.color,
    })),
  },
  {
    month: 'FEB',
    values: leadSources.map((source) => ({
      source: source.name,
      value: Math.floor(source.value * 2.6),
      color: source.color,
    })),
  },
  {
    month: 'MAR',
    values: leadSources.map((source) => ({
      source: source.name,
      value: Math.floor(source.value * 3.9),
      color: source.color,
    })),
  },
  {
    month: 'APR',
    values: leadSources.map((source) => ({
      source: source.name,
      value: Math.floor(source.value * 3.9),
      color: source.color,
    })),
  },
  {
    month: 'MAY',
    values: leadSources.map((source) => ({
      source: source.name,
      value: Math.floor(source.value * 1.4),
      color: source.color,
    })),
  },
  {
    month: 'JUN',
    values: leadSources.map((source) => ({
      source: source.name,
      value: Math.floor(source.value * 1.7),
      color: source.color,
    })),
  },
];

// Static data for the pie chart - using the same lead sources

const DashboardLayout = () => {
  const [selectedDateRange, setSelectedDateRange] = useState<
    [Date | null, Date | null] | null
  >(null);
  const [selectedLocation, setSelectedLocation] = useState<string>('');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4">
        <div className="flex gap-4">
          <div className="w-[325px]">
            <DateRangePickerWithSidebar
              value={selectedDateRange}
              onPrimaryBtnClick={(date) => {
                if (!date?.[0] || !date?.[1]) return;
                setSelectedDateRange(date);
              }}
              onClearBtnClick={() => {
                setSelectedDateRange(null);
              }}
            />
          </div>

          <div className="w-[200px]">
            <Select
              value={selectedLocation}
              onValueChange={setSelectedLocation}
            >
              <SelectTrigger
                icon={
                  <Icon
                    iconName="mapPin"
                    iconProps={{ className: 'text-gray-600' }}
                  />
                }
              >
                <SelectValue placeholder="All Locations" />
              </SelectTrigger>
              <SelectContent>
                {staticLocations
                  .sort((a, b) => a.name.localeCompare(b.name))
                  .map((location) => (
                    <SelectItem
                      key={location.id}
                      value={location.id.toString()}
                    >
                      {location.name}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button
          variant="outlineLight"
          className="!py-2.5"
          icon={
            <Icon
              iconName="export"
              iconProps={{ className: '!w-5 !h-5 text-gray-600' }}
            />
          }
        >
          Export
        </Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <TotalCard
          title="Total Sales Revenue"
          value="980K"
          valuePrefix="$"
          trend={{
            value: 5,
            isPositive: true,
            comparisonText: 'vs Last Month',
            icon: <Icon iconName="arrow" />,
          }}
          className="bg-[#E6F5F5]"
          trendGraph={
            <Icon
              iconName="graph"
              iconProps={{ className: 'text-[#009499]' }}
            />
          }
        />
        <TotalCard
          title="Profit Margin"
          value="28.4"
          valueSuffix="%"
          trend={{
            value: 5,
            isPositive: true,
            comparisonText: 'vs Last Month',
            icon: <Icon iconName="arrow" />,
          }}
          className="bg-[#FCDFD8]"
          trendGraph={
            <Icon
              iconName="graph"
              iconProps={{ className: 'text-[#FF6844]' }}
            />
          }
        />
        <TotalCard
          title="Lead Conversion Rate"
          value="44.80"
          valueSuffix="%"
          trend={{
            value: 10,
            isPositive: true,
            comparisonText: 'vs Last Month',
            icon: <Icon iconName="arrow" />,
          }}
          className="bg-[#E6F5FE]"
          trendGraph={
            <Icon
              iconName="graph"
              iconProps={{ className: 'text-[#019BF4]' }}
            />
          }
        />
        <TotalCard
          title="Average Job Size"
          value="24.5K"
          valuePrefix="$"
          trend={{
            value: 5,
            isPositive: true,
            comparisonText: 'vs Last Year',
            icon: <Icon iconName="arrow" />,
          }}
          className="bg-[#F1E7F8]"
          trendGraph={
            <Icon
              iconName="graph"
              iconProps={{ className: 'text-[#BC5BFF]' }}
            />
          }
        />
        <TotalCard
          title="Home Canvassed"
          value="715"
          trend={{
            value: 5,
            isPositive: false,
            comparisonText: 'vs Last Month',
            icon: <Icon iconName="arrowDown" />,
          }}
          className="bg-green-100"
          trendGraph={
            <Icon
              iconName="graph"
              iconProps={{ className: 'text-[#00A65D]' }}
            />
          }
        />
        <TotalCard
          title="New Construction"
          value="29"
          trend={{
            value: 2,
            isPositive: false,
            comparisonText: 'vs Last Year',
            icon: <Icon iconName="arrowDown" />,
          }}
          className="bg-yellow-50"
          trendGraph={
            <Icon
              iconName="graph"
              iconProps={{ className: 'text-[#E3A008]' }}
            />
          }
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Bar Chart Section */}

        <BarChart
          itemMarginTop={10}
          title="Total Leads From Lead Sources (225)"
          showMultiColor={true}
          series={leadSources.map((source) => ({
            name: source.name,
            data: barChartData.map((month) => {
              const sourceData = month.values.find(
                (v) => v.source === source.name
              );
              return sourceData?.value || 0;
            }),
            color: source.color,
            type: 'column',
          }))}
          categories={barChartData.map((item) => item.month)}
          yAxisMax={400}
          yAxisTickInterval={100}
          defaultTimeFrame="monthly"
        />

        {/* Pie Chart Section */}
        <ServicePieChart
          legendClassName="h-3 w-3"
          {...serviceChartProps}
          legendPosition="bottom"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <ItemsCard
          title="Customer Acquisition Cost"
          items={[
            { label: 'Average CAC', value: '$85' },
            { label: 'Total Customers', value: '390' },
            { label: 'Best Performing Source', value: 'Referrals' },
          ]}
        />
        <ItemsCard
          title="Leads Overview"
          items={[
            { label: 'Total Leads', value: '2450' },
            { label: 'Total Appointments', value: '1245' },
            { label: 'Total Sold', value: '565' },
          ]}
        />
        <ItemsCard
          title="New Construction"
          items={[
            { label: 'Revenue', value: '$8,850,000' },
            { label: 'Profit', value: '$3,710,000' },
            { label: 'Payment Received', value: '$7,965,000' },
          ]}
        />
        <ItemsCard
          title="Retail"
          items={[
            { label: 'Total Profit', value: '$324,060' },
            { label: 'Expenses', value: '$673,940' },
            { label: 'Profit Margin', value: '32.4%' },
          ]}
        />
      </div>
    </div>
  );
};

export default DashboardLayout;
