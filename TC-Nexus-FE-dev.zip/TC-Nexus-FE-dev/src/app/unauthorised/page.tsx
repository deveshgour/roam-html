'use client';

import { Button } from '@/components/coreUI/button';
import Icon from '@/components/coreUI/icon';
import { APP_ROUTE } from '@/constants/routes';
import { useRouter } from 'next/navigation';

export default function PermissionNotAccess() {
  const router = useRouter();

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="text-center p-8">
        <div className="mb-4">
          <Icon
            iconName="lock"
            iconProps={{
              className: 'w-16 h-16 mx-auto text-red-500',
            }}
          />
        </div>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Access Denied</h1>
        <p className="text-gray-600 mb-6">
          You don&apos;t have permission to access this page. Please contact
          your administrator for access.
        </p>
        <Button
          variant="primary"
          onClick={() => router.push(APP_ROUTE.DASHBOARD)}
          className="inline-flex items-center"
        >
          <Icon
            iconName="home"
            iconProps={{
              className: 'w-4 h-4 mr-2',
            }}
          />
          Back to Dashboard
        </Button>
      </div>
    </div>
  );
}
