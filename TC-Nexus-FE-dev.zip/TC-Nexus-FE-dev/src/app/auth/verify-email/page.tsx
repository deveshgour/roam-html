'use client';
import React, { useState, Suspense } from 'react';
import Image from 'next/image';
import VerifyEmailImg from '@/app/assets/images/verify-email.svg';
import { forgotPassword } from '@/services/auth';
import { showErrorMsg, showSuccessMsg } from '@/utils/notifications';
import { ERROR_MESSAGES, FORGOT_PASSWORD_MSG } from '@/constants/messages';
import { useRouter, useSearchParams } from 'next/navigation';
import Icon from '@/components/coreUI/icon';
import { Button } from '@/components/coreUI/button';
import { AUTH_API_URLS } from '@/constants/urls';

const VerifyEmailContent: React.FC = () => {
  const [isDisabled, setIsDisabled] = useState(false);
  const searchParams = useSearchParams();
  const router = useRouter();
  const resendEmail = async () => {
    const encodedEmail = searchParams.get('email');
    if (!encodedEmail) return;

    try {
      setIsDisabled(true);
      const email = atob(encodedEmail);
      const response = await forgotPassword({ email });

      if (response?.status === 200) {
        showSuccessMsg(FORGOT_PASSWORD_MSG.mailSentSuccess);
      } else {
        showErrorMsg(ERROR_MESSAGES.internalError);
      }
    } catch (error: unknown) {
      const message =
        error instanceof Error ? error.message : ERROR_MESSAGES.internalError;
      showErrorMsg(message);
    } finally {
      setIsDisabled(false);
    }
  };

  return (
    <div className="bg-[#F8FAFC] h-[100vh]">
      {/* Logo Section */}
      <div className="p-4">
        <Icon iconName="logo" iconProps={{ width: '180px', height: '90px' }} />
      </div>
      {/* Main Content Section */}
      <div className="w-full flex justify-center items-center">
        <div className="w-full max-w-[500px] space-y-8 xs:mb-20 bg-[#fff] py-[37px] px-[40px]">
          {/* Title and Subtitle */}
          <div className="w-full text-center">
            <Image
              src={VerifyEmailImg}
              alt="verify email"
              width={151}
              height={132}
              className="mb-[32px] mx-auto"
            />
            <h1 className="text-2xl font-bold text-black">Verify your Email</h1>
            <p className="text-[#64748B] leading-[22.4px] mt-3 text-sm">
              Thank you, check your email for instructions to reset your <br />
              password
            </p>
            <Button
              className="mt-[32px]"
              type="button"
              variant="primary"
              full
              size="lg"
              onClick={() => router.push(AUTH_API_URLS.authLogin)}
            >
              Skip Now
            </Button>
            <div className="mt-[32px]">
              Don&apos;t receive an email?{' '}
              <button
                className={
                  isDisabled
                    ? 'opacity-70 text-primary-800 text-[14px] font-bold pointer-events-none'
                    : 'text-primary-800 text-[14px] font-bold cursor-pointer'
                }
                onClick={() => resendEmail()}
              >
                Resend
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const VerifyEmail: React.FC = () => {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <VerifyEmailContent />
    </Suspense>
  );
};

export default VerifyEmail;
