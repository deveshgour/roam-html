'use client';
import React from 'react';
import { TextInput } from '@/components/coreUI/textInput';
import { Button } from '@/components/coreUI/button';
import Icon from '@/components/coreUI/icon';
import { ErrorMessage, Formik } from 'formik';
import * as Yup from 'yup';
import { showSuccessMsg } from '@/utils/notifications';
import { FORGOT_PASSWORD_MSG, VALIDATION_MESSAGES } from '@/constants/messages';
import { forgotPassword } from '@/services/auth';
import { useRouter } from 'next/navigation';
import { EMAIL_PATTERN } from '@/constants/common';
import { AUTH_API_URLS, USER_API_URLS } from '@/constants/urls';

interface forgotPasswordFormValues {
  email: string;
}

const validationSchema = Yup.object().shape({
  email: Yup.string()
    .matches(EMAIL_PATTERN, VALIDATION_MESSAGES.VALID_EMAIL)
    .required(VALIDATION_MESSAGES.EMAIL.REQUIRED),
});

const ForgotPassword: React.FC = () => {
  const router = useRouter();

  const initialValues: forgotPasswordFormValues = {
    email: '',
  };

  const handleSubmit = async (
    values: forgotPasswordFormValues,
    // eslint-disable-next-line no-unused-vars
    setSubmitting: (isSubmitting: boolean) => void
  ) => {
    setSubmitting(true);
    const { email } = values;
    const encodedEmail = btoa(email);
    try {
      const response = await forgotPassword({ email: email });
      if (response?.status == 200) {
        showSuccessMsg(FORGOT_PASSWORD_MSG.mailSentSuccess);
        router.push(USER_API_URLS.verifyEmail(encodedEmail));
      }
    } catch (err: unknown) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="bg-[#F8FAFC] h-[100vh]">
      {/* Logo Section */}
      <div className="p-4">
        <Icon iconName="logo" iconProps={{ width: '180px', height: '90px' }} />
      </div>
      {/* Main Content Section */}
      <div className="w-full flex justify-center items-center h-full">
        <div className="w-full max-w-[500px] space-y-8 xs:mb-20 bg-[#fff] py-[37px] px-[40px]">
          {/* Title and Subtitle */}
          <div className="w-full text-center">
            <h1 className="text-2xl font-bold text-black">Forgot password</h1>
            <p className="text-[#64748B] leading-[22.4px] mt-3 text-sm">
              Enter the email address associated with your account and we will
              send you a link to reset your password.
            </p>
          </div>
          {/* Reset Password Form */}
          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            validateOnMount={true}
            onSubmit={(values, { setSubmitting }) => {
              handleSubmit(values, setSubmitting);
            }}
          >
            {({
              values,
              isSubmitting,
              handleBlur,
              handleChange,
              handleSubmit,
            }) => (
              <form className="space-y-8 w-full" onSubmit={handleSubmit}>
                <div className="space-y-8">
                  <TextInput
                    className="!bg-gray-50 pl-12"
                    name="email"
                    size="lg"
                    type="email"
                    placeholder="Enter Email"
                    value={values.email}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    startAdornment={
                      <span className="absolute left-4 top-1/2 transform -translate-y-1/2">
                        <Icon
                          iconName="email"
                          iconProps={{ className: 'h-6 w-6 text-gray-500' }}
                        />
                      </span>
                    }
                  />
                  <ErrorMessage
                    name="email"
                    component="div"
                    className="text-[12px] text-red-500 !mt-[8px]"
                  />
                  <Button
                    type="submit"
                    variant="primary"
                    full
                    size="lg"
                    disabled={isSubmitting}
                  >
                    Continue
                  </Button>
                  <Button
                    type="button"
                    variant="link"
                    full
                    size="lg"
                    disabled={isSubmitting}
                    onClick={() => router.push(AUTH_API_URLS.authLogin)}
                  >
                    Back to Sign In
                  </Button>
                </div>
              </form>
            )}
          </Formik>
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;
