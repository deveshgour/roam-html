'use client';
import React, { useState } from 'react';
import { loginUser } from '@/services/auth';
import { EMAIL_PATTERN } from '@/constants/common';
import { APP_ROUTE } from '@/constants/routes';
import { AUTH_MSG, VALIDATION_MESSAGES } from '@/constants/messages';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { TextInput } from '@/components/coreUI/textInput';
import { Button } from '@/components/coreUI/button';
import { showSuccessMsg } from '@/utils/notifications';
import { setCookie } from '@/utils/cookies';
import { TC_BACKER_USER_DATA } from '@/constants/configs';
import Icon from '@/components/coreUI/icon';
import Logo from '@/app/assets/images/tcbacker.svg';

/**
 * LoginPage component renders the login page layout with email and password input fields.
 * Users can toggle password visibility and navigate to forgot password functionality.
 */
const LoginPage: React.FC = () => {
  const { push } = useRouter();
  // State to manage the visibility of the password field
  const [showPassword, setShowPassword] = useState(false);
  // State to manage form errors
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  // State to manage form data
  const [formData, setFormData] = useState({ email: '', password: '' });
  // State to manage loading state
  const [loading, setLoading] = useState(false);

  /**
   * Validates if the provided email matches the defined pattern.
   * @param {string} email - The email to validate.
   * @returns {boolean} - Returns true if email is valid, otherwise false.
   */
  const isValidEmail = (email: string) => {
    return EMAIL_PATTERN.test(email);
  };

  /**
   * Validates a single form field and returns an error message if invalid.
   * @param {string} name - The name of the field.
   * @param {string} value - The value of the field.
   * @returns {string} - Returns error message if invalid, otherwise empty string.
   */
  const validateField = (name: string, value: string) => {
    if (!value) return VALIDATION_MESSAGES.REQUIRED;
    if (name === 'email' && !isValidEmail(value))
      return VALIDATION_MESSAGES.VALID_EMAIL;
    if (name === 'password' && value.length < 8)
      return VALIDATION_MESSAGES.PASSWORD.MIN_LENGTH;
    return '';
  };

  /**
   * Handles input changes by updating form data and errors.
   * @param {React.ChangeEvent<HTMLInputElement>} e - The input change event.
   */
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [name]: validateField(name, value),
    }));
  };

  /**
   * Validates all form fields and updates error state.
   * @returns {boolean} - Returns true if all fields are valid, otherwise false.
   */
  const validate = () => {
    const fields: (keyof typeof formData)[] = ['email', 'password'];
    const newErrors: { [key: string]: string } = {};
    let isValid = true;

    fields.forEach((field) => {
      const value = formData[field];
      if (!value) {
        newErrors[field] = VALIDATION_MESSAGES.REQUIRED;
        isValid = false;
      } else if (field === 'email' && !isValidEmail(value)) {
        newErrors.email = VALIDATION_MESSAGES.VALID_EMAIL;
        isValid = false;
      } else if (field === 'password' && value.length < 8) {
        newErrors.password = VALIDATION_MESSAGES.PASSWORD.MIN_LENGTH;
        isValid = false;
      }
    });

    setErrors(newErrors);
    return isValid;
  };

  /**
   * Handles the login process when the form is submitted.
   * @param {React.FormEvent} e - The form submit event.
   */
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate the form data before submitting the form
    if (!validate()) return;

    // Set the loading state to true and show the loading animation
    setLoading(true);

    try {
      // Call the login API and handle the response
      const payload = { ...formData, email: formData?.email?.toLowerCase() };
      await loginUser(payload);

      // Set the user data in local storage
      setCookie(TC_BACKER_USER_DATA, 'true');

      // Redirect the user to the dashboard
      push(APP_ROUTE.DASHBOARD);
      showSuccessMsg(AUTH_MSG.loginSuccess);
    } catch (error) {
      // Handle any errors that occur during the login process
      console.error('Login failed:', error);
    } finally {
      // Set the loading state to false and hide the loading animation
      setLoading(false);
    }
  };

  return (
    <>
      {/* Logo Section */}
      <div>
        <Image src={Logo} alt="TcBacker" width={190} height={100} />
      </div>
      {/* Main Content Section */}
      <div className="w-full flex justify-center items-center h-full">
        <div className="w-full max-w-[500px] space-y-8 xs:mb-20">
          {/* Title and Subtitle */}
          <div className="w-full text-left">
            <h1 className="text-2xl font-bold text-black">
              Sign in to your account
            </h1>
            <p className="text-gray-600 mt-3 text-sm">
              Welcome back! Please enter your details
            </p>
          </div>
          {/* Login Form */}
          <form
            className="space-y-8 w-full"
            onSubmit={handleLogin}
            method="POST"
          >
            <div className="space-y-4">
              {/* Email Input Field */}
              <TextInput
                type="email"
                name="email"
                placeholder="Email"
                size="lg"
                className="pl-12"
                error={errors.email}
                value={formData.email}
                onChange={handleInputChange}
                startAdornment={
                  <span className="absolute left-4 top-1/2 transform -translate-y-1/2">
                    <Icon
                      iconName="email"
                      iconProps={{ className: 'h-6 w-6 text-gray-500' }}
                    />
                  </span>
                }
              />
              {/* Password Input Field */}
              <TextInput
                type={showPassword ? 'text' : 'password'}
                name="password"
                placeholder="Password"
                size="lg"
                className="pl-12"
                error={errors.password}
                value={formData.password}
                onChange={handleInputChange}
                startAdornment={
                  <span className="absolute left-4 top-1/2 transform -translate-y-1/2">
                    <Icon
                      iconName="lock"
                      iconProps={{ className: 'h-6 w-6 text-gray-500' }}
                    />
                  </span>
                }
                endAdornment={
                  <span
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 cursor-pointer"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <Icon
                        iconName="eyeOff"
                        iconProps={{ className: 'h-6 w-6 text-gray-500' }}
                      />
                    ) : (
                      <Icon
                        iconName="eye"
                        iconProps={{ className: 'h-6 w-6 text-gray-500' }}
                      />
                    )}
                  </span>
                }
              />
              {/* Forgot Password Link */}
              <div className="flex justify-end">
                <Button
                  variant="link"
                  onClick={() => push(APP_ROUTE.AUTH.FORGOT_PASSWORD)}
                >
                  Forgot Password?
                </Button>
              </div>
            </div>
            {/* Submit Button */}
            <Button
              type="submit"
              variant="primary"
              full
              size="lg"
              loading={loading}
            >
              Sign In
            </Button>
          </form>
        </div>
      </div>
    </>
  );
};

export default LoginPage;
