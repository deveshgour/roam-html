'use client';
import React, { Suspense, useEffect, useState } from 'react';
import { TextInput } from '@/components/coreUI/textInput';
import { Button } from '@/components/coreUI/button';
import Icon from '@/components/coreUI/icon';
import { ErrorMessage, Formik } from 'formik';
import * as Yup from 'yup';
import { showSuccessMsg } from '@/utils/notifications';
import { RESET_PASSWORD_MSG, VALIDATION_MESSAGES } from '@/constants/messages';
import { resetUserPassword } from '@/services/auth';
import { useSearchParams, useRouter } from 'next/navigation';
import { APP_ROUTE } from '@/constants/routes';

interface ResetPasswordFormValues {
  password: string;
  confirmPassword: string;
}

const validationSchema = Yup.object().shape({
  password: Yup.string()
    .min(8, VALIDATION_MESSAGES.PASSWORD.MIN_LENGTH)
    .required(VALIDATION_MESSAGES.PASSWORD.REQUIRED),
  confirmPassword: Yup.string()
    .oneOf(
      [Yup.ref('password'), ''],
      VALIDATION_MESSAGES.CONFIRM_PASSWORD.MATCH
    )
    .required(VALIDATION_MESSAGES.CONFIRM_PASSWORD.REQUIRED),
});

const ResetPasswordForm = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isInvalidToken, setIsInvalidToken] = useState(true);
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get('token');

  const initialValues: ResetPasswordFormValues = {
    password: '',
    confirmPassword: '',
  };

  useEffect(() => {
    setIsInvalidToken(!token);
  }, [token]);

  const handleSubmit = async (
    values: ResetPasswordFormValues,
    // eslint-disable-next-line no-unused-vars
    setSubmitting: (isSubmitting: boolean) => void
  ) => {
    const queryParams = `token=${token}`;
    const params = { new_password: values?.confirmPassword };
    try {
      setSubmitting(true);
      const response = await resetUserPassword(queryParams, params);
      if (response.status == 200) {
        showSuccessMsg(RESET_PASSWORD_MSG.passwordResetSuccess);
        router.push(APP_ROUTE.AUTH.LOGIN);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="bg-[#F8FAFC] h-[100vh]">
      {!isInvalidToken ? (
        <>
          <div className="p-4">
            <Icon
              iconName="logo"
              iconProps={{ width: '180px', height: '90px' }}
            />
          </div>
          <div className="w-full flex justify-center items-center h-full">
            <div className="w-full max-w-[500px] space-y-8 xs:mb-20 bg-[#fff] py-[37px] px-[40px]">
              {/* Title and Subtitle */}
              <div className="w-full text-center">
                <h1 className="text-2xl font-bold text-black">
                  Reset your password
                </h1>
              </div>
              {/* Reset Password Form */}
              <Formik
                initialValues={initialValues}
                validationSchema={validationSchema}
                validateOnMount={true}
                onSubmit={(values, { setSubmitting }) => {
                  handleSubmit(values, setSubmitting);
                }}
              >
                {({
                  values,
                  isSubmitting,
                  handleBlur,
                  handleChange,
                  handleSubmit,
                }) => (
                  <form className="space-y-8 w-full" onSubmit={handleSubmit}>
                    <div className="space-y-8">
                      <TextInput
                        className="!bg-gray-50"
                        name="password"
                        label="New Password"
                        size="sm"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Enter Password"
                        value={values.password}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        endAdornment={
                          <span
                            className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 cursor-pointer"
                            onClick={() => setShowPassword(!showPassword)}
                          >
                            {showPassword ? (
                              <Icon
                                iconName="eyeOff"
                                iconProps={{
                                  className: 'h-4 w-4 text-gray-500',
                                }}
                              />
                            ) : (
                              <Icon
                                iconName="eye"
                                iconProps={{
                                  className: 'h-4 w-4 text-gray-500',
                                }}
                              />
                            )}
                          </span>
                        }
                      />
                      <ErrorMessage
                        name="password"
                        component="div"
                        className="text-[12px] text-red-500 !mt-[8px]"
                      />
                      <TextInput
                        className="!bg-gray-50"
                        name="confirmPassword"
                        label="Confirm New Password"
                        size="sm"
                        type={showConfirmPassword ? 'text' : 'password'}
                        placeholder="Confirm Password"
                        value={values.confirmPassword}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        endAdornment={
                          <span
                            className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 cursor-pointer"
                            onClick={() =>
                              setShowConfirmPassword(!showConfirmPassword)
                            }
                          >
                            {showConfirmPassword ? (
                              <Icon
                                iconName="eyeOff"
                                iconProps={{
                                  className: 'h-4 w-4 text-gray-500',
                                }}
                              />
                            ) : (
                              <Icon
                                iconName="eye"
                                iconProps={{
                                  className: 'h-4 w-4 text-gray-500',
                                }}
                              />
                            )}
                          </span>
                        }
                      />
                      <ErrorMessage
                        name="confirmPassword"
                        component="div"
                        className="text-[12px] text-red-500 !mt-[8px]"
                      />
                      <Button
                        type="submit"
                        variant="primary"
                        full
                        size="lg"
                        disabled={isSubmitting}
                      >
                        Reset
                      </Button>
                      <Button
                        type="button"
                        variant="link"
                        full
                        size="lg"
                        disabled={isSubmitting}
                        onClick={() => router.push('/auth/login')}
                      >
                        Back to Sign In
                      </Button>
                    </div>
                  </form>
                )}
              </Formik>
            </div>
          </div>
        </>
      ) : (
        <>
          <div className="p-4 fixed">
            <Icon
              iconName="logo"
              iconProps={{ width: '180px', height: '90px' }}
            />
          </div>
          <div className="w-full flex justify-center items-center h-full">
            <div className="w-full max-w-[500px] space-y-8 xs:mb-20 bg-[#fff] py-[37px] px-[40px]">
              <div className="text-center text-primary-800 font-bold">
                Invalid or expired link
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

const ResetPassword: React.FC = () => {
  return (
    <Suspense fallback={<div className="bg-[#F8FAFC] h-[100vh]"></div>}>
      <ResetPasswordForm />
    </Suspense>
  );
};

export default ResetPassword;
