'use client';
import { useState } from 'react';
import {
  OperationProvider,
  useOperationContext,
} from '@/contexts/operationsContext';
import InfoCard from '@/components/infoCard';
import { Location, SalesRep } from '@/app/operations/types';
import { Button } from '@/components/coreUI/button';
import DateRangePickerWithSidebar from '@/components/coreUI/dateRangePicker';
import Icon from '@/components/coreUI/icon';

import LineChart, {
  defaultPercentageLabelFormatter,
  multipleOfEightLabelFormatter,
} from '@/components/highCharts/LineChart';
import ExploreDataTable from './ExploreDataTable';
import MultiSelect from '@/components/coreUI/multiSelect';
import { DataTableWithCard } from '@/components/dataTableWithCard';
import JobsModal from './JobsModal';
import { PAGE_SIZE } from '@/constants/configs';

// Add type definitions
interface RepeatCustomer {
  customerName: string;
  numberOfJobs: number;
}

interface TimelineData {
  jobs: string;
  customerName: string;
  leadDate: string;
  firstAppointment: { date: string; days: number };
  conversion: { date: string; days: number };
  completion: { date: string; days: number };
}

interface ExploreTableData {
  jobName: string;
  customer: string;
  representativeName: string;
  leadDate: string;
  firstAppointment: { date: string; days: number };
  conversion: { date: string; days: number };
  completion: { date: string; days: number };
}

// Add mock data for explore table
const mockExploreData: ExploreTableData[] = [
  {
    jobName: 'Machine Mall',
    customer: 'Chris Patelski',
    representativeName: 'John Doe',
    leadDate: '2024-01-15',
    firstAppointment: {
      date: '2024-01-18',
      days: 3,
    },
    conversion: {
      date: '2024-01-25',
      days: 10,
    },
    completion: {
      date: '2024-02-15',
      days: 31,
    },
  },
  {
    jobName: 'Park View Homes',
    customer: 'David Alexander',
    representativeName: 'Jane Smith',
    leadDate: '2024-01-18',
    firstAppointment: {
      date: '2024-01-22',
      days: 4,
    },
    conversion: {
      date: '2024-02-01',
      days: 14,
    },
    completion: {
      date: '2024-02-28',
      days: 41,
    },
  },
  {
    jobName: 'Highland Residence',
    customer: 'Stephen Wilson',
    representativeName: 'Mike Johnson',
    leadDate: '2024-01-20',
    firstAppointment: {
      date: '2024-01-21',
      days: 1,
    },
    conversion: {
      date: '2024-01-28',
      days: 8,
    },
    completion: {
      date: '2024-02-18',
      days: 29,
    },
  },
  {
    jobName: 'Sunset Apartments',
    customer: 'Valerie Bloom',
    representativeName: 'Sarah Williams',
    leadDate: '2024-01-22',
    firstAppointment: {
      date: '2024-01-24',
      days: 2,
    },
    conversion: {
      date: '2024-02-05',
      days: 14,
    },
    completion: {
      date: '2024-02-29',
      days: 38,
    },
  },
  {
    jobName: 'Cedar Grove Complex',
    customer: 'Dawn Staub',
    representativeName: 'David Brown',
    leadDate: '2024-01-25',
    firstAppointment: {
      date: '2024-01-27',
      days: 2,
    },
    conversion: {
      date: '2024-02-08',
      days: 14,
    },
    completion: {
      date: '2024-03-01',
      days: 36,
    },
  },
];

const Operations = () => {
  return (
    <OperationProvider>
      <OperationContent />
    </OperationProvider>
  );
};

const OperationContent = () => {
  const [selectedExploreData, setSelectedExploreData] = useState(false);
  const [locationOpen, setLocationOpen] = useState(false);
  const [menuIsOpen, setMenuIsOpen] = useState(false);
  const [isJobsModalOpen, setIsJobsModalOpen] = useState(false);

  const { infoCards, loading, filters, updateFilters, filterOptions } =
    useOperationContext();

  const toggleExploreData = () => {
    setSelectedExploreData((prev) => !prev);
  };

  return (
    <>
      <div className="flex items-center gap-2 flex-wrap mb-4">
        {/* Date Range Filter */}
        <div className="w-64 block">
          <DateRangePickerWithSidebar
            value={filters.dateRange}
            onPrimaryBtnClick={(date) =>
              updateFilters({ ...filters, dateRange: date })
            }
            onClearBtnClick={() =>
              updateFilters({ ...filters, dateRange: [null, null] })
            }
          />
        </div>

        {/* Location Filter */}
        <div className="relative max-w-80 min-w-56">
          <MultiSelect
            backgroundColor="rgb(var(--color-gray-50))"
            menuIsOpen={locationOpen}
            setMenuIsOpen={setLocationOpen}
            options={(filterOptions?.locations || [])
              .map((location: Location) => ({
                value: location?.id?.toString(),
                label: location?.name,
              }))
              .sort((a, b) => a.label.localeCompare(b.label))}
            value={
              Array.isArray(filters?.location)
                ? filters?.location?.map((id) => ({
                    value: id,
                    label:
                      filterOptions?.locations?.find(
                        (loc) => loc?.id?.toString() === id
                      )?.name || '',
                  }))
                : []
            }
            isDisabled={false}
            size="md"
            onChange={(selected) => {
              updateFilters({
                ...filters,
                location: Array.isArray(selected)
                  ? selected?.map((item) => item?.value?.toString())
                  : [],
              });
            }}
            placeholder="All Locations"
            icon="mapPin"
            showCheckbox={true}
          />
        </div>

        <div className="relative max-w-80 min-w-56">
          <MultiSelect
            backgroundColor="rgb(var(--color-gray-50))"
            menuIsOpen={menuIsOpen}
            setMenuIsOpen={setMenuIsOpen}
            options={(filterOptions?.salesReps || [])
              .map((rep: SalesRep) => ({
                value: rep?.id?.toString(),
                label: rep?.name,
              }))
              .sort((a, b) => a.label.localeCompare(b.label))}
            value={
              Array.isArray(filters?.salesRep)
                ? filters?.salesRep?.map((id) => ({
                    value: id,
                    label:
                      filterOptions?.salesReps?.find(
                        (rep) => rep?.id?.toString() === id
                      )?.name || '',
                  }))
                : []
            }
            isDisabled={false}
            size="md"
            onChange={(selected) => {
              updateFilters({
                ...filters,
                salesRep: Array.isArray(selected)
                  ? selected?.map((item) => item?.value?.toString())
                  : [],
              });
            }}
            placeholder="All Sales Rep"
            icon="user"
            showCheckbox={true}
          />
        </div>

        {/* Right side buttons */}
        <div className="lg:ml-auto gap-2 flex items-center">
          <Button
            variant={selectedExploreData ? 'primary' : 'outlineLight'}
            className="h-10"
            onClick={toggleExploreData}
            icon={
              <Icon
                iconName={selectedExploreData ? 'lineChart' : 'table'}
                iconProps={{ className: '' }}
              />
            }
          >
            {selectedExploreData ? 'Trend Visualization' : 'Explore Data'}
          </Button>
          <Button
            variant="outlineLight"
            className="!py-2.5"
            onClick={() => {}}
            icon={
              <Icon
                iconName="export"
                iconProps={{ className: '!w-5 !h-5 text-gray-600' }}
              />
            }
          >
            Export
          </Button>
        </div>
      </div>
      {selectedExploreData ? (
        <div>
          <ExploreDataTable
            exploreTableData={mockExploreData}
            explorePagination={{
              page: 1,
              pageSize: 10,
              total: mockExploreData.length,
            }}
            handleExplorePageChange={() => {}}
            handleExplorePageSizeChange={() => {}}
            isLoading={false}
            sorting={{
              field: '',
              direction: null,
            }}
            handleExploreSortingChange={() => {}}
            showPageSize={false}
          />
        </div>
      ) : (
        <>
          {/* ... start info cards ... */}
          <div className="grid gap-5 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-4">
            {loading?.infoCards
              ? Array.from({ length: 8 }).map((_, index) => (
                  <InfoCard key={index} isLoading={true} />
                ))
              : infoCards?.map((card, index) => (
                  <InfoCard key={index} {...card} />
                ))}
          </div>
          {/* ... end info cards ... */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-5">
            <LineChart
              {...{
                title: 'Total Jobs Vs. Completed Jobs',
                type: 'line',
                categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                series: [
                  {
                    name: 'Month',
                    type: 'column',
                    color: '#FF8B4C',
                    data: [75, 85, 90, 82, 88, 92],
                    yAxis: 0, // Use left y-axis (percentage)
                    enableMouseTracking: false,
                  },
                  {
                    name: 'Total Jobs',
                    type: 'line',
                    color: '#8B5CF6',
                    data: [20, 24, 26, 22, 28, 32],
                    yAxis: 1, // Use right y-axis (numbers)
                  },
                  {
                    name: 'Completed Jobs',
                    type: 'line',
                    color: '#10B981',
                    data: [15, 20, 24, 18, 24, 28],
                    yAxis: 1, // Use right y-axis (numbers)
                  },
                ],
                yAxis: [],
              }}
              labelsFormatter={defaultPercentageLabelFormatter}
              secondaryLabelsFormatter={multipleOfEightLabelFormatter}
              useDualYAxis={true}
              height={350}
              isLoading={false}
              itemMarginBottom={50}
            />

            {/* Repeat Customers Table */}
            <DataTableWithCard<RepeatCustomer>
              data={[
                { customerName: 'Chris Patelski', numberOfJobs: 4 },
                { customerName: 'David Alexander', numberOfJobs: 3 },
                { customerName: 'Stephen', numberOfJobs: 2 },
                { customerName: 'Valerie Bloom', numberOfJobs: 2 },
              ]}
              columns={[
                {
                  header: 'Customer Name',
                  accessorKey: 'customerName',
                  sortable: true,
                  cell: (row: RepeatCustomer) => (
                    <div className="px-4 py-2 text-left">
                      {row.customerName}
                    </div>
                  ),
                },
                {
                  header: 'Number of Jobs',
                  accessorKey: 'numberOfJobs',
                  sortable: true,
                  cell: (row: RepeatCustomer) => (
                    <div className="px-4 py-2 text-left">
                      {row.numberOfJobs}
                    </div>
                  ),
                },
              ]}
              actions={[
                {
                  label: 'View',
                  onClick: () => setIsJobsModalOpen(true),
                },
              ]}
              page={1}
              pageSize={10}
              pageSizeOptions={PAGE_SIZE}
              totalItems={10}
              onPageChange={() => {}}
              onPageSizeChange={() => {}}
              showTitle="Repeat Customers"
              cardClassName="h-[440px]"
              scrollAreaClassName="h-[290px]"
              headerActions={
                <>
                  {[
                    { customerName: 'Chris Patelski', numberOfJobs: 4 },
                    { customerName: 'David Alexander', numberOfJobs: 3 },
                    { customerName: 'Stephen', numberOfJobs: 2 },
                    { customerName: 'Valerie Bloom', numberOfJobs: 2 },
                  ]?.length > 0 ? (
                    <Button variant="light" size="sm" onClick={() => {}}>
                      Export
                    </Button>
                  ) : null}
                </>
              }
            />
          </div>

          {/* Time from Lead to Job Completion Table */}
          <div className="mt-5">
            <DataTableWithCard<TimelineData>
              data={[
                {
                  jobs: 'Machine Mall',
                  customerName: 'Chris Patelski',
                  leadDate: 'Jan 15, 2024',
                  firstAppointment: { date: 'Jan 15, 2024', days: 0 },
                  conversion: { date: 'Jan 25, 2024', days: 10 },
                  completion: { date: 'Feb 15, 2024', days: 31 },
                },
                {
                  jobs: 'Park View Homes',
                  customerName: 'David Alexander',
                  leadDate: 'Jan 15, 2024',
                  firstAppointment: { date: 'Jan 22, 2024', days: 7 },
                  conversion: { date: 'Feb 1, 2024', days: 17 },
                  completion: { date: 'Feb 28, 2024', days: 44 },
                },
                {
                  jobs: 'Highland Residence',
                  customerName: 'Stephen',
                  leadDate: 'Jan 20, 2024',
                  firstAppointment: { date: 'Jan 21, 2024', days: 1 },
                  conversion: { date: 'Jan 28, 2024', days: 8 },
                  completion: { date: 'Feb 18, 2024', days: 29 },
                },
                {
                  jobs: 'Sunset Apartments',
                  customerName: 'Valerie Bloom',
                  leadDate: 'Jan 22, 2024',
                  firstAppointment: { date: 'Jan 24, 2024', days: 2 },
                  conversion: { date: 'Feb 5, 2024', days: 14 },
                  completion: { date: 'Feb 29, 2024', days: 38 },
                },
              ]}
              columns={[
                {
                  header: 'Jobs',
                  accessorKey: 'jobs',
                  sortable: true,
                  cell: (row: TimelineData) => (
                    <div className="py-2 text-left">{row.jobs}</div>
                  ),
                },
                {
                  header: 'Customer Name',
                  accessorKey: 'customerName',
                  sortable: true,
                  cell: (row: TimelineData) => (
                    <div className="py-2 text-left">{row.customerName}</div>
                  ),
                },
                {
                  header: 'Lead Date',
                  accessorKey: 'leadDate',
                  sortable: true,
                  cell: (row: TimelineData) => (
                    <div className="py-2 text-left">{row.leadDate}</div>
                  ),
                },
                {
                  header: 'First Appointment Date',
                  accessorKey: 'firstAppointment',
                  sortable: true,
                  cell: (row: TimelineData) => (
                    <div className="py-2 text-left">
                      <div>{row.firstAppointment.date}</div>
                      <div className="text-[11px] text-gray-400">
                        ({row.firstAppointment.days}{' '}
                        {row.firstAppointment.days === 1 ? 'day' : 'days'})
                      </div>
                    </div>
                  ),
                },
                {
                  header: 'Conversion Date',
                  accessorKey: 'conversion',
                  sortable: true,
                  cell: (row: TimelineData) => (
                    <div className="py-2 text-left">
                      <div>{row.conversion.date}</div>
                      <div className="text-[11px] text-gray-400">
                        ({row.conversion.days} days)
                      </div>
                    </div>
                  ),
                },
                {
                  header: 'Completion Date',
                  accessorKey: 'completion',
                  sortable: true,
                  cell: (row: TimelineData) => (
                    <div className="py-2 text-left">
                      <div>{row.completion.date}</div>
                      <div className="text-[11px] text-gray-400">
                        ({row.completion.days} days)
                      </div>
                    </div>
                  ),
                },
              ]}
              page={1}
              pageSize={10}
              pageSizeOptions={PAGE_SIZE}
              totalItems={10}
              onPageChange={() => {}}
              onPageSizeChange={() => {}}
              showTitle="Time from Lead to Job Completion"
              cardClassName="h-[440px]"
              scrollAreaClassName="h-[290px]"
              headerActions={
                <>
                  {[
                    {
                      jobs: 'Machine Mall',
                      customerName: 'Chris Patelski',
                      leadDate: 'Jan 15, 2024',
                      firstAppointment: { date: 'Jan 15, 2024', days: 0 },
                      conversion: { date: 'Jan 25, 2024', days: 10 },
                      completion: { date: 'Feb 15, 2024', days: 31 },
                    },
                    {
                      jobs: 'Park View Homes',
                      customerName: 'David Alexander',
                      leadDate: 'Jan 15, 2024',
                      firstAppointment: { date: 'Jan 22, 2024', days: 7 },
                      conversion: { date: 'Feb 1, 2024', days: 17 },
                      completion: { date: 'Feb 28, 2024', days: 44 },
                    },
                    {
                      jobs: 'Highland Residence',
                      customerName: 'Stephen',
                      leadDate: 'Jan 20, 2024',
                      firstAppointment: { date: 'Jan 21, 2024', days: 1 },
                      conversion: { date: 'Jan 28, 2024', days: 8 },
                      completion: { date: 'Feb 18, 2024', days: 29 },
                    },
                    {
                      jobs: 'Sunset Apartments',
                      customerName: 'Valerie Bloom',
                      leadDate: 'Jan 22, 2024',
                      firstAppointment: { date: 'Jan 24, 2024', days: 2 },
                      conversion: { date: 'Feb 5, 2024', days: 14 },
                      completion: { date: 'Feb 29, 2024', days: 38 },
                    },
                  ]?.length > 0 ? (
                    <Button variant="light" size="sm" onClick={() => {}}>
                      Export
                    </Button>
                  ) : null}
                </>
              }
            />
          </div>
        </>
      )}

      <JobsModal
        isOpen={isJobsModalOpen}
        onClose={() => setIsJobsModalOpen(false)}
      />
    </>
  );
};

export default Operations;
