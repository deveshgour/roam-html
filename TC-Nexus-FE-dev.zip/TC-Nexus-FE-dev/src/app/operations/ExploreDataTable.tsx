import { DataTableWithFixedColumn } from '@/components/dataTableWithFixedColumn';

interface ExploreTableData {
  jobName: string;
  customer: string;
  representativeName: string;
  leadDate: string;
  firstAppointment: {
    date: string;
    days: number;
  };
  conversion: {
    date: string;
    days: number;
  };
  completion: {
    date: string;
    days: number;
  };
}

interface PaginationState {
  page: number;
  pageSize: number;
  total: number;
}

interface SortingState {
  field: string;
  direction: 'asc' | 'desc' | null;
}

interface ExploreDataTableProps {
  exploreTableData: ExploreTableData[] | null;
  explorePagination: PaginationState;
  handleExplorePageChange: (newPage: number) => void; // eslint-disable-line no-unused-vars
  handleExplorePageSizeChange: (newPageSize: number) => void; // eslint-disable-line no-unused-vars
  isLoading: boolean;
  sorting: SortingState;
  handleExploreSortingChange: (
    field: string, // eslint-disable-line no-unused-vars
    direction: 'asc' | 'desc' | null // eslint-disable-line no-unused-vars
  ) => void;
  showPageSize?: boolean;
}

export default function ExploreDataTable({
  exploreTableData,
  explorePagination,
  handleExplorePageChange,
  handleExplorePageSizeChange,
  isLoading,
  sorting,
  handleExploreSortingChange,
  showPageSize = true,
}: ExploreDataTableProps) {
  return (
    <DataTableWithFixedColumn
      data={exploreTableData || []}
      columns={[
        {
          header: 'Job Name',
          accessorKey: 'jobName',
          sortable: true,
          cell: (row) => <div className="py-2">{row?.jobName || '-'}</div>,
        },
        {
          header: 'Customer',
          accessorKey: 'customer',
          sortable: true,
          cell: (row) => <div className="py-2">{row?.customer || '-'}</div>,
        },
        {
          header: 'Representative Name',
          accessorKey: 'representativeName',
          sortable: true,
          cell: (row) => (
            <div className="py-2">{row?.representativeName || '-'}</div>
          ),
        },
        {
          header: 'Lead Date',
          accessorKey: 'leadDate',
          sortable: true,
          cell: (row) => <div className="py-2">{row?.leadDate || '-'}</div>,
        },
        {
          header: 'First Appointment',
          accessorKey: 'firstAppointment',
          sortable: true,
          cell: (row) => (
            <div className="py-2">
              <div>{row?.firstAppointment?.date || '-'}</div>
              {row?.firstAppointment?.days !== undefined && (
                <div className="text-[11px] text-gray-400">
                  ({row.firstAppointment.days}{' '}
                  {row.firstAppointment.days === 1 ? 'day' : 'days'})
                </div>
              )}
            </div>
          ),
        },
        {
          header: 'Conversion',
          accessorKey: 'conversion',
          sortable: true,
          cell: (row) => (
            <div className="py-2">
              <div>{row?.conversion?.date || '-'}</div>
              {row?.conversion?.days !== undefined && (
                <div className="text-[11px] text-gray-400">
                  ({row.conversion.days}{' '}
                  {row.conversion.days === 1 ? 'day' : 'days'})
                </div>
              )}
            </div>
          ),
        },
        {
          header: 'Completion',
          accessorKey: 'completion',
          sortable: true,
          cell: (row) => (
            <div className="py-2">
              <div>{row?.completion?.date || '-'}</div>
              {row?.completion?.days !== undefined && (
                <div className="text-[11px] text-gray-400">
                  ({row.completion.days}{' '}
                  {row.completion.days === 1 ? 'day' : 'days'})
                </div>
              )}
            </div>
          ),
        },
      ]}
      showSearch={false}
      showPageSize={showPageSize}
      page={explorePagination.page}
      pageSize={explorePagination.pageSize}
      totalItems={explorePagination.total}
      onPageChange={handleExplorePageChange}
      onPageSizeChange={handleExplorePageSizeChange}
      loading={isLoading}
      sorting={sorting}
      onSortingChange={handleExploreSortingChange}
      getRowId={(row) => row.jobName}
      showTableFilter={null}
    />
  );
}
