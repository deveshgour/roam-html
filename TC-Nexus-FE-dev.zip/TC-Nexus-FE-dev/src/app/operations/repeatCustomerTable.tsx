import React from 'react';
import { Button } from '@/components/coreUI/button';
import { DataTableWithCard } from '@/components/dataTableWithCard';
import { PAGE_SIZE } from '@/constants/configs';

/**
 * Props interface for SourceDetailTable component
 */

/**
 * Component for displaying a table of sales representatives.
 */
function SourceDetailTable() {
  const columns = [
    {
      header: 'Source',
      accessorKey: 'source',
      sortable: true,
    },
    {
      header: 'Leads',
      accessorKey: 'leads_generated',
      sortable: true,
    },
    {
      header: 'Appointments',
      accessorKey: 'appointments',
      sortable: true,
    },
    {
      header: 'Sold',
      accessorKey: 'sold',
      sortable: true,
    },
    {
      header: 'Conversion Rate',
      accessorKey: 'conversion_rate',
      sortable: true,
    },
  ];

  // Actions for each row
  const actions = [
    {
      label: 'View',
      onClick: () => {},
    },
  ];

  return (
    <>
      <DataTableWithCard
        data={[]}
        skeletonClassName="h-[300px]"
        columns={columns}
        page={1}
        pageSize={10}
        totalItems={0}
        onPageChange={() => {}}
        onPageSizeChange={() => {}}
        actions={actions}
        showFooter={true}
        showTitle={
          <div className="flex items-center gap-2 w-full justify-between">
            <span>Lead Source Details</span>
          </div>
        }
        pageSizeOptions={PAGE_SIZE}
        scrollAreaClassName="h-[300px]"
        showPagination={true}
        showPageSize={true}
        headerActions={
          <>
            <Button variant="light" size="sm" onClick={() => {}}>
              Reset Filter
            </Button>
            <Button
              variant="light"
              size="sm"
              className="px-4"
              onClick={() => {}}
            >
              Export
            </Button>
          </>
        }
      />
    </>
  );
}

export default SourceDetailTable;
