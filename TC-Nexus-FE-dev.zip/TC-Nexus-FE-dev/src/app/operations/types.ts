/**
 * Data for info cards
 */
export interface InfoCardProps {
  title: string;
  value: number | string;
  icon: string;
  iconBgColor: string;
  iconColor: string;
  borderColor: string;
  helping_text?: string;
}
export interface HighNumbersResponse {
  job_completion_rate: number;
  conversion_to_job_completion: string;
  lead_to_appointment: string;
  lead_to_conversion: string;
  repeat_customers: string;
}
/**
 * Shape of the loading states
 */
export interface LoadingData {
  infoCards: boolean;
}
/**
 * Shape of the error states
 */
export interface ErrorStates {
  infoCards: Error | null;
}
/**
 * Shape of the filter state
 */
export interface FilterState {
  dateRange: [Date | null, Date | null] | null;
  location: string[];
  salesRep: string[];
}
export interface FilterOptions {
  locations: Location[];
  salesReps: SalesRep[];
}
export interface Location {
  id: number;
  name: string;
}
export interface SalesRep {
  id: number;
  name: string;
}
