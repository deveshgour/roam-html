import { DataTableWithCard } from '@/components/dataTableWithCard';
import Icon from '@/components/coreUI/icon';
import { PAGE_SIZE } from '@/constants/configs';

interface JobData {
  jobId: string;
  name: string;
  zipCode: string;
  startDate: string;
  numberOfJobs: string;
}

interface JobsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const mockData: JobData[] = [
  {
    jobId: '101',
    name: '1600 John F Kennedy Blvd',
    zipCode: '17019',
    startDate: 'Jan 15, 2024',
    numberOfJobs: '4 jobs',
  },
  {
    jobId: '102',
    name: '600 Grant St',
    zipCode: '17302',
    startDate: 'Jan 18, 2024',
    numberOfJobs: '3 jobs',
  },
  {
    jobId: '103',
    name: '500 N 3rd St',
    zipCode: '17309',
    startDate: 'Jan 20, 2024',
    numberOfJobs: '2 jobs',
  },
  {
    jobId: '104',
    name: '835 Hamilton St',
    zipCode: '17311',
    startDate: 'Jan 22, 2024',
    numberOfJobs: '2 jobs',
  },
];

const JobsModal = ({ isOpen, onClose }: JobsModalProps) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-[90%] max-w-5xl max-h-[50vh] overflow-hidden">
        <div className="p-4 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-xl font-semibold">Jobs</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <Icon iconName="cross" iconProps={{ className: 'w-5 h-5' }} />
          </button>
        </div>

        <div className="">
          <DataTableWithCard<JobData>
            data={mockData}
            columns={[
              {
                header: 'Job ID',
                accessorKey: 'jobId',
                sortable: true,
                cell: (row) => (
                  <div className="py-2 text-left">{row.jobId}</div>
                ),
              },
              {
                header: 'Name',
                accessorKey: 'name',
                sortable: true,
                cell: (row) => <div className="py-2 text-left">{row.name}</div>,
              },
              {
                header: 'Zip Code',
                accessorKey: 'zipCode',
                sortable: true,
                cell: (row) => (
                  <div className="py-2 text-left">{row.zipCode}</div>
                ),
              },
              {
                header: 'Start Date',
                accessorKey: 'startDate',
                sortable: true,
                cell: (row) => (
                  <div className="py-2 text-left">{row.startDate}</div>
                ),
              },
            ]}
            page={1}
            pageSize={10}
            pageSizeOptions={PAGE_SIZE}
            totalItems={4}
            onPageChange={() => {}}
            onPageSizeChange={() => {}}
          />
        </div>
      </div>
    </div>
  );
};

export default JobsModal;
