'use client';
import React from 'react';
import Image from 'next/image';
import { TextInput } from '@/components/coreUI/textInput';
import { Checkbox } from '@/components/coreUI/checkbox';
import { Button } from '@/components/coreUI/button';
import { Switch } from '@/components/coreUI/switch';
import DateRangePickerWithSidebar from '@/components/coreUI/dateRangePicker';
import Modal from '@/components/coreUI/dialog';
import UserTable from './UserTable';
import MultiSelect, { Option } from '@/components/coreUI/multiSelect';
import { RadioGroup, RadioGroupItem } from '@/components/coreUI/radioButton';
//import SalesRepTable from '@/app/financial/sales/SalesRepTable';
import ServicePieChart from '@/components/highCharts/ServicePieChart';
import RevenueBarChart from '@/components/highCharts/BarChart';
import LocationLineChart from '@/components/highCharts/LineChart';
import Icon from '@/components/coreUI/icon';
import SidePanel from '@/components/coreUI/drawer';
import InfoCard from '@/components/infoCard';

const labelClasses = 'block text-sm font-bold text-gray-700 mb-2';

export default function ComponentsPage() {
  const [selectedDate, setSelectedDate] = React.useState<
    [Date | null, Date | null] | null
  >(null);
  const [checkboxStates, setCheckboxStates] = React.useState({
    checkbox1: false,
    checkbox2: false,
    checkbox3: false,
    checkbox4: true,
  });
  const locationOptions = [
    { value: 'ny', label: 'New York' },
    { value: 'sf', label: 'San Francisco' },
    { value: 'la', label: 'Los Angeles' },
  ];

  const handleCheckboxChange = (id: string, checked: boolean) => {
    setCheckboxStates((prevState) => ({
      ...prevState,
      [id]: checked,
    }));
  };
  const [isChecked, setIsChecked] = React.useState(false);
  const [isOpen, setIsOpen] = React.useState(false);
  const [isSideOpen, setIsSideOpen] = React.useState(false);

  const [selectedLocations, setSelectedLocations] = React.useState<Option[]>(
    []
  );

  const handleSwitchChange = (checked: boolean) => {
    setIsChecked(checked);
  };
  const [selectedValue, setSelectedValue] = React.useState('');

  const handleRadioChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedValue(event.target.value);
  };

  const revenueChartProps = {
    title: 'Total Revenue',
    categories: ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN'],
    series: [
      {
        name: 'Revenue',
        data: [750, 450, 700, 850, 1100, 700],
        color: '#FBD5D5',
        type: 'column' as const,
        borderRadius: 8,
        pointWidth: 36,
      },
    ],
  };

  const locationChartProps = {
    title: 'Total Revenue By Location',
    categories: ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN'],
    series: [
      {
        name: 'York, PA',
        type: 'line' as const,
        data: [100000, 200000, 100000, 900000, 700000, 750000],
        color: '#4E79A7',
      },
      {
        name: 'Millsboro, DE',
        type: 'line' as const,
        data: [120000, 400000, 250000, 600000, 400000, 600000],
        color: '#59A14F',
      },
      {
        name: 'Greenville, SC',
        type: 'line' as const,
        data: [150000, 300000, 400000, 300000, 700000, 650000],
        color: '#F28E2C',
      },
      {
        name: 'Bluffton, SC',
        type: 'line' as const,
        data: [400000, 600000, 300000, 200000, 500000, 400000],
        color: '#AF7AA1',
      },
    ],
    yAxisMax: 1200000,
    yAxisTickInterval: 200000,
  };

  const serviceChartProps = {
    title: 'Total Revenue By Service Type',
    data: [
      { name: 'Roofing', y: 20 },
      { name: 'Siding', y: 15 },
      { name: 'Solar', y: 12 },
      { name: 'Windows', y: 10 },
      { name: 'RS', y: 8 },
      { name: 'RG', y: 7 },
      { name: 'RW', y: 7 },
      { name: 'RS2', y: 7 },
      { name: 'SW', y: 7 },
      { name: 'RSGW', y: 7 },
    ],
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-6">
        <h1 className="text-4xl font-bold text-gray-900 text-center mb-8">
          Components Page
        </h1>

        {/* Input field section */}
        <h3 className="mb-4">Input Field Examples</h3>
        <div className="mb-4">
          <p className={labelClasses}>Input with Error</p>
          <TextInput
            size="sm"
            label="This is a label"
            error="This is an error"
          />
        </div>
        <div className="mb-4">
          <p className={labelClasses}>Simple Input</p>
          <TextInput size="md" placeholder="This is a placeholder" />
        </div>
        <div className="mb-7">
          <p className={labelClasses}>Input with Start Adornment Icon</p>
          <TextInput
            size="lg"
            className="pl-12"
            startAdornment={
              <div className="absolute left-4 top-1/2 transform -translate-y-1/2">
                <Image src="/file.svg" alt="File icon" width={24} height={24} />
              </div>
            }
          />
        </div>
        <hr />

        {/* Multi Select section */}
        <h3 className="mb-4 mt-4">Multi Select Examples</h3>
        <div className="space-y-4 mb-7">
          <MultiSelect
            options={locationOptions}
            value={selectedLocations}
            onChange={(selected: Option | Option[]) =>
              setSelectedLocations(selected as Option[])
            }
            placeholder="Select Location"
            icon={'mapPin'}
            showCheckbox={true}
          />
        </div>
        <hr />

        {/* Modal section */}
        <h3 className="mb-4 mt-4">Modal Examples</h3>
        <div className="space-y-4 mb-7">
          <Button onClick={() => setIsOpen(true)} variant="primary">
            Open Modal
          </Button>
        </div>
        <Modal
          maxWidth="2xl"
          header={
            <>
              <h1>Modal Title</h1>
              <div className="h-px bg-border -mx-6" />
            </>
          }
          open={isOpen}
          onClose={() => setIsOpen(false)}
          footer={
            <div className="flex justify-end gap-2">
              <Button
                size="lg"
                onClick={() => setIsOpen(false)}
                variant="outlinePrimary"
              >
                Submit
              </Button>
              <Button
                size="lg"
                onClick={() => setIsOpen(false)}
                variant="primary"
              >
                Close
              </Button>
            </div>
          }
        >
          <div className="flex flex-col gap-4">
            <form className="space-y-4">
              <div>
                <p className="text-sm font-medium mb-2">Name</p>
                <TextInput placeholder="Enter your name" />
              </div>
              <div>
                <p className="text-sm font-medium mb-2">Email</p>
                <TextInput placeholder="Enter your email" type="email" />
              </div>
              <div>
                <p className="text-sm font-medium mb-2">Message</p>
                <TextInput placeholder="Enter your message" />
              </div>
              <div>
                <Checkbox label="I agree to the terms and conditions" />
              </div>
            </form>
          </div>
        </Modal>

        {/* Table section */}
        <h3 className="mb-4 mt-4">Table Examples</h3>
        <div className="space-y-4 mb-7">
          <UserTable />
        </div>

        <div>{/* <SalesRepTable /> */}</div>

        {/* Checkbox section */}
        <h3 className="mb-4 mt-4">Checkbox Examples</h3>
        <div className="space-y-4 mb-7">
          <Checkbox
            size="sm"
            id="checkbox1"
            name="checkbox"
            label="Small"
            checked={checkboxStates.checkbox1}
            onchange={(checked: boolean) =>
              handleCheckboxChange('checkbox1', checked)
            }
          />
          <Checkbox
            id="checkbox2"
            name="checkbox"
            label="Default"
            checked={checkboxStates.checkbox2}
            onchange={(checked: boolean) =>
              handleCheckboxChange('checkbox2', checked)
            }
          />
          <Checkbox disabled label="Disabled" />
          <Checkbox
            size="md"
            id="checkbox3"
            name="checkbox"
            label="Medium"
            checked={checkboxStates.checkbox3}
            onchange={(checked: boolean) =>
              handleCheckboxChange('checkbox3', checked)
            }
          />
          <Checkbox
            size="lg"
            id="checkbox4"
            name="checkbox"
            label="Large"
            checked={checkboxStates.checkbox4}
            onchange={(checked: boolean) =>
              handleCheckboxChange('checkbox4', checked)
            }
          />
        </div>
        <hr />
        {/* Button section */}
        <h3 className="mb-4">Button Examples</h3>
        <div className="flex gap-4 justify-center items-center">
          <Button variant="primary">Primary Button</Button>
          <Button variant="light" size="sm">
            Light Button
          </Button>
          <Button variant="outlinePrimary" size="lg">
            Primary Outline
          </Button>
          <Button variant="outlinePrimary" size="md" loading>
            Primary Outline
          </Button>
          <Button variant="outlineLight">Light Outline</Button>
          <Button variant="link" size="lg">
            Link
          </Button>
          <Button variant="primary" type="submit" size="sm" disabled>
            Link
          </Button>
          <Button
            variant="primary"
            icon={<Icon iconName="plus" iconProps={{ className: `h-4 w-4` }} />}
          >
            Add Icon Button
          </Button>
        </div>
        <div>
          <Button variant="primary" full>
            Primary Full width
          </Button>
        </div>
        {/* Toggle button section */}
        <h3 className="mb-4 mt-4">Toggle Button Examples</h3>
        <div className="mb-4">
          <Switch
            checked={isChecked}
            onChange={handleSwitchChange}
            label="Switch Button"
          />
        </div>
        <div className="mb-7">
          <Switch disabled label="Disabled Switch Button" />
        </div>
        <hr />

        {/* Radio Button Section */}
        <h3 className="mb-4 mt-4">Radio Button Examples</h3>

        <RadioGroup>
          <RadioGroupItem
            id="option1"
            label="Option 1"
            value="option1"
            name="myRadio"
            customSize="sm"
            checked={selectedValue === 'option1'}
            onChange={handleRadioChange}
          />
          <RadioGroupItem
            id="option2"
            label="Option 2"
            value="option2"
            name="myRadio"
            customSize="sm"
            checked={selectedValue === 'option2'}
            onChange={handleRadioChange}
          />
          <RadioGroupItem
            id="option3"
            label="Option 3"
            value="option3"
            name="myRadio"
            customSize="sm"
            checked={selectedValue === 'option3'}
            onChange={handleRadioChange}
          />
        </RadioGroup>

        {/* Toggle button section */}
        <h3 className="mb-4 mt-4">Date range picker</h3>
        <div className="flex gap-4 items-center">
          <div className="w-96">
            <DateRangePickerWithSidebar
              value={selectedDate}
              onPrimaryBtnClick={(date) => setSelectedDate(date)}
            />
          </div>
          <div className="w-96">
            <DateRangePickerWithSidebar
              disabled
              value={selectedDate}
              onPrimaryBtnClick={(date) => setSelectedDate(date)}
            />
          </div>
        </div>

        {/* Drawer Examples */}

        <h3 className="mb-4 mt-4">Modal Examples</h3>
        <div className="space-y-4 mb-7">
          <Button onClick={() => setIsSideOpen(true)} variant="primary">
            Open Side Panel
          </Button>
        </div>
        <SidePanel
          header
          title="Side Panel"
          open={isSideOpen}
          onClose={() => setIsSideOpen(false)}
        >
          <div className="flex flex-col gap-4">
            <form className="space-y-4">
              <div>
                <p className="text-sm font-medium mb-2">Name</p>
                <TextInput placeholder="Enter your name" />
              </div>
              <div>
                <p className="text-sm font-medium mb-2">Email</p>
                <TextInput placeholder="Enter your email" type="email" />
              </div>
              <div>
                <p className="text-sm font-medium mb-2">Message</p>
                <TextInput placeholder="Enter your message" />
              </div>
              <div>
                <Checkbox label="I agree to the terms and conditions" />
              </div>
            </form>
          </div>
        </SidePanel>

        {/* Stats card section */}
        <h3 className="mb-4 mt-4">Info Cards Examples</h3>
        <div className="grid gap-5 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
          <InfoCard
            title="Total Revenue"
            value="$980k"
            percentage={
              <>
                <span>12%</span>
              </>
            }
            isPositive={true}
            icon="dollarSign"
            iconBgColor="bg-indigo-50"
            iconColor="text-indigo-600"
            borderColor="border-indigo-200"
          />
          <InfoCard
            title="New Business Revenue"
            value="$590K"
            percentage="35%"
            isPositive={true}
            icon="user"
            iconBgColor="bg-blue-50"
            iconColor="text-blue-600"
            borderColor="border-blue-200"
          />
          <InfoCard
            title="Sales"
            value="2,345"
            percentage="5%"
            isPositive={false}
            icon="shoppingCart"
            iconBgColor="bg-amber-50"
            iconColor="text-amber-600"
            borderColor="border-amber-200"
          />
          <InfoCard
            title="Conversion Rate"
            value="3.2%"
            isPositive={true}
            icon="history"
            iconBgColor="bg-pink-50"
            iconColor="text-pink-600"
            borderColor="border-pink-200"
          />
        </div>

        {/* HighCharts chart */}
        <h3 className="mb-4 mt-4">HighCharts Examples</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          <RevenueBarChart {...revenueChartProps} />
          <LocationLineChart {...locationChartProps} />
          <ServicePieChart {...serviceChartProps} />
        </div>
      </div>
    </div>
  );
}
