/* eslint-disable no-console */
import { DataTable } from '@/components/coreUI/table/dataTable';
import { useState } from 'react';
import { Button } from '@/components/coreUI/button';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/coreUI/select';
import Icon from '@/components/coreUI/icon';

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  status: 'active' | 'inactive';
}

function UserTable() {
  // State management
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [sorting, setSorting] = useState<{
    field: string;
    direction: 'asc' | 'desc' | null;
  }>({
    field: 'name',
    direction: null,
  });

  // Example data
  const users: User[] = [
    {
      id: '1',
      name: 'John Doe',
      email: 'john@example.com',
      role: 'Admin',
      status: 'active',
    },
    {
      id: '2',
      name: 'Jane Smith',
      email: 'jane@example.com',
      role: 'User',
      status: 'active',
    },
    // ... more users
  ];

  // Column definitions
  const columns = [
    { header: 'Name', accessorKey: 'name', sortable: true },
    { header: 'Email', accessorKey: 'email', sortable: true },
    { header: 'Role', accessorKey: 'role' },
    {
      header: 'Status',
      accessorKey: 'status',
      cell: (row: User) => (
        <span
          className={`px-4 py-1 rounded-md text-xs capitalize font-medium ${
            row.status === 'active'
              ? 'bg-green-100 text-green-800'
              : 'bg-red-100 text-red-800'
          }`}
        >
          {row.status}
        </span>
      ),
    },
  ];

  // Action handlers
  const handleSearch = (query: string) => {
    console.log('Searching for:', query);
    // Implement search logic
  };

  const handleRowSelect = (id: string, selected: boolean) => {
    console.log('Selected:', id, selected);
    setSelectedUsers((prev) =>
      selected ? [...prev, id] : prev.filter((userId) => userId !== id)
    );
  };

  const handleSelectAll = (selected: boolean, ids: string[]) => {
    console.log('Selecting all:', selected, ids);
    setSelectedUsers(selected ? ids : []); // Simply set to ids when selecting, empty array when deselecting
  };

  const actions = [
    {
      label: 'Edit',
      onClick: (row: User) => {
        console.log('Edit user:', row);
      },
    },
    {
      label: 'Delete',
      onClick: (row: User) => {
        console.log('Delete user:', row);
      },
    },
  ];

  return (
    <DataTable
      data={users}
      columns={columns}
      page={page}
      pageSize={pageSize}
      totalItems={100} // Total number of items in your database
      onPageChange={setPage}
      onPageSizeChange={setPageSize}
      onSearch={handleSearch}
      onRowClick={(row) => console.log('Clicked row:', row)}
      selectedRows={selectedUsers}
      onRowSelect={handleRowSelect}
      onSelectAll={handleSelectAll}
      actions={actions}
      getRowId={(row) => row.id}
      // Optional customizations
      pageSizeOptions={[5, 10, 20, 50]} // Custom page size options
      sorting={sorting}
      onSortingChange={(field, direction) => {
        console.log('Sorting:', field, direction);
        setSorting({ field, direction });
        // Fetch sorted data or handle sorting logic
      }}
      showSearch={true}
      showPagination={true}
      showPageSize={true}
      showFilters
      filters={
        <div className="grid grid-cols-1">
          <div className="space-y-1">
            <label htmlFor="status" className="text-sm text-gray-800">
              Select Status
            </label>
            <Select onValueChange={(value) => console.log(value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {/* Add more filter controls */}
        </div>
      }
      headerActions={
        <Button
          variant="primary"
          icon={<Icon iconName="plus" iconProps={{ className: `h-4 w-4` }} />}
        >
          Add User
        </Button>
      }
    />
  );
}

export default UserTable;
