import { DataTable } from '@/components/coreUI/table/dataTable';
import { useEffect, useState } from 'react';
import { PAGE_SIZE } from '@/constants/configs';
import { TransformedExploreData } from '@/hooks/useSalesRevenue';

/**
 * Interface representing a ExploreData.
 */
interface ExploreData {
  id: string;
  customer: string;
  representative_name: string;
  job_name: string;
  contract_signed_date: string;
  total_amount: string;
  job_type: string;
  trades: string;
  location: string;
  last_sync_date: string;
}

type SortingDirection = 'asc' | 'desc' | null;

interface SortingState {
  field: string;
  direction: SortingDirection;
}

interface ExploreTableProps {
  exploreTableData: TransformedExploreData[] | null;
  explorePagination: {
    page: number;
    pageSize: number;
    total: number;
  };
  isLoading: boolean;
  // eslint-disable-next-line no-unused-vars
  handleExplorePageChange: (page: number) => void;
  // eslint-disable-next-line no-unused-vars
  handleExplorePageSizeChange: (pageSize: number) => void;
  sorting: SortingState;
  handleExploreSortingChange: (
    // eslint-disable-next-line no-unused-vars
    field: string,
    // eslint-disable-next-line no-unused-vars
    direction: SortingDirection
  ) => void;
}

/**
 * A component for displaying a table of sales representatives.
 *
 * The component receives the following props:
 *
 * - `exploreTableData`: An array of `TransformedExploreData` objects to be displayed in the table.
 * - `explorePagination`: An object with the following properties:
 *   - `page`: The current page number.
 *   - `pageSize`: The number of items per page.
 *   - `total`: The total number of items.
 * - `isLoading`: A boolean indicating whether the data is being loaded or not.
 * - `handleExplorePageChange`: A function to be called when the page number changes.
 * - `handleExplorePageSizeChange`: A function to be called when the page size changes.
 * - `sorting`: An object with the sorting information.
 * - `handleExploreSortingChange`: A function to be called when the sorting changes.
 */
function ExploreDataTable({
  exploreTableData,
  explorePagination,
  isLoading,
  handleExplorePageChange,
  handleExplorePageSizeChange,
  sorting,
  handleExploreSortingChange,
}: ExploreTableProps) {
  // A state variable to hold the data to be displayed in the table.
  const [users, setUsers] = useState<ExploreData[]>([]);

  // An effect that runs when the `exploreTableData` changes.
  useEffect(() => {
    if (exploreTableData) {
      // Map the `TransformedExploreData` objects to the `ExploreData` objects.
      // The `ExploreData` objects will be used in the table.
      const users = exploreTableData.map((user: TransformedExploreData) => ({
        id: user.id,
        job_id: user.job_id,
        customer: user.customer,
        representative_name: user.representative_name,
        job_name: user.job_name,
        contract_signed_date: user.contract_signed_date,
        total_amount: `${user.total_amount}`,
        job_type: user.job_type,
        trades: user.trades,
        location: user.location,
        last_sync_date: user.last_sync_date,
      }));
      // Set the state variable to the new data.
      setUsers(users);
    }
  }, [exploreTableData]);

  // The columns of the table.
  const columns = [
    {
      // The header of the column.
      header: 'Customer',
      // The accessor key of the column.
      accessorKey: 'customer',
      // Whether the column is sortable.
      sortable: true,
    },

    {
      header: 'Representative Name',
      accessorKey: 'representative_name',
      sortable: true,
    },

    {
      header: 'Job ID',
      accessorKey: 'job_id',
      sortable: true,
    },

    {
      header: 'Job Name',
      accessorKey: 'job_name',
      sortable: true,
    },

    {
      header: 'Contract Signed Date',
      accessorKey: 'contract_signed_date',
      sortable: true,
    },

    {
      header: 'Total Amount',
      accessorKey: 'total_amount',
      sortable: true,
    },

    {
      header: 'Job Type',
      accessorKey: 'job_type',
      sortable: true,
    },

    {
      header: 'Trades',
      accessorKey: 'trades',
      sortable: true,
    },

    {
      header: 'Location',
      accessorKey: 'location',
      sortable: true,
    },

    {
      header: 'Last Sync Date',
      accessorKey: 'last_sync_date',
      sortable: true,
    },
  ];

  // The JSX of the table.
  return (
    <>
      <DataTable
        // Whether the data is being loaded.
        loading={isLoading}
        // Whether to show the skeleton.
        showSkeleton={true}
        // The data to be displayed in the table.
        data={users}
        // The columns of the table.
        columns={columns}
        // The current page number.
        page={explorePagination.page}
        // The number of items per page.
        pageSize={explorePagination.pageSize}
        // The total number of items.
        totalItems={explorePagination.total}
        // A function to be called when the page number changes.
        onPageChange={(newPage: number) => handleExplorePageChange(newPage)}
        // A function to be called when the page size changes.
        onPageSizeChange={(newPageSize: number) =>
          handleExplorePageSizeChange(newPageSize)
        }
        // The accessor key of the row.
        getRowId={(row) => row.id}
        // The page size options.
        pageSizeOptions={PAGE_SIZE}
        // The sorting information.
        sorting={sorting}
        // A function to be called when the sorting changes.
        onSortingChange={handleExploreSortingChange}
        // Whether to show the search.
        showSearch={false}
        // Whether to show the pagination.
        showPagination={true}
        // The class name of the scroll area.
        scrollAreaClassName="h-[600px]"
        // Whether to show the page size.
        showPageSize={true}
      />
    </>
  );
}

export default ExploreDataTable;
