import React, { useEffect, useState } from 'react';
import { Button } from '@/components/coreUI/button';
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from '@/components/coreUI/avatar';
import { DataTableWithCard } from '@/components/dataTableWithCard';
import Icon from '@/components/coreUI/icon';
import { PAGE_SIZE } from '@/constants/configs';
import { TransformedSalesRep } from '@/hooks/useSalesRevenue';
import { SortingState } from '@/types/common';
import ViewSalesRepModal from './components/viewSalesRepModal';

/**
 * Interface representing a SalesRep.
 */
interface SalesRep {
  id: string;
  sales_rep: React.ReactNode;
  total_revenue: string;
  deals_closed: string;
  deal_size: string;
  growth: React.ReactNode;
  user: SalesRepUser;
}

/**
 * Props interface for SalesRepTable component
 */
interface SalesRepTableProps {
  salesRepTableData: {
    representatives: TransformedSalesRep[];
    total: {
      total_revenue: number;
      deals_closed: number;
      average_revenue: number;
      growth_rate: number;
    };
  } | null;
  pagination: {
    page: number;
    pageSize: number;
    total: number;
  };
  isLoading: boolean;
  // eslint-disable-next-line no-unused-vars
  handlePageChange: (page: number) => void;
  // eslint-disable-next-line no-unused-vars
  handlePageSizeChange: (pageSize: number) => void;
  fetchPerformanceReport: () => void;
  sorting: SortingState;
  handleSortingChange: (
    // eslint-disable-next-line no-unused-vars
    field: string,
    // eslint-disable-next-line no-unused-vars
    direction: 'asc' | 'desc' | null
  ) => void;
  filters: {
    dateRange: [Date | null, Date | null] | null;
    location: string;
    revenueType: Array<string | null> | string | string[];
    salesRep: string | string[];
  };
}

interface SalesRepUser {
  id: string;
  sales_rep: string;
  total_revenue: string;
  deals_closed: string;
  deal_size: string;
}

/**
 * Component for displaying a table of sales representatives.
 */
function SalesRepTable({
  salesRepTableData,
  pagination,
  isLoading,
  handlePageChange,
  handlePageSizeChange,
  fetchPerformanceReport,
  sorting,
  handleSortingChange,
  filters,
}: SalesRepTableProps) {
  const [users, setUsers] = useState<SalesRep[]>([]);
  const [isDisplaySalesRepModal, setIsDisplaySalesRepModal] = useState(false);
  const [selectedSalesRep, setSelectedSalesRep] = useState<SalesRepUser | null>(
    null
  );

  useEffect(() => {
    if (salesRepTableData) {
      let users = salesRepTableData.representatives.map(
        (user: TransformedSalesRep) => ({
          id: user.id,
          sales_rep: (
            <div className="flex items-center gap-x-2">
              <Avatar>
                <AvatarImage src={user.sales_rep.avatar} />
                <AvatarFallback>{user.sales_rep.initials}</AvatarFallback>
              </Avatar>
              {user.sales_rep.name}
            </div>
          ),
          total_revenue: user.total_revenue,
          deals_closed: user.deals_closed,
          deal_size: user.deal_size,
          growth: (
            <p
              className={`${user.growth.isPositive ? 'text-green-700' : 'text-red-700'} mb-0 flex items-center gap-1`}
            >
              <Icon
                iconName={
                  user.growth.isPositive ? 'trendingUp' : 'trendingDown'
                }
                iconProps={{ className: `h-4 w-4` }}
              />
              {user.growth.value}
            </p>
          ),
          user: {
            id: user.representative_id,
            sales_rep: user.sales_rep.name,
            total_revenue: user.total_revenue,
            deals_closed: user.deals_closed,
            deal_size: user.deal_size,
          },
        })
      );
      setUsers(users);
    }
  }, [salesRepTableData]);

  const columns = [
    {
      header: 'Sales Rep',
      accessorKey: 'sales_rep',
      sortable: true,
      footer: () => <>Total</>,
    },

    {
      header: 'Total Revenue',
      accessorKey: 'total_revenue',
      sortable: true,
      footer: () => {
        return `$${salesRepTableData?.total?.total_revenue?.toLocaleString('en-US') || 0}`;
      },
    },

    {
      header: 'Deals Closed',
      accessorKey: 'deals_closed',
      sortable: true,
      footer: () => {
        return salesRepTableData?.total?.deals_closed?.toString() || 0;
      },
    },

    {
      header: 'Avg Deal Size',
      accessorKey: 'deal_size',
      sortable: true,
      footer: () => {
        return salesRepTableData?.total?.average_revenue?.toString() || 0;
      },
    },

    {
      header: 'Growth',
      accessorKey: 'growth',
      sortable: true,
      footer: () => {
        const avgGrowth = salesRepTableData?.total?.growth_rate || 0;

        return (
          <p
            className={`${avgGrowth >= 0 ? 'text-green-700' : 'text-red-700'} mb-0 flex items-center gap-1`}
          >
            {avgGrowth >= 0 ? (
              <Icon
                iconName="trendingUp"
                iconProps={{ className: `h-4 w-4` }}
              />
            ) : (
              <Icon
                iconName="trendingDown"
                iconProps={{ className: `h-4 w-4` }}
              />
            )}
            {Math.abs(avgGrowth).toFixed(2)}%
          </p>
        );
      },
    },
  ];

  // Actions for each row
  const actions = [
    {
      label: 'View',
      onClick: (row: SalesRep) => {
        setSelectedSalesRep(row.user);
        setIsDisplaySalesRepModal(true);
      },
    },
  ];

  const closeModal = () => {
    setIsDisplaySalesRepModal(!isDisplaySalesRepModal);
  };

  return (
    <>
      <DataTableWithCard
        data={users}
        columns={columns}
        page={pagination.page}
        pageSize={pagination.pageSize}
        totalItems={pagination.total} // Total number of items in your database
        onPageChange={(newPage: number) => handlePageChange(newPage)}
        onPageSizeChange={(newPageSize: number) =>
          handlePageSizeChange(newPageSize)
        }
        actions={actions}
        showFooter={true}
        showTitle="Sales Representative Revenue Performance"
        pageSizeOptions={PAGE_SIZE}
        isLoading={isLoading}
        showPagination={true}
        scrollAreaClassName="h-[360px]"
        showPageSize={true}
        sorting={sorting}
        onSortingChange={handleSortingChange}
        headerActions={
          users?.length > 0 ? (
            <Button
              onClick={() => fetchPerformanceReport()}
              variant="light"
              className="px-6"
              size="sm"
            >
              Export
            </Button>
          ) : null
        }
      />
      {selectedSalesRep && (
        <ViewSalesRepModal
          selectedSalesRep={selectedSalesRep}
          open={isDisplaySalesRepModal}
          onClose={closeModal}
          filters={filters}
        />
      )}
    </>
  );
}

export default SalesRepTable;
