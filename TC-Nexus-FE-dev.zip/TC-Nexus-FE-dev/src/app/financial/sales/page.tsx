'use client';
import React, { useEffect, useState } from 'react';
import DateRangePickerWithSidebar from '@/components/coreUI/dateRangePicker';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/coreUI/select';
import { Button } from '@/components/coreUI/button';
import InfoCard from '@/components/infoCard';
import { LeastPerformingList } from '@/components/leastPerformingList';
//import SalesRepTable from './SalesRepTable';
import ServicePieChart from '@/components/highCharts/ServicePieChart';
import Icon from '@/components/coreUI/icon';
import {
  SalesRep,
  useSalesRevenue,
  Location,
  TimePeriod,
} from '@/hooks/useSalesRevenue';
import SalesRepTable from './SalesRepTable';
import LineChart from '@/components/highCharts/LineChart';
import ExploreDataTable from '@/app/financial/sales/ExploreDataTable';
import MultiSelect from '@/components/coreUI/multiSelect';
import BarChart from '@/components/highCharts/BarChart';

const SalesRevenue = () => {
  const {
    filterOptions,
    filters,
    updateFilters,
    infoCardsData,
    loadingStates,
    setRevenueChartTimePeriod,
    revenueChartData,
    revenueChartTimePeriod,
    locationChartData,
    locationChartTimePeriod,
    setLocationChartTimePeriod,
    serviceChartData,
    leastPerformingData,
    fetchDownloadReport,
    fetchExportDownloadReport,
    salesRepTableData,
    exploreTableData,
    pagination,
    explorePagination,
    handlePageChange,
    handleExplorePageChange,
    handlePageSizeChange,
    fetchPerformanceReport,
    sorting,
    handleSortingChange,
    handleExploreSortingChange,
    handleExplorePageSizeChange,
    isAllDataEmpty,
    fetchExploreData,
    isFilterLoading,
  } = useSalesRevenue();
  const [selectKey, setSelectKey] = React.useState(0);
  const [selectedExploreData, setSelectedExploreData] = useState(false);
  const [menuIsOpen, setMenuIsOpen] = useState(false);
  const [menuIsOpen2, setMenuIsOpen2] = useState(false);

  const toggleExploreData = () => {
    setSelectedExploreData((prev) => !prev);
  };

  useEffect(
    () => {
      if (selectedExploreData) {
        fetchExploreData(
          explorePagination.page,
          Number(sorting.field),
          sorting.field,
          sorting.direction
        );
      } else {
        handleExploreSortingChange('', null);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [selectedExploreData, explorePagination.page]
  );

  return (
    <>
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="flex gap-2">
          <div className="w-64 block">
            <DateRangePickerWithSidebar
              value={filters?.dateRange}
              onPrimaryBtnClick={(date) =>
                updateFilters({ ...filters, dateRange: date })
              }
              onClearBtnClick={() =>
                updateFilters({ ...filters, dateRange: [null, null] })
              }
            />
          </div>
          <div>
            <div className="relative">
              <Select
                key={selectKey}
                value={filters?.location?.toString()}
                onValueChange={(value) =>
                  updateFilters({ ...filters, location: value })
                }
                onOpenChange={() => {
                  setMenuIsOpen(false);
                  setMenuIsOpen2(false);
                }}
              >
                {filters?.location && (
                  <span
                    className="z-10 pointer-events-auto py-3 px-1.5 absolute right-7 cursor-pointer hover:opacity-70"
                    onClick={(e) => {
                      e.stopPropagation();
                      updateFilters({ ...filters, location: '' });
                      setSelectKey((prev) => prev + 1);
                    }}
                  >
                    <Icon
                      iconName="cross"
                      iconProps={{ className: '!w-4 !h-4 text-red-600' }}
                    />
                  </span>
                )}
                <SelectTrigger
                  innerSelectedValue="max-w-[160px]"
                  icon={
                    <Icon
                      iconName="mapPin"
                      iconProps={{ className: 'text-gray-600' }}
                    />
                  }
                  className="min-w-48 max-w-60"
                >
                  <SelectValue placeholder="All Locations" />
                </SelectTrigger>
                <SelectContent>
                  {filterOptions?.locations
                    .sort((a, b) => a?.name?.localeCompare(b?.name))
                    .map((location: Location) => (
                      <SelectItem
                        key={location?.id}
                        value={location?.id?.toString()}
                      >
                        {location?.name}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="max-w-80 min-w-56 relative">
            <MultiSelect
              menuIsOpen={menuIsOpen}
              setMenuIsOpen={setMenuIsOpen}
              backgroundColor="rgb(var(--color-gray-50))"
              options={filterOptions?.revenueType
                ?.map((rep) => ({
                  value: rep?.id?.toString(),
                  label: rep?.name,
                }))
                .sort((a, b) => a.label.localeCompare(b.label))}
              value={
                Array.isArray(filters?.revenueType)
                  ? filters?.revenueType
                      ?.filter((id) => id !== null)
                      ?.map((id) => ({
                        value: id as string,
                        label:
                          filterOptions?.revenueType?.find(
                            (rep) => rep?.id?.toString() === id
                          )?.name || '',
                      }))
                  : []
              }
              isDisabled={false}
              size="md"
              onChange={(selected) => {
                updateFilters({
                  ...filters,
                  revenueType: Array.isArray(selected)
                    ? selected.map((item) => item?.value?.toString())
                    : [],
                });
              }}
              placeholder="All Revenue Type"
              icon="dollarSign"
              showCheckbox={true}
            />
          </div>
          <div className="relative max-w-80 min-w-56">
            <MultiSelect
              menuIsOpen={menuIsOpen2}
              setMenuIsOpen={setMenuIsOpen2}
              backgroundColor="rgb(var(--color-gray-50))"
              options={filterOptions?.salesReps
                ?.map((rep: SalesRep) => ({
                  value: rep?.id?.toString(),
                  label: rep?.name,
                }))
                .sort((a, b) => a.label.localeCompare(b.label))}
              value={
                Array.isArray(filters?.salesRep)
                  ? filters?.salesRep?.map((id) => ({
                      value: id,
                      label:
                        filterOptions?.salesReps?.find(
                          (rep) => rep?.id?.toString() === id
                        )?.name || '',
                    }))
                  : []
              }
              isDisabled={false}
              size="md"
              onChange={(selected) => {
                updateFilters({
                  ...filters,
                  salesRep: Array.isArray(selected)
                    ? selected?.map((item) => item?.value?.toString())
                    : [],
                });
              }}
              placeholder="All Sales Rep"
              icon="user"
              showCheckbox={true}
            />
          </div>
        </div>
        <div className="gap-2 flex">
          {/* Toggle between Trend Visualization and Explore Data */}
          <Button
            variant={selectedExploreData ? 'primary' : 'outlineLight'}
            className="h-10"
            onClick={toggleExploreData}
            icon={
              <Icon
                iconName={selectedExploreData ? 'lineChart' : 'table'}
                iconProps={{ className: '' }}
              />
            }
          >
            {/* Text to be displayed on the button. Trend Visualization if selectedExploreData is true, else Explore Data */}
            {selectedExploreData ? 'Trend Visualization' : 'Explore Data'}
          </Button>
          {/* Export button */}
          <Button
            variant="outlineLight"
            className="!py-2.5 h-10"
            onClick={
              selectedExploreData
                ? fetchExportDownloadReport
                : fetchDownloadReport
            }
            icon={
              <Icon
                iconName="export"
                iconProps={{ className: '!w-5 !h-5 text-gray-600' }}
              />
            }
            disabled={isAllDataEmpty || isFilterLoading}
          >
            Export
          </Button>
        </div>
      </div>
      {isFilterLoading && <></>}
      {selectedExploreData ? (
        <div>
          {/* Explore Data Table */}
          <ExploreDataTable
            exploreTableData={exploreTableData}
            explorePagination={explorePagination}
            handleExplorePageChange={handleExplorePageChange}
            handleExplorePageSizeChange={handleExplorePageSizeChange}
            isLoading={loadingStates.exploreTable || isFilterLoading}
            sorting={sorting}
            handleExploreSortingChange={handleExploreSortingChange}
          />
        </div>
      ) : (
        <>
          {/* Info Cards */}
          <div className="grid gap-5 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
            {loadingStates?.infoCards || isFilterLoading
              ? Array.from({ length: 4 }).map((_, index) => (
                  <InfoCard key={index} isLoading={true} />
                ))
              : infoCardsData?.map((card, index) => (
                  <InfoCard key={index} {...card} />
                ))}
          </div>
          {/* Charts */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {/* Revenue Chart */}
            <BarChart
              isLoading={loadingStates.revenueChart}
              defaultTimeFrame={revenueChartTimePeriod}
              onTimeFrameChange={(value) =>
                setRevenueChartTimePeriod(value as TimePeriod)
              }
              {...(revenueChartData || {
                title: '',
                categories: [],
                series: [],
              })}
            />
            {/* Location Chart */}
            <LineChart
              {...(locationChartData || {
                title: '',
                categories: [],
                series: [],
              })}
              defaultTimeFrame={locationChartTimePeriod}
              onTimeFrameChange={(value) =>
                setLocationChartTimePeriod(value as TimePeriod)
              }
              isLoading={loadingStates.locationChart || isFilterLoading}
            />
            {/* Service Chart */}
            <ServicePieChart
              legendClassName="h-2 w-2"
              {...(serviceChartData || {
                title: '',
                data: [],
              })}
              isLoading={loadingStates.serviceChart || isFilterLoading}
            />
          </div>
          {/* Sales Rep Table and Least Performing List */}
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
            {/* Sales Rep Table */}
            <div className="col-span-1 sm:col-span-2">
              <SalesRepTable
                salesRepTableData={salesRepTableData}
                pagination={pagination}
                handlePageChange={handlePageChange}
                handlePageSizeChange={handlePageSizeChange}
                fetchPerformanceReport={fetchPerformanceReport}
                isLoading={loadingStates.salesRepTable || isFilterLoading}
                sorting={sorting}
                handleSortingChange={handleSortingChange}
                filters={filters}
              />
            </div>
            {/* Least Performing List */}
            <div className="col-span-1 sm:col-span-1">
              <LeastPerformingList
                salesReps={leastPerformingData}
                isLoading={loadingStates.leastPerforming || isFilterLoading}
              />
            </div>
          </div>
        </>
      )}
    </>
  );
};

export default SalesRevenue;
