import Modal from '@/components/coreUI/dialog';
import { DataTableWithCard } from '@/components/dataTableWithCard';

import React, { useEffect } from 'react';

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/coreUI/select';
import { useSalesRepView } from '@/hooks/useSalesRepPerformView';
import { PAGE_SIZE } from '@/constants/configs';
interface ViewSalesRepModalProps {
  open: boolean;
  selectedSalesRep: salesRepType;
  onClose: () => void;
  filters: {
    dateRange: [Date | null, Date | null] | null;
    location: string;
    revenueType: Array<string | null> | string | string[];
    salesRep: string | string[];
  };
}

interface salesRepType {
  id: string;
  sales_rep: string;
  total_revenue: string;
  deals_closed: string;
  deal_size: string;
}

const columns = [
  {
    header: 'Customer',
    accessorKey: 'customer',
  },

  {
    header: 'Job Name',
    accessorKey: 'job_name',
  },

  {
    header: 'Contract Signed Date',
    accessorKey: 'contract_signed_date',
  },

  {
    header: 'Job Price',
    accessorKey: 'job_price',
  },

  {
    header: 'Change Order',
    accessorKey: 'change_orders',
  },
  {
    header: 'Total Amount',
    accessorKey: 'total_amount',
  },
];

const ViewSalesRepModal = ({
  open = false,
  onClose = () => {},
  selectedSalesRep,
  filters,
}: ViewSalesRepModalProps) => {
  const {
    isLoading,
    jobs,
    pagination,
    handleSalesRepView,
    handlePageSizeChange,
    handlePageChange,
  } = useSalesRepView(filters);

  useEffect(() => {
    if (!selectedSalesRep.id || !open) return;
    handleSalesRepView(selectedSalesRep.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedSalesRep.id, open]);

  return (
    <>
      <Modal
        maxWidth={'max-w-[1000px]'}
        hideBorder={true}
        header={
          <div className="flex items-center justify-between w-full mr-[25px]">
            <span className="inline-flex text-gray text-[22px]">
              {selectedSalesRep?.sales_rep}
              <span className="mx-2">-</span>
              <span className="text-[#057A55]">
                {selectedSalesRep?.total_revenue}
              </span>
            </span>
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-500">Show:</span>
              <Select
                value={String(pagination.pageSize)}
                onValueChange={(value) => {
                  handlePageSizeChange?.(Number(value));
                }}
              >
                <SelectTrigger className="w-20 !h-9">
                  <SelectValue placeholder="Rows per page" />
                </SelectTrigger>
                <SelectContent>
                  {PAGE_SIZE.map((size) => (
                    <SelectItem key={size} value={String(size)}>
                      {size}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        }
        open={open}
        onClose={onClose}
      >
        <DataTableWithCard
          skeletonClassName="h-[370px]"
          scrollAreaClassName="h-[290px]"
          showFooter={false}
          headerClassName="!p-0"
          data={jobs}
          columns={columns}
          page={pagination.page}
          pageSize={pagination.pageSize}
          totalItems={pagination.total}
          onPageChange={handlePageChange}
          onPageSizeChange={handlePageSizeChange}
          showPagination={true}
          showPageSize={false}
          isLoading={isLoading}
        />
      </Modal>
    </>
  );
};
export default ViewSalesRepModal;
