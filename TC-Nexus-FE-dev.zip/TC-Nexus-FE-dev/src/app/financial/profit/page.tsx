'use client';
import { Button } from '@/components/coreUI/button';
import DateRangePickerWithSidebar from '@/components/coreUI/dateRangePicker';
import Icon from '@/components/coreUI/icon';
import { FinancialProfitProvider } from '@/contexts/financialProfitContext';
import React, { useState, useEffect } from 'react';
import NewConstruction from '@/app/financial/profit/newConstruction/newConstruction';
import MultiSelect from '@/components/coreUI/multiSelect';
import { useUserProfile } from '@/contexts/userProfileContext';

interface Location {
  id: number;
  name: string;
}

const dummyLocations: Location[] = [
  { id: 1, name: 'New York' },
  { id: 2, name: 'Los Angeles' },
  { id: 3, name: 'Chicago' },
  { id: 4, name: 'Houston' },
  { id: 5, name: 'Phoenix' },
];

const Profit = () => {
  return (
    <FinancialProfitProvider>
      <ProfitContent />
    </FinancialProfitProvider>
  );
};

const ProfitContent = () => {
  const { permission } = useUserProfile();
  const [activeTab, setActiveTab] = useState('');
  const [selectedExploreData, setSelectedExploreData] = useState(false);
  const [menuIsOpen, setMenuIsOpen] = useState(false);
  const [selectedLocations, setSelectedLocations] = useState<string[]>([]);

  // Set initial active tab when permissions load
  useEffect(() => {
    if (permission?.profit_margin_nc === 1) {
      setActiveTab('newConstruction');
    } else if (permission?.profit_margin_retail === 1) {
      setActiveTab('retail');
    }
  }, [permission]);

  const toggleExploreData = () => {
    setSelectedExploreData((prev) => !prev);
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'newConstruction':
        return <NewConstruction />;
      case 'retail':
        return <div>Retail Content</div>;
      default:
        return null;
    }
  };

  return (
    <>
      <div className="flex items-center gap-2 flex-wrap justify-between mb-2">
        <div className="flex gap-x-8">
          {permission?.profit_margin_nc === 1 && (
            <Button
              variant="ghost"
              className={`!py-3.5 !text-base border-b-4 rounded-none ${
                activeTab === 'newConstruction'
                  ? 'border-primary text-primary'
                  : 'border-transparent text-gray-600'
              }`}
              onClick={() => setActiveTab('newConstruction')}
            >
              New Construction
            </Button>
          )}

          {permission?.profit_margin_retail === 1 && (
            <Button
              variant="ghost"
              className={`!py-3.5 !text-base border-b-4 rounded-none ${
                activeTab === 'retail'
                  ? 'border-primary text-primary'
                  : 'border-transparent text-gray-600'
              }`}
              onClick={() => setActiveTab('retail')}
            >
              Retail
            </Button>
          )}
        </div>
        <div className="flex gap-2 items-center">
          <div className="w-72 block">
            <DateRangePickerWithSidebar />
          </div>
          <div className="relative max-w-80 min-w-56">
            <MultiSelect
              backgroundColor="rgb(var(--color-gray-50))"
              menuIsOpen={menuIsOpen}
              setMenuIsOpen={setMenuIsOpen}
              options={dummyLocations
                .map((location) => ({
                  value: location.id.toString(),
                  label: location.name,
                }))
                .sort((a, b) => a.label.localeCompare(b.label))}
              value={selectedLocations.map((id) => ({
                value: id,
                label:
                  dummyLocations.find((loc) => loc.id.toString() === id)
                    ?.name || '',
              }))}
              isDisabled={false}
              size="md"
              onChange={(selected) => {
                setSelectedLocations(
                  Array.isArray(selected)
                    ? selected.map((item) => item.value.toString())
                    : []
                );
              }}
              placeholder="All Locations"
              icon="mapPin"
              showCheckbox={true}
            />
          </div>
          <Button
            variant={selectedExploreData ? 'primary' : 'outlineLight'}
            className="h-10"
            onClick={toggleExploreData}
            icon={
              <Icon
                iconName={selectedExploreData ? 'lineChart' : 'table'}
                iconProps={{ className: '' }}
              />
            }
          >
            {selectedExploreData ? 'Trend Visualization' : 'Explore Data'}
          </Button>
          <Button
            variant="outlineLight"
            className="h-10"
            icon={
              <Icon
                iconName="export"
                iconProps={{ className: '!w-5 !h-5 text-gray-600' }}
              />
            }
          >
            Export
          </Button>
        </div>
      </div>
      <>{renderContent()}</>
    </>
  );
};

export default Profit;
