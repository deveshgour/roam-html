import BarChart from '@/components/highCharts/BarChart';
import InfoCard from '@/components/infoCard';
import { useFinancialProfitContext } from '@/contexts/financialProfitContext';
import AnalysisBuilderTable from '@/app/financial/profit/newConstruction/analysisBuilderTable';
import AnalysisTradeTable from '@/app/financial/profit/newConstruction/analysisTradeTable';

const NewConstruction = () => {
  const { infoCards, loading, barChartData, tooltipFormatter } =
    useFinancialProfitContext();
  return (
    <>
      <div className="grid gap-5 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-4">
        {loading?.infoCards
          ? Array.from({ length: 8 }).map((_, index) => (
              <InfoCard key={index} isLoading={true} />
            ))
          : infoCards?.map((card, index) => <InfoCard key={index} {...card} />)}
      </div>
      <div className="grid grid-cols-1">
        <BarChart
          isLoading={loading.barChart}
          tooltipFormatter={tooltipFormatter}
          showTimeFrameSelect={false}
          {...(barChartData || {
            title: '',
            categories: [],
            series: [],
            type: 'column',
          })}
        />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-5">
        <AnalysisBuilderTable />
        <AnalysisTradeTable />
      </div>
    </>
  );
};
export default NewConstruction;
