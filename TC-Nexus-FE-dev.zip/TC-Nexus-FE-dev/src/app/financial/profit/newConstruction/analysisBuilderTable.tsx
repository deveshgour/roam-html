import { DataTableWithCard } from '@/components/dataTableWithCard';
import { AnalysisBuilderData } from './types';
import { useEffect, useState } from 'react';
import { Button } from '@/components/coreUI/button';
import { PAGE_SIZE, SORTING_TYPES } from '@/constants/configs';
import { SortingTypes } from '@/types/common';

function AnalysisBuilderTable() {
  const [builders, setBuilders] = useState<AnalysisBuilderData[]>([]);
  const [sorting, setSorting] = useState({
    field: 'builder',
    direction: null as SortingTypes,
  });
  const [loading, setLoading] = useState(false);

  // Dummy data generator
  const generateDummyData = (): AnalysisBuilderData[] => {
    return [
      {
        id: '1',
        builder: 'BrookField',
        completedJobs: 12,
        inProgressJobs: 5,
        revenue: '$800,000',
        profit: '$150,000',
        paymentsReceived: '$720,000',
        accountsPayable: '$80,000',
        credits: '$20,000',
        commission: '$40,000',
      },
      {
        id: '2',
        builder: 'Burkentine',
        completedJobs: 8,
        inProgressJobs: 3,
        revenue: '$150,000',
        profit: '$100,000',
        paymentsReceived: '$135,000',
        accountsPayable: '$15,000',
        credits: '$5,000',
        commission: '$7,500',
      },
      {
        id: '3',
        builder: 'Charter Holms',
        completedJobs: 15,
        inProgressJobs: 7,
        revenue: '$400,000',
        profit: '$350,000',
        paymentsReceived: '$380,000',
        accountsPayable: '$20,000',
        credits: '$10,000',
        commission: '$20,000',
      },
      {
        id: '4',
        builder: 'Creative Homes',
        completedJobs: 20,
        inProgressJobs: 8,
        revenue: '$750,000',
        profit: '$180,000',
        paymentsReceived: '$675,000',
        accountsPayable: '$75,000',
        credits: '$25,000',
        commission: '$37,500',
      },
    ];
  };

  useEffect(() => {
    setLoading(true);
    // Simulate API call delay
    setTimeout(() => {
      setBuilders(generateDummyData());
      setLoading(false);
    }, 1000);
  }, []);

  const handleSortingChange = (field: string, direction: SortingTypes) => {
    setSorting({ field, direction });
    // Here you would typically make an API call with the new sorting parameters
    // For now, we'll just sort the dummy data
    const sortedData = [...builders].sort((a, b) => {
      const aValue = a[field as keyof AnalysisBuilderData];
      const bValue = b[field as keyof AnalysisBuilderData];
      if (direction === SORTING_TYPES.ASC) {
        return aValue > bValue ? 1 : -1;
      }
      return aValue < bValue ? 1 : -1;
    });
    setBuilders(sortedData);
  };

  const columns = [
    {
      header: 'Builder',
      accessorKey: 'builder',
      sortable: true,
      footer: () => 'Total',
    },
    {
      header: 'Completed Jobs',
      accessorKey: 'completedJobs',
      sortable: true,
      footer: () => builders.reduce((sum, row) => sum + row.completedJobs, 0),
    },
    {
      header: 'In Progress Jobs',
      accessorKey: 'inProgressJobs',
      sortable: true,
      footer: () => builders.reduce((sum, row) => sum + row.inProgressJobs, 0),
    },
    {
      header: 'Revenue',
      accessorKey: 'revenue',
      sortable: true,
      footer: () =>
        '$' +
        builders
          .reduce(
            (sum, row) =>
              sum + parseFloat(row.revenue.replace('$', '').replace(/,/g, '')),
            0
          )
          .toLocaleString(),
    },
    {
      header: 'Profit',
      accessorKey: 'profit',
      sortable: true,
      footer: () =>
        '$' +
        builders
          .reduce(
            (sum, row) =>
              sum + parseFloat(row.profit.replace('$', '').replace(/,/g, '')),
            0
          )
          .toLocaleString(),
    },
    {
      header: 'Payments Received',
      accessorKey: 'paymentsReceived',
      sortable: true,
      footer: () =>
        '$' +
        builders
          .reduce(
            (sum, row) =>
              sum +
              parseFloat(
                row.paymentsReceived.replace('$', '').replace(/,/g, '')
              ),
            0
          )
          .toLocaleString(),
    },
    {
      header: 'Accounts Payable',
      accessorKey: 'accountsPayable',
      sortable: true,
      footer: () =>
        '$' +
        builders
          .reduce(
            (sum, row) =>
              sum +
              parseFloat(
                row.accountsPayable.replace('$', '').replace(/,/g, '')
              ),
            0
          )
          .toLocaleString(),
    },
    {
      header: 'Credits',
      accessorKey: 'credits',
      sortable: true,
      footer: () =>
        '$' +
        builders
          .reduce(
            (sum, row) =>
              sum + parseFloat(row.credits.replace('$', '').replace(/,/g, '')),
            0
          )
          .toLocaleString(),
    },
    {
      header: 'Commission',
      accessorKey: 'commission',
      sortable: true,
      footer: () =>
        '$' +
        builders
          .reduce(
            (sum, row) =>
              sum +
              parseFloat(row.commission.replace('$', '').replace(/,/g, '')),
            0
          )
          .toLocaleString(),
    },
  ];

  return (
    <DataTableWithCard
      data={builders}
      columns={columns}
      page={1}
      pageSize={10}
      totalItems={builders.length}
      onPageChange={() => {}}
      onPageSizeChange={() => {}}
      showFooter={true}
      showTitle="Profit/Loss Analysis by Builder"
      pageSizeOptions={PAGE_SIZE}
      cardClassName="h-[450px]"
      scrollAreaClassName="h-[310px]"
      skeletonClassName="h-[200px]"
      showPagination={true}
      showPageSize={true}
      isLoading={loading}
      sorting={sorting}
      onSortingChange={handleSortingChange}
      headerActions={
        <>
          <Button variant="light" size="sm" className="px-4">
            Export
          </Button>
        </>
      }
    />
  );
}

export default AnalysisBuilderTable;
