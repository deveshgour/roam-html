import React, { useEffect, useState } from 'react';
import { DataTableWithCard } from '@/components/dataTableWithCard';
import { PAGE_SIZE } from '@/constants/configs';
import Modal from '@/components/coreUI/dialog';
import { TradeDetailData } from './types';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/coreUI/select';

interface ViewTradeModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
}

function ViewTradeModal({
  open = false,
  onClose = () => {},
  title,
}: ViewTradeModalProps) {
  const [loading, setLoading] = useState(false);
  const [tradeDetails, setTradeDetails] = useState<TradeDetailData[]>([]);

  // Dummy data generator
  const generateDummyData = (): TradeDetailData[] => {
    return [
      {
        id: '1',
        customer: 'Chris Pastelak',
        jobName: '1600 John F Kennedy Blvd',
        jobPrice: '$42,850',
        changeOrders: '$3,200',
        totalAmount: '$46,050',
        expenseOverhead: '$27,630',
      },
      {
        id: '2',
        customer: 'David Alexander',
        jobName: '600 Grant St',
        jobPrice: '$58,750',
        changeOrders: '$4,850',
        totalAmount: '$63,600',
        expenseOverhead: '$38,160',
      },
      {
        id: '3',
        customer: 'Stephen',
        jobName: '500 N 3rd St',
        jobPrice: '$35,600',
        changeOrders: '$2,100',
        totalAmount: '$37,700',
        expenseOverhead: '$22,620',
      },
      {
        id: '4',
        customer: 'Valerie Bloom',
        jobName: '835 Hamilton St',
        jobPrice: '$47,250',
        changeOrders: '$3,900',
        totalAmount: '$51,150',
        expenseOverhead: '$30,690',
      },
      {
        id: '5',
        customer: 'Dawn Staub',
        jobName: '1001 State St',
        jobPrice: '$28,900',
        changeOrders: '$1,756',
        totalAmount: '$30,656',
        expenseOverhead: '$18,393',
      },
    ];
  };

  useEffect(() => {
    setLoading(true);
    // Simulate API call delay
    setTimeout(() => {
      setTradeDetails(generateDummyData());
      setLoading(false);
    }, 1000);
  }, []);

  const columns = [
    {
      header: 'Customer',
      accessorKey: 'customer',
      sortable: true,
    },
    {
      header: 'Job Name',
      accessorKey: 'jobName',
      sortable: true,
    },
    {
      header: 'Job Price',
      accessorKey: 'jobPrice',
      sortable: true,
    },
    {
      header: 'Change Orders',
      accessorKey: 'changeOrders',
      sortable: true,
    },
    {
      header: 'Total Amount',
      accessorKey: 'totalAmount',
      sortable: true,
    },
    {
      header: 'Expense + Overhead',
      accessorKey: 'expenseOverhead',
      sortable: true,
    },
  ];

  return (
    <Modal
      maxWidth={'max-w-[1000px]'}
      hideBorder={true}
      header={
        <div className="flex items-center justify-between w-full mr-[25px]">
          <span className="inline-flex text-gray text-[22px]">{title}</span>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-500">Show:</span>
            <Select value={`5`} onValueChange={() => {}}>
              <SelectTrigger className="w-20 !h-9">
                <SelectValue placeholder="Rows per page" />
              </SelectTrigger>
              <SelectContent>
                {PAGE_SIZE.map((size) => (
                  <SelectItem key={size} value={String(size)}>
                    {size}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      }
      open={open}
      onClose={onClose}
    >
      <DataTableWithCard
        skeletonClassName="h-[370px]"
        scrollAreaClassName="h-[300px]"
        showFooter={false}
        data={tradeDetails}
        columns={columns}
        page={1}
        pageSize={5}
        headerClassName="!p-0"
        totalItems={tradeDetails.length}
        onPageChange={() => {}}
        onPageSizeChange={() => {}}
        isLoading={loading}
        pageSizeOptions={PAGE_SIZE}
        showPagination={true}
        showPageSize={false}
      />
    </Modal>
  );
}

export default ViewTradeModal;
