import { DataTableWithCard } from '@/components/dataTableWithCard';
import { AnalysisTradeData } from './types';
import { useEffect, useState } from 'react';
import { Button } from '@/components/coreUI/button';
import { PAGE_SIZE, SORTING_TYPES } from '@/constants/configs';
import { SortingTypes } from '@/types/common';
import ViewTradeModal from './viewTradeModal';

function AnalysisTradeTable() {
  const [trades, setTrades] = useState<AnalysisTradeData[]>([]);
  const [sorting, setSorting] = useState({
    field: 'trade',
    direction: null as SortingTypes,
  });
  const [loading, setLoading] = useState(false);
  const [viewTradeModalOpen, setViewTradeModalOpen] = useState(false);
  const [selectedTrade, setSelectedTrade] = useState('');

  // Dummy data generator
  const generateDummyData = (): AnalysisTradeData[] => {
    return [
      {
        id: '1',
        trade: 'R',
        completedJobs: 85,
        inProgressJobs: 32,
        revenue: '$980,000',
        profit: '$245,000',
      },
      {
        id: '2',
        trade: 'R,S',
        completedJobs: 92,
        inProgressJobs: 28,
        revenue: '$750,000',
        profit: '$187,500',
      },
      {
        id: '3',
        trade: 'R,S,G',
        completedJobs: 78,
        inProgressJobs: 25,
        revenue: '$890,000',
        profit: '$222,500',
      },
      {
        id: '4',
        trade: 'R2,S,G',
        completedJobs: 88,
        inProgressJobs: 30,
        revenue: '$820,000',
        profit: '$205,000',
      },
    ];
  };

  useEffect(() => {
    setLoading(true);
    // Simulate API call delay
    setTimeout(() => {
      setTrades(generateDummyData());
      setLoading(false);
    }, 1000);
  }, []);

  const handleSortingChange = (field: string, direction: SortingTypes) => {
    setSorting({ field, direction });
    // Here you would typically make an API call with the new sorting parameters
    // For now, we'll just sort the dummy data
    const sortedData = [...trades].sort((a, b) => {
      const aValue = a[field as keyof AnalysisTradeData];
      const bValue = b[field as keyof AnalysisTradeData];
      if (direction === SORTING_TYPES.ASC) {
        return aValue > bValue ? 1 : -1;
      }
      return aValue < bValue ? 1 : -1;
    });
    setTrades(sortedData);
  };

  const columns = [
    {
      header: 'Trades',
      accessorKey: 'trade',
      sortable: true,
      footer: () => 'Total',
    },
    {
      header: 'Completed Jobs',
      accessorKey: 'completedJobs',
      sortable: true,
      footer: () => trades.reduce((sum, row) => sum + row.completedJobs, 0),
    },
    {
      header: 'In Progress Jobs',
      accessorKey: 'inProgressJobs',
      sortable: true,
      footer: () => trades.reduce((sum, row) => sum + row.inProgressJobs, 0),
    },
    {
      header: 'Revenue',
      accessorKey: 'revenue',
      sortable: true,
      footer: () =>
        '$' +
        trades
          .reduce(
            (sum, row) =>
              sum + parseFloat(row.revenue.replace('$', '').replace(/,/g, '')),
            0
          )
          .toLocaleString(),
    },
    {
      header: 'Profit',
      accessorKey: 'profit',
      sortable: true,
      footer: () =>
        '$' +
        trades
          .reduce(
            (sum, row) =>
              sum + parseFloat(row.profit.replace('$', '').replace(/,/g, '')),
            0
          )
          .toLocaleString(),
    },
  ];

  // Actions for each row
  const actions = [
    {
      label: 'View',
      onClick: (row: AnalysisTradeData) => {
        setSelectedTrade(row.trade);
        setViewTradeModalOpen(true);
      },
    },
  ];

  return (
    <>
      <DataTableWithCard
        data={trades}
        columns={columns}
        page={1}
        pageSize={10}
        totalItems={trades.length}
        onPageChange={() => {}}
        onPageSizeChange={() => {}}
        showFooter={true}
        actions={actions}
        showTitle="Profit/Loss Analysis by Trade"
        pageSizeOptions={PAGE_SIZE}
        cardClassName="h-[450px]"
        scrollAreaClassName="h-[310px]"
        skeletonClassName="h-[200px]"
        showPagination={true}
        showPageSize={true}
        isLoading={loading}
        sorting={sorting}
        onSortingChange={handleSortingChange}
        headerActions={
          <>
            <Button variant="light" size="sm" className="px-4">
              Export
            </Button>
          </>
        }
      />
      <ViewTradeModal
        open={viewTradeModalOpen}
        onClose={() => setViewTradeModalOpen(false)}
        title={selectedTrade}
      />
    </>
  );
}

export default AnalysisTradeTable;
