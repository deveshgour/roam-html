/**
 * Data shape for info cards
 */
export interface InfoCardProps {
  title: string;
  value: number | string;
  icon: string;
  iconBgColor: string;
  iconColor: string;
  borderColor: string;
}

export interface HighNumbersResponse {
  revenue: string;
  profit: string;
  paymentsReceived: string;
  accountsPayable: string;
  credits: string;
  commission: string;
  completedJobs: string;
  inProgressJobs: string;
}

/**
 * Shape of the loading states
 */
export interface LoadingData {
  infoCards: boolean;
  barChart: boolean;
}

/**
 * Shape of the error states
 */
export interface ErrorStates {
  infoCards: Error | null;
  barChart: Error | null;
}

export interface BarChartData {
  title: string;
  categories: string[];
  series: {
    name: string;
    data: {
      y: number;
      revenue: number;
      profit: number;
      expenses: number;
    }[];
    color: string;
    type: 'column';
    borderRadius: number;
    pointWidth: number;
  }[];
}

export interface ChartDataPoint {
  expense: string;
  revenue: number;
  profit: number;
}
export interface PaginationState {
  page: number;
  pageSize: number;
  total: number;
}

export interface FilterState {
  dateRange: [Date | null, Date | null] | null;
  location: string[];
}
export interface FilterOptions {
  locations: Location[];
}
export interface Location {
  id: number;
  name: string;
}

export interface AnalysisBuilderData {
  id: string;
  builder: string;
  completedJobs: number;
  inProgressJobs: number;
  revenue: string;
  profit: string;
  paymentsReceived: string;
  accountsPayable: string;
  credits: string;
  commission: string;
}

export interface AnalysisTradeData {
  id: string;
  trade: string;
  completedJobs: number;
  inProgressJobs: number;
  revenue: string;
  profit: string;
}

export interface TradeDetailData {
  id: string;
  customer: string;
  jobName: string;
  jobPrice: string;
  changeOrders: string;
  totalAmount: string;
  expenseOverhead: string;
}
