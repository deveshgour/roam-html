export default function Bag(props: object) {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M15.0002 11.0002V12.9998M17.0003 11.0002H7M16 6.99984H8.00032V3.99984C8.00032 3.73467 8.10566 3.48035 8.29317 3.29285C8.48067 3.10534 8.73499 3 9.00016 3H15.0002C15.2653 3 15.5196 3.10534 15.7072 3.29285C15.8947 3.48035 16 3.73467 16 3.99984V6.99984Z"
        stroke="currentColor"
        strokeWidth="0.96"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M21 20.0001V8.00008C21 7.73486 20.8947 7.48049 20.7072 7.29291C20.5197 7.10533 20.2654 6.99988 20.0002 6.99976H3.99984C3.44784 6.99976 3 7.4476 3 8.00008V20.0001C3 20.5521 3.44784 20.9999 3.99984 20.9999H20.0002C20.5522 20.9999 21 20.5521 21 20.0001Z"
        stroke="currentColor"
        strokeWidth="0.96"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
