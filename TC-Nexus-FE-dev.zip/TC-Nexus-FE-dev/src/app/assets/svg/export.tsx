export default function Export(props: object) {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M6.66658 8.33333L4.99992 8.33333C4.55789 8.33333 4.13397 8.50893 3.82141 8.82149C3.50885 9.13405 3.33325 9.55797 3.33325 10L3.33325 15.8333C3.33325 16.2754 3.50885 16.6993 3.82141 17.0118C4.13397 17.3244 4.55789 17.5 4.99992 17.5L14.9999 17.5C15.4419 17.5 15.8659 17.3244 16.1784 17.0118C16.491 16.6993 16.6666 16.2754 16.6666 15.8333L16.6666 10C16.6666 9.55797 16.491 9.13405 16.1784 8.82149C15.8659 8.50893 15.4419 8.33333 14.9999 8.33333L13.3333 8.33333"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M10 14.1666L10 2.49996M10 2.49996L7.5 4.99996M10 2.49996L12.5 4.99996"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
