export default function History(props: object) {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M12 8V12L14 14"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M3.05005 11.0001C3.27414 8.80013 4.30031 6.75968 5.93278 5.26803C7.56525 3.77639 9.68974 2.93795 11.9009 2.9127C14.1121 2.88744 16.2552 3.67713 17.9213 5.1311C19.5874 6.58507 20.6599 8.60155 20.9342 10.7958C21.2085 12.99 20.6654 15.2085 19.4084 17.0278C18.1515 18.8472 16.2687 20.1401 14.1193 20.6599C11.97 21.1797 9.70446 20.89 7.75504 19.8461C5.80563 18.8022 3.05005 15.0001 3.05005 15.0001M3.05005 20.0001V15.0001M3.05005 15.0001H8.05005"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
