export default function Coin(props: object) {
  return (
    <svg
      width="25"
      height="24"
      viewBox="0 0 25 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M12.5 21C17.4706 21 21.5 16.9706 21.5 12C21.5 7.02944 17.4706 3 12.5 3C7.52944 3 3.5 7.02944 3.5 12C3.5 16.9706 7.52944 21 12.5 21Z"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M15.3 8.99991C15.1188 8.68567 14.8557 8.42661 14.5386 8.25047C14.2215 8.07432 13.8625 7.98771 13.5 7.99991H11.5C10.9696 7.99991 10.4609 8.21063 10.0858 8.5857C9.71071 8.96077 9.5 9.46948 9.5 9.99991C9.5 10.5303 9.71071 11.0391 10.0858 11.4141C10.4609 11.7892 10.9696 11.9999 11.5 11.9999H13.5C14.0304 11.9999 14.5391 12.2106 14.9142 12.5857C15.2893 12.9608 15.5 13.4695 15.5 13.9999C15.5 14.5303 15.2893 15.0391 14.9142 15.4141C14.5391 15.7892 14.0304 15.9999 13.5 15.9999H11.5C11.1375 16.0121 10.7785 15.9255 10.4614 15.7494C10.1443 15.5732 9.88115 15.3142 9.7 14.9999"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M12.5 16V18M12.5 6V8V6Z"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
