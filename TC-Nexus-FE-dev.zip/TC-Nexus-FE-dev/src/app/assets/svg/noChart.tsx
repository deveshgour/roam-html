export default function NoChart(props: object) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="118"
      height="111"
      viewBox="0 0 118 111"
      fill="none"
      {...props}
    >
      <path
        d="M79.44 41.6299C71.08 41.6299 62.58 41.2999 54.62 39.0799C46.66 36.8599 39.68 32.7099 33.25 27.8499C29.07 24.6799 25.25 22.1699 19.83 22.5499C14.5173 22.8301 9.43618 24.8149 5.34005 28.2099C-1.56995 34.2099 -0.519955 45.4398 2.24004 53.3099C6.39005 65.1599 19 73.3899 29.77 78.7599C42.18 84.9599 55.7701 88.5599 69.48 90.6299C81.48 92.4499 96.85 93.7699 107.23 85.9498C116.77 78.7598 119.39 62.3499 117.05 51.2599C116.469 48.0024 114.724 45.0671 112.14 42.9999C105.45 38.1099 95.45 41.3799 87.93 41.5399C85.13 41.5499 82.29 41.6199 79.44 41.6299Z"
        fill="currentColor"
      />
      <path
        d="M102.63 12.2197H16.1597C13.6855 12.2197 11.6797 14.2255 11.6797 16.6997V78.5497C11.6797 81.024 13.6855 83.0297 16.1597 83.0297H102.63C105.104 83.0297 107.11 81.024 107.11 78.5497V16.6997C107.11 14.2255 105.104 12.2197 102.63 12.2197Z"
        fill="white"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M15.2305 76.4399H100.6"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M15.2305 65.2402H100.6"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M15.2305 54.0498H100.6"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M15.2305 42.8501H100.6"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M15.2305 31.6499H100.6"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M15.2305 20.4502H100.6"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M31.9403 27.7402H26.3204C24.9617 27.7402 23.8604 28.8416 23.8604 30.2002V74.5802C23.8604 75.9389 24.9617 77.0402 26.3204 77.0402H31.9403C33.299 77.0402 34.4004 75.9389 34.4004 74.5802V30.2002C34.4004 28.8416 33.299 27.7402 31.9403 27.7402Z"
        fill="currentColor"
      />
      <path
        d="M52.12 46.9697H46.5C45.1414 46.9697 44.04 48.0711 44.04 49.4297V74.5797C44.04 75.9383 45.1414 77.0397 46.5 77.0397H52.12C53.4787 77.0397 54.58 75.9383 54.58 74.5797V49.4297C54.58 48.0711 53.4787 46.9697 52.12 46.9697Z"
        fill="currentColor"
      />
      <path
        d="M72.29 32.8999H66.67C65.3113 32.8999 64.21 34.0013 64.21 35.3599V74.5699C64.21 75.9285 65.3113 77.0299 66.67 77.0299H72.29C73.6486 77.0299 74.75 75.9285 74.75 74.5699V35.3599C74.75 34.0013 73.6486 32.8999 72.29 32.8999Z"
        fill="currentColor"
      />
      <path
        d="M92.4599 53.8501H86.8399C85.4813 53.8501 84.3799 54.9515 84.3799 56.3101V74.5701C84.3799 75.9287 85.4813 77.0301 86.8399 77.0301H92.4599C93.8185 77.0301 94.9199 75.9287 94.9199 74.5701V56.3101C94.9199 54.9515 93.8185 53.8501 92.4599 53.8501Z"
        fill="currentColor"
      />
      <path
        d="M24.3604 49.9001L30.2204 49.6701L46.6303 66.5401L62.3304 52.2401L79.4404 57.8701L95.9503 47.3301"
        stroke="currentColor"
        strokeWidth="1.1"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M35.3799 88.7002V93.0002"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M33.2305 90.8501H37.5305"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M112.29 32.1099V36.4099"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M110.14 34.2598H114.44"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M4.37988 11.2803V15.5703"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M2.23047 13.4302H6.53047"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M6.18996 69.9297C6.7312 69.9297 7.16996 69.491 7.16996 68.9497C7.16996 68.4085 6.7312 67.9697 6.18996 67.9697C5.64872 67.9697 5.20996 68.4085 5.20996 68.9497C5.20996 69.491 5.64872 69.9297 6.18996 69.9297Z"
        fill="currentColor"
      />
      <path
        d="M53.1099 2.17973C53.6511 2.17973 54.0899 1.74097 54.0899 1.19973C54.0899 0.658489 53.6511 0.219727 53.1099 0.219727C52.5686 0.219727 52.1299 0.658489 52.1299 1.19973C52.1299 1.74097 52.5686 2.17973 53.1099 2.17973Z"
        fill="currentColor"
      />
      <path
        d="M63.1803 110.04C83.4215 110.04 99.8303 109.019 99.8303 107.76C99.8303 106.501 83.4215 105.48 63.1803 105.48C42.939 105.48 26.5303 106.501 26.5303 107.76C26.5303 109.019 42.939 110.04 63.1803 110.04Z"
        fill="currentColor"
      />
      <path
        d="M103.56 24.8899C109.972 24.8899 115.17 19.6919 115.17 13.2799C115.17 6.8679 109.972 1.66992 103.56 1.66992C97.1482 1.66992 91.9502 6.8679 91.9502 13.2799C91.9502 19.6919 97.1482 24.8899 103.56 24.8899Z"
        fill="currentColor"
      />
      <path
        d="M98.5098 8.22998L108.6 18.33"
        stroke="white"
        strokeWidth="1.1"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M108.6 8.22998L98.5098 18.33"
        stroke="white"
        strokeWidth="1.1"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
