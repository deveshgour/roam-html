'use client';
import React from 'react';
import UserManagementTable from '@/app/users/management/components/UserManagementTable';

const UsersManagementPage = () => {
  return (
    <div className="bg-white p-8">
      <UserManagementTable />
    </div>
  );
};

export default UsersManagementPage;
