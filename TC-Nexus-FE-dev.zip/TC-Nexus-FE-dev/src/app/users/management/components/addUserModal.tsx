import { Button } from '@/components/coreUI/button';
import Modal from '@/components/coreUI/dialog';
import { TextInput } from '@/components/coreUI/textInput';
import MultiSelect, { Option } from '@/components/coreUI/multiSelect';

import { FieldArray, Formik, FormikProps } from 'formik';

import * as Yup from 'yup';
import React from 'react';
import { STATUS_OPTIONS } from './constants';
import { VALIDATION_MESSAGES } from '@/constants/messages';
import Icon from '@/components/coreUI/icon';
import { PHONE_PATTERN } from '@/constants/common';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/coreUI/select';
import { ROLE_TYPE } from '@/constants/configs';

interface AddUserModalProps {
  open: boolean;
  onClose: () => void;
  // eslint-disable-next-line no-unused-vars
  onSubmit: (values: UserFormValues) => void;
  user?: UserFormValues;
  isSubmitting?: boolean;
  roles?: RoleLocationType[];
  teams?: TeamsType[];
  locations?: RoleLocationType[];
}

interface RoleLocationType {
  value: string;
  label: string;
  role_type?: string;
}

interface TeamsType {
  value: string;
  label: string;
}

interface RoleLocation {
  role: string;
  location: string;
  team: string;
  role_type: string;
}

export interface UserFormValues {
  id?: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  status: string;
  password: string;
  roleLocations: RoleLocation[];
}

const AddUserModal = ({
  open = false,
  onClose = () => {},
  onSubmit = () => {},
  user = undefined,
  isSubmitting = false,
  roles,
  teams,
  locations,
}: AddUserModalProps) => {
  const formikRef = React.useRef<FormikProps<UserFormValues>>(null);
  const isEditing = Boolean(user);
  const initialValues: UserFormValues = {
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    email: user?.email || '',
    phone: user?.phone || '',
    status: user?.status || '',
    password: '',
    roleLocations: user?.roleLocations || [
      { role: '', location: '', team: '', role_type: '' },
    ],
  };

  const validationSchema = Yup.object().shape({
    firstName: Yup.string()
      .min(3, VALIDATION_MESSAGES.NAME.FIRST_MIN_LENGTH)
      .max(100, VALIDATION_MESSAGES.NAME.FIRST_MAX_LENGTH)
      .required(VALIDATION_MESSAGES.NAME.FIRST_REQUIRED),

    lastName: Yup.string()
      .min(3, VALIDATION_MESSAGES.NAME.LAST_MIN_LENGTH)
      .max(100, VALIDATION_MESSAGES.NAME.LAST_MAX_LENGTH)
      .required(VALIDATION_MESSAGES.NAME.LAST_REQUIRED),
    email: Yup.string()
      .email(VALIDATION_MESSAGES.VALID_EMAIL)
      .required(VALIDATION_MESSAGES.REQUIRED),
    phone: Yup.string()
      .required(VALIDATION_MESSAGES.PHONE.REQUIRED)
      .matches(PHONE_PATTERN, VALIDATION_MESSAGES.PHONE.INVALID),
    status: Yup.string().required(VALIDATION_MESSAGES.STATUS.REQUIRED),
    password: isEditing
      ? Yup.string().optional()
      : Yup.string()
          .required(VALIDATION_MESSAGES.PASSWORD.REQUIRED)
          .min(8, VALIDATION_MESSAGES.PASSWORD.MIN_LENGTH),
    roleLocations: Yup.array()
      .of(
        Yup.object().shape({
          role: Yup.string().required(VALIDATION_MESSAGES.ROLE.REQUIRED),
          location: Yup.string().required(
            VALIDATION_MESSAGES.LOCATION.REQUIRED
          ),
          team: Yup.string().when('role_type', {
            is: ROLE_TYPE.MANAGER,
            then: () =>
              Yup.string().required(VALIDATION_MESSAGES.TEAM.REQUIRED),
            otherwise: () => Yup.string().optional(),
          }),
        })
      )
      .test(
        'unique-combinations',
        VALIDATION_MESSAGES.ROLE_LOCATION_PAIR,
        function (roleLocations) {
          if (!roleLocations) return true;

          const combinations = new Set();
          for (const item of roleLocations) {
            const combo = `${item.role}-${item.location}`;
            if (combinations.has(combo)) {
              return false;
            }
            combinations.add(combo);
          }
          return true;
        }
      ),
  });

  const handleSubmit = async () => {
    if (formikRef.current) {
      const { validateForm, submitForm, setTouched } = formikRef.current;

      // Mark all fields as touched
      setTouched({
        firstName: true,
        lastName: true,
        email: true,
        phone: true,
        status: true,
        password: true,
        roleLocations: [{ role: true, location: true, team: true }],
      });

      const errors = await validateForm();

      if (Object.keys(errors).length === 0) {
        await submitForm();
      }
    }
  };

  return (
    <>
      <Modal
        maxWidth="2xl"
        header={
          <>
            <span className="text-lg inline-flex text-gray">
              {user ? 'Edit User' : 'Add User'}
            </span>
          </>
        }
        open={open}
        onClose={onClose}
        footer={
          <div className="flex items-center gap-4 w-full">
            <Button
              size="lg"
              onClick={onClose}
              variant="outlineLight"
              full
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              size="lg"
              onClick={handleSubmit}
              variant="primary"
              full
              loading={isSubmitting}
              disabled={isSubmitting}
            >
              {user ? 'Update User' : 'Add User'}
            </Button>
          </div>
        }
      >
        <Formik
          innerRef={formikRef}
          initialValues={initialValues}
          validationSchema={validationSchema}
          validateOnMount={false}
          enableReinitialize={true}
          validationContext={{ isEditing }}
          onSubmit={(values) => {
            // Only include password in new user creation
            const submitValues = isEditing
              ? {
                  ...values,
                  password: '',
                  role: '',
                  location: [],
                }
              : values;
            onSubmit(submitValues);
          }}
        >
          {({ values, errors, touched, setFieldValue }) => {
            return (
              <form className="mx-auto mb-4">
                <div className="grid gap-x-4 gap-y-5 grid-cols-2">
                  <div>
                    <TextInput
                      size="sm"
                      className="pl-10 !bg-gray-50"
                      label="First Name"
                      name="firstName"
                      maxLength={100}
                      placeholder="Enter First Name"
                      error={
                        touched.firstName && errors.firstName
                          ? errors.firstName
                          : ''
                      }
                      value={values.firstName}
                      onChange={(e) => {
                        setFieldValue('firstName', e.target.value);
                      }}
                      startAdornment={
                        <div className="absolute left-4 top-1/2 transform -translate-y-1/2">
                          <Icon
                            iconName="user"
                            iconProps={{ className: `w-4 h-4 text-gray-500` }}
                          />
                        </div>
                      }
                    />
                  </div>
                  <div>
                    <TextInput
                      size="sm"
                      className="pl-10 !bg-gray-50"
                      label="Last Name"
                      name="lastName"
                      maxLength={100}
                      placeholder="Enter Last Name"
                      value={values.lastName}
                      error={
                        touched.lastName && errors.lastName
                          ? errors.lastName
                          : ''
                      }
                      onChange={(e) =>
                        setFieldValue('lastName', e.target.value)
                      }
                      startAdornment={
                        <div className="absolute left-4 top-1/2 transform -translate-y-1/2">
                          <Icon
                            iconName="user"
                            iconProps={{ className: `w-4 h-4 text-gray-500` }}
                          />
                        </div>
                      }
                    />
                  </div>
                  <div>
                    <TextInput
                      size="sm"
                      className="pl-10 !bg-gray-50"
                      label="Email"
                      name="email"
                      value={values.email}
                      placeholder="Enter Email Address"
                      error={touched.email && errors.email ? errors.email : ''}
                      onChange={(e) => setFieldValue('email', e.target.value)}
                      startAdornment={
                        <div className="absolute left-4 top-1/2 transform -translate-y-1/2">
                          <Icon
                            iconName="emailFilled"
                            iconProps={{ className: `w-4 h-4 text-gray-500` }}
                          />
                        </div>
                      }
                    />
                  </div>
                  <div>
                    <TextInput
                      size="sm"
                      className="pl-10 !bg-gray-50"
                      label="Phone"
                      name="phone"
                      value={values.phone}
                      placeholder="Enter Phone Number"
                      error={touched.phone && errors.phone ? errors.phone : ''}
                      onChange={(e) =>
                        setFieldValue(
                          'phone',
                          e?.target?.value?.replace(/\D/g, '')
                        )
                      }
                      maxLength={10}
                      startAdornment={
                        <div className="absolute left-4 top-1/2 transform -translate-y-1/2">
                          <Icon
                            iconName="phone"
                            iconProps={{ className: `w-4 h-4 text-gray-500` }}
                          />
                        </div>
                      }
                    />
                  </div>
                  {/* <div>
                    <label className="text-xs text-gray  font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 mb-2 block">
                      Location
                    </label>
                    <MultiSelect
                      className="[&_svg]:mr-2 text-xs"
                      backgroundColor="rgb(var(--color-gray-50))"
                      options={LOCATIONS}
                      isDisabled={true}
                      value={
                        values?.location?.map((loc) => ({
                          value: loc,
                          label: loc,
                        })) || []
                      }
                      size="sm"
                      onChange={(selected) =>
                        setFieldValue(
                          'location',
                          (selected as Option[]).map((item) => item.value)
                        )
                      }
                      placeholder="Select Location"
                      icon={'mapPinFilled'}
                      showCheckbox={true}
                    />
                  </div> */}
                  <div>
                    <label className="text-xs text-gray font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 mb-2 block">
                      Status
                    </label>
                    <MultiSelect
                      backgroundColor="rgb(var(--color-gray-50))"
                      isMulti={false}
                      closeMenuOnSelect={true}
                      options={STATUS_OPTIONS}
                      value={
                        values.status
                          ? [
                              {
                                value: values.status,
                                label:
                                  values.status.charAt(0).toUpperCase() +
                                  values.status.slice(1),
                              },
                            ]
                          : []
                      }
                      size="sm"
                      onChange={(selected) =>
                        setFieldValue(
                          'status',
                          selected ? (selected as Option).value : ''
                        )
                      }
                      placeholder="Select Status"
                      icon={'list'}
                      className="[&_svg]:mr-2 text-xs [&_.select__placeholder]:text-xs [&_.select__single-value]:text-xs"
                    />
                    {touched.status && errors.status && (
                      <div className="text-red-500 text-xs mt-1">
                        {errors.status}
                      </div>
                    )}
                  </div>
                  {!isEditing ? (
                    <div>
                      <TextInput
                        size="sm"
                        className="pl-10 !bg-gray-50"
                        label="Password"
                        name="password"
                        type="password"
                        placeholder="Enter Password"
                        error={
                          touched.password && errors.password
                            ? errors.password
                            : ''
                        }
                        onChange={(e) =>
                          setFieldValue('password', e.target.value)
                        }
                        startAdornment={
                          <div className="absolute left-4 top-1/2 transform -translate-y-1/2">
                            <Icon
                              iconName="lockFilled"
                              iconProps={{ className: `w-4 h-4 text-gray-500` }}
                            />
                          </div>
                        }
                      />
                    </div>
                  ) : null}
                </div>
                <FieldArray
                  name="roleLocations"
                  render={(arrayHelpers) => (
                    <div>
                      {values.roleLocations && values.roleLocations.length > 0
                        ? values.roleLocations.map((item, index) => {
                            return (
                              <div key={index}>
                                <div className="flex gap-4 mt-[20px]">
                                  <div className="flex-[0_0_49%]">
                                    <label className="text-xs text-gray font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 mb-2 block">
                                      Role
                                    </label>
                                    <div className="input-with-icon">
                                      <Select
                                        value={values.roleLocations[index].role}
                                        onValueChange={(value) => {
                                          const selectedRole = roles?.find(
                                            (role) => role.value === value
                                          );
                                          setFieldValue(
                                            `roleLocations.${index}`,
                                            {
                                              ...values.roleLocations[index],
                                              role: value,
                                              role_type:
                                                selectedRole?.role_type || '',
                                            }
                                          );
                                        }}
                                      >
                                        <SelectTrigger className="bg-gray-50 [&_svg]:mr-2 h-9 px-3">
                                          <div className="flex items-center text-xs">
                                            <Icon
                                              iconName="user"
                                              iconProps={{
                                                className:
                                                  'w-4 h-4 text-gray-500 mr-2',
                                              }}
                                            />
                                            <SelectValue
                                              placeholder="Select Role"
                                              className="[&_*]:text-xs [&_.placeholder]:text-gray-500"
                                            />
                                          </div>
                                        </SelectTrigger>
                                        <SelectContent>
                                          {roles?.map(
                                            (role: RoleLocationType) => (
                                              <SelectItem
                                                key={role.value}
                                                value={role.value}
                                                className="text-xs"
                                              >
                                                {role.label}
                                              </SelectItem>
                                            )
                                          )}
                                        </SelectContent>
                                      </Select>
                                    </div>
                                    {touched.roleLocations?.[0]?.role &&
                                      errors.roleLocations?.[0] &&
                                      errors.roleLocations !==
                                        VALIDATION_MESSAGES.ROLE_LOCATION_PAIR && (
                                        <div className="text-red-500 text-xs mt-1">
                                          {typeof errors.roleLocations ===
                                          'string'
                                            ? errors.roleLocations
                                            : (
                                                errors.roleLocations[0] as {
                                                  role: string;
                                                }
                                              )?.role}
                                        </div>
                                      )}
                                  </div>

                                  <div className="flex-1">
                                    <label className="text-xs text-gray font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 mb-2 block">
                                      Location
                                    </label>
                                    <div className="input-with-icon">
                                      <Select
                                        value={
                                          values.roleLocations[index].location
                                        }
                                        onValueChange={(value) => {
                                          setFieldValue(
                                            `roleLocations.${index}.location`,
                                            value
                                          );
                                        }}
                                      >
                                        <SelectTrigger className="bg-gray-50 [&_svg]:mr-2 h-9 px-3">
                                          <div className="flex items-center text-xs">
                                            <Icon
                                              iconName="mapPinFilled"
                                              iconProps={{
                                                className:
                                                  'w-4 h-4 text-gray-500 mr-2',
                                              }}
                                            />
                                            <SelectValue
                                              placeholder="Select Location"
                                              className="[&_*]:text-xs [&_.placeholder]:text-gray-500"
                                            />
                                          </div>
                                        </SelectTrigger>
                                        <SelectContent>
                                          {locations?.map(
                                            (location: RoleLocationType) => (
                                              <SelectItem
                                                key={location.value}
                                                value={location.value}
                                                className="text-xs"
                                              >
                                                {location.label}
                                              </SelectItem>
                                            )
                                          )}
                                        </SelectContent>
                                      </Select>
                                    </div>
                                    {touched.roleLocations?.[index]?.location &&
                                      errors.roleLocations?.[index] &&
                                      errors.roleLocations !==
                                        VALIDATION_MESSAGES.ROLE_LOCATION_PAIR && (
                                        <div className="text-red-500 text-xs mt-1">
                                          {typeof errors.roleLocations ===
                                          'string'
                                            ? errors.roleLocations
                                            : (
                                                errors.roleLocations[index] as {
                                                  location: string;
                                                }
                                              )?.location}
                                        </div>
                                      )}
                                  </div>

                                  {values.roleLocations.length > 1 && (
                                    <button
                                      type="button"
                                      className="delete-button mt-[20px]"
                                      onClick={() => arrayHelpers.remove(index)}
                                    >
                                      <Icon
                                        iconName={'cross'}
                                        iconProps={{
                                          className: `ml-2 text-[rgb(var(--color-gray-500))]`,
                                        }}
                                      />
                                    </button>
                                  )}
                                </div>

                                {values.roleLocations[index].role_type ===
                                  ROLE_TYPE.MANAGER && (
                                  <div className="flex-1 mt-3">
                                    <label className="text-xs text-gray font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 mb-2 block">
                                      Team
                                    </label>
                                    <div className="input-with-icon">
                                      <Select
                                        value={values?.roleLocations?.[
                                          index
                                        ].team?.toString()}
                                        onValueChange={(value) => {
                                          setFieldValue(
                                            `roleLocations.${index}.team`,
                                            value
                                          );
                                        }}
                                      >
                                        <SelectTrigger className="bg-gray-50 [&_svg]:mr-2 h-9 px-3">
                                          <div className="flex items-center text-xs">
                                            <Icon
                                              iconName="user"
                                              iconProps={{
                                                className:
                                                  'w-4 h-4 text-gray-500 mr-2',
                                              }}
                                            />
                                            <SelectValue
                                              placeholder="Select Team"
                                              className="[&_*]:text-xs [&_.placeholder]:text-gray-500"
                                            />
                                          </div>
                                        </SelectTrigger>
                                        <SelectContent>
                                          {teams?.map((team: any) => (
                                            <SelectItem
                                              key={team.value}
                                              value={team.value}
                                              className="text-xs"
                                            >
                                              {team.label}
                                            </SelectItem>
                                          ))}
                                        </SelectContent>
                                      </Select>
                                    </div>
                                    {touched.roleLocations?.[index]?.team &&
                                      errors.roleLocations?.[index] &&
                                      errors.roleLocations !==
                                        VALIDATION_MESSAGES.ROLE_LOCATION_PAIR && (
                                        <div className="text-red-500 text-xs mt-1">
                                          {typeof errors.roleLocations ===
                                          'string'
                                            ? errors.roleLocations
                                            : (
                                                errors.roleLocations[index] as {
                                                  team: string;
                                                }
                                              )?.team}
                                        </div>
                                      )}
                                  </div>
                                )}
                              </div>
                            );
                          })
                        : null}

                      <button
                        type="button"
                        className="add-more-button text-[#9b1c1c] text-[12px] font-bold mt-[15px]"
                        onClick={() =>
                          arrayHelpers.push({ role: '', location: '' })
                        }
                      >
                        + Add More Roles & Locations
                      </button>

                      {touched.roleLocations?.[0]?.role &&
                        errors.roleLocations?.[0] &&
                        errors.roleLocations ==
                          VALIDATION_MESSAGES.ROLE_LOCATION_PAIR && (
                          <div className="text-red-500 text-xs mt-1">
                            {typeof errors.roleLocations === 'string'
                              ? errors.roleLocations
                              : (
                                  errors.roleLocations[0] as {
                                    role: string;
                                  }
                                )?.role}
                          </div>
                        )}
                    </div>
                  )}
                />
              </form>
            );
          }}
        </Formik>
      </Modal>
    </>
  );
};
export default AddUserModal;
