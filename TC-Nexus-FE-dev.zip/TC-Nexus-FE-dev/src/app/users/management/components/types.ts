export interface User {
  id: string;
  name: string;
  email: string;
  status: 'active' | 'inactive';
  phone: string;
  createdOn: string;
  lastLogin: string;
  role_and_location: {
    role_id: string;
    loc_id: string;
    team_id: string;
    role_type?: string;
  }[];
}
