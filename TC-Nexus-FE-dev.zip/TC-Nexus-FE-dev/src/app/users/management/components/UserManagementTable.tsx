import { DataTable } from '@/components/coreUI/table/dataTable';
import { useState, useCallback, useMemo } from 'react';
import { Button } from '@/components/coreUI/button';
import { useUsers } from '@/hooks/useUsers';
import Modal from '@/components/coreUI/dialog';
import { showSuccessMsg, showErrorMsg } from '@/utils/notifications';
import AddUserModal, {
  UserFormValues,
} from '@/app/users/management/components/addUserModal';
import { User } from '@/app/users/management/components/types';
import { columns, STATUS } from '@/app/users/management/components/constants';
import ResetPasswordModal from '@components/resetPassword';
import { TOAST_MESSAGES } from '@/constants/messages';
import { PAGE_SIZE } from '@/constants/configs';
import Icon from '@/components/coreUI/icon';
import { SortingState } from '@/types/common';

// Add this constant before the ModalType type definition
const MODAL_TYPES = {
  STATUS: 'status',
  DELETE: 'delete',
  EDIT: 'edit',
  PASSWORD: 'password',
  ADD: 'add',
} as const;

type ModalType = (typeof MODAL_TYPES)[keyof typeof MODAL_TYPES];

interface SelectedUserState {
  type: ModalType;
  user: User | UserFormValues;
}

function UserManagementTable() {
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [sorting, setSorting] = useState<SortingState>({
    field: 'name',
    direction: null,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Replace multiple selected user states with a single state
  const [selectedUserState, setSelectedUserState] =
    useState<SelectedUserState | null>(null);
  const [showModal, setShowModal] = useState<ModalType | null>(null);

  const {
    users,
    roles,
    teams,
    locations,
    totalCount,
    updateFilters,
    filters,
    activateDeactivateUser,
    deleteUser,
    addUser,
    updateUser,
    isLoading,
    resetUserPassword,
  } = useUsers({
    initialFilters: {
      page: 1,
      pageSize: 10,
    },
    autoFetch: true,
  });

  // Action handlers
  const handleSearch = useCallback(
    (query: string) => {
      try {
        updateFilters({ email: query, page: 1 });
      } catch (error) {
        console.error('Error updating filters:', error);
        showErrorMsg(TOAST_MESSAGES.FILTER_UPDATE_ERROR);
      }
    },
    [updateFilters]
  );

  const debouncedSearch = useMemo(() => {
    let timeoutId: NodeJS.Timeout;
    return (query: string) => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        handleSearch(query);
      }, 500);
    };
  }, [handleSearch]);

  const handleSelectAll = (selected: boolean, ids: string[]) => {
    setSelectedUsers(selected ? ids : []);
  };

  const closeModal = () => {
    setShowModal(null);
    setSelectedUserState(null);
  };

  const actions = [
    {
      label: 'Edit',
      onClick: (row: User) => {
        const user = {
          id: row.id,
          firstName: row.name.split(' ')[0],
          lastName: row.name.split(' ')[1],
          email: row.email,
          phone: row.phone,
          status: row.status,
          password: '',
          roleLocations:
            row.role_and_location.length > 0
              ? row.role_and_location.map((loc) => ({
                  role: loc.role_id.toString() || '',
                  location: loc.loc_id.toString() || '',
                  team: loc?.team_id?.toString() || '',
                  role_type: loc?.role_type || '',
                }))
              : [{ role: '', location: '', team: '', role_type: '' }],
        };
        setSelectedUserState({ type: MODAL_TYPES.EDIT, user });
        setShowModal(MODAL_TYPES.EDIT);
      },
    },
    {
      label: (row: User) =>
        row.status === STATUS.ACTIVE ? 'Deactivate User' : 'Activate User',
      onClick: (row: User) => {
        setSelectedUserState({ type: MODAL_TYPES.STATUS, user: row });
        setShowModal(MODAL_TYPES.STATUS);
      },
    },
    {
      label: 'Reset Password',
      onClick: (row: User) => {
        setSelectedUserState({ type: MODAL_TYPES.PASSWORD, user: row });
        setShowModal(MODAL_TYPES.PASSWORD);
      },
    },
    {
      label: 'Permanent Delete',
      onClick: (row: User) => {
        setSelectedUserState({ type: MODAL_TYPES.DELETE, user: row });
        setShowModal(MODAL_TYPES.DELETE);
      },
    },
  ];

  const handleStatusChange = async () => {
    try {
      setIsSubmitting(true);
      if (selectedUserState?.type === MODAL_TYPES.STATUS) {
        const user = selectedUserState.user as User;
        await activateDeactivateUser(
          user.id,
          user.status === STATUS.ACTIVE ? false : true
        );
        showSuccessMsg(TOAST_MESSAGES.USER_STATUS_SUCCESS);
        closeModal();
      }
    } catch (error) {
      console.error('Error updating user status:', error);
      showErrorMsg(TOAST_MESSAGES.USER_STATUS_ERROR);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    try {
      setIsSubmitting(true);
      if (selectedUserState?.type === MODAL_TYPES.DELETE) {
        const user = selectedUserState.user as User;
        await deleteUser(user.id);
        showSuccessMsg(TOAST_MESSAGES.USER_DELETE_SUCCESS);
        closeModal();
      }
    } catch (error) {
      console.error('Error deleting user:', error);
      showErrorMsg(TOAST_MESSAGES.USER_DELETE_ERROR);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAddUser = async (user: UserFormValues) => {
    try {
      setIsSubmitting(true);
      if (selectedUserState?.type === MODAL_TYPES.EDIT) {
        const editUser = selectedUserState.user as UserFormValues;
        await updateUser(editUser.id!, user);
        showSuccessMsg(TOAST_MESSAGES.USER_UPDATE_SUCCESS);
      } else {
        await addUser(user);
        showSuccessMsg(TOAST_MESSAGES.USER_ADD_SUCCESS);
      }
      closeModal();
    } catch (error) {
      setIsSubmitting(false);
      console.error('Error adding/updating user', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetPassword = async (values: {
    newPassword: string;
    confirmPassword: string;
  }) => {
    try {
      setIsSubmitting(true);
      if (selectedUserState?.type === MODAL_TYPES.PASSWORD) {
        const user = selectedUserState.user as User;
        await resetUserPassword(user.id, values.newPassword);
        showSuccessMsg(TOAST_MESSAGES.PASSWORD_RESET_SUCCESS);
        closeModal();
      }
    } catch (error) {
      console.error('Error resetting password:', error);
      showErrorMsg(TOAST_MESSAGES.PASSWORD_RESET_ERROR);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSortingChange = (
    field: string,
    direction: 'asc' | 'desc' | null
  ) => {
    const orderingValue = direction === 'desc' ? `-${field}` : field;
    updateFilters({ page: 1, ordering: orderingValue });
    setSorting({ field, direction });
  };

  return (
    <>
      <DataTable
        loading={isLoading}
        showSkeleton={true}
        data={users as unknown as User[]}
        columns={columns}
        page={filters.page || 1}
        pageSize={filters.pageSize || 10}
        totalItems={totalCount}
        onPageChange={(page) => updateFilters({ page })}
        onPageSizeChange={(pageSize) => updateFilters({ pageSize })}
        onSearch={debouncedSearch}
        selectedRows={selectedUsers}
        onSelectAll={handleSelectAll}
        actions={actions}
        getRowId={(row) => row.id}
        pageSizeOptions={PAGE_SIZE}
        sorting={sorting}
        onSortingChange={handleSortingChange}
        showSearch={true}
        showPagination={true}
        scrollAreaClassName="h-[500px]"
        showPageSize={true}
        headerActions={
          <Button
            onClick={() => setShowModal(MODAL_TYPES.ADD)}
            variant="primary"
            className="!py-2.5"
          >
            <Icon iconName="plus" iconProps={{ className: `!h-5 !w-5` }} />
            Add User
          </Button>
        }
      />

      {selectedUserState?.type === MODAL_TYPES.STATUS && (
        <Modal
          open={showModal === MODAL_TYPES.STATUS}
          onClose={closeModal}
          title={`${(selectedUserState.user as User).status === STATUS.ACTIVE ? 'Deactivate' : 'Activate'} User`}
          primaryButton={{
            text: 'Confirm',
            onClick: handleStatusChange,
            loading: isSubmitting,
            disabled: isSubmitting,
          }}
          secondaryButton={{
            text: 'Cancel',
            onClick: closeModal,
            disabled: isSubmitting,
          }}
        >
          <div className="text-left">
            <p className="text-gray-600">
              Are you sure you want to{' '}
              {(selectedUserState.user as User).status === STATUS.ACTIVE
                ? 'deactivate'
                : 'activate'}{' '}
              <span className="font-semibold">
                {(selectedUserState.user as User).name}
              </span>
              ?
            </p>
          </div>
        </Modal>
      )}

      {selectedUserState?.type === MODAL_TYPES.DELETE && (
        <Modal
          open={showModal === MODAL_TYPES.DELETE}
          onClose={closeModal}
          title="Delete User"
          primaryButton={{
            text: 'Delete',
            onClick: handleDelete,
            loading: isSubmitting,
          }}
          secondaryButton={{
            text: 'Cancel',
            onClick: closeModal,
            disabled: isSubmitting,
          }}
        >
          <div className="text-left">
            <p className="text-gray-600">
              Are you sure you want to permanently delete{' '}
              <span className="font-semibold">
                {(selectedUserState.user as User).name}
              </span>
              ?
            </p>
            <p className="mt-3 text-red-500">This action cannot be undone.</p>
          </div>
        </Modal>
      )}

      <AddUserModal
        onSubmit={handleAddUser}
        open={showModal === MODAL_TYPES.EDIT || showModal === MODAL_TYPES.ADD}
        onClose={closeModal}
        user={
          selectedUserState?.type === MODAL_TYPES.EDIT
            ? (selectedUserState.user as UserFormValues)
            : undefined
        }
        isSubmitting={isSubmitting}
        roles={roles}
        teams={teams}
        locations={locations}
      />

      {selectedUserState?.type === MODAL_TYPES.PASSWORD && (
        <ResetPasswordModal
          open={showModal === MODAL_TYPES.PASSWORD}
          onClose={closeModal}
          onSubmit={handleResetPassword}
          isSubmitting={isSubmitting}
        />
      )}
    </>
  );
}

export default UserManagementTable;
