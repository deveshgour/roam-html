import { User } from '@/app/users/management/components/types';

export const columns = [
  { header: 'USER ID', accessorKey: 'id', sortable: true },
  { header: 'USER NAME', accessorKey: 'name', sortable: true },
  { header: 'EMAIL', accessorKey: 'email', sortable: true },
  { header: 'PHONE', accessorKey: 'phone', sortable: true },
  { header: 'LAST LOGIN', accessorKey: 'lastLogin', sortable: true },
  { header: 'CREATED ON', accessorKey: 'createdOn', sortable: true },
  {
    header: 'Status',
    accessorKey: 'status',
    cell: (row: User) => (
      <span
        className={`px-4 py-1 rounded-md text-xs capitalize font-medium ${
          row.status === 'active'
            ? 'bg-green-100 text-green-800'
            : 'bg-red-100 text-red-800'
        }`}
      >
        {row.status}
      </span>
    ),
  },
];

export const STATUS = {
  ACTIVE: 'active',
  INACTIVE: 'inactive',
};

export const STATUS_OPTIONS = [
  { value: 'active', label: 'Active' },
  { value: 'inactive', label: 'Inactive' },
];

export const ROLES = [
  { value: 'admin', label: 'Admin' },
  { value: 'user', label: 'User' },
];
