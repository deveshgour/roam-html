/**
 * Data shape for info cards
 */
export interface InfoCardData {
  /**
   * Title of the info card
   */
  title: string;
  /**
   * Value of the info card
   */
  value: string;
  /**
   * Icon of the info card
   */
  icon: string;
  /**
   * Background color of the icon
   */
  iconBgColor: string;
  /**
   * Color of the icon
   */
  iconColor: string;
  /**
   * Border color of the info card
   */
  borderColor: string;
  /**
   * percentage of the info card
   */
  percentage: string;
  /**
   * value of the info card
   */
  isPositive: boolean;
}

/**
 * Response data shape from the API
 */
export interface HighNumbersResponse {
  /**
   * Average customer acquisition cost
   */
  average_cac: number;
  /**
   * Total number of customers
   */
  total_customers: number;
  /**
   * Best performing source
   */
  best_performing_source: number;

  cac: number | string;

  growth_rate: number | string;
}

/**
 * Shape of the loading states
 */
export interface LoadingData {
  trendLineChart: boolean;
  infoCards: boolean;
  barChart: boolean;
  sourceBarChart: boolean;
  leadSourceTable: boolean;
  sourceDetailTable: boolean;
  filterOptions: boolean;
  barChartPopupData: boolean;
  exploreTable: boolean;
}

/**
 * Shape of the error states
 */
export interface ErrorStates {
  infoCards: Error | null;
  barChart: Error | null;
  trendLineChart: Error | null;
  sourceBarChart: Error | null;
  leadSourceTable: Error | null;
  sourceDetailTable: Error | null;
  filterOptions: Error | null;
  barChartPopupData: Error | null;
  exploreTable: Error | null;
}

export interface BarChartData {
  title: string;
  categories: string[];
  series: {
    name: string;
    data: {
      y: number;
      customers_acquired: number;
      marketing_spends: number;
      cac: number;
    }[];
    color: string;
    type: 'column';
    borderRadius: number;
    pointWidth: number;
  }[];
}

export interface ChartDataPoint {
  month: number;
  source: string;
  marketing_spends: number;
  customers_acquired: number;
  cac: number;
}

export interface LineChartData {
  title: string;
  categories: string[];
  series: {
    name: string;
    data: { y: number }[];
    color: string;
    type: any;
    yAxis?: number;
  }[];
  type: any;
  yAxisTickInterval: number;
  yAxisMin: number;
  useDualYAxis: boolean;
  yAxisMaxCAC?: number;
  yAxisMaxCustomers?: number;
  yAxis?: {
    title: { text: string };
    max: number;
    labels: { format: string };
    opposite?: boolean;
  }[];
}

export interface TrendChartDataPoint {
  week?: string;
  month?: string;
  quarter?: string;
  year?: string;
  cac?: number;
  customers_acquired?: string;
  trend?: string;
  [key: string]: any;
}
export interface SourceChartDataPoint {
  source: string;
  customers: number;
  conversion_rate: number;
}

export interface SourceBarChartData {
  title: string;
  categories: string[];
  series: {
    name: string;
    data: {
      y: number;
      conversion: number;
      color: string;
    }[];
    type: any;
    borderRadius: number;
    pointWidth: number;
  }[];
}
export interface LeadSourceTableDataItem {
  id: string;
  source: string;
  marketing_spends: number;
  customers_acquired: number;
  cac: number;
}

export interface LeadSourceTableData {
  data: LeadSourceTableDataItem[];
  total?: {
    marketing_spends: number;
    customers_acquired: number;
    cac: number;
  };
}

export interface LeadSourceTableTransformData {
  id: string;
  source: string;
  marketing_spends: string;
  customers_acquired: number;
  cac: string;
}
export interface PaginationState {
  page: number;
  pageSize: number;
  total: number;
}

export interface LeadSourceDetailData {
  id: string;
  customer: string;
  job_id: number;
  job_name: string;
  lead_date: number;
  contract_signed_date: number;
  total_amount: string;
}
export interface FilterState {
  dateRange: [Date | null, Date | null] | null;
  location: string[];
}
export interface FilterOptions {
  locations: Location[];
}
export interface Location {
  id: number;
  name: string;
}

export interface ExploreTableData {
  id: string;
  source: string;
  lead_date: string;
  representative_name: string;
  contact_name: string;
  contact_number: string;
  first_appointment_date: string;
  contract_signed_date: string;
  status: string;
  total_amount: string;
}
