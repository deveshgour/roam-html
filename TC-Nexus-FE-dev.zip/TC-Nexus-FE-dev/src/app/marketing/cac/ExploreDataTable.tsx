import { DataTable } from '@/components/coreUI/table/dataTable';
import { useEffect, useState } from 'react';
import { PAGE_SIZE } from '@/constants/configs';
import { ExploreTableData } from '@/app/marketing/cac/types';
import { useMarketingCACContext } from '@/contexts/marketingCacContext';

function ExploreDataTable() {
  // A state variable to hold the data to be displayed in the table.
  const [users, setUsers] = useState<ExploreTableData[]>([]);
  const {
    exploreTableData,
    handleExplorePageSizeChange,
    explorePagination,
    handleExploreSortingChange,
    handleExplorePageChange,
    loading,
    exploreSorting,
    isFilterLoading,
  } = useMarketingCACContext();

  // An effect that runs when the `exploreTableData` changes.
  useEffect(() => {
    if (exploreTableData) {
      const users = exploreTableData.map((user: ExploreTableData) => ({
        id: user.id,
        source: user.source,
        lead_date: user.lead_date,
        representative_name: user.representative_name,
        contact_name: user.contact_name,
        contact_number: user.contact_number,
        first_appointment_date: user.first_appointment_date,
        contract_signed_date: user.contract_signed_date,
        status: user.status,
        total_amount: user.total_amount,
      }));
      // Set the state variable to the new data.
      setUsers(users);
    }
  }, [exploreTableData]);

  // The columns of the table.
  const columns = [
    {
      header: 'Lead Source',
      accessorKey: 'source',
      sortable: true,
    },

    {
      header: 'Lead Date',
      accessorKey: 'lead_date',
      sortable: true,
    },

    {
      header: 'Representative Name',
      accessorKey: 'representative_name',
      sortable: true,
    },

    {
      header: 'Contact Name',
      accessorKey: 'contact_name',
      sortable: true,
    },

    {
      header: 'Contact Number',
      accessorKey: 'contact_number',
      sortable: true,
    },

    {
      header: 'First Appointment',
      accessorKey: 'first_appointment_date',
      sortable: true,
    },

    {
      header: 'Contract Signed',
      accessorKey: 'contract_signed_date',
      sortable: true,
    },

    {
      header: 'Status',
      accessorKey: 'status',
      sortable: true,
    },

    {
      header: 'Total Amount',
      accessorKey: 'total_amount',
      sortable: true,
    },
  ];

  return (
    <>
      <DataTable
        loading={loading.exploreTable || isFilterLoading}
        showSkeleton={true}
        data={users}
        columns={columns}
        page={explorePagination.page}
        pageSize={explorePagination.pageSize}
        totalItems={explorePagination.total}
        onPageChange={(newPage: number) => handleExplorePageChange(newPage)}
        onPageSizeChange={(newPageSize: number) =>
          handleExplorePageSizeChange(newPageSize)
        }
        getRowId={(row) => row.id}
        pageSizeOptions={PAGE_SIZE}
        sorting={exploreSorting}
        onSortingChange={handleExploreSortingChange}
        showSearch={false}
        showPagination={true}
        scrollAreaClassName="h-[600px]"
        showPageSize={true}
      />
    </>
  );
}

export default ExploreDataTable;
