import { Button } from '@/components/coreUI/button';
import { DataTableWithCard } from '@/components/dataTableWithCard';
import { PAGE_SIZE } from '@/constants/configs';
import { useMarketingCACContext } from '@/contexts/marketingCacContext';
import { useEffect, useState } from 'react';
import { LeadSourceTableTransformData } from '@/app/marketing/cac/types';
import SourceDetailModal from '@/app/marketing/cac/SourceDetailModal';

function SourceDetailTable() {
  const {
    leadSourceTableData,
    loading,
    handleSourcePageChange,
    handleSourcePageSizeChange,
    sourcePagination,
    handleSortingChange,
    sorting,
    fetchSourceReport,
    handleSourceModal,
    isFilterLoading,
  } = useMarketingCACContext();
  const [users, setUsers] = useState<LeadSourceTableTransformData[]>([]);
  const [sourceDetailModalOpen, setSourceDetailModalOpen] = useState(false);
  const [sourceDetailModalTitle, setSourceDetailModalTitle] = useState('');

  useEffect(() => {
    if (Array.isArray(leadSourceTableData?.data)) {
      const users =
        leadSourceTableData.data.map((user) => ({
          id: user?.id,
          source: user?.source,
          marketing_spends: `$${user?.marketing_spends?.toLocaleString() || '0'}`,
          customers_acquired: user?.customers_acquired || 0,
          cac: `$${user?.cac?.toLocaleString() || '0'}`,
        })) || [];
      setUsers(users);
    }
  }, [leadSourceTableData]);

  const columns = [
    {
      header: 'Source',
      accessorKey: 'source',
      sortable: true,
      footer: () => <>Total</>,
    },
    {
      header: 'Marketing Cost',
      accessorKey: 'marketing_spends',
      sortable: true,
      footer: () =>
        `$${leadSourceTableData?.total?.marketing_spends.toLocaleString() || '0'}`,
    },
    {
      header: 'Customers',
      accessorKey: 'customers_acquired',
      sortable: true,
      footer: () => leadSourceTableData?.total?.customers_acquired || '0',
    },
    {
      header: 'CAC',
      accessorKey: 'cac',
      sortable: true,
      footer: () =>
        `$${leadSourceTableData?.total?.cac.toLocaleString() || '0'}`,
    },
  ];

  // Actions for each row
  const actions = [
    {
      label: 'View',
      onClick: (row: LeadSourceTableTransformData) => {
        if (!row) {
          console.error('Row data is undefined!');
          return;
        }
        setSourceDetailModalOpen(true);
        handleSourceModal(row?.source);
        setSourceDetailModalTitle(row?.source);
      },
    },
  ];

  return (
    <>
      <DataTableWithCard
        data={users}
        columns={columns}
        page={sourcePagination.page}
        pageSize={sourcePagination.pageSize}
        totalItems={sourcePagination.total}
        onPageChange={(newPage: number) => handleSourcePageChange(newPage)}
        onPageSizeChange={(newPageSize: number) =>
          handleSourcePageSizeChange(newPageSize)
        }
        actions={actions}
        showFooter={true}
        showTitle="Detailed Lead Source Performance"
        pageSizeOptions={PAGE_SIZE}
        cardClassName={`h-[500px]`}
        scrollAreaClassName="h-[360px]"
        skeletonClassName="h-[260px]"
        showPagination={true}
        showPageSize={true}
        isLoading={loading.leadSourceTable || isFilterLoading}
        sorting={sorting}
        onSortingChange={handleSortingChange}
        headerActions={
          users?.length > 0 ? (
            <Button
              variant="light"
              size="sm"
              className="px-4"
              onClick={() => fetchSourceReport()}
            >
              Export
            </Button>
          ) : null
        }
      />
      {sourceDetailModalOpen && (
        <SourceDetailModal
          open={sourceDetailModalOpen}
          onClose={() => {
            setSourceDetailModalOpen(false);
          }}
          title={sourceDetailModalTitle}
        />
      )}
    </>
  );
}

export default SourceDetailTable;
