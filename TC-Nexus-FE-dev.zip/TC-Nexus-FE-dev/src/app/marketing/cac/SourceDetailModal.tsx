import React, { useEffect, useState } from 'react';
import { DataTableWithCard } from '@/components/dataTableWithCard';
import { Button } from '@/components/coreUI/button';
import { PAGE_SIZE } from '@/constants/configs';
import Modal from '@/components/coreUI/dialog';
import { LeadSourceDetailData } from '@/app/marketing/cac/types';
import BarChart from '@/components/highCharts/BarChart';
import { useMarketingCACContext } from '@/contexts/marketingCacContext';

interface SourceJobDetailProps {
  open: boolean;
  onClose: () => void;
  title: string;
}

function SourceDetailModal({
  open = false,
  onClose = () => {},
  title,
}: SourceJobDetailProps) {
  const {
    loading,
    popupTooltipFormatter,
    barChartPopupData,
    sourceDetailModal,
    handleSourceViewPageChange,
    handleSourceViewPageSizeChange,
    handleSourceViewSortingChange,
    sourceViewPagination,
    isFilterLoading,
    fetchSourceViewReport,
    selectedSource,
    sourceViewSorting,
    setSourceViewSorting,
  } = useMarketingCACContext();
  const [users, setUsers] = useState<LeadSourceDetailData[]>([]);

  useEffect(() => {
    if (Array.isArray(sourceDetailModal)) {
      let users =
        sourceDetailModal.map((user: LeadSourceDetailData) => ({
          id: user?.id,
          customer: user?.customer,
          job_id: user?.job_id,
          job_name: user?.job_name,
          lead_date: user?.lead_date,
          contract_signed_date: user?.contract_signed_date,
          total_amount: user?.total_amount,
        })) || [];
      setUsers(users);
    }
  }, [sourceDetailModal]);

  useEffect(() => {
    if (open) {
      setSourceViewSorting({ field: '', direction: null }); // Reset sorting when modal opens
    }
  }, [open]);

  const columns = [
    {
      header: 'Customer',
      accessorKey: 'customer',
      sortable: true,
    },
    {
      header: 'Job Name',
      accessorKey: 'job_name',
      sortable: true,
    },
    {
      header: 'Lead Date',
      accessorKey: 'lead_date',
      sortable: true,
    },
    {
      header: 'Contract Signed Date',
      accessorKey: 'contract_signed_date',
      sortable: true,
    },
    {
      header: 'Total Amount',
      accessorKey: 'total_amount',
      sortable: true,
    },
  ];

  return (
    <>
      <Modal
        maxWidth="max-w-[1200px]"
        header={
          <span className="text-gray-800 font-normal text-xl">{title}</span>
        }
        open={open}
        onClose={onClose}
      >
        <div className="grid grid-cols-2 gap-4 h-[400px]">
          <div className="">
            <BarChart
              chartClassName="!bg-gray-50"
              isLoading={loading.barChartPopupData || isFilterLoading}
              tooltipFormatter={popupTooltipFormatter}
              showTimeFrameSelect={false}
              {...(barChartPopupData || {
                title: '',
                categories: [],
                series: [],
                type: 'column',
              })}
            />
          </div>
          <>
            <DataTableWithCard
              data={users}
              cardClassName="!bg-gray-50 w-full"
              scrollAreaClassName="h-[240px]  whitespace-nowrap"
              columns={columns}
              headerClassName="flex-nowrap !p-4"
              page={sourceViewPagination.page}
              pageSize={sourceViewPagination.pageSize}
              totalItems={sourceViewPagination.total}
              onPageChange={(newPage: number) =>
                handleSourceViewPageChange(newPage)
              }
              onPageSizeChange={(newPageSize: number) =>
                handleSourceViewPageSizeChange(newPageSize)
              }
              sorting={sourceViewSorting}
              onSortingChange={(field, direction) => {
                setSourceViewSorting({ field, direction }); // Update local sorting state
                handleSourceViewSortingChange(field, direction); // Call the original sorting change handler
              }}
              isLoading={loading?.sourceDetailTable || isFilterLoading}
              showFooter={false}
              showTitle="Customers"
              pageSizeOptions={PAGE_SIZE}
              showPagination={true}
              showPageSize={true}
              headerActions={
                users?.length > 0 ? (
                  <Button
                    variant="light"
                    size="sm"
                    onClick={() => fetchSourceViewReport(selectedSource)}
                  >
                    Export
                  </Button>
                ) : null
              }
            />
          </>
        </div>
      </Modal>
    </>
  );
}
export default SourceDetailModal;
