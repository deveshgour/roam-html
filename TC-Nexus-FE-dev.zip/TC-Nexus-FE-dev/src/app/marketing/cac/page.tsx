'use client';
import { Button } from '@/components/coreUI/button';
import Icon from '@/components/coreUI/icon';
import BarChart from '@/components/highCharts/BarChart';
import LineChart from '@/components/highCharts/LineChart';
import InfoCard from '@/components/infoCard';
import {
  MarketingCACProvider,
  useMarketingCACContext,
} from '@/contexts/marketingCacContext';
import { TimePeriod } from '@/types/common';
import { useEffect, useState } from 'react';
import SourceDetailTable from '@/app/marketing/cac/SourceDetailTable';
import { Location } from '@/app/marketing/cac/types';
import MultiSelect from '@/components/coreUI/multiSelect';
import DateRangePickerWithSidebar from '@/components/coreUI/dateRangePicker';
import ExploreDataTable from '@/app/marketing/cac/ExploreDataTable';

const CAC = () => {
  return (
    <MarketingCACProvider>
      <CACContent />
    </MarketingCACProvider>
  );
};

const CACContent = () => {
  const [selectedExploreData, setSelectedExploreData] = useState(false);
  const [menuIsOpen, setMenuIsOpen] = useState(false);
  const {
    infoCards,
    loading,
    barChartData,
    tooltipFormatter,
    trendChartData,
    labelsFormatter,
    secondaryLabelsFormatter,
    trendChartTimePeriod,
    setTrendChartTimePeriod,
    trendTooltipFormatter,
    sourceBarChartData,
    sourceTooltipFormatter,
    fetchExploreDownloadReport,
    fetchDownloadReport,
    updateFilters,
    filterOptions,
    filters,
    isFilterLoading,
    exploreTableData,
    fetchExploreData,
    hasAnyEmptyData,
    explorePagination,
    exploreSorting,
    handleExploreSortingChange,
  } = useMarketingCACContext();
  const toggleExploreData = () => {
    setSelectedExploreData((prev) => !prev);
  };

  useEffect(
    () => {
      if (selectedExploreData) {
        fetchExploreData(
          explorePagination.page,
          Number(exploreSorting.field),
          exploreSorting.field,
          exploreSorting.direction
        );
      } else {
        handleExploreSortingChange('', null);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [selectedExploreData, explorePagination.page]
  );
  return (
    <>
      <div className="flex items-center gap-2 flex-wrap">
        <div className="w-64 block">
          <DateRangePickerWithSidebar
            value={filters?.dateRange}
            onPrimaryBtnClick={(date) =>
              updateFilters({ ...filters, dateRange: date })
            }
            onClearBtnClick={() =>
              updateFilters({ ...filters, dateRange: [null, null] })
            }
            monthOnlyView
          />
        </div>
        <div className="relative max-w-80 min-w-56">
          <MultiSelect
            backgroundColor="rgb(var(--color-gray-50))"
            menuIsOpen={menuIsOpen}
            setMenuIsOpen={setMenuIsOpen}
            options={(filterOptions?.locations || [])
              .map((location: Location) => ({
                value: location?.id?.toString(),
                label: location?.name,
              }))
              .sort((a, b) => a.label.localeCompare(b.label))}
            value={
              Array.isArray(filters?.location)
                ? filters?.location?.map((id) => ({
                    value: id,
                    label:
                      filterOptions?.locations?.find(
                        (loc) => loc?.id?.toString() === id
                      )?.name || '',
                  }))
                : []
            }
            isDisabled={false}
            size="md"
            onChange={(selected) => {
              updateFilters({
                ...filters,
                location: Array.isArray(selected)
                  ? selected?.map((item) => item?.value?.toString())
                  : [],
              });
            }}
            placeholder="All Locations"
            icon="mapPin"
            showCheckbox={true}
          />
        </div>
        <div className="md:ml-auto gap-2 flex">
          {/* Toggle between Trend Visualization and Explore Data */}
          <Button
            variant={selectedExploreData ? 'primary' : 'outlineLight'}
            className="h-10"
            onClick={toggleExploreData}
            icon={
              <Icon
                iconName={selectedExploreData ? 'lineChart' : 'table'}
                iconProps={{ className: '' }}
              />
            }
          >
            {/* Text to be displayed on the button. Trend Visualization if selectedExploreData is true, else Explore Data */}
            {selectedExploreData ? 'Trend Visualization' : 'Explore Data'}
          </Button>
          {/* Export button */}
          <Button
            variant="outlineLight"
            className="h-10"
            onClick={
              selectedExploreData
                ? fetchExploreDownloadReport
                : fetchDownloadReport
            }
            icon={
              <Icon
                iconName="export"
                iconProps={{ className: '!w-5 !h-5 text-gray-600' }}
              />
            }
            disabled={
              selectedExploreData ? !exploreTableData?.length : !hasAnyEmptyData
            }
          >
            {/* Text to be displayed on the button. Export */}
            Export
          </Button>
        </div>
      </div>
      {selectedExploreData ? (
        <div>
          {/* Explore Data Table */}
          <ExploreDataTable />
        </div>
      ) : (
        <>
          {/* ... start info cards ... */}
          <div className="grid gap-5 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            {loading?.infoCards || isFilterLoading
              ? Array.from({ length: 3 }).map((_, index) => (
                  <InfoCard key={index} isLoading={true} />
                ))
              : infoCards?.map((card, index) => (
                  <InfoCard key={index} {...card} />
                ))}
          </div>
          {/* ... existing info cards ... */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-5">
            <BarChart
              isLoading={loading.barChart}
              tooltipFormatter={tooltipFormatter}
              showTimeFrameSelect={false}
              height={350}
              {...(barChartData || {
                title: '',
                categories: [],
                series: [],
                type: 'column',
              })}
            />
            <LineChart
              {...(trendChartData || {
                title: '',
                categories: [],
                series: [],
                type: 'spline' as const,
              })}
              defaultTimeFrame={trendChartTimePeriod}
              onTimeFrameChange={(value) =>
                setTrendChartTimePeriod(value as TimePeriod)
              }
              height={350}
              isLoading={loading.trendLineChart || isFilterLoading}
              itemMarginBottom={30}
              labelsFormatter={labelsFormatter}
              secondaryLabelsFormatter={secondaryLabelsFormatter}
              tooltipFormatter={trendTooltipFormatter}
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-5">
            <BarChart
              isLoading={loading.sourceBarChart || isFilterLoading}
              showTimeFrameSelect={false}
              {...(sourceBarChartData || {
                title: '',
                categories: [],
                series: [],
                type: 'bar',
              })}
              height={400}
              labelsFormatter={secondaryLabelsFormatter}
              tooltipFormatter={sourceTooltipFormatter}
            />
            <SourceDetailTable />
          </div>
        </>
      )}
    </>
  );
};

export default CAC;
