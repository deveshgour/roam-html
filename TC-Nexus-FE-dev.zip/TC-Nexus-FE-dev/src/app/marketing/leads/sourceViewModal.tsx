import React, { useEffect, useState } from 'react';
import { DataTableWithCard } from '@/components/dataTableWithCard';
import { Button } from '@/components/coreUI/button';
import { PAGE_SIZE, SORTING_TYPES } from '@/constants/configs';
import Modal from '@/components/coreUI/dialog';
import { TransformSourceDetail } from '@/hooks/useMarketingLeads';
import LineChart from '@/components/highCharts/LineChart';
import { TimePeriod } from '@/types/common';

/**
 * Interface representing a row in the source detail table.
 */
interface SourceDetail {
  /**
   * The ID of the source detail.
   */
  id: string;
  /**
   * The job name of the source detail.
   */
  job_name: string;
  /**
   * The customer of the source detail.
   */
  customer: string;
  /**
   * The total amount of the source detail.
   */
  total_amount: string;
}

/**
 * Interface representing the selected chart data.
 *
 * @property {string} category - The category of the selected chart data.
 * @property {string} funnel_type - The funnel type of the selected chart data.
 */
interface SelectedChartData {
  category: string;
  funnel_type: string;
}

/**
 * Interface representing the sorting state.
 */
interface SortingState {
  /**
   * The field to sort by.
   */
  field: string;
  /**
   * The direction to sort in.
   * Can be 'asc' for ascending, 'desc' for descending, or null for no sorting.
   */
  direction: (typeof SORTING_TYPES.ASC)[keyof typeof SORTING_TYPES.DESC] | null;
}

/**
 * Type representing the direction of a sorting.
 * Can be 'asc' for ascending, 'desc' for descending, or null for no sorting.
 */
type SortingDirection = 'asc' | 'desc' | null;

/**
 * Props interface for SourceDetailTable component
 */
interface SourceJobDetailProps {
  sourceDetailTableData: {
    data: TransformSourceDetail[];
  } | null;
  sourceDetailPagination: {
    page: number;
    pageSize: number;
    total: number;
  };
  open: boolean;
  onClose: () => void;
  handleSourceDetailPageChange: (
    // eslint-disable-next-line no-unused-vars
    page: number
  ) => void;
  handleSourceDetailPageSizeChange: (
    // eslint-disable-next-line no-unused-vars
    pageSize: number
  ) => void;
  sorting: SortingState;
  handleSourceDetailSortingChange: (
    // eslint-disable-next-line no-unused-vars
    field: string,
    // eslint-disable-next-line no-unused-vars
    direction: SortingDirection
  ) => void;
  tooltipFormatter?: () => string;
  modalViewTooltipFormatter?: () => string;
  labelsFormatter?: () => string;
  loadingStates?: {
    modalViewFunnelChart: boolean;
    leadSourceDetailTable: boolean;
  };
  handleModalResetFilter: () => void;
  selectedRowData?: { source: string } | undefined;
  onPointClick?: (
    // eslint-disable-next-line no-unused-vars
    event: any,
    // eslint-disable-next-line no-unused-vars
    point: any
  ) => void;
  // eslint-disable-next-line no-unused-vars
  fetchSourceDetailReport?: (source: string) => void;
  modalViewFunnelChartTimePeriod?: string;
  modalViewFunnelChartData?: {
    title: string;
    type: string;
    categories: string[];
    series: any[];
  } | null;
  setModalViewFunnelChartTimePeriod?: (
    // eslint-disable-next-line no-unused-vars
    value: TimePeriod
  ) => void;
}

const SourceViewModal = ({
  open = false,
  onClose = () => {},
  sourceDetailTableData,
  sourceDetailPagination,
  selectedRowData = { source: '' },
  loadingStates,
  modalViewFunnelChartData,
  modalViewTooltipFormatter,
  labelsFormatter,
  handleSourceDetailPageChange,
  handleSourceDetailPageSizeChange,
  sorting,
  handleSourceDetailSortingChange,
  onPointClick,
  handleModalResetFilter,
  fetchSourceDetailReport,
  modalViewFunnelChartTimePeriod,
  setModalViewFunnelChartTimePeriod,
}: SourceJobDetailProps) => {
  const [users, setUsers] = useState<SourceDetail[]>([]);

  const [selectedChartData, setSelectedChartData] = useState<SelectedChartData>(
    {
      category: 'All',
      funnel_type: 'Detail',
    }
  );

  useEffect(() => {
    if (sourceDetailTableData) {
      let users = sourceDetailTableData?.data?.map(
        (user: TransformSourceDetail) => ({
          id: user?.id,
          customer: user?.customer,
          job_name: user?.job_name,
          total_amount: String(user?.total_amount),
        })
      );
      setUsers(users);
    }
  }, [sourceDetailTableData]);

  const columns = [
    {
      header: 'Job Name',
      accessorKey: 'job_name',
      sortable: true,
    },
    {
      header: 'Customer',
      accessorKey: 'customer',
      sortable: true,
    },
    {
      header: 'Total',
      accessorKey: 'total_amount',
      sortable: true,
    },
  ];

  return (
    <>
      <Modal
        maxWidth="max-w-[1200px]"
        header={
          <>
            <span className="text-gray-800 font-normal text-xl">
              Sales Funnel - {selectedRowData?.source}
            </span>
          </>
        }
        open={open}
        onClose={onClose}
      >
        <div className="grid grid-cols-2 gap-4 h-[400px]">
          <div className="">
            <LineChart
              chartClassName="!bg-gray-50"
              {...(modalViewFunnelChartData || {
                title: '',
                categories: [],
                series: [],
                type: '',
              })}
              defaultTimeFrame={modalViewFunnelChartTimePeriod}
              onTimeFrameChange={(value) => {
                if (setModalViewFunnelChartTimePeriod) {
                  setModalViewFunnelChartTimePeriod(value as TimePeriod);
                }
              }}
              height={300}
              isLoading={loadingStates?.modalViewFunnelChart}
              itemMarginBottom={30}
              tooltipFormatter={modalViewTooltipFormatter}
              labelsFormatter={labelsFormatter}
              onClick={(event) => {
                onPointClick && onPointClick(event, 'sourceDetailModal');
                setSelectedChartData({
                  category: event?.point?.category,
                  funnel_type: event?.point?.series?.name,
                });
              }}
              yAxisTickInterval={50}
            />
          </div>
          <>
            <DataTableWithCard
              data={users}
              cardClassName="!bg-gray-50 "
              scrollAreaClassName="h-[240px]"
              columns={columns}
              headerClassName="flex-nowrap !p-4"
              page={sourceDetailPagination.page}
              pageSize={sourceDetailPagination.pageSize}
              totalItems={sourceDetailPagination.total} // Total number of items in your database
              onPageChange={(newPage: number) =>
                handleSourceDetailPageChange(newPage)
              }
              onPageSizeChange={(newPageSize: number) =>
                handleSourceDetailPageSizeChange(newPageSize)
              }
              sorting={sorting}
              onSortingChange={handleSourceDetailSortingChange}
              isLoading={loadingStates?.leadSourceDetailTable}
              showFooter={false}
              showTitle={
                <div className="flex items-center gap-2 w-full justify-between">
                  <span>
                    {selectedChartData?.category} -
                    <span className="ml-1">
                      {selectedChartData?.funnel_type}
                    </span>
                  </span>
                </div>
              }
              pageSizeOptions={PAGE_SIZE}
              showPagination={true}
              showPageSize={true}
              headerActions={
                <>
                  <Button
                    variant="light"
                    size="sm"
                    onClick={() => {
                      handleModalResetFilter();
                      setSelectedChartData({
                        category: 'All',
                        funnel_type: 'Detail',
                      });
                    }}
                  >
                    Reset Filter
                  </Button>
                  {users?.length > 0 ? (
                    <Button
                      variant="light"
                      size="sm"
                      onClick={() =>
                        fetchSourceDetailReport?.(selectedRowData?.source)
                      }
                    >
                      Export
                    </Button>
                  ) : null}
                </>
              }
            />
          </>
        </div>
      </Modal>
    </>
  );
};
export default SourceViewModal;
