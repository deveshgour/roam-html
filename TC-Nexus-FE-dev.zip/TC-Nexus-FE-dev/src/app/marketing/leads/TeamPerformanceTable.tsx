import React, { useEffect, useState } from 'react';
import { Button } from '@/components/coreUI/button';
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from '@/components/coreUI/avatar';
import { DataTableWithCard } from '@/components/dataTableWithCard';
import { PAGE_SIZE, SORTING_TYPES } from '@/constants/configs';
import { TransformedTeamPerformance } from '@/hooks/useMarketingLeads';

/**
 * Interface representing a row in the team performance table.
 */
interface TeamPerformance {
  /**
   * Unique identifier for the row.
   */
  id: string;
  /**
   * The sales representative's name, initials and avatar.
   */
  sales_rep: React.ReactNode;
  /**
   * The number of doors knocked.
   */
  doors_knocked: number;
  /**
   * The number of homes canvassed.
   */
  homes_canvassed: number;
  /**
   * The number of leads generated.
   */
  leads_generated: number;
  /**
   * The number of appointments booked.
   */
  appointments_booked: number;
  /**
   * The number of insurance claims filed.
   */
  insurance_claims_filed: number;
  /**
   * The number of adjuster meetings attended.
   */
  adjuster_meetings_attented: number;
  /**
   * The number of followup appointments.
   */
  followup_appointments: number;
  /**
   * The total number of sales made.
   */
  sold: number;
  /**
   * The conversion rate as a percentage.
   */
  conversion_rate: string;
}

interface SortingState {
  field: string;
  direction: (typeof SORTING_TYPES.ASC)[keyof typeof SORTING_TYPES.DESC] | null;
}

type SortingDirection = 'asc' | 'desc' | null;

/**
 * Props interface for SalesRepTable component
 */
interface TeamPerformanceTableProps {
  teamPerformanceTableData: {
    representatives: TransformedTeamPerformance[];
    total: {
      doors_knocked: number;
      homes_canvassed: number;
      leads_generated: number;
      appointments_booked: number;
      insurance_claims_filed: number;
      adjuster_meetings_attented: number;
      followup_appointments: number;
      sold: number;
      conversion_rate: number;
    };
  } | null;
  performancePagination: {
    page: number;
    pageSize: number;
    total: number;
  };
  isLoading: boolean;
  // eslint-disable-next-line no-unused-vars
  handlePageChange: (page: number) => void;
  // eslint-disable-next-line no-unused-vars
  handlePageSizeChange: (pageSize: number) => void;
  sorting: SortingState;
  handleSortingChange: (
    // eslint-disable-next-line no-unused-vars
    field: string,
    // eslint-disable-next-line no-unused-vars
    direction: SortingDirection
  ) => void;
  fetchPerformanceReport: () => void;
}

/**
 * Component for displaying a table of sales representatives.
 */
function TeamPerformanceTable({
  teamPerformanceTableData,
  performancePagination,
  handlePageChange,
  handlePageSizeChange,
  sorting,
  isLoading = false,
  handleSortingChange,
  fetchPerformanceReport,
}: TeamPerformanceTableProps) {
  const [users, setUsers] = useState<TeamPerformance[]>([]);

  useEffect(() => {
    if (teamPerformanceTableData) {
      let users = teamPerformanceTableData.representatives.map(
        (user: TransformedTeamPerformance) => ({
          id: user?.id,
          sales_rep: (
            <div className="flex items-center gap-x-2" key={user.id}>
              <Avatar>
                <AvatarImage src={user.sales_rep.avatar} />
                <AvatarFallback>{user.sales_rep.initials}</AvatarFallback>
              </Avatar>
              {user.sales_rep.name}
            </div>
          ),
          doors_knocked: user?.doors_knocked,
          homes_canvassed: user?.homes_canvassed,
          leads_generated: user?.leads_generated,
          appointments_booked: user?.appointments_booked,
          insurance_claims_filed: user?.insurance_claims_filed,
          adjuster_meetings_attented: user?.adjuster_meetings_attented,
          followup_appointments: user?.followup_appointments,
          sold: user?.sold,
          conversion_rate: user?.conversion_rate,
        })
      );
      setUsers(users);
    }
  }, [teamPerformanceTableData]);

  const columns = [
    {
      header: 'Sales Rep',
      accessorKey: 'sales_rep',
      sortable: true,
      footer: () => <>Total</>,
    },
    {
      header: 'Doors Knocked',
      accessorKey: 'doors_knocked',
      sortable: true,
      footer: () =>
        teamPerformanceTableData?.total?.doors_knocked?.toString() || 0,
    },
    {
      header: 'Homes Canvassed',
      accessorKey: 'homes_canvassed',
      sortable: true,
      footer: () =>
        teamPerformanceTableData?.total?.homes_canvassed?.toString() || 0,
    },
    {
      header: 'Leads Generated',
      accessorKey: 'leads_generated',
      sortable: true,
      footer: () =>
        teamPerformanceTableData?.total?.leads_generated?.toString() || 0,
    },
    {
      header: 'Appointments Booked',
      accessorKey: 'appointments_booked',
      sortable: true,
      footer: () =>
        teamPerformanceTableData?.total?.appointments_booked?.toString() || 0,
    },
    {
      header: 'Insurance Claims Filed',
      accessorKey: 'insurance_claims_filed',
      sortable: true,
      footer: () =>
        teamPerformanceTableData?.total.insurance_claims_filed?.toString() || 0,
    },
    {
      header: 'Adjuster Meetings attended',
      accessorKey: 'adjuster_meetings_attented',
      sortable: true,
      footer: () =>
        teamPerformanceTableData?.total?.adjuster_meetings_attented?.toString() ||
        0,
    },
    {
      header: 'Follow Up Appointments',
      accessorKey: 'followup_appointments',
      sortable: true,
      footer: () =>
        teamPerformanceTableData?.total.followup_appointments?.toString() || 0,
    },
    {
      header: 'Sold',
      accessorKey: 'sold',
      sortable: true,
      footer: () => teamPerformanceTableData?.total.sold?.toString() || 0,
    },
    {
      header: 'Conversion Rate (%)',
      accessorKey: 'conversion_rate',
      sortable: true,
      footer: () =>
        `${teamPerformanceTableData?.total.conversion_rate?.toFixed(2)}%` ||
        '0%',
    },
  ];

  return (
    <>
      <DataTableWithCard
        data={users}
        columns={columns}
        page={performancePagination.page}
        pageSize={performancePagination.pageSize}
        totalItems={performancePagination.total} // Total number of items in your database
        onPageChange={(newPage: number) => handlePageChange(newPage)}
        onPageSizeChange={(newPageSize: number) =>
          handlePageSizeChange(newPageSize)
        }
        showFooter={true}
        showTitle="Team Performance"
        pageSizeOptions={PAGE_SIZE}
        scrollAreaClassName="h-[360px]"
        showPagination={true}
        showPageSize={true}
        isLoading={isLoading}
        sorting={sorting}
        onSortingChange={handleSortingChange}
        headerActions={
          users?.length > 0 ? (
            <Button
              variant="light"
              className="px-6"
              size="sm"
              onClick={() => fetchPerformanceReport()}
            >
              Export
            </Button>
          ) : null
        }
      />
    </>
  );
}

export default TeamPerformanceTable;
