'use client';
import { Button } from '@/components/coreUI/button';
import DateRangePickerWithSidebar from '@/components/coreUI/dateRangePicker';
import Icon from '@/components/coreUI/icon';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/coreUI/select';
import {
  SalesRep,
  useMarketingLeads,
  Location,
} from '@/hooks/useMarketingLeads';
import SourceDetailTable from '@/app/marketing/leads/SourceDetailTable';
import TeamPerformanceTable from '@/app/marketing/leads/TeamPerformanceTable';
import LineChart from '@/components/highCharts/LineChart';
import { useEffect, useState } from 'react';
import ExploreDataTable from '@/app/marketing/leads/ExploreDataTable';
import { TimePeriod } from '@/types/common';
import MultiSelect from '@/components/coreUI/multiSelect';
import InfoCard from '@/components/infoCard';

const LeadsConversion = () => {
  const {
    filterOptions,
    filters,
    updateFilters,
    loadingStates,
    funnelChartTimePeriod,
    setFunnelChartTimePeriod,
    sourceDetailPagination,
    performancePagination,
    sourcePagination,
    infoCardsData,
    teamPerformanceTableData,
    leadSourceTableData,
    sourceDetailTableData,
    funnelChartData,
    modalViewFunnelChartData,
    exploreTableData,
    explorePagination,
    handleExplorePageChange,
    handleExplorePageSizeChange,
    handleExploreSortingChange,
    tooltipFormatter,
    labelsFormatter,
    handleSourcePageChange,
    handlePerformancePageChange,
    handlePageSizeChange,
    handleSourcePageSizeChange,
    handleSourceDetailPageSizeChange,
    sorting,
    handleSortingChange,
    handleSourceSortingChange,
    fetchSourceReport,
    fetchPerformanceReport,
    onPointClick,
    handleResetFilter,
    handleFunnelChartDetail,
    handleModalResetFilter,
    handleSourceDetailPageChange,
    setModalViewFunnelChartTimePeriod,
    modalViewFunnelChartTimePeriod,
    fetchSourceDetailReport,
    fetchDownloadReport,
    fetchExportDownloadReport,
    fetchExploreData,
    hasAnyEmptyData,
    modalViewTooltipFormatter,
    isFilterLoading,
    handleSourceDetailSortingChange,
    exploreSorting,
  } = useMarketingLeads();

  const [selectKey, setSelectKey] = useState(0);
  const [selectedExploreData, setSelectedExploreData] = useState(false);
  const [menuIsOpen, setMenuIsOpen] = useState(false);

  const toggleExploreData = () => {
    setSelectedExploreData((prev) => !prev);
  };

  useEffect(
    () => {
      if (selectedExploreData) {
        fetchExploreData(
          explorePagination.page,
          Number(exploreSorting.field),
          exploreSorting.field,
          exploreSorting.direction
        );
      } else {
        handleExploreSortingChange('', null);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [selectedExploreData, explorePagination.page]
  );

  return (
    <>
      <div className="flex items-center gap-2 flex-wrap">
        <div className="w-64 block">
          <DateRangePickerWithSidebar
            value={filters?.dateRange}
            onPrimaryBtnClick={(date) =>
              updateFilters({ ...filters, dateRange: date })
            }
            onClearBtnClick={() =>
              updateFilters({ ...filters, dateRange: [null, null] })
            }
          />
        </div>
        <div className="relative">
          <Select
            key={selectKey}
            value={filters?.location?.toString()}
            onValueChange={(value) =>
              updateFilters({ ...filters, location: value })
            }
            onOpenChange={() => setMenuIsOpen(false)}
          >
            {filters?.location && (
              <span
                className="z-10 pointer-events-auto py-3 px-1.5 absolute right-7 cursor-pointer hover:opacity-70"
                onClick={(e) => {
                  e.stopPropagation();
                  updateFilters({ ...filters, location: '' });
                  setSelectKey((prev) => prev + 1);
                }}
              >
                <Icon
                  iconName="cross"
                  iconProps={{ className: '!w-4 !h-4 text-red-600' }}
                />
              </span>
            )}
            <SelectTrigger
              innerSelectedValue="max-w-[160px]"
              icon={
                <Icon
                  iconName="mapPin"
                  iconProps={{ className: 'text-gray-600' }}
                />
              }
              className="min-w-48 max-w-60"
            >
              <SelectValue placeholder="All Locations" />
            </SelectTrigger>
            <SelectContent>
              {filterOptions?.locations
                .sort((a, b) => a?.name?.localeCompare(b?.name))
                .map((location: Location) => (
                  <SelectItem
                    key={location?.id}
                    value={location?.id?.toString()}
                  >
                    {location?.name}
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>
        </div>
        <div className="relative max-w-80 min-w-56">
          <MultiSelect
            backgroundColor="rgb(var(--color-gray-50))"
            menuIsOpen={menuIsOpen}
            setMenuIsOpen={setMenuIsOpen}
            options={filterOptions?.salesReps
              ?.map((rep: SalesRep) => ({
                value: rep?.id?.toString(),
                label: rep?.name,
              }))
              .sort((a, b) => a.label.localeCompare(b.label))}
            value={
              Array.isArray(filters?.salesRep)
                ? filters?.salesRep?.map((id) => ({
                    value: id,
                    label:
                      filterOptions?.salesReps?.find(
                        (rep) => rep?.id?.toString() === id
                      )?.name || '',
                  }))
                : []
            }
            isDisabled={false}
            size="md"
            onChange={(selected) => {
              updateFilters({
                ...filters,
                salesRep: Array.isArray(selected)
                  ? selected?.map((item) => item?.value?.toString())
                  : [],
              });
            }}
            placeholder="All Sales Rep"
            icon="user"
            showCheckbox={true}
          />
        </div>
        <div className="lg:ml-auto gap-2 flex">
          {/* Toggle between Trend Visualization and Explore Data */}
          <Button
            variant={selectedExploreData ? 'primary' : 'outlineLight'}
            className="h-10"
            onClick={toggleExploreData}
            icon={
              <Icon
                iconName={selectedExploreData ? 'lineChart' : 'table'}
                iconProps={{ className: '' }}
              />
            }
          >
            {/* Text to be displayed on the button. Trend Visualization if selectedExploreData is true, else Explore Data */}
            {selectedExploreData ? 'Trend Visualization' : 'Explore Data'}
          </Button>
          {/* Export button */}
          <Button
            variant="outlineLight"
            className="!py-2.5"
            onClick={
              selectedExploreData
                ? fetchExportDownloadReport
                : fetchDownloadReport
            }
            disabled={
              selectedExploreData ? !exploreTableData?.length : !hasAnyEmptyData
            }
            icon={
              <Icon
                iconName="export"
                iconProps={{ className: '!w-5 !h-5 text-gray-600' }}
              />
            }
          >
            {/* Text to be displayed on the button. Export */}
            Export
          </Button>
        </div>
      </div>
      {selectedExploreData ? (
        <div>
          {/* Explore Data Table */}
          <ExploreDataTable
            exploreTableData={exploreTableData}
            explorePagination={explorePagination}
            handleExplorePageChange={handleExplorePageChange}
            handleExplorePageSizeChange={handleExplorePageSizeChange}
            isLoading={loadingStates.exploreTable || isFilterLoading}
            exploreSorting={exploreSorting}
            handleExploreSortingChange={handleExploreSortingChange}
          />
        </div>
      ) : (
        <>
          <div className="grid gap-5 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5">
            {loadingStates?.infoCards || isFilterLoading
              ? Array.from({ length: 10 }).map((_, index) => (
                  <InfoCard key={index} isLoading={true} />
                ))
              : infoCardsData?.map((card, index) => (
                  <InfoCard key={index} {...card} />
                ))}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-5">
            <LineChart
              {...(funnelChartData || {
                title: '',
                type: 'line',
                categories: [],
                series: [],
              })}
              defaultTimeFrame={funnelChartTimePeriod}
              onTimeFrameChange={(value) =>
                setFunnelChartTimePeriod(value as TimePeriod)
              }
              height={350}
              isLoading={loadingStates.funnelChart || isFilterLoading}
              itemMarginBottom={50}
              tooltipFormatter={tooltipFormatter}
              labelsFormatter={labelsFormatter}
              onClick={(event) =>
                onPointClick.call(this, event, 'leadSourceTable')
              }
              yAxisTickInterval={50}
            />

            <SourceDetailTable
              sourcePagination={sourcePagination}
              sourceDetailPagination={sourceDetailPagination}
              handleSourcePageChange={handleSourcePageChange}
              handleSourcePageSizeChange={handleSourcePageSizeChange}
              handleSourceDetailPageSizeChange={
                handleSourceDetailPageSizeChange
              }
              loadingStates={loadingStates}
              isFilterLoading={isFilterLoading}
              sorting={sorting}
              handleSourceDetailSortingChange={handleSourceDetailSortingChange}
              handleSourceSortingChange={handleSourceSortingChange}
              leadSourceTableData={leadSourceTableData}
              fetchSourceReport={fetchSourceReport}
              handleResetFilter={handleResetFilter}
              sourceDetailTableData={sourceDetailTableData || { data: [] }}
              handleFunnelChartDetail={handleFunnelChartDetail}
              handleModalResetFilter={handleModalResetFilter}
              modalViewFunnelChartData={modalViewFunnelChartData}
              modalViewFunnelChartTimePeriod={modalViewFunnelChartTimePeriod}
              setModalViewFunnelChartTimePeriod={
                setModalViewFunnelChartTimePeriod
              }
              tooltipFormatter={tooltipFormatter}
              modalViewTooltipFormatter={modalViewTooltipFormatter}
              labelsFormatter={labelsFormatter}
              onPointClick={onPointClick}
              handleSourceDetailPageChange={handleSourceDetailPageChange}
              fetchSourceDetailReport={fetchSourceDetailReport}
            />
          </div>
          <div className="grid grid-cols-1 text-center">
            <TeamPerformanceTable
              performancePagination={performancePagination}
              handlePageChange={handlePerformancePageChange}
              handlePageSizeChange={handlePageSizeChange}
              isLoading={loadingStates.teamPerformanceTable || isFilterLoading}
              teamPerformanceTableData={teamPerformanceTableData}
              sorting={sorting}
              handleSortingChange={handleSortingChange}
              fetchPerformanceReport={fetchPerformanceReport}
            />
          </div>
        </>
      )}
    </>
  );
};

export default LeadsConversion;
