import React, { useEffect, useState } from 'react';
import { Button } from '@/components/coreUI/button';
import { DataTableWithCard } from '@/components/dataTableWithCard';
import {
  PAGE_SIZE,
  SORTING_TYPES,
  TIME_PERIOD_TYPES,
} from '@/constants/configs';
import SourceViewModal from '@/app/marketing/leads/sourceViewModal';
import {
  TransformLeadSource,
  TransformSourceDetail,
} from '@/hooks/useMarketingLeads';
import { SortingTypes, TimePeriod } from '@/types/common';

/**
 * Interface representing a SalesRep.
 */
interface LeadSource {
  id: string;
  source: string;
  leads_generated: number;
  appointments: number;
  sold: number;
  conversion_rate: string;
}

interface SortingState {
  field: string;
  direction: (typeof SORTING_TYPES.ASC)[keyof typeof SORTING_TYPES.DESC] | null;
}

type SortingDirection = 'asc' | 'desc' | null;

/**
 * Props interface for SourceDetailTable component
 */
interface SourceDetailTableProps {
  leadSourceTableData: {
    data: TransformLeadSource[];
    total: {
      leads_generated: number;
      appointments: number;
      sold: number;
      conversion_rate: number;
    };
  } | null;
  sourcePagination: {
    page: number;
    pageSize: number;
    total: number;
  };
  sourceDetailPagination: {
    page: number;
    pageSize: number;
    total: number;
  };
  loadingStates: {
    filterOptions: boolean;
    infoCards: boolean;
    teamPerformanceTable: boolean;
    funnelChart: boolean;
    leadSourceTable: boolean;
    leadSourceDetailTable: boolean;
    modalViewFunnelChart: boolean;
    sourceDetailTable: boolean;
  };
  isFilterLoading: boolean;
  // showTitle?: React.ReactNode;
  headerClassName?: string;
  cardClassName?: string;
  // eslint-disable-next-line no-unused-vars
  handleSourcePageChange: (page: number) => void;
  // eslint-disable-next-line no-unused-vars
  handleSourceDetailPageChange: (page: number) => void;
  // eslint-disable-next-line no-unused-vars
  handleSourcePageSizeChange: (pageSize: number) => void;
  // eslint-disable-next-line no-unused-vars
  handleSourceDetailPageSizeChange: (pageSize: number) => void;
  sorting: SortingState;
  fetchSourceReport: () => void;
  handleResetFilter: () => void;
  handleModalResetFilter: () => void;
  handleSourceDetailSortingChange: (
    // eslint-disable-next-line no-unused-vars
    field: string,
    // eslint-disable-next-line no-unused-vars
    direction: SortingDirection
  ) => void;
  sourceDetailTableData: {
    data: TransformSourceDetail[];
  };
  // eslint-disable-next-line no-unused-vars
  handleSourceSortingChange: (field: string, direction: SortingTypes) => void;
  // eslint-disable-next-line no-unused-vars
  handleFunnelChartDetail: (timePeriod?: TimePeriod, source?: string) => void;
  fetchSourceDetailReport?: () => void;
  // eslint-disable-next-line no-unused-vars
  onPointClick?: (event: any, point: any) => void;
  modalViewFunnelChartTimePeriod?: string;
  modalViewFunnelChartData?: {
    title: string;
    type: string;
    categories: string[];
    series: any[];
  } | null;
  // eslint-disable-next-line no-unused-vars
  setModalViewFunnelChartTimePeriod?: (value: TimePeriod) => void;
  tooltipFormatter?: () => string;
  modalViewTooltipFormatter?: () => string;
  labelsFormatter?: () => string;
}
/**
 * Component for displaying a table of sales representatives.
 */
function SourceDetailTable({
  leadSourceTableData,
  sourcePagination,
  sourceDetailPagination,
  handleSourcePageChange,
  handleSourcePageSizeChange,
  handleSourceDetailPageChange,
  handleSourceDetailPageSizeChange,
  // showTitle,
  headerClassName,
  cardClassName,
  sorting,
  loadingStates,
  fetchSourceReport,
  handleResetFilter,
  handleFunnelChartDetail,
  handleModalResetFilter,
  sourceDetailTableData,
  onPointClick,
  modalViewFunnelChartData,
  fetchSourceDetailReport,
  modalViewFunnelChartTimePeriod,
  setModalViewFunnelChartTimePeriod,
  tooltipFormatter,
  modalViewTooltipFormatter,
  labelsFormatter,
  handleSourceSortingChange,
  handleSourceDetailSortingChange,
  isFilterLoading,
}: SourceDetailTableProps) {
  const [users, setUsers] = useState<LeadSource[]>([]);
  const [sourceDetailModalOpen, setSourceDetailModalOpen] = useState(false);
  const [selectedRowData, setSelectedRowData] = useState<
    TransformLeadSource | undefined
  >(undefined);

  useEffect(() => {
    if (leadSourceTableData) {
      let users = leadSourceTableData?.data?.map(
        (user: TransformLeadSource) => ({
          id: user?.id,
          source: user?.source,
          leads_generated: user?.leads_generated,
          appointments: user?.appointments,
          sold: user?.sold,
          conversion_rate: String(user?.conversion_rate),
        })
      );
      setUsers(users);
    }
  }, [leadSourceTableData]);

  const columns = [
    {
      header: 'Source',
      accessorKey: 'source',
      sortable: true,
      footer: () => <>Total</>,
    },
    {
      header: 'Leads',
      accessorKey: 'leads_generated',
      sortable: true,
      footer: () =>
        leadSourceTableData?.total?.leads_generated?.toString() || 0,
    },
    {
      header: 'Appointments',
      accessorKey: 'appointments',
      sortable: true,
      footer: () => leadSourceTableData?.total?.appointments?.toString() || 0,
    },
    {
      header: 'Sold',
      accessorKey: 'sold',
      sortable: true,
      footer: () => leadSourceTableData?.total?.sold?.toString() || 0,
    },
    {
      header: 'Conversion Rate',
      accessorKey: 'conversion_rate',
      sortable: true,
      footer: () =>
        `${leadSourceTableData?.total.conversion_rate?.toFixed(2)}%` || '0%',
    },
  ];

  // Actions for each row
  const actions = [
    {
      label: 'View',
      onClick: (row: TransformLeadSource) => {
        if (!row) {
          console.error('Row data is undefined!');
          return;
        }
        setSourceDetailModalOpen(true);
        handleFunnelChartDetail(
          TIME_PERIOD_TYPES.MONTHLY as TimePeriod,
          row?.source || ''
        );
        setSelectedRowData({
          id: row?.id,
          source: row?.source,
          leads_generated: row?.leads_generated,
          appointments: row?.appointments,
          sold: row?.sold,
          conversion_rate: row?.conversion_rate,
        });
      },
    },
  ];

  return (
    <>
      <DataTableWithCard
        data={users}
        headerClassName={`${headerClassName}`}
        skeletonClassName="h-[400px]"
        columns={columns}
        page={sourcePagination.page}
        pageSize={sourcePagination.pageSize}
        totalItems={sourcePagination.total} // Total number of items in your database
        onPageChange={(newPage: number) => handleSourcePageChange(newPage)}
        onPageSizeChange={(newPageSize: number) =>
          handleSourcePageSizeChange(newPageSize)
        }
        actions={actions}
        showFooter={true}
        showTitle={
          <div className="flex items-center gap-2 w-full justify-between">
            <span>Lead Source Details</span>
          </div>
        }
        pageSizeOptions={PAGE_SIZE}
        cardClassName={`h-[450px] ${cardClassName}`}
        scrollAreaClassName="h-[300px]"
        showPagination={true}
        showPageSize={true}
        isLoading={loadingStates?.leadSourceTable || isFilterLoading}
        sorting={sorting}
        onSortingChange={handleSourceSortingChange}
        headerActions={
          <>
            <Button
              variant="light"
              size="sm"
              onClick={() => {
                handleResetFilter();
              }}
            >
              Reset Filter
            </Button>
            {users?.length > 0 ? (
              <Button
                variant="light"
                size="sm"
                className="px-4"
                onClick={() => fetchSourceReport()}
              >
                Export
              </Button>
            ) : null}
          </>
        }
      />
      {sourceDetailModalOpen && (
        <SourceViewModal
          loadingStates={loadingStates}
          open={sourceDetailModalOpen}
          onClose={() => {
            setSourceDetailModalOpen(false);
          }}
          tooltipFormatter={tooltipFormatter}
          modalViewTooltipFormatter={modalViewTooltipFormatter}
          labelsFormatter={labelsFormatter}
          sourceDetailPagination={sourceDetailPagination}
          handleSourceDetailPageChange={handleSourceDetailPageChange}
          handleSourceDetailPageSizeChange={handleSourceDetailPageSizeChange}
          sourceDetailTableData={sourceDetailTableData}
          sorting={sorting}
          handleSourceDetailSortingChange={handleSourceDetailSortingChange}
          handleModalResetFilter={handleModalResetFilter}
          selectedRowData={selectedRowData}
          onPointClick={onPointClick}
          modalViewFunnelChartData={modalViewFunnelChartData}
          fetchSourceDetailReport={fetchSourceDetailReport}
          setModalViewFunnelChartTimePeriod={setModalViewFunnelChartTimePeriod}
          modalViewFunnelChartTimePeriod={modalViewFunnelChartTimePeriod}
        />
      )}
    </>
  );
}

export default SourceDetailTable;
