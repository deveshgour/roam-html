'use client';
import React from 'react';
import TeamManagementTable from './components/TeamManagementTable';

const UsersManagementPage = () => {
  return (
    <div className="bg-white p-8">
      <TeamManagementTable />
    </div>
  );
};

export default UsersManagementPage;
