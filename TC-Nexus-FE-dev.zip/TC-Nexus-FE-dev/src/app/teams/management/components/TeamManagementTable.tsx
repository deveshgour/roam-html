import { DataTable } from '@/components/coreUI/table/dataTable';
import { useState, useCallback, useMemo } from 'react';
import { Button } from '@/components/coreUI/button';
import { useTeams } from '@/hooks/useTeams';
import Modal from '@/components/coreUI/dialog';
import { showSuccessMsg, showErrorMsg } from '@/utils/notifications';

import { columns } from '@/app/teams/management/components/constants';
import { TOAST_MESSAGES } from '@/constants/messages';
import { PAGE_SIZE } from '@/constants/configs';
import Icon from '@/components/coreUI/icon';
import { SortingState } from '@/types/common';
import AddTeamModal, {
  TeamFormValues,
} from '@/app/teams/management/components/addTeamModal';

// Add this constant before the ModalType type definition
const MODAL_TYPES = {
  STATUS: 'status',
  DELETE: 'delete',
  EDIT: 'edit',
  PASSWORD: 'password',
  ADD: 'add',
} as const;
interface Team {
  id: string;
  teamName: string;
  userList: string[];
  manager: {
    id: string;
    first_name: string;
    last_name: string;
    email: string;
  } | null;
}

type ModalType = (typeof MODAL_TYPES)[keyof typeof MODAL_TYPES];

interface SelectedTeamState {
  type: ModalType;
  team: Team | TeamFormValues;
}

function TeamManagementTable() {
  const [selectedTeams, setSelectedTeams] = useState<string[]>([]);
  const [sorting, setSorting] = useState<SortingState>({
    field: 'name',
    direction: null,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Replace multiple selected team states with a single state
  const [selectedTeamState, setSelectedTeamState] =
    useState<SelectedTeamState | null>(null);
  const [showModal, setShowModal] = useState<ModalType | null>(null);

  const {
    teams,
    updateFilters,
    filters,
    deleteTeam,
    addTeam,
    updateTeam,
    isLoading,
    totalCount,
  } = useTeams({
    initialFilters: {
      page: 1,
      pageSize: 10,
    },
    autoFetch: true,
  });

  // Action handlers
  const handleSearch = useCallback(
    (query: string) => {
      try {
        updateFilters({ teamName: query, page: 1 });
      } catch (error) {
        console.error('Error updating filters:', error);
        showErrorMsg(TOAST_MESSAGES.FILTER_UPDATE_ERROR);
      }
    },
    [updateFilters]
  );

  const debouncedSearch = useMemo(() => {
    let timeoutId: NodeJS.Timeout;
    return (query: string) => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        handleSearch(query);
      }, 500);
    };
  }, [handleSearch]);

  const handleSelectAll = (selected: boolean, ids: string[]) => {
    setSelectedTeams(selected ? ids : []);
  };

  const closeModal = () => {
    setShowModal(null);
    setSelectedTeamState(null);
  };

  const actions = [
    {
      label: 'Edit',
      onClick: (row: Team) => {
        const team = {
          id: row.id,
          teamName: row.teamName,
          userList: row.userList,
        };
        setSelectedTeamState({ type: MODAL_TYPES.EDIT, team });
        setShowModal(MODAL_TYPES.EDIT);
      },
    },
    {
      label: 'Delete',
      onClick: (row: Team) => {
        setSelectedTeamState({ type: MODAL_TYPES.DELETE, team: row });
        setShowModal(MODAL_TYPES.DELETE);
      },
    },
  ];

  const handleDelete = async () => {
    try {
      setIsSubmitting(true);
      if (selectedTeamState?.type === MODAL_TYPES.DELETE) {
        const team = selectedTeamState.team as Team;
        await deleteTeam(team.id);
        showSuccessMsg(TOAST_MESSAGES.TEAM_DELETE_SUCCESS);
        closeModal();
      }
    } catch (error) {
      console.error('Error deleting team:', error);
      showErrorMsg(TOAST_MESSAGES.TEAM_DELETE_ERROR);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAddTeam = async (team: any) => {
    try {
      setIsSubmitting(true);
      if (selectedTeamState?.type === MODAL_TYPES.EDIT) {
        const editTeam = selectedTeamState.team as Team;
        await updateTeam(editTeam.id!, team);
        showSuccessMsg(TOAST_MESSAGES.TEAM_UPDATE_SUCCESS);
      } else {
        await addTeam(team);
        showSuccessMsg(TOAST_MESSAGES.TEAM_ADD_SUCCESS);
      }
      closeModal();
    } catch (error) {
      setIsSubmitting(false);
      console.error(TOAST_MESSAGES.TEAM_MODIFY_ERROR, error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSortingChange = (
    field: string,
    direction: 'asc' | 'desc' | null
  ) => {
    const orderingValue = direction === 'desc' ? `-${field}` : field;
    updateFilters({ page: 1, ordering: orderingValue });
    setSorting({ field, direction });
  };

  return (
    <>
      <DataTable
        loading={isLoading}
        showSkeleton={true}
        data={teams as unknown as Team[]}
        columns={columns}
        page={filters.page || 1}
        pageSize={filters.pageSize || 10}
        totalItems={totalCount}
        onPageChange={(page) => updateFilters({ page })}
        onPageSizeChange={(pageSize) => updateFilters({ pageSize })}
        onSearch={debouncedSearch}
        selectedRows={selectedTeams}
        onSelectAll={handleSelectAll}
        actions={actions}
        getRowId={(row) => row.id}
        pageSizeOptions={PAGE_SIZE}
        sorting={sorting}
        onSortingChange={handleSortingChange}
        showSearch={true}
        showPagination={true}
        scrollAreaClassName="h-[500px]"
        showPageSize={true}
        headerActions={
          <Button
            onClick={() => setShowModal(MODAL_TYPES.ADD)}
            variant="primary"
            className="!py-2.5"
          >
            <Icon iconName="plus" iconProps={{ className: `!h-5 !w-5` }} />
            Add Team
          </Button>
        }
      />

      {selectedTeamState?.type === MODAL_TYPES.DELETE && (
        <Modal
          open={showModal === MODAL_TYPES.DELETE}
          onClose={closeModal}
          title="Delete Team"
          primaryButton={{
            text: 'Delete',
            onClick: handleDelete,
            loading: isSubmitting,
            disabled: (selectedTeamState.team as Team)?.manager !== null,
          }}
          secondaryButton={{
            text: 'Cancel',
            onClick: closeModal,
            disabled: isSubmitting,
          }}
        >
          <div className="text-left">
            {(selectedTeamState.team as Team)?.manager === null ? (
              <>
                <p className="text-gray-600">
                  Are you sure you want to permanently delete{' '}
                  <span className="font-semibold">
                    {(selectedTeamState.team as Team).teamName}
                  </span>
                  ?
                </p>
                <p className="mt-3 text-red-500">
                  This action cannot be undone.
                </p>
              </>
            ) : (
              <p className="text-gray-600">
                This team is assigned to a manager. Please remove the manager
                before deleting the team.
              </p>
            )}
          </div>
        </Modal>
      )}

      <AddTeamModal
        onSubmit={handleAddTeam}
        open={showModal === MODAL_TYPES.EDIT || showModal === MODAL_TYPES.ADD}
        onClose={closeModal}
        team={
          selectedTeamState?.type === MODAL_TYPES.EDIT
            ? (selectedTeamState.team as TeamFormValues)
            : undefined
        }
        isSubmitting={isSubmitting}
      />
    </>
  );
}

export default TeamManagementTable;
