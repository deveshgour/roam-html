import { Button } from '@/components/coreUI/button';
import Modal from '@/components/coreUI/dialog';
import { TextInput } from '@/components/coreUI/textInput';
import MultiSelect, { Option } from '@/components/coreUI/multiSelect';
import * as Yup from 'yup';
import React from 'react';
import Icon from '@/components/coreUI/icon';
import { Formik, FormikProps } from 'formik';
import { VALIDATION_MESSAGES } from '@/constants/messages';
import { useTeams } from '@/hooks/useTeams';

interface AddTeamModalProps {
  open: boolean;
  onClose: () => void;
  // eslint-disable-next-line no-unused-vars
  onSubmit: (values: TeamFormValues) => void;
  team?: TeamFormValues;
  isSubmitting: boolean;
}

export interface TeamFormValues {
  id?: string;
  teamName: string;
  userList: string[];
}

const AddTeamModal = ({
  open = false,
  onClose = () => {},
  onSubmit = () => {},
  team = undefined,
  isSubmitting = false,
}: AddTeamModalProps) => {
  const formikRef = React.useRef<FormikProps<TeamFormValues>>(null);
  const isEditing = Boolean(team);
  const initialValues: TeamFormValues = {
    teamName: team?.teamName || '',
    userList: team?.userList || [],
  };

  const { users } = useTeams();

  const validationSchema = Yup.object().shape({
    teamName: Yup.string().required(
      VALIDATION_MESSAGES.TEAM.TEAM_NAME_REQUIRED
    ),
    userList: Yup.array()
      .min(1, VALIDATION_MESSAGES.TEAM.USER_SELECTED)
      .required(VALIDATION_MESSAGES.TEAM.USER_REQUIRED),
  });

  const handleSubmit = async () => {
    if (formikRef.current) {
      const { validateForm, submitForm, setTouched } = formikRef.current;

      // Mark all fields as touched
      setTouched({
        teamName: true,
        userList: true,
      });

      const errors = await validateForm();

      if (Object.keys(errors).length === 0) {
        await submitForm();
      }
    }
  };

  return (
    <>
      <Modal
        maxWidth="2xl"
        header={
          <>
            <span className="text-lg inline-flex text-gray">
              {team ? 'Edit Team' : 'Add Team'}
            </span>
          </>
        }
        open={open}
        onClose={onClose}
        footer={
          <div className="flex items-center gap-4 w-full">
            <Button
              size="lg"
              onClick={onClose}
              variant="outlineLight"
              full
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              size="lg"
              onClick={handleSubmit}
              variant="primary"
              full
              loading={isSubmitting}
              disabled={isSubmitting}
            >
              {team ? 'Update Team' : 'Add Team'}
            </Button>
          </div>
        }
      >
        <Formik
          innerRef={formikRef}
          initialValues={initialValues}
          validationSchema={validationSchema}
          validateOnMount={false}
          enableReinitialize={true}
          validationContext={{ isEditing }}
          onSubmit={(values) => {
            const submitValues = isEditing
              ? {
                  ...values,
                }
              : values;
            onSubmit(submitValues);
          }}
        >
          {({ values, errors, touched, setFieldValue }) => {
            return (
              <form className="mx-auto mb-4">
                <div className="grid gap-x-4 gap-y-5">
                  <div>
                    <TextInput
                      size="md"
                      className="pl-10 !bg-gray-50"
                      label="Team Name"
                      name="teamName"
                      maxLength={100}
                      placeholder="Enter Team Name"
                      error={
                        touched.teamName && errors.teamName
                          ? errors.teamName
                          : ''
                      }
                      value={values.teamName}
                      onChange={(e) => {
                        setFieldValue('teamName', e.target.value);
                      }}
                      startAdornment={
                        <div className="absolute left-4 top-1/2 transform -translate-y-1/2">
                          <Icon
                            iconName="user"
                            iconProps={{ className: `w-4 h-4 text-gray-500` }}
                          />
                        </div>
                      }
                    />
                  </div>

                  <div>
                    <label className="text-xs text-gray font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 mb-2 block">
                      User(s)
                    </label>
                    <MultiSelect
                      backgroundColor="rgb(var(--color-gray-50))"
                      showCheckbox={true}
                      closeMenuOnSelect={true}
                      selectProps={{
                        menuPortalTarget: document.body,
                      }}
                      options={
                        users?.map((user: any) => ({
                          value: user.id,
                          label: user.first_name + ' ' + user.last_name,
                        })) || []
                      }
                      value={values.userList.map((user: any) => {
                        return {
                          value: user.id || user.value,
                          label:
                            user.label ||
                            user.first_name + ' ' + user.last_name,
                        };
                      })}
                      size="md"
                      onChange={(
                        selected: Option | readonly Option[] | null
                      ) => {
                        let selectedUsers: Option[] = [];

                        if (Array.isArray(selected)) {
                          selectedUsers = selected;
                        } else if (selected) {
                          selectedUsers = [selected as Option];
                        }
                        const userIds = selectedUsers.map((user) => ({
                          id: user.value,
                          label: user.label,
                        }));
                        setFieldValue('userList', userIds);
                      }}
                      placeholder="Select User(s)"
                      icon={'list'}
                    />
                    {touched.userList && errors.userList && (
                      <div className="text-red-500 text-xs mt-1">
                        {errors.userList}
                      </div>
                    )}
                  </div>
                </div>
              </form>
            );
          }}
        </Formik>
      </Modal>
    </>
  );
};
export default AddTeamModal;
