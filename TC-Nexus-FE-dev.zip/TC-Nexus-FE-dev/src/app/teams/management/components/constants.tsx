interface User {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
}
interface Team {
  id: string;
  teamName: string;
  userList: User[];
}

export const columns = [
  { header: 'TEAM NAME', accessorKey: 'teamName', sortable: true },
  {
    header: 'USERS LIST',
    accessorKey: 'userList',
    sortable: false,
    cell: (row: Team) => {
      return (
        <span>
          {row?.userList
            .map((user: User) => user?.first_name + ' ' + user?.last_name)
            .join(', ')}
        </span>
      );
    },
  },
];
