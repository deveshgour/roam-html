'use client';
import { Button } from '@/components/coreUI/button';
import { TextInput } from '@/components/coreUI/textInput';
import { Formik } from 'formik';
import { useParams, useRouter } from 'next/navigation';
import { useRef } from 'react';
import { APP_ROUTE } from '@/constants/routes';
import * as yup from 'yup';
import { VALIDATION_MESSAGES } from '@/constants/messages';

interface NewConstructionBidValues {
  community: string;
  builder: string;
  trader: string;
  projected_start_date: string;
  homes: string;
  bid_per_home: string;
  projected_bid_total: string;
  profit_percent_bid_at: string;
  projected_profit_generated: string;
}

const NewConstructionBidValuesSchema = yup.object({
  community: yup
    .string()
    .required(VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.COMMUNITY_REQUIRED),
  builder: yup
    .string()
    .required(VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.BUILDERS_REQUIRED),
  trader: yup
    .string()
    .required(VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.TRADERS_REQUIRED),
  projected_start_date: yup
    .string()
    .required(
      VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.PROJECTED_START_DATE_REQUIRED
    )
    .matches(
      /^\d{4}-\d{2}-\d{2}$/,
      VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.PROJECTED_START_DATE_FORMAT
    ),
  homes: yup
    .number()
    .positive(VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.HOMES_POSITIVE)
    .required(
      VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.NUMBER_OF_HOMES_REQUIRED
    ),
  bid_per_home: yup
    .number()
    .positive(VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.BID_PER_HOME_POSITIVE)
    .required(VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.BID_PER_HOME_REQUIRED),
  projected_bid_total: yup
    .number()
    .positive(
      VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.PROJECTED_BID_TOTAL_POSITIVE
    )
    .required(
      VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.PROJECTED_BID_TOTAL_REQUIRED
    ),
  profit_percent_bid_at: yup
    .number()
    .min(0, VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.PROFIT_PERCENT_MIN)
    .max(100, VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.PROFIT_PERCENT_MAX)
    .required(VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.PROFIT_PERCENT_REQUIRED),
  projected_profit_generated: yup
    .number()
    .positive(
      VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.PROJECTED_PROFIT_POSITIVE
    )
    .required(
      VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.PROJECTED_PROFIT_REQUIRED
    ),
});

const NewConstructionBidForm = () => {
  const params = useParams();
  const router = useRouter();

  const isEditing = params?.params?.[0] === 'edit';

  const initialValues: NewConstructionBidValues = {
    community: '',
    builder: '',
    trader: '',
    projected_start_date: '',
    homes: '',
    bid_per_home: '',
    projected_bid_total: '',
    profit_percent_bid_at: '',
    projected_profit_generated: '',
  };

  const formikRef = useRef<any>(null);

  return (
    <Formik
      innerRef={formikRef}
      initialValues={initialValues}
      validationSchema={NewConstructionBidValuesSchema}
      validateOnMount={false}
      enableReinitialize={true}
      onSubmit={() => {}}
    >
      {({ handleChange, handleSubmit, isSubmitting }) => (
        <form className="bg-white p-5 mb-4" onSubmit={handleSubmit}>
          <div className="grid gap-x-4 gap-y-5 grid-cols-4">
            <div>
              <TextInput
                size="sm"
                className="!bg-gray-50"
                label="Community"
                name="leadScheduled"
                maxLength={100}
                placeholder="Enter #"
                onChange={handleChange}
              />
            </div>
            <div>
              <TextInput
                size="sm"
                className="!bg-gray-50"
                label="Community"
                name="leadScheduled"
                maxLength={100}
                placeholder="Enter #"
                onChange={handleChange}
              />
            </div>
            <div>
              <TextInput
                size="sm"
                className="!bg-gray-50"
                label="Traders"
                name="leadsRan"
                maxLength={100}
                placeholder="Enter #"
                onChange={handleChange}
              />
            </div>
            <div></div>
            <div>
              <TextInput
                size="sm"
                className="!bg-gray-50"
                label="# of Homes"
                name="jobSold"
                maxLength={100}
                placeholder="Enter #"
                onChange={handleChange}
              />
            </div>
            <div>
              <TextInput
                size="sm"
                className="!bg-gray-50"
                label="Bid Per Home"
                name="changeOrderSold"
                maxLength={100}
                placeholder="Enter #"
                onChange={handleChange}
              />
            </div>
            <div>
              <TextInput
                size="sm"
                className="!bg-gray-50"
                label="Projeted Bid Total"
                name="totalSalesAmount"
                maxLength={100}
                placeholder="Enter #"
                onChange={handleChange}
              />
            </div>
            <div>
              <TextInput
                size="sm"
                className="!bg-gray-50"
                label="Profit % Bid at"
                name="appointmentDoorToDoorEngage"
                maxLength={100}
                placeholder="Enter #"
                onChange={handleChange}
              />
            </div>
            <div>
              <TextInput
                size="sm"
                className="!bg-gray-50"
                label="Projected Profit Generated"
                name="googleReview"
                maxLength={100}
                placeholder="Enter #"
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="grid items-center gap-4 grid-cols-10 mt-6">
            <Button
              size="md"
              type="submit"
              variant="primary"
              full
              loading={isSubmitting}
              disabled={isSubmitting}
            >
              {isEditing ? 'Update Report' : 'Add Report'}
            </Button>
            <Button
              size="md"
              variant="outlineLight"
              full
              disabled={isSubmitting}
              onClick={() => router.push(APP_ROUTE.DATA_FORM.SALES_REPORT)}
            >
              Cancel
            </Button>
          </div>
        </form>
      )}
    </Formik>
  );
};

export default NewConstructionBidForm;
