import { Button } from '@/components/coreUI/button';
import Modal from '@/components/coreUI/dialog';
import { TextInput } from '@/components/coreUI/textInput';
import { Formik, FormikProps } from 'formik';
import * as Yup from 'yup';
import React, { useEffect } from 'react';
import CustomDatePicker from '@/components/coreUI/datePicker';
import { VALIDATION_MESSAGES } from '@/constants/messages';
import MultiSelect, { Option } from '@/components/coreUI/multiSelect';
import { format } from 'date-fns';

// Utility function to format number with thousand separators
const formatCurrency = (value: string | number): string => {
  if (!value && value !== 0) return '';

  // Convert to number first
  const numValue = typeof value === 'string' ? parseFloat(value) : value;

  // Handle NaN
  if (isNaN(numValue)) return '';

  // Format with thousand separators and up to 2 decimal places
  return numValue.toLocaleString('en-US', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  });
};

// Utility function to remove formatting (for input)
const unformatValue = (value: string): string => {
  if (!value) return '';
  return value.replace(/,/g, '');
};

interface Trader {
  id: number;
  name: string;
}

interface ConstructionBidFormValues {
  community: string;
  builder: string;
  trades: string[];
  trade_names: string[];
  projected_start_date: string;
  homes: string;
  bid_per_home: string;
  projected_bid_total: string;
  profit_bid: string;
  projected_profit_generated: string;
}

interface ConstructionBidFormData {
  community: string;
  builder: string;
  trades: number[];
  trade_names: string[];
  projected_start_date: string;
  homes: number;
  bid_per_home: number;
  projected_bid_total: number;
  profit_bid: number;
  projected_profit_generated: number;
}

interface AddConstructionBidModalProps {
  open?: boolean;
  onClose?: () => void;
  // eslint-disable-next-line no-unused-vars
  onSubmit?: (data: ConstructionBidFormData) => Promise<void>;
  bid?: Partial<ConstructionBidFormData>;
  isSubmitting?: boolean;
  traders: Trader[];
}

const AddConstructionBidModal = ({
  open = false,
  onClose = () => {},
  onSubmit = async () => {},
  bid = undefined,
  isSubmitting = false,
  traders = [],
}: AddConstructionBidModalProps) => {
  const formikRef = React.useRef<FormikProps<ConstructionBidFormValues>>(null);
  const isEditing = Boolean(bid);

  const initialValues: ConstructionBidFormValues = {
    community: bid?.community || '',
    builder: bid?.builder || '',
    trades: bid?.trades ? bid.trades.map(String) : [],
    trade_names: bid?.trade_names ? bid.trade_names : [],
    projected_start_date: bid?.projected_start_date || '',
    homes: bid?.homes ? String(bid.homes) : '',
    bid_per_home: bid?.bid_per_home ? String(bid.bid_per_home) : '',
    projected_bid_total: bid?.projected_bid_total
      ? String(bid.projected_bid_total)
      : '',
    profit_bid: bid?.profit_bid ? String(bid.profit_bid) : '',
    projected_profit_generated: bid?.projected_profit_generated
      ? String(bid.projected_profit_generated)
      : '',
  };

  // Auto-calculate derived fields when form is initialized or when relevant values change
  useEffect(() => {
    if (formikRef.current) {
      const { setFieldValue, values } = formikRef.current;

      // Calculate projected bid total if homes and bid_per_home are available
      if (values.homes && values.bid_per_home) {
        const homes = parseFloat(values.homes) || 0;
        const bidPerHome = parseFloat(values.bid_per_home) || 0;
        setFieldValue('projected_bid_total', (homes * bidPerHome).toString());
      }

      // Calculate projected profit generated if projected_bid_total and profit_bid are available
      if (values.projected_bid_total && values.profit_bid) {
        const bidTotal = parseFloat(values.projected_bid_total) || 0;
        const profitPercent = parseFloat(values.profit_bid) || 0;
        setFieldValue(
          'projected_profit_generated',
          ((bidTotal * profitPercent) / 100).toString()
        );
      }
    }
  }, []);

  // Function to calculate projected bid total
  const calculateProjectedBidTotal = (homes: string, bidPerHome: string) => {
    const homesValue = parseFloat(homes) || 0;
    const bidPerHomeValue = parseFloat(bidPerHome) || 0;
    return (homesValue * bidPerHomeValue).toString();
  };

  // Function to calculate projected profit generated
  const calculateProjectedProfit = (bidTotal: string, profitBid: string) => {
    const bidTotalValue = parseFloat(bidTotal) || 0;
    const profitBidValue = parseFloat(profitBid) || 0;
    return ((bidTotalValue * profitBidValue) / 100).toString();
  };

  const handleHomesChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    setFieldValue: any,
    values: ConstructionBidFormValues
  ) => {
    const { value } = e.target;
    setFieldValue('homes', value);

    // Update projected bid total
    if (value && values.bid_per_home) {
      // Strip any formatting from bid_per_home
      const bidPerHome = unformatValue(values.bid_per_home);
      const newProjectedBidTotal = calculateProjectedBidTotal(
        value,
        bidPerHome
      );
      setFieldValue('projected_bid_total', newProjectedBidTotal);

      // Also update projected profit generated
      if (values.profit_bid) {
        // Strip any formatting from profit_bid
        const profitBid = values.profit_bid.replace(/%/g, '');
        setFieldValue(
          'projected_profit_generated',
          calculateProjectedProfit(newProjectedBidTotal, profitBid)
        );
      }
    }
  };

  const handleBidPerHomeChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    setFieldValue: any,
    values: ConstructionBidFormValues
  ) => {
    const { value } = e.target;
    // Remove commas before storing
    const unformattedValue = unformatValue(value);
    setFieldValue('bid_per_home', unformattedValue);

    // Update projected bid total
    if (unformattedValue && values.homes) {
      const newProjectedBidTotal = calculateProjectedBidTotal(
        values.homes,
        unformattedValue
      );
      setFieldValue('projected_bid_total', newProjectedBidTotal);

      // Also update projected profit generated
      if (values.profit_bid) {
        setFieldValue(
          'projected_profit_generated',
          calculateProjectedProfit(newProjectedBidTotal, values.profit_bid)
        );
      }
    }
  };

  const handleProfitBidChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    setFieldValue: any,
    values: ConstructionBidFormValues
  ) => {
    const { value } = e.target;
    setFieldValue('profit_bid', value);

    // Update projected profit generated
    if (value && values.projected_bid_total) {
      setFieldValue(
        'projected_profit_generated',
        calculateProjectedProfit(values.projected_bid_total, value)
      );
    }
  };

  const validationSchema = Yup.object().shape({
    community: Yup.string().required(
      VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.COMMUNITY_REQUIRED
    ),
    builder: Yup.string().required(
      VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.BUILDERS_REQUIRED
    ),
    trades: Yup.array()
      .of(Yup.string())
      .min(1, VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.TRADERS_REQUIRED),
    projected_start_date: Yup.string().required(
      VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.PROJECTED_START_DATE_REQUIRED
    ),
    homes: Yup.string()
      .required(
        VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.NUMBER_OF_HOMES_REQUIRED
      )
      .matches(
        /^\d+$/,
        VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.NUMBER_OF_HOMES_INVALID
      ),
    bid_per_home: Yup.string()
      .required(VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.BID_PER_HOME_REQUIRED)
      .matches(
        /^\d+(\.\d{1,2})?$/,
        VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.BID_PER_HOME_INVALID
      ),
    projected_bid_total: Yup.string()
      .required('Projected Bid Total is required')
      .matches(
        /^\d+(\.\d{1,2})?$/,
        'Projected Bid Total must be a valid number'
      ),
    profit_bid: Yup.string()
      .required(VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.PROFIT_BID_AT_REQUIRED)
      .matches(
        /^\d+(\.\d{1,2})?$/,
        VALIDATION_MESSAGES.NEW_CONSTRUCTION_BID.PROFIT_BID_AT_INVALID
      ),
    projected_profit_generated: Yup.string()
      .required('Projected Profit Generated is required')
      .matches(
        /^\d+(\.\d{1,2})?$/,
        'Projected Profit Generated must be a valid number'
      ),
  });

  const handleSubmit = async () => {
    if (formikRef.current) {
      const { validateForm, setTouched, values } = formikRef.current;

      // Mark all fields as touched to trigger validation
      setTouched({
        community: true,
        builder: true,
        trades: true,
        projected_start_date: true,
        homes: true,
        bid_per_home: true,
        projected_bid_total: true,
        profit_bid: true,
        projected_profit_generated: true,
      });

      const errors = await validateForm();

      if (Object.keys(errors).length === 0) {
        const transformedValues: ConstructionBidFormData = {
          community: values.community,
          builder: values.builder,
          trades: values.trades.map(Number),
          trade_names: values.trades.map(
            (id) =>
              traders.find((trader) => trader.id.toString() === id)?.name || ''
          ),
          projected_start_date: values.projected_start_date,
          homes: Number(values.homes),
          bid_per_home: Number(unformatValue(values.bid_per_home)),
          projected_bid_total: Number(
            unformatValue(values.projected_bid_total)
          ),
          profit_bid: Number(values.profit_bid.replace(/%/g, '')),
          projected_profit_generated: Number(
            unformatValue(values.projected_profit_generated)
          ),
        };
        await onSubmit(transformedValues);
      } else {
        // Validation errors exist, but we don't need to show a toast message
        // as the form already displays validation errors
      }
    }
  };

  return (
    <Modal
      maxWidth="2xl"
      isScrollable={false}
      header={
        <span className="text-lg inline-flex text-gray">
          {isEditing ? 'Edit Construction Bid' : 'New Construction Bid Outlook'}
        </span>
      }
      open={open}
      onClose={onClose}
      showCloseButton={true}
      footer={
        <div className="flex items-center gap-4 w-full">
          <Button
            size="lg"
            onClick={onClose}
            variant="outlineLight"
            full
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            size="lg"
            onClick={handleSubmit}
            variant="primary"
            full
            loading={isSubmitting}
            disabled={isSubmitting}
          >
            {isEditing ? 'Update' : 'Add'}
          </Button>
        </div>
      }
    >
      <Formik
        innerRef={formikRef}
        initialValues={initialValues}
        validationSchema={validationSchema}
        validateOnMount={false}
        enableReinitialize={true}
        onSubmit={() => {}}
      >
        {({ errors, touched, setFieldValue, values }) => (
          <div className="grid gap-x-4 gap-y-5 grid-cols-2 mx-auto mb-4">
            <div>
              <TextInput
                size="sm"
                className="!bg-gray-50"
                label="Community"
                name="community"
                placeholder="Enter Community Name"
                error={
                  touched.community && errors.community ? errors.community : ''
                }
                value={values.community}
                onChange={(e) => setFieldValue('community', e.target.value)}
              />
            </div>
            <div>
              <TextInput
                size="sm"
                className="!bg-gray-50"
                label="Builder"
                name="builder"
                placeholder="Enter Builder Name"
                error={touched.builder && errors.builder ? errors.builder : ''}
                value={values.builder}
                onChange={(e) => setFieldValue('builder', e.target.value)}
              />
            </div>
            <div className="">
              <div className="text-xs text-gray  font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 mb-2 block">
                Trades
              </div>
              <MultiSelect
                className="custom-select"
                backgroundColor="rgb(var(--color-gray-50))"
                options={traders.map((trader) => ({
                  value: trader.id.toString(),
                  label: trader.name,
                }))}
                value={values.trades.map((id) => ({
                  value: id,
                  label:
                    traders.find((t) => t.id.toString() === id)?.name || '',
                }))}
                onChange={(selected: Option | Option[]) => {
                  const selectedIds = Array.isArray(selected)
                    ? selected.map((item: Option) => String(item.value))
                    : [String(selected.value)];
                  setFieldValue('trades', selectedIds);
                }}
                placeholder="Select Trades"
                isDisabled={false}
                size="md"
                icon="users"
                showCheckbox={true}
              />
              {touched.trades && errors.trades && (
                <div className="text-red-500 text-xs mt-1">{errors.trades}</div>
              )}
            </div>
            <div>
              <CustomDatePicker
                label="Select Date"
                placeholder="MM/DD/YYYY"
                selected={
                  values.projected_start_date
                    ? new Date(values.projected_start_date)
                    : null
                }
                onChange={(date: Date | null) => {
                  setFieldValue(
                    'projected_start_date',
                    date ? format(date, 'yyyy-MM-dd') : ''
                  );
                }}
              />
              {touched.projected_start_date && errors.projected_start_date && (
                <div className="text-red-500 text-xs mt-1">
                  {errors.projected_start_date}
                </div>
              )}
            </div>
            <div>
              <TextInput
                size="sm"
                className="!bg-gray-50"
                label="Number of Homes"
                name="homes"
                placeholder="Enter # of Homes"
                error={touched.homes && errors.homes ? errors.homes : ''}
                value={values.homes}
                onChange={(e) => handleHomesChange(e, setFieldValue, values)}
              />
            </div>
            <div>
              <TextInput
                size="sm"
                className="!bg-gray-50"
                label="Bid Per Home"
                name="bid_per_home"
                placeholder="Enter bid per home"
                error={
                  touched.bid_per_home && errors.bid_per_home
                    ? errors.bid_per_home
                    : ''
                }
                value={
                  values.bid_per_home
                    ? `$${formatCurrency(values.bid_per_home)}`
                    : ''
                }
                onChange={(e) => {
                  // Strip out any $ signs and commas
                  const rawValue = e.target.value.replace(/[$,]/g, '');
                  e.target.value = rawValue;
                  handleBidPerHomeChange(e, setFieldValue, values);
                }}
              />
            </div>
            <div>
              <TextInput
                size="sm"
                className="!bg-gray-50"
                label="Projected Bid Total"
                name="projected_bid_total"
                placeholder="--"
                value={
                  values.projected_bid_total
                    ? `$${formatCurrency(values.projected_bid_total)}`
                    : '--'
                }
                readOnly={true}
                error={
                  touched.projected_bid_total && errors.projected_bid_total
                    ? errors.projected_bid_total
                    : ''
                }
              />
            </div>
            <div>
              <TextInput
                size="sm"
                className="!bg-gray-50"
                label="Profit % Bid At"
                name="profit_bid"
                placeholder="--"
                error={
                  touched.profit_bid && errors.profit_bid
                    ? errors.profit_bid
                    : ''
                }
                value={values.profit_bid}
                onChange={(e) => {
                  // Strip out any % signs
                  const rawValue = e.target.value.replace(/%/g, '');
                  e.target.value = rawValue;
                  handleProfitBidChange(e, setFieldValue, values);
                }}
              />
            </div>
            <div>
              <TextInput
                size="sm"
                className="!bg-gray-50"
                label="Projected Profit Generated"
                name="projected_profit_generated"
                placeholder="--"
                value={
                  values.projected_profit_generated
                    ? `$${formatCurrency(values.projected_profit_generated)}`
                    : '--'
                }
                readOnly={true}
                error={
                  touched.projected_profit_generated &&
                  errors.projected_profit_generated
                    ? errors.projected_profit_generated
                    : ''
                }
              />
            </div>
          </div>
        )}
      </Formik>
    </Modal>
  );
};

export default AddConstructionBidModal;
