import { useState, useEffect } from 'react';
import { Button } from '@/components/coreUI/button';
import { PAGE_SIZE } from '@/constants/configs';
import Icon from '@/components/coreUI/icon';
import { DataTableWithFixedColumn } from '@/components/dataTableWithFixedColumn';
import Modal from '@/components/coreUI/dialog';
import AddConstructionBidModal from './AddConstructionBidModal';
import {
  BidFilters,
  useBids,
  ConstructionBid,
  ConstructionBidFormData,
  ExportFilters,
} from '@/hooks/useConstructionBids';
import { showSuccessMsg, showErrorMsg } from '@/utils/notifications';
import { TOAST_MESSAGES } from '@/constants/messages';
import MultiSelect from '@/components/coreUI/multiSelect';
import {
  getTradersList,
  getBuildersList,
  getCommunitiesList,
} from '@/services/constructionBid';

interface SortingState {
  field: string;
  direction: 'asc' | 'desc' | null;
}

// Define constants for modal types
const MODAL_TYPES = {
  DELETE: 'delete',
  EDIT: 'edit',
  ADD: 'add',
} as const;

type ModalType = (typeof MODAL_TYPES)[keyof typeof MODAL_TYPES];

interface Trader {
  id: number;
  name: string;
}

interface Builder {
  name: string;
}

interface Community {
  name: string;
}

// Add this helper function after the MODAL_TYPES constant
const getApiFieldName = (field: string): string => {
  const fieldMapping: { [key: string]: string } = {
    community: 'community',
    builders: 'builder',
    trade_names: 'trade_names',
    projectedStartDate: 'projected_start_date',
    numberOfHomes: 'homes',
    bidPerHome: 'bid_per_home',
    projectedBidTotal: 'projected_bid_total',
    profitBidAt: 'profit_bid',
    projectedProfitGenerated: 'projected_profit_generated',
  };
  return fieldMapping[field] || field;
};

function NewConstructionBid() {
  const [sorting, setSorting] = useState<SortingState>({
    field: 'community',
    direction: null,
  });

  // State for managing selected bid and modal visibility
  const [selectedBid, setSelectedBid] = useState<ConstructionBid | null>(null);
  const [showModal, setShowModal] = useState<ModalType | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [tradersList, setTradersList] = useState<Trader[]>([]);
  const [builders, setBuilders] = useState<Builder[]>([]);
  const [communities, setCommunities] = useState<Community[]>([]);
  const [isExporting, setIsExporting] = useState(false);
  const [isFilterLoading, setIsFilterLoading] = useState(false);

  // Create a function to fetch filter options
  const fetchFilterOptions = async () => {
    try {
      // Fetch traders
      const tradersResponse = await getTradersList();
      if (tradersResponse && tradersResponse.data) {
        setTradersList(tradersResponse.data);
      }

      // Fetch builders
      const buildersResponse = await getBuildersList();
      if (buildersResponse && buildersResponse.data) {
        setBuilders(buildersResponse.data);
      }

      // Fetch communities
      const communitiesResponse = await getCommunitiesList();
      if (communitiesResponse && communitiesResponse.data) {
        setCommunities(communitiesResponse.data);
      }
      // eslint-disable-next-line @typescript-eslint/no-unused-vars, no-unused-vars
    } catch (error) {
      showErrorMsg('Failed to fetch filter options');
    }
  };

  // Fetch bids using the useBids hook
  const {
    bids,
    isLoading,
    totalCount,
    filters,
    setFilters,
    totals,
    addBid,
    updateBid,
    deleteBid,
    exportBids,
  } = useBids({
    initialFilters: {
      page: 1,
      page_size: 10,
      ordering: undefined,
    },
  });

  useEffect(() => {
    fetchFilterOptions();
  }, []);

  useEffect(() => {
    // Reset isFilterLoading when bids are updated
    setIsFilterLoading(false);
  }, [bids]);

  useEffect(() => {
    // Debug totals in console to verify API data
    if (totals) {
    }
  }, [totals]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value);
  };

  const formatPercentage = (value: number) => {
    return `${value}%`;
  };

  const columns = [
    {
      accessorKey: 'community',
      header: 'COMMUNITY',
      sortable: true,
      width: 150,
      footer: () => 'Total',
    },
    {
      accessorKey: 'builders',
      header: 'BUILDERS',
      sortable: true,
      width: 150,
      footer: () => '',
    },
    {
      accessorKey: 'trade_names',
      header: 'TRADES',
      sortable: true,
      width: 200,
      cellClassName: 'max-w-[250px] !overflow-visible !text-wrap',
      footer: () => '',
    },
    {
      accessorKey: 'projectedStartDate',
      header: 'PROJECTED START DATE',
      sortable: true,
      width: 150,
      cell: (row: any) => {
        const date = new Date(row?.projectedStartDate);
        return `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`;
      },
      footer: () => '',
    },
    {
      accessorKey: 'numberOfHomes',
      header: '# OF HOMES',
      sortable: true,
      width: 100,
      cell: (row: any) => row?.numberOfHomes || 0,
      footer: () => totals?.homes || 0,
    },
    {
      accessorKey: 'bidPerHome',
      header: 'BID PER HOME',
      sortable: true,
      width: 150,
      cell: (row: any) => formatCurrency(row?.bidPerHome || 0),
      footer: () => formatCurrency(totals?.bid_per_home || 0),
    },
    {
      accessorKey: 'projectedBidTotal',
      header: 'PROJECTED BID TOTAL',
      sortable: true,
      width: 150,
      cell: (row: any) => formatCurrency(row?.projectedBidTotal || 0),
      footer: () => formatCurrency(totals?.projected_bid_total || 0),
    },
    {
      accessorKey: 'profitBidAt',
      header: 'PROFIT % BID AT',
      sortable: true,
      width: 150,
      cell: (row: any) => formatPercentage(row?.profitBidAt || 0),
      footer: () => formatPercentage(totals?.profit_bid || 0),
    },
    {
      accessorKey: 'projectedProfitGenerated',
      header: 'PROJECTED PROFIT GENERATED',
      sortable: true,
      width: 200,
      cell: (row: any) => formatCurrency(row?.projectedProfitGenerated || 0),
      footer: () => formatCurrency(totals?.projected_profit_generated || 0),
    },
  ];

  const actions = [
    {
      label: 'Edit',
      onClick: (row: ConstructionBid) => {
        setSelectedBid(row);
        setShowModal(MODAL_TYPES.EDIT);
      },
    },
    {
      label: 'Delete',
      onClick: (row: ConstructionBid) => {
        setSelectedBid(row);
        setShowModal(MODAL_TYPES.DELETE);
      },
    },
  ];

  const handleSortingChange = (
    field: string,
    direction: 'asc' | 'desc' | null
  ) => {
    setSorting({ field, direction });
    const apiFieldName = getApiFieldName(field);
    setFilters((prev: BidFilters) => ({
      ...prev,
      ordering: direction
        ? `${direction === 'asc' ? '' : '-'}${apiFieldName}`
        : undefined,
    }));
  };

  const closeModal = () => {
    setShowModal(null);
    setSelectedBid(null);
  };

  const handleAddOrUpdateBid = async (bidData: ConstructionBidFormData) => {
    try {
      setIsSubmitting(true);
      if (showModal === MODAL_TYPES.EDIT && selectedBid) {
        const success = await updateBid(selectedBid.id, bidData);
        if (success) {
          showSuccessMsg(
            TOAST_MESSAGES.UPDATE_SUCCESS || 'Bid updated successfully'
          );
          closeModal();
        }
      } else {
        const success = await addBid(bidData);
        if (success) {
          showSuccessMsg(
            TOAST_MESSAGES.CREATE_SUCCESS || 'Bid created successfully'
          );
          // Refetch filter options after successful creation
          await fetchFilterOptions();
          closeModal();
        }
      }
      // eslint-disable-next-line @typescript-eslint/no-unused-vars, no-unused-vars
    } catch (error: any) {
      showErrorMsg(TOAST_MESSAGES.OPERATION_ERROR || 'Operation failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteBid = async () => {
    if (!selectedBid) return;

    try {
      setIsSubmitting(true);
      await deleteBid(selectedBid.id);
      showSuccessMsg(
        TOAST_MESSAGES.DELETE_SUCCESS || 'Bid deleted successfully'
      );
      closeModal();
      // eslint-disable-next-line @typescript-eslint/no-unused-vars, no-unused-vars
    } catch (error) {
      showErrorMsg(TOAST_MESSAGES.DELETE_ERROR || 'Failed to delete bid');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleExport = async () => {
    try {
      setIsExporting(true);
      const exportFilters: ExportFilters = {
        builder:
          typeof filters.builder === 'string' ? filters.builder : undefined,
        community:
          typeof filters.community === 'string' ? filters.community : undefined,
        trades: Array.isArray(filters.trades) ? filters.trades : undefined,
      };

      await exportBids(exportFilters);
      showSuccessMsg(TOAST_MESSAGES.EXPORT_SUCCESS || 'Export successful');
      // eslint-disable-next-line @typescript-eslint/no-unused-vars, no-unused-vars
    } catch (error) {
      showErrorMsg(TOAST_MESSAGES.EXPORT_ERROR || 'Export failed');
    } finally {
      setIsExporting(false);
    }
  };

  const handleFilterChange = (field: string, value: string | string[]) => {
    setIsFilterLoading(true);
    let formattedValue: string | string[] | number = value;

    // Handle pagination fields as numbers
    if (field === 'page' || field === 'pageSize') {
      formattedValue = Number(value);
    }
    // Handle array values for different fields
    else if (Array.isArray(value) && value.length > 0) {
      if (field === 'builder' || field === 'community') {
        // Create a list of double-quoted values and URL encode it
        // Ensure the values are in array format even for single values
        const valueArray = Array.isArray(value) ? value : [value];
        const quotedValues = valueArray.map((val) => `"${val?.trim()}"`);
        formattedValue = encodeURIComponent(`[${quotedValues.join(',')}]`);
      } else if (field === 'trades') {
        formattedValue = value; // Keep trades as array
      }
    }

    // Prevent page reset for certain fields
    const shouldResetPage = !['page', 'pageSize'].includes(field);

    setFilters((prev: BidFilters) => ({
      ...prev,
      [field === 'pageSize' ? 'page_size' : field]:
        value === 'all' || (Array.isArray(value) && value.length === 0)
          ? undefined
          : formattedValue,
      ...(shouldResetPage ? { page: 1 } : {}),
    }));
  };

  return (
    <>
      <DataTableWithFixedColumn
        columns={columns}
        data={bids}
        page={filters?.page || 1}
        pageSize={filters?.page_size || PAGE_SIZE[0]}
        totalItems={totalCount}
        loading={isLoading || isFilterLoading}
        showSkeleton={true}
        sorting={sorting}
        onPageChange={(newPage) => {
          handleFilterChange('page', String(newPage));
        }}
        onPageSizeChange={(newSize) => {
          handleFilterChange('pageSize', String(newSize));
          handleFilterChange('page', '1');
        }}
        onSortingChange={handleSortingChange}
        actions={actions}
        pageSizeOptions={PAGE_SIZE}
        showSearch={false}
        showPagination={true}
        showPageSize={false}
        showFooter={true}
        isActionSticky={true}
        getRowId={(row: any) => row?.id}
        headerActions={
          <>
            <Button
              onClick={() => setShowModal(MODAL_TYPES.ADD)}
              variant="primary"
              className="!py-2.5"
            >
              <Icon iconName="plus" iconProps={{ className: `!h-5 !w-5` }} />
              Add New
            </Button>
            <Button
              variant="outlineLight"
              className="!py-2.5"
              onClick={handleExport}
              disabled={isExporting}
              icon={
                <Icon
                  iconName="export"
                  iconProps={{ className: '!w-5 !h-5 text-gray-600' }}
                />
              }
            >
              {isExporting ? 'Exporting...' : 'Export'}
            </Button>
          </>
        }
        showTableFilter={
          <div className="flex items-center gap-3 flex-wrap">
            <div className="max-w-80 min-w-60 relative">
              <MultiSelect
                backgroundColor="rgb(var(--color-gray-50))"
                options={builders?.map((builder) => ({
                  value: builder?.name,
                  label: builder?.name,
                }))}
                value={
                  typeof filters?.builder === 'string' && filters.builder
                    ? decodeURIComponent(filters.builder)
                        .replace(/^\[|\]$/g, '')
                        .split(',')
                        .map((builder) => ({
                          value: builder?.replace(/^"|"$/g, '').trim(),
                          label: builder?.replace(/^"|"$/g, '').trim(),
                        }))
                    : []
                }
                isDisabled={false}
                size="md"
                onChange={(selected) => {
                  const selectedValues = Array.isArray(selected)
                    ? selected?.map((item) => String(item?.value))
                    : [];
                  handleFilterChange('builder', selectedValues);
                }}
                placeholder="All Builders"
                showCheckbox={true}
              />
            </div>
            <div className="max-w-80 min-w-60 relative">
              <MultiSelect
                backgroundColor="rgb(var(--color-gray-50))"
                options={tradersList?.map((trader) => ({
                  value: trader?.id?.toString(),
                  label: trader?.name,
                }))}
                value={
                  Array.isArray(filters?.trades)
                    ? filters.trades?.map((id) => ({
                        value: id,
                        label:
                          tradersList?.find((t) => t?.id?.toString() === id)
                            ?.name || '',
                      }))
                    : []
                }
                isDisabled={false}
                size="md"
                onChange={(selected) => {
                  const selectedIds = Array.isArray(selected)
                    ? selected?.map((item) => String(item?.value))
                    : [];
                  handleFilterChange('trades', selectedIds);
                }}
                placeholder="All Trades"
                showCheckbox={true}
              />
            </div>
            <div className="max-w-80 min-w-60 relative">
              <MultiSelect
                backgroundColor="rgb(var(--color-gray-50))"
                options={communities?.map((community) => ({
                  value: community?.name,
                  label: community?.name,
                }))}
                value={
                  typeof filters?.community === 'string' && filters.community
                    ? decodeURIComponent(filters.community)
                        .replace(/^\[|\]$/g, '')
                        .split(',')
                        .map((community) => ({
                          value: community?.replace(/^"|"$/g, '').trim(),
                          label: community?.replace(/^"|"$/g, '').trim(),
                        }))
                    : []
                }
                isDisabled={false}
                size="md"
                onChange={(selected) => {
                  const selectedValues = Array.isArray(selected)
                    ? selected?.map((item) => String(item?.value))
                    : [];
                  handleFilterChange('community', selectedValues);
                }}
                placeholder="All Community"
                showCheckbox={true}
              />
            </div>
          </div>
        }
      />

      <Modal
        open={showModal === MODAL_TYPES.DELETE}
        onClose={closeModal}
        title="Delete Construction Bid"
        primaryButton={{
          text: 'Delete',
          onClick: handleDeleteBid,
          loading: isSubmitting,
        }}
        secondaryButton={{
          text: 'Cancel',
          onClick: closeModal,
          disabled: isSubmitting,
        }}
      >
        <div className="text-left">
          <p className="text-gray-600">
            Are you sure you want to permanently delete this construction bid?
          </p>
          <p className="mt-3 text-red-500">This action cannot be undone.</p>
        </div>
      </Modal>

      <AddConstructionBidModal
        open={showModal === MODAL_TYPES.ADD || showModal === MODAL_TYPES.EDIT}
        onClose={closeModal}
        bid={
          selectedBid
            ? {
                community: selectedBid.community,
                builder: selectedBid.builders,
                trades: selectedBid.traders.split(',').map(Number),
                trade_names: selectedBid.trade_names,
                projected_start_date: selectedBid.projectedStartDate,
                homes: selectedBid.numberOfHomes,
                bid_per_home: selectedBid.bidPerHome,
                projected_bid_total: selectedBid.projectedBidTotal,
                profit_bid: selectedBid.profitBidAt,
                projected_profit_generated:
                  selectedBid.projectedProfitGenerated,
              }
            : undefined
        }
        onSubmit={handleAddOrUpdateBid}
        isSubmitting={isSubmitting}
        traders={tradersList}
      />
    </>
  );
}

export default NewConstructionBid;
