'use client';
import React from 'react';
import NewConstructionBid from './components/NewConstructionBid';

const NewConstructionBidsPage = () => {
  return (
    <div>
      <NewConstructionBid />
    </div>
  );
};

export default NewConstructionBidsPage;
