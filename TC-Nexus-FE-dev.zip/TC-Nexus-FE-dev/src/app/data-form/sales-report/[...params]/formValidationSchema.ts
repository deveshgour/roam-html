import * as Yup from 'yup';
import { VALIDATION_MESSAGES } from '@/constants/messages';

export const validationSchema = Yup.object().shape({
  team: Yup.string().required(VALIDATION_MESSAGES.TEAM.REQUIRED),
  location: Yup.string().required(VALIDATION_MESSAGES.LOCATION.REQUIRED),
  salesRepName: Yup.string().required(
    VALIDATION_MESSAGES.SALES_REP_NAME.REQUIRED
  ),
  date: Yup.string().required(VALIDATION_MESSAGES.DATE.REQUIRED),
  leadScheduled: Yup.number()
    .typeError(VALIDATION_MESSAGES.VALUE_MUST_BE_NUMBER.REQUIRED)
    .min(0, VALIDATION_MESSAGES.VALUE_MUST_BE_GREATER_THAN_ZERO.REQUIRED)
    .required('This field is required'),
  leadsRan: Yup.number()
    .typeError(VALIDATION_MESSAGES.VALUE_MUST_BE_NUMBER.REQUIRED)
    .min(0, VALIDATION_MESSAGES.VALUE_MUST_BE_GREATER_THAN_ZERO.REQUIRED)
    .required('This field is required'),
  followUpAppointmentScheduled: Yup.number()
    .typeError(VALIDATION_MESSAGES.VALUE_MUST_BE_NUMBER.REQUIRED)
    .min(0, VALIDATION_MESSAGES.VALUE_MUST_BE_GREATER_THAN_ZERO.REQUIRED)
    .required('This field is required'),
  jobSold: Yup.number()
    .typeError(VALIDATION_MESSAGES.VALUE_MUST_BE_NUMBER.REQUIRED)
    .min(0, VALIDATION_MESSAGES.VALUE_MUST_BE_GREATER_THAN_ZERO.REQUIRED)
    .required('This field is required'),
  changeOrderSold: Yup.number()
    .typeError(VALIDATION_MESSAGES.VALUE_MUST_BE_NUMBER.REQUIRED)
    .min(0, VALIDATION_MESSAGES.VALUE_MUST_BE_GREATER_THAN_ZERO.REQUIRED)
    .required('This field is required'),
  totalSalesAmount: Yup.number()
    .typeError(VALIDATION_MESSAGES.VALUE_MUST_BE_NUMBER.REQUIRED)
    .min(0, VALIDATION_MESSAGES.VALUE_MUST_BE_GREATER_THAN_ZERO.REQUIRED)
    .required('This field is required'),
  homesCanvassed: Yup.number()
    .typeError(VALIDATION_MESSAGES.VALUE_MUST_BE_NUMBER.REQUIRED)
    .min(0, VALIDATION_MESSAGES.VALUE_MUST_BE_GREATER_THAN_ZERO.REQUIRED)
    .required('This field is required'),
  doorsKnocked: Yup.number()
    .typeError(VALIDATION_MESSAGES.VALUE_MUST_BE_NUMBER.REQUIRED)
    .min(0, VALIDATION_MESSAGES.VALUE_MUST_BE_GREATER_THAN_ZERO.REQUIRED)
    .required('This field is required'),
  appointmentDoorToDoorEngage: Yup.number()
    .typeError(VALIDATION_MESSAGES.VALUE_MUST_BE_NUMBER.REQUIRED)
    .min(0, VALIDATION_MESSAGES.VALUE_MUST_BE_GREATER_THAN_ZERO.REQUIRED)
    .required('This field is required'),
  googleReview: Yup.number()
    .typeError(VALIDATION_MESSAGES.VALUE_MUST_BE_NUMBER.REQUIRED)
    .min(0, VALIDATION_MESSAGES.VALUE_MUST_BE_GREATER_THAN_ZERO.REQUIRED)
    .required('This field is required'),
  referralsExistingClients: Yup.number()
    .typeError(VALIDATION_MESSAGES.VALUE_MUST_BE_NUMBER.REQUIRED)
    .min(0, VALIDATION_MESSAGES.VALUE_MUST_BE_GREATER_THAN_ZERO.REQUIRED)
    .required('This field is required'),
  yardSign: Yup.number()
    .typeError(VALIDATION_MESSAGES.VALUE_MUST_BE_NUMBER.REQUIRED)
    .min(0, VALIDATION_MESSAGES.VALUE_MUST_BE_GREATER_THAN_ZERO.REQUIRED)
    .required('This field is required'),
  lois: Yup.number()
    .typeError(VALIDATION_MESSAGES.VALUE_MUST_BE_NUMBER.REQUIRED)
    .min(0, VALIDATION_MESSAGES.VALUE_MUST_BE_GREATER_THAN_ZERO.REQUIRED)
    .required('This field is required'),
  claimFiled: Yup.number()
    .typeError(VALIDATION_MESSAGES.VALUE_MUST_BE_NUMBER.REQUIRED)
    .min(0, VALIDATION_MESSAGES.VALUE_MUST_BE_GREATER_THAN_ZERO.REQUIRED)
    .required('This field is required'),
  adjusterMeeting: Yup.number()
    .typeError(VALIDATION_MESSAGES.VALUE_MUST_BE_NUMBER.REQUIRED)
    .min(0, VALIDATION_MESSAGES.VALUE_MUST_BE_GREATER_THAN_ZERO.REQUIRED)
    .required('This field is required'),
});
