'use client';
import { Button } from '@/components/coreUI/button';
import { TextInput } from '@/components/coreUI/textInput';
import { Formik } from 'formik';
import { TOAST_MESSAGES } from '@/constants/messages';
import { useParams, useRouter } from 'next/navigation';
import { useEffect, useState, useRef } from 'react';
import { SalesReportPayload, useSalesReport } from '@/hooks/useSalesReport';
import { showSuccessMsg, showErrorMsg } from '@/utils/notifications';
import { APP_ROUTE } from '@/constants/routes';
import { getSalesReportById } from '@/services/salesReport';
import CustomDatePicker from '@/components/coreUI/datePicker';
import { validationSchema } from './formValidationSchema';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/coreUI/select';
import Icon from '@/components/coreUI/icon';
import { Checkbox } from '@/components/coreUI/checkbox';

interface SalesReportFormValues {
  team: string;
  location: string;
  salesRepName: string;
  date: string;
  leadScheduled: string;
  leadsRan: string;
  followUpAppointmentScheduled: string;
  jobSold: string;
  changeOrderSold: string;
  totalSalesAmount: string;
  homesCanvassed: string;
  doorsKnocked: string;
  appointmentDoorToDoorEngage: string;
  googleReview: string;
  referralsExistingClients: string;
  yardSign: string;
  lois: string;
  claimFiled: string;
  adjusterMeeting: string;
  is_approved: boolean;
  is_auto_processed: boolean;
}

interface SalesReportResponse {
  status: number;
  message: string;
  data: {
    id: number;
    entry_date: string;
    door_knocked: number;
    home_canvassed: number;
    leads_generated: number;
    leads_ran: number;
    change_order: number;
    amount: number;
    google_reviews: number;
    referral: number;
    yard_signed: number;
    appointments: number;
    insurance_claim_filed: number;
    loi: number;
    adjuster_meetings: number;
    followup_appointments: number;
    sold: number;
    rep_id: number;
    team: string;
    loc_id: number;
    sales_rep: string;
    location: string;
    auto_door_knocked: number;
    auto_home_canvassed: number;
    auto_leads_generated: number;
    auto_loi: number;
    auto_sold: number;
    auto_insurance_claim_filed: number;
    is_approved: boolean;
    is_auto_processed: boolean;
  };
}

const TEAM_OPTIONS = [
  { value: 'Team 1', label: 'Team 1' },
  { value: 'Team 2', label: 'Team 2' },
  { value: 'Team 3', label: 'Team 3' },
  { value: 'Team 4', label: 'Team 4' },
];

const SalesReportForm = () => {
  const params = useParams();
  const { salesRepresentatives, locations, createReport, updateReport } =
    useSalesReport({
      autoFetch: false,
    });
  const router = useRouter();
  const [isAutoCalculated, setIsAutoCalculated] = useState(false);
  const [autoValues, setAutoValues] = useState({
    autoDoorKnocked: 0,
    autoHomeCanvassed: 0,
    autoLeadsGenerated: 0,
    autoLoi: 0,
    autoSold: 0,
    autoInsuranceClaimFiled: 0,
  });

  // For /data-form/sales-report/add - params.params will be ['add']
  // For /data-form/sales-report/edit/18 - params.params will be ['edit', '18']
  const isEditing = params?.params?.[0] === 'edit';
  const id = isEditing ? params?.params?.[1] : null;

  const [formValues, setFormValues] = useState<SalesReportFormValues>({
    team: '',
    location: '',
    salesRepName: '',
    date: '',
    leadScheduled: '',
    leadsRan: '',
    followUpAppointmentScheduled: '',
    jobSold: '',
    changeOrderSold: '',
    totalSalesAmount: '',
    homesCanvassed: '',
    doorsKnocked: '',
    appointmentDoorToDoorEngage: '',
    googleReview: '',
    referralsExistingClients: '',
    yardSign: '',
    lois: '',
    claimFiled: '',
    adjusterMeeting: '',
    is_approved: false,
    is_auto_processed: false,
  });

  const formikRef = useRef<any>(null);
  const [loadingStates, setLoadingStates] = useState({ form: false });

  useEffect(() => {
    if (!isEditing || !id) return;
    const fetchData = async () => {
      if (isEditing && id) {
        try {
          setLoadingStates((prev) => ({ ...prev, form: true }));
          const response = await getSalesReportById(id);

          if (!response?.data) {
            throw new Error('Invalid response data');
          }

          const formValues = transformResponseToFormValues(response);
          setFormValues(formValues);
          setIsAutoCalculated(response?.data?.is_auto_processed || false);
          setAutoValues({
            autoDoorKnocked: response?.data?.auto_door_knocked ?? 0,
            autoHomeCanvassed: response?.data?.auto_home_canvassed ?? 0,
            autoLeadsGenerated: response?.data?.auto_leads_generated ?? 0,
            autoLoi: response?.data?.auto_loi ?? 0,
            autoSold: response?.data?.auto_sold ?? 0,
            autoInsuranceClaimFiled:
              response?.data?.auto_insurance_claim_filed ?? 0,
          });
        } catch (error) {
          console.error('Error fetching data:', error);
          showErrorMsg(TOAST_MESSAGES.FETCH_REPORT_ERROR);
          router.push(APP_ROUTE.DATA_FORM.SALES_REPORT);
        } finally {
          setLoadingStates((prev) => ({ ...prev, form: false }));
        }
      }
    };

    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isEditing, id]);

  const handleOnSubmit = async (values: SalesReportFormValues) => {
    const payload: SalesReportPayload = {
      loc_id: values.location, // Assuming team value contains location id
      rep_id: parseInt(values.salesRepName), // Assuming salesRepName contains rep id
      team: values.team,
      entry_date: values.date,
      door_knocked: parseInt(values.doorsKnocked),
      home_canvassed: parseInt(values.homesCanvassed),
      leads_generated: parseInt(values.leadScheduled),
      leads_ran: parseInt(values.leadsRan),
      change_order: parseInt(values.changeOrderSold),
      amount: parseFloat(values.totalSalesAmount),
      google_reviews: parseInt(values.googleReview),
      referral: parseInt(values.referralsExistingClients),
      yard_signed: parseInt(values.yardSign),
      appointments: parseInt(values.appointmentDoorToDoorEngage),
      insurance_claim_filed: parseInt(values.claimFiled),
      loi: parseInt(values.lois),
      adjuster_meetings: parseInt(values.adjusterMeeting),
      followup_appointments: parseInt(values.followUpAppointmentScheduled),
      sold: parseInt(values.jobSold),
      ...(isEditing && { is_approved: values.is_approved }),
    };

    // Add error handling for parsing failures
    if (Object.values(payload).some((value) => Number.isNaN(value))) {
      console.error('Invalid number in form values');
      return;
    }

    if (isEditing && id) {
      try {
        await updateReport(id, payload);
        showSuccessMsg(TOAST_MESSAGES.UPDATE_REPORT_SUCCESS);
        router.push(APP_ROUTE.DATA_FORM.SALES_REPORT);
      } catch (err) {
        console.error(err);
        // showErrorMsg(TOAST_MESSAGES.UPDATE_REPORT_ERROR);
      }
    } else {
      try {
        await createReport(payload);
        showSuccessMsg(TOAST_MESSAGES.ADD_REPORT_SUCCESS);
        router.push(APP_ROUTE.DATA_FORM.SALES_REPORT);
      } catch (err) {
        console.error(err);
        // showErrorMsg(TOAST_MESSAGES.ADD_REPORT_ERROR);
      }
    }
  };

  const transformResponseToFormValues = (
    response: SalesReportResponse
  ): SalesReportFormValues => {
    const { data } = response;

    return {
      location: data?.loc_id?.toString() ?? '',
      team: data?.team ?? '',
      salesRepName: data?.rep_id?.toString() ?? '',
      date: data?.entry_date ?? '',
      leadScheduled: data?.leads_generated?.toString() ?? '0',
      leadsRan: data?.leads_ran?.toString() ?? '0',
      followUpAppointmentScheduled:
        data?.followup_appointments?.toString() ?? '0',
      jobSold: data?.sold?.toString() ?? '0',
      changeOrderSold: data?.change_order?.toString() ?? '0',
      totalSalesAmount: data?.amount?.toString() ?? '0',
      homesCanvassed: data?.home_canvassed?.toString() ?? '0',
      doorsKnocked: data?.door_knocked?.toString() ?? '0',
      appointmentDoorToDoorEngage: data?.appointments?.toString() ?? '0',
      googleReview: data?.google_reviews?.toString() ?? '0',
      referralsExistingClients: data?.referral?.toString() ?? '0',
      yardSign: data?.yard_signed?.toString() ?? '0',
      lois: data?.loi?.toString() ?? '0',
      claimFiled: data?.insurance_claim_filed?.toString() ?? '0',
      adjusterMeeting: data?.adjuster_meetings?.toString() ?? '0',
      is_approved: data?.is_approved ?? false,
      is_auto_processed: data?.is_auto_processed ?? false,
    };
  };

  return (
    <Formik
      innerRef={formikRef}
      initialValues={formValues}
      validationSchema={validationSchema}
      validateOnMount={false}
      enableReinitialize={true}
      onSubmit={handleOnSubmit}
    >
      {({
        values,
        errors,
        touched,
        handleChange,
        handleSubmit,
        isSubmitting,
        setFieldValue,
      }) => {
        return (
          <form className="bg-white p-5 mb-4" onSubmit={handleSubmit}>
            {loadingStates.form ? (
              <div className="flex justify-center items-center min-h-[200px]">
                Loading...
              </div>
            ) : (
              <>
                <div className="grid gap-x-4 gap-y-5 grid-cols-2 mb-4">
                  <div className={'w-full relative'}>
                    <Select
                      value={values.team ? values.team : formValues.team}
                      onValueChange={(selected) => {
                        setFieldValue('team', selected ? selected : '');
                      }}
                    >
                      {values?.team && (
                        <span
                          className="z-10 pointer-events-auto top-[12px] px-1.5 absolute right-7 cursor-pointer hover:opacity-70"
                          onClick={(e) => {
                            e.stopPropagation();
                            setFieldValue('team', '');
                            setFormValues((prev) => ({
                              ...prev,
                              team: '',
                            }));
                          }}
                        >
                          <Icon
                            iconName="cross"
                            iconProps={{ className: '!w-3 !h-3 text-red-600' }}
                          />
                        </span>
                      )}
                      <SelectTrigger className="w-full text-left h-[36px] text-[12px]">
                        <SelectValue placeholder="Select Team" />
                      </SelectTrigger>
                      <SelectContent>
                        {TEAM_OPTIONS.map((item) => (
                          <SelectItem
                            key={item.value}
                            value={String(item.value)}
                            className="text-[12px] h-[32px]"
                          >
                            {item.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    {touched.team && errors.team && (
                      <div className="text-red-500 text-xs mt-1">
                        {errors.team}
                      </div>
                    )}
                  </div>
                  <div className={'w-full relative'}>
                    <Select
                      value={
                        values.location ? values.location : formValues.location
                      }
                      onValueChange={(selected) => {
                        setFieldValue('location', selected ? selected : '');
                      }}
                    >
                      {values?.location && (
                        <span
                          className="z-10 pointer-events-auto top-[12px] px-1.5 absolute right-7 cursor-pointer hover:opacity-70"
                          onClick={(e) => {
                            e.stopPropagation();
                            setFieldValue('location', '');
                            setFormValues((prev) => ({
                              ...prev,
                              location: '',
                            }));
                          }}
                        >
                          <Icon
                            iconName="cross"
                            iconProps={{ className: '!w-3 !h-3 text-red-600' }}
                          />
                        </span>
                      )}
                      <SelectTrigger className="w-full text-left h-[36px] text-[12px]">
                        <SelectValue placeholder="Select Location" />
                      </SelectTrigger>
                      <SelectContent>
                        {locations.map((item) => (
                          <SelectItem
                            key={item.id}
                            value={String(item.id)}
                            className="text-[12px] h-[32px]"
                          >
                            {item.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    {touched.location && errors.location && (
                      <div className="text-red-500 text-xs mt-1">
                        {errors.location}
                      </div>
                    )}
                  </div>
                </div>
                <div className="grid gap-x-4 gap-y-5 grid-cols-4">
                  <div className={'w-full relative'}>
                    <label className="text-xs text-gray  font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 mb-2 block">
                      Sales Rep Name
                    </label>
                    <Select
                      value={
                        values.salesRepName
                          ? values.salesRepName
                          : formValues.salesRepName
                      }
                      onValueChange={(selected) => {
                        setFieldValue('salesRepName', selected ? selected : '');
                      }}
                    >
                      {values?.salesRepName && (
                        <span
                          className="z-10 pointer-events-auto top-[31px] px-1.5 absolute right-7 cursor-pointer hover:opacity-70"
                          onClick={(e) => {
                            e.stopPropagation();
                            setFieldValue('salesRepName', '');
                            setFormValues((prev) => ({
                              ...prev,
                              salesRepName: '',
                            }));
                          }}
                        >
                          <Icon
                            iconName="cross"
                            iconProps={{ className: '!w-3 !h-3 text-red-600' }}
                          />
                        </span>
                      )}
                      <SelectTrigger className="w-full text-left h-[36px] text-[12px]">
                        <SelectValue placeholder="Select Sales Rep" />
                      </SelectTrigger>
                      <SelectContent>
                        {salesRepresentatives.map((item) => (
                          <SelectItem
                            key={item.id}
                            value={String(item.id)}
                            className="text-[12px] h-[32px]"
                          >
                            {item.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    {touched.salesRepName && errors.salesRepName && (
                      <div className="text-red-500 text-xs mt-1">
                        {errors.salesRepName}
                      </div>
                    )}
                  </div>
                  <div>
                    <CustomDatePicker
                      placeholder="MM/DD/YYYY"
                      selected={
                        values.date
                          ? new Date(values.date + 'T00:00:00.000Z')
                          : null
                      }
                      onChange={(date: Date | null) => {
                        setFieldValue(
                          'date',
                          date
                            ? new Date(
                                date.getTime() -
                                  date.getTimezoneOffset() * 60000
                              )
                                .toISOString()
                                .split('T')[0]
                            : ''
                        );
                      }}
                      error={touched.date && errors.date ? errors.date : ''}
                      label="Date"
                    />
                    {touched.date && errors.date && (
                      <div className="text-red-500 text-xs mt-1">
                        {errors.date}
                      </div>
                    )}
                  </div>
                  <div>
                    <TextInput
                      size="sm"
                      className="!bg-gray-50"
                      label={
                        <label className="text-xs text-gray font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 mb-2 block">
                          Leads Scheduled
                          {isAutoCalculated && isEditing && (
                            <span className="text-primary ml-1">
                              ({autoValues.autoLeadsGenerated})
                            </span>
                          )}
                        </label>
                      }
                      name="leadScheduled"
                      maxLength={100}
                      placeholder="Enter #"
                      error={
                        touched.leadScheduled && errors.leadScheduled
                          ? errors.leadScheduled
                          : ''
                      }
                      value={values.leadScheduled}
                      onChange={handleChange}
                    />
                  </div>
                  <div>
                    <TextInput
                      size="sm"
                      className="!bg-gray-50"
                      label="Leads Ran"
                      name="leadsRan"
                      maxLength={100}
                      placeholder="Enter #"
                      error={
                        touched.leadsRan && errors.leadsRan
                          ? errors.leadsRan
                          : ''
                      }
                      value={values.leadsRan}
                      onChange={handleChange}
                    />
                  </div>
                  <div>
                    <TextInput
                      size="sm"
                      className="!bg-gray-50"
                      label="Follow Up Appointments Scheduled"
                      name="followUpAppointmentScheduled"
                      maxLength={100}
                      placeholder="Enter #"
                      error={
                        touched.followUpAppointmentScheduled &&
                        errors.followUpAppointmentScheduled
                          ? errors.followUpAppointmentScheduled
                          : ''
                      }
                      value={values.followUpAppointmentScheduled}
                      onChange={handleChange}
                    />
                  </div>
                  <div>
                    <TextInput
                      size="sm"
                      className="!bg-gray-50"
                      label={
                        <label className="text-xs text-gray font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 mb-2 block">
                          Jobs Sold
                          {isAutoCalculated && isEditing && (
                            <span className="text-primary ml-1">
                              ({autoValues.autoSold})
                            </span>
                          )}
                        </label>
                      }
                      name="jobSold"
                      error={
                        touched.jobSold && errors.jobSold ? errors.jobSold : ''
                      }
                      value={values.jobSold}
                      onChange={handleChange}
                    />
                  </div>
                  <div>
                    <TextInput
                      size="sm"
                      className="!bg-gray-50"
                      label="Change Orders Sold/Supplements"
                      name="changeOrderSold"
                      maxLength={100}
                      placeholder="Enter #"
                      error={
                        touched.changeOrderSold && errors.changeOrderSold
                          ? errors.changeOrderSold
                          : ''
                      }
                      value={values.changeOrderSold}
                      onChange={handleChange}
                    />
                  </div>
                  <div>
                    <TextInput
                      size="sm"
                      className="!bg-gray-50"
                      label="Total Sales Amount"
                      name="totalSalesAmount"
                      maxLength={100}
                      placeholder="Enter #"
                      error={
                        touched.totalSalesAmount && errors.totalSalesAmount
                          ? errors.totalSalesAmount
                          : ''
                      }
                      value={values.totalSalesAmount}
                      onChange={handleChange}
                    />
                  </div>
                  <div>
                    <TextInput
                      size="sm"
                      className="!bg-gray-50"
                      label={
                        <label className="text-xs text-gray font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 mb-2 block">
                          Homes canvassed
                          {isAutoCalculated && isEditing && (
                            <span className="text-primary ml-1">
                              ({autoValues.autoHomeCanvassed})
                            </span>
                          )}
                        </label>
                      }
                      name="homesCanvassed"
                      maxLength={100}
                      placeholder="Enter #"
                      error={
                        touched.homesCanvassed && errors.homesCanvassed
                          ? errors.homesCanvassed
                          : ''
                      }
                      value={values.homesCanvassed}
                      onChange={handleChange}
                    />
                  </div>
                  <div>
                    <TextInput
                      size="sm"
                      className="!bg-gray-50"
                      label={
                        <label className="text-xs text-gray font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 mb-2 block">
                          Numbers of doors knocked
                          {isAutoCalculated && isEditing && (
                            <span className="text-primary ml-1">
                              ({autoValues.autoDoorKnocked})
                            </span>
                          )}
                        </label>
                      }
                      name="doorsKnocked"
                      maxLength={100}
                      placeholder="Enter #"
                      error={
                        touched.doorsKnocked && errors.doorsKnocked
                          ? errors.doorsKnocked
                          : ''
                      }
                      value={values.doorsKnocked}
                      onChange={handleChange}
                    />
                  </div>
                  <div>
                    <TextInput
                      size="sm"
                      className="!bg-gray-50"
                      label="Appointment from door-to-door engagements"
                      name="appointmentDoorToDoorEngage"
                      maxLength={100}
                      placeholder="Enter #"
                      error={
                        touched.appointmentDoorToDoorEngage &&
                        errors.appointmentDoorToDoorEngage
                          ? errors.appointmentDoorToDoorEngage
                          : ''
                      }
                      value={values.appointmentDoorToDoorEngage}
                      onChange={handleChange}
                    />
                  </div>
                  <div>
                    <TextInput
                      size="sm"
                      className="!bg-gray-50"
                      label="How many Google reviews did you receive?"
                      name="googleReview"
                      maxLength={100}
                      placeholder="Enter #"
                      error={
                        touched.googleReview && errors.googleReview
                          ? errors.googleReview
                          : ''
                      }
                      value={values.googleReview}
                      onChange={handleChange}
                    />
                  </div>
                  <div>
                    <TextInput
                      size="sm"
                      className="!bg-gray-50"
                      label="Referral you receive from existing clients?"
                      name="referralsExistingClients"
                      maxLength={100}
                      placeholder="Enter #"
                      error={
                        touched.referralsExistingClients &&
                        errors.referralsExistingClients
                          ? errors.referralsExistingClients
                          : ''
                      }
                      value={values.referralsExistingClients}
                      onChange={handleChange}
                    />
                  </div>
                  <div>
                    <TextInput
                      size="sm"
                      className="!bg-gray-50"
                      label="How many yard signs did you put out?"
                      name="yardSign"
                      maxLength={100}
                      placeholder="Enter #"
                      error={
                        touched.yardSign && errors.yardSign
                          ? errors.yardSign
                          : ''
                      }
                      value={values.yardSign}
                      onChange={handleChange}
                    />
                  </div>
                  <div>
                    <TextInput
                      size="sm"
                      className="!bg-gray-50"
                      label={
                        <label className="text-xs text-gray font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 mb-2 block">
                          Numbers of LOIs
                          {isAutoCalculated && isEditing && (
                            <span className="text-primary ml-1">
                              ({autoValues.autoLoi})
                            </span>
                          )}
                        </label>
                      }
                      name="lois"
                      maxLength={100}
                      placeholder="Enter #"
                      error={touched.lois && errors.lois ? errors.lois : ''}
                      value={values.lois}
                      onChange={handleChange}
                    />
                  </div>
                  <div>
                    <TextInput
                      size="sm"
                      className="!bg-gray-50"
                      label={
                        <label className="text-xs text-gray font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 mb-2 block">
                          Number of claims filed
                          {isAutoCalculated && isEditing && (
                            <span className="text-primary ml-1">
                              ({autoValues.autoInsuranceClaimFiled})
                            </span>
                          )}
                        </label>
                      }
                      name="claimFiled"
                      maxLength={100}
                      placeholder="Enter #"
                      error={
                        touched.claimFiled && errors.claimFiled
                          ? errors.claimFiled
                          : ''
                      }
                      value={values.claimFiled}
                      onChange={handleChange}
                    />
                  </div>
                  <div>
                    <TextInput
                      size="sm"
                      className="!bg-gray-50"
                      label="Numbers of adjuster meetings"
                      name="adjusterMeeting"
                      maxLength={100}
                      placeholder="Enter #"
                      error={
                        touched.adjusterMeeting && errors.adjusterMeeting
                          ? errors.adjusterMeeting
                          : ''
                      }
                      value={values.adjusterMeeting}
                      onChange={handleChange}
                    />
                  </div>
                </div>
                {values.is_auto_processed && (
                  <div className="mt-6">
                    <label className="text-xs text-gray  font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 mb-2 block">
                      Approve Sales Report
                    </label>
                    <Checkbox
                      size="sm"
                      id="checkbox1"
                      name="checkbox"
                      label={values.is_approved ? 'Approved' : 'Disapproved'}
                      checked={values.is_approved}
                      onchange={(selected) => {
                        setFieldValue(
                          'is_approved',
                          selected ? selected : false
                        );
                      }}
                    />
                  </div>
                )}
                <div className="grid items-center gap-4 grid-cols-10 mt-6">
                  <Button
                    size="md"
                    type="submit"
                    variant="primary"
                    full
                    loading={isSubmitting}
                    disabled={isSubmitting}
                  >
                    {isEditing ? 'Update Report' : 'Add Report'}
                  </Button>
                  <Button
                    size="md"
                    variant="outlineLight"
                    full
                    disabled={isSubmitting}
                    onClick={() =>
                      router.push(APP_ROUTE.DATA_FORM.SALES_REPORT)
                    }
                  >
                    Cancel
                  </Button>
                </div>
              </>
            )}
          </form>
        );
      }}
    </Formik>
  );
};

export default SalesReportForm;
