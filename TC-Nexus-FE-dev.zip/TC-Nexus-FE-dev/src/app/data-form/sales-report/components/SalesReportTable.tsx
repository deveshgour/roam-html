import { useState } from 'react';
import { Button } from '@/components/coreUI/button';
import { PAGE_SIZE } from '@/constants/configs';
import Icon from '@/components/coreUI/icon';
import { useSalesReport, getApiFieldName } from '@/hooks/useSalesReport';
import DateRangePickerWithSidebar from '@/components/coreUI/dateRangePicker';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/coreUI/select';
import { DataTableWithFixedColumn } from '@/components/dataTableWithFixedColumn';
import { useRouter } from 'next/navigation';
import Modal from '@/components/coreUI/dialog';
import { showSuccessMsg, showErrorMsg } from '@/utils/notifications';
import { CONFIRMATION_MESSAGES, TOAST_MESSAGES } from '@/constants/messages';
import { APP_ROUTE } from '@/constants/routes';
import MultiSelect from '@/components/coreUI/multiSelect';

interface SortingState {
  field: string;
  direction: 'asc' | 'desc' | null;
}
// Add this constant before the ModalType type definition
const MODAL_TYPES = {
  STATUS: 'status',
} as const;

type ModalType = (typeof MODAL_TYPES)[keyof typeof MODAL_TYPES];
interface SelectedUserState {
  type: ModalType;
  user: any;
}

function SalesReportTable() {
  const [selectedDateRange, setSelectedDateRange] = useState<
    [Date | null, Date | null] | null
  >(null);
  const [sorting, setSorting] = useState<SortingState>({
    field: 'name',
    direction: null,
  });
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedReport, setSelectedReport] = useState<any>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [menuIsOpen, setMenuIsOpen] = useState(false);
  const [selectedUserState, setSelectedUserState] =
    useState<SelectedUserState | null>(null);
  const [showModal, setShowModal] = useState<ModalType | null>(null);

  const {
    salesReport,
    updateFilters,
    totalCount,
    filters,
    isLoading,
    salesRepresentatives,
    downloadSalesReport,
    deleteManualSalesReport,
    toggleSalesReportApproval,
    locations,
    isFilterLoading,
  } = useSalesReport({
    initialFilters: {
      page: 1,
      pageSize: 10,
    },
    autoFetch: true,
  });

  const router = useRouter();

  const salesReportColumns = [
    {
      header: 'SALES REP',
      accessorKey: 'sales_rep',
      sortable: true,
      width: 150,
      fixed: 'left',
      footer: () => {
        return `Total`;
      },
    },
    {
      header: 'DATE',
      accessorKey: 'date',
      sortable: true,
      width: 150,
      fixed: 'left',
    },
    {
      header: 'LEADS SCHEDULED',
      accessorKey: 'leads_scheduled',
      sortable: true,
      width: 100,
      cell: (row: any) => {
        return row?.is_auto_processed
          ? `${row?.leads_scheduled}/${row?.auto_leads_generated}`
          : row?.leads_scheduled;
      },
      footer: () => {
        return `${salesReport?.total?.total_leads_scheduled?.toLocaleString('en-US') || 0}`;
      },
    },
    {
      header: 'LEADS RAN',
      accessorKey: 'leads_ran',
      footer: () => {
        return `${salesReport?.total?.total_leads_ran?.toLocaleString('en-US') || 0}`;
      },
      sortable: true,
    },
    {
      header: 'FOLLOW UP APPOINTMENTS SCHEDULED',
      accessorKey: 'follow_up_appointments_scheduled',
      sortable: true,
      width: 250,
      footer: () => {
        return `${salesReport?.total?.total_follow_up_appointments_scheduled?.toLocaleString('en-US') || 0}`;
      },
    },
    {
      header: 'JOBS SOLD',
      accessorKey: 'jobs_sold',
      sortable: true,
      cell: (row: any) => {
        return row?.auto_sold > 0
          ? `${row?.jobs_sold}/${row?.auto_sold}`
          : row?.jobs_sold;
      },
      footer: () => {
        return `${salesReport?.total?.total_jobs_sold?.toLocaleString('en-US') || 0}`;
      },
    },
    {
      header: 'CHANGE ORDERS SOLD/SUPPLEMENTS',
      accessorKey: 'change_orders_sold',
      width: 200,
      footer: () => {
        return `${salesReport?.total?.total_change_orders_sold?.toLocaleString('en-US') || 0}`;
      },
      sortable: true,
    },
    {
      header: 'TOTAL SALES AMOUNT',
      accessorKey: 'total_sales_amount',
      footer: () => {
        const total = salesReport?.total?.total_total_sales_amount ?? 0;
        return total.toLocaleString('en-US');
      },
      sortable: true,
    },
    {
      header: 'HOME CANVASSED',
      accessorKey: 'homes_canvassed',
      cell: (row: any) => {
        return row?.is_auto_processed
          ? `${row?.homes_canvassed}/${row?.auto_home_canvassed}`
          : row?.homes_canvassed;
      },
      footer: () => {
        return `${salesReport?.total?.total_homes_canvassed?.toLocaleString('en-US') || 0}`;
      },
      sortable: true,
    },
    {
      header: 'NUMBER OF DOORS KNOCKED',
      accessorKey: 'doors_knocked',
      cell: (row: any) => {
        return row?.is_auto_processed
          ? `${row?.doors_knocked}/${row?.auto_door_knocked}`
          : row?.doors_knocked;
      },
      width: 150,
      footer: () => {
        return `${salesReport?.total?.total_doors_knocked?.toLocaleString('en-US') || 0}`;
      },
      sortable: true,
    },
    {
      header: 'APPOINTMENTS FROM DOOR-TO-DOOR ENGAGEMENTS',
      accessorKey: 'appointments_from_door_to_door_engagements',
      width: 200,
      footer: () => {
        return `${salesReport?.total?.total_appointments_from_door_to_door_engagements?.toLocaleString('en-US') || 0}`;
      },
      sortable: true,
    },
    {
      header: 'HOW MANY GOOGLE REVIEWS DID YOU RECEIVE',
      accessorKey: 'google_reviews',
      width: 200,
      footer: () => {
        return `${salesReport?.total?.total_google_reviews?.toLocaleString('en-US') || 0}`;
      },
      sortable: true,
    },
    {
      header: 'HOW MANY REFERRALS DID YOU RECEIVE FROM EXISTING CLIENTS?',
      accessorKey: 'referrals_from_clients',
      width: 250,
      footer: () => {
        return `${salesReport?.total?.total_referrals_from_clients?.toLocaleString('en-US') || 0}`;
      },
      sortable: true,
    },
    {
      header: 'HOW MANY YARDS SIGNS DID YOU PUT OUT?',
      accessorKey: 'yard_signs',
      width: 200,
      footer: () => {
        return `${salesReport?.total?.total_yard_signs?.toLocaleString('en-US') || 0}`;
      },
      sortable: true,
    },
    {
      header: 'NUMBERS OF LOIS (LETTERS OF INTENT) SIGNED',
      accessorKey: 'lois',
      width: 200,
      cell: (row: any) => {
        return row?.is_auto_processed
          ? `${row?.lois}/${row?.auto_loi}`
          : row?.lois;
      },
      footer: () => {
        return `${salesReport?.total?.total_lois.toLocaleString('en-US') || 0}`;
      },
      sortable: true,
    },
    {
      header: 'NUMBERS OF CLAIMS  FILED',
      accessorKey: 'claim_filed',
      width: 150,
      cell: (row: any) => {
        return row?.is_auto_processed
          ? `${row?.claim_filed}/${row?.auto_insurance_claim_filed}`
          : row?.claim_filed;
      },
      footer: () => {
        return `${salesReport?.total?.total_claim_filed?.toLocaleString('en-US') || 0}`;
      },
      sortable: true,
    },
    {
      header: 'NUMBERS OF ADJUSTER MEETINGS',
      accessorKey: 'adjuster_meeting',
      width: 200,
      footer: () => {
        return `${salesReport?.total?.total_adjuster_meeting?.toLocaleString('en-US') || 0}`;
      },
      sortable: true,
    },
  ];

  const handleDelete = async () => {
    if (!selectedReport?.id) {
      showErrorMsg('Invalid report selected');
      return;
    }

    try {
      setIsSubmitting(true);
      await deleteManualSalesReport(selectedReport.id);
      showSuccessMsg(TOAST_MESSAGES.REPORT_DELETE_SUCCESS);
      setShowDeleteModal(false);
    } catch (error) {
      console.error('Error deleting sales report:', error);
      showErrorMsg(TOAST_MESSAGES.REPORT_DELETE_ERROR);
    } finally {
      setIsSubmitting(false);
    }
  };

  const actions = [
    {
      label: 'Edit',
      onClick: (row: any) => {
        router.push(APP_ROUTE.DATA_FORM.EDIT_REPORT(row?.id));
      },
    },
    {
      label: 'Delete',
      onClick: (row: any) => {
        setSelectedReport(row);
        setShowDeleteModal(true);
      },
    },
    {
      label: (row: any) => {
        if (row?.is_auto_processed === false) {
          return '';
        } else {
          return row?.is_approved ? 'Disapprove' : 'Approve';
        }
      },
      onClick: (row: any) => {
        setSelectedUserState({ type: MODAL_TYPES.STATUS, user: row });
        setShowModal(MODAL_TYPES.STATUS);
      },
    },
  ];

  const handleSortingChange = (
    field: string,
    direction: 'asc' | 'desc' | null
  ) => {
    const orderingValue =
      direction === 'desc'
        ? `-${getApiFieldName(field)}`
        : getApiFieldName(field);
    updateFilters({ page: 1, ordering: orderingValue });
    setSorting({ field, direction });
  };
  const closeModal = () => {
    setShowModal(null);
    setSelectedUserState(null);
  };

  const handleStatusChange = async (row: any) => {
    try {
      setIsSubmitting(true);
      if (selectedUserState?.type === MODAL_TYPES.STATUS) {
        await toggleSalesReportApproval(row);
        showSuccessMsg(TOAST_MESSAGES.SALES_REPORT_STATUS_SUCCESS);
        closeModal();
      }
    } catch (error) {
      console.error('Error updating sales report status:', error);
      showErrorMsg(TOAST_MESSAGES.SALES_REPORT_STATUS_ERROR);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <DataTableWithFixedColumn
        loading={isLoading || isFilterLoading}
        showSkeleton={true}
        data={salesReport?.salesReportData || []}
        columns={salesReportColumns}
        page={filters.page || 1}
        pageSize={filters.pageSize || 10}
        totalItems={totalCount || 0}
        onPageChange={(page) => updateFilters({ page })}
        onPageSizeChange={(pageSize) => updateFilters({ pageSize })}
        actions={actions}
        isActionSticky={true}
        getRowId={(row: any) => row.id}
        pageSizeOptions={PAGE_SIZE}
        sorting={sorting}
        onSortingChange={handleSortingChange}
        showSearch={false}
        showPagination={true}
        showPageSize={false}
        headerActions={
          <>
            <Button
              onClick={() => router.push(APP_ROUTE.DATA_FORM.ADD_SALES_REPORT)}
              variant="primary"
              className="!py-2.5"
            >
              <Icon iconName="plus" iconProps={{ className: `!h-5 !w-5` }} />
              Add New
            </Button>
            <Button
              variant="outlineLight"
              className="!py-2.5"
              onClick={downloadSalesReport}
              icon={
                <Icon
                  iconName="export"
                  iconProps={{ className: '!w-5 !h-5 text-gray-600' }}
                />
              }
            >
              Export
            </Button>
          </>
        }
        showTableFilter={
          <div className="flex items-center gap-3 flex-wrap">
            <div className="w-70 block">
              <DateRangePickerWithSidebar
                value={selectedDateRange}
                onPrimaryBtnClick={(date) => {
                  if (!date?.[0] || !date?.[1]) return;

                  setSelectedDateRange(date);
                  updateFilters({
                    start_date: date[0]
                      ? new Date(
                          date[0].getTime() -
                            date[0].getTimezoneOffset() * 60000
                        )
                          .toISOString()
                          .split('T')[0]
                      : null,
                    end_date: date[1]
                      ? new Date(
                          date[1].getTime() -
                            date[1].getTimezoneOffset() * 60000
                        )
                          .toISOString()
                          .split('T')[0]
                      : null,
                  });
                }}
                onClearBtnClick={() => {
                  setSelectedDateRange(null);
                  updateFilters({
                    start_date: null,
                    end_date: null,
                  });
                }}
              />
            </div>
            <div className="relative">
              <Select
                value={filters?.loc_id?.toString() || ''}
                onValueChange={(value) => updateFilters({ loc_id: value })}
                onOpenChange={() => setMenuIsOpen(false)}
              >
                {filters?.loc_id && (
                  <span
                    className="z-10 pointer-events-auto py-3 px-1.5 absolute right-7 cursor-pointer hover:opacity-70"
                    onClick={(e) => {
                      e.stopPropagation();
                      updateFilters({ ...filters, loc_id: '' });
                    }}
                  >
                    <Icon
                      iconName="cross"
                      iconProps={{ className: '!w-4 !h-4 text-red-600' }}
                    />
                  </span>
                )}
                <SelectTrigger>
                  <SelectValue placeholder="All Locations" />
                </SelectTrigger>
                <SelectContent>
                  {(locations || [])
                    .sort((a, b) =>
                      (a?.name || '').localeCompare(b?.name || '')
                    )
                    .map((location) => (
                      <SelectItem
                        key={location?.id || ''}
                        value={location?.id?.toString() || ''}
                      >
                        {location?.name || 'Unnamed Rep'}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
            <div className="relative max-w-80 min-w-56">
              <MultiSelect
                menuIsOpen={menuIsOpen}
                setMenuIsOpen={setMenuIsOpen}
                backgroundColor="rgb(var(--color-gray-50))"
                options={salesRepresentatives
                  ?.map((rep) => ({
                    value: rep?.id?.toString(),
                    label: rep?.name,
                  }))
                  .sort((a, b) => a.label.localeCompare(b.label))}
                value={
                  Array.isArray(filters?.rep_id)
                    ? filters?.rep_id?.map((id) => ({
                        value: id,
                        label:
                          salesRepresentatives?.find(
                            (rep) => rep?.id?.toString() === id
                          )?.name || '',
                      }))
                    : []
                }
                isDisabled={false}
                size="md"
                onChange={(selected) => {
                  updateFilters({
                    ...filters,
                    rep_id: Array.isArray(selected)
                      ? selected.map((item) => item.value?.toString())
                      : [],
                  });
                }}
                placeholder="All Sales Rep"
                icon="user"
                showCheckbox={true}
              />
            </div>
            <div className="relative">
              <Select
                value={filters?.approval_status?.toString() || ''}
                onValueChange={(value) =>
                  updateFilters({ approval_status: value })
                }
                onOpenChange={() => setMenuIsOpen(false)}
              >
                {filters?.approval_status && (
                  <span
                    className="z-10 pointer-events-auto py-3 px-1.5 absolute right-7 cursor-pointer hover:opacity-70"
                    onClick={(e) => {
                      e.stopPropagation();
                      updateFilters({ ...filters, approval_status: '' });
                    }}
                  >
                    <Icon
                      iconName="cross"
                      iconProps={{ className: '!w-4 !h-4 text-red-600' }}
                    />
                  </span>
                )}
                <SelectTrigger>
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  {[
                    { value: 'approved', name: 'Approved' },
                    { value: 'disapproved', name: 'Disapproved' },
                    { value: 'pending', name: 'Pending' },
                  ]
                    .sort((a, b) =>
                      (a?.name || '').localeCompare(b?.name || '')
                    )
                    .map((item, index) => (
                      <SelectItem
                        key={index || ''}
                        value={item?.value?.toString() || ''}
                      >
                        {item?.name || ''}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        }
        showFooter={true}
      />

      <Modal
        open={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        title="Delete Sales Report"
        primaryButton={{
          text: 'Delete',
          onClick: handleDelete,
          loading: isSubmitting,
        }}
        secondaryButton={{
          text: 'Cancel',
          onClick: () => setShowDeleteModal(false),
          disabled: isSubmitting,
        }}
      >
        <div className="text-left">
          <p className="text-gray-600">
            {CONFIRMATION_MESSAGES.DELETE_SALES_REPORT}
          </p>
          <p className="mt-3 text-red-500">
            {CONFIRMATION_MESSAGES.CANNOT_BE_UNDONE}
          </p>
        </div>
      </Modal>

      {selectedUserState?.type === MODAL_TYPES.STATUS && (
        <Modal
          open={showModal === MODAL_TYPES.STATUS}
          onClose={closeModal}
          title={`${selectedUserState?.user?.is_approved ? 'Disapprove' : 'Approve'} Sales Report`}
          primaryButton={{
            text: 'Confirm',
            onClick: () => handleStatusChange(selectedUserState?.user),
            loading: isSubmitting,
            disabled: isSubmitting,
          }}
          secondaryButton={{
            text: 'Cancel',
            onClick: closeModal,
            disabled: isSubmitting,
          }}
        >
          <div className="text-left">
            <p className="text-gray-600">
              {selectedUserState?.user?.is_approved
                ? CONFIRMATION_MESSAGES.DISAPPROVE_SALES_REPORT
                : CONFIRMATION_MESSAGES.APPROVE_SALES_REPORT}
            </p>
          </div>
        </Modal>
      )}
    </>
  );
}

export default SalesReportTable;
