'use client';
import React from 'react';
import SalesReportTable from '@/app/data-form/sales-report/components/SalesReportTable';

const SalesReportPage = () => {
  return (
    <div>
      <SalesReportTable />
    </div>
  );
};

export default SalesReportPage;
