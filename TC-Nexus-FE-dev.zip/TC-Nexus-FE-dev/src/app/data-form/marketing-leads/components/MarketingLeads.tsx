import { useState, useEffect } from 'react';
import { Button } from '@/components/coreUI/button';
import { PAGE_SIZE } from '@/constants/configs';
import Icon from '@/components/coreUI/icon';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/coreUI/select';
import { DataTableWithFixedColumn } from '@/components/dataTableWithFixedColumn';
import Modal from '@/components/coreUI/dialog';
import AddMarketingLeadModal from './AddMarketingLeadModal';
import {
  ExpenseFilters,
  useExpenses,
  ExpenseTable,
  useLocations,
  useExportMarketingLeads,
  MarketingLeadsFilters,
} from '@/hooks/marketingLeads';
import { MarketingLeadFormValues } from './AddMarketingLeadModal';
import { TOAST_MESSAGES } from '@/constants/messages';
import { showErrorMsg, showSuccessMsg } from '@/utils/notifications';
import DateRangePickerWithSidebar from '@/components/coreUI/dateRangePicker';
import React from 'react';

interface SortingState {
  field: string;
  direction: 'asc' | 'desc' | null;
}

const renderLocationOptions = (
  locations: any[],
  isLoadingLocations: boolean
) => {
  if (isLoadingLocations) {
    return (
      <SelectItem value="loading" disabled className="text-xs">
        Loading...
      </SelectItem>
    );
  }

  if (!locations?.length) {
    return (
      <SelectItem value="no-locations" disabled className="text-xs">
        No locations available
      </SelectItem>
    );
  }

  return locations
    .sort((a, b) => a.name.localeCompare(b.name))
    .map((location) => (
      <SelectItem
        key={location.id}
        value={location.id.toString()}
        className="text-xs"
      >
        {location.name}
      </SelectItem>
    ));
};

export default function MarketingLeads() {
  const [sorting, setSorting] = useState<SortingState>({
    field: 'source',
    direction: null,
  });
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedLeadId, setSelectedLeadId] = useState<string | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isFilterLoading, setIsFilterLoading] = useState(false);
  const [selectedLead, setSelectedLead] = useState<
    MarketingLeadFormValues | undefined
  >(undefined);
  const [selectedDateRange, setSelectedDateRange] = useState<
    [Date | null, Date | null] | null
  >(null);

  const { locations, isLoading: isLoadingLocations } = useLocations();
  const { exportLeads, isExporting } = useExportMarketingLeads();

  // Fetch expenses using the hook with filters
  const {
    expenses,
    isLoading,
    refetch,
    deleteLead,
    createExpense,
    editExpense,
    filters,
    setFilters,
    totalCount,
  } = useExpenses({
    initialFilters: {
      page: 1,
      pageSize: 10,
      ordering: sorting.direction
        ? `${sorting.direction === 'desc' ? '-' : ''}${sorting.field}`
        : undefined,
    },
  });

  // Update filters when sorting changes
  useEffect(() => {
    setFilters((prev) => ({
      ...prev,
      ordering: sorting.direction
        ? `${sorting.direction === 'desc' ? '-' : ''}${sorting.field}`
        : undefined,
    }));
  }, [sorting, setFilters]);

  // Reset isFilterLoading when expenses are updated
  useEffect(() => {
    setIsFilterLoading(false);
  }, [expenses]);

  const handleSortingChange = (
    field: string,
    direction: 'asc' | 'desc' | null
  ) => {
    setIsFilterLoading(true);
    setSorting({ field, direction });
  };

  const updateFilters = (newFilters: Partial<ExpenseFilters>) => {
    setIsFilterLoading(true);
    setFilters((prev) => ({
      ...prev,
      ...newFilters,
      page: 1, // Reset to first page when filters change
    }));
  };

  const handleExport = async () => {
    try {
      const exportFilters: MarketingLeadsFilters = {};

      if (selectedDateRange?.[0] && selectedDateRange?.[1]) {
        exportFilters.start_date = selectedDateRange[0]
          ?.toISOString()
          ?.split('T')[0];
        exportFilters.end_date = selectedDateRange[1]
          ?.toISOString()
          ?.split('T')[0];
      }

      if (filters?.location_id) {
        exportFilters.location_id = filters.location_id;
      }

      exportFilters.ordering = filters?.ordering;

      await exportLeads(exportFilters);
    } catch (error) {
      showErrorMsg(
        error instanceof Error
          ? error.message
          : TOAST_MESSAGES.DOWNLOAD_REPORT_ERROR
      );
    }
  };

  const marketingLeadsColumns = [
    {
      header: 'Lead Source',
      accessorKey: 'source',
      sortable: true,
      width: 150,
      className: 'border-r',
      footer: () => 'Total',
    },
    {
      header: 'Date',
      accessorKey: 'expenseDate',
      sortable: true,
      width: 150,
      cell: (row: any) => {
        if (!row?.expenseDate) return 'Date not available'; // Handle missing or null dates

        const date = new Date(row?.expenseDate);
        if (isNaN(date.getTime())) return 'Invalid Date'; // Handle incorrect date formats

        return `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`; // MM/DD/YYYY format
      },
    },
    {
      header: 'Location',
      accessorKey: 'location',
      sortable: true,
      width: 150,
    },
    {
      header: 'Amount',
      accessorKey: 'amount',
      sortable: true,
      width: 150,
      cell: (row: any) => {
        return `$${row?.amount?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || '0.00'}`;
      },
      footer: () => {
        const total = expenses.reduce(
          (sum, row) => sum + (row?.amount || 0),
          0
        );
        return `$${total.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      },
    },
  ];

  const actions = [
    {
      label: 'Edit',
      onClick: (row: ExpenseTable) => {
        setSelectedLead({
          leadSource: row?.source,
          date: row?.expenseDate,
          location: row?.locId?.toString(),
          amount: row?.amount?.toString(),
        });
        setSelectedLeadId(row.id.toString());
        setShowAddModal(true);
      },
    },
    {
      label: 'Delete',
      onClick: (row: ExpenseTable) => {
        setSelectedLeadId(row.id.toString());
        setShowDeleteModal(true);
      },
    },
  ];

  const handleSubmit = async (values: MarketingLeadFormValues) => {
    try {
      setIsSubmitting(true);
      const data = {
        source: values?.leadSource,
        expense_date: values?.date,
        loc_id: parseInt(values?.location),
        amount: parseFloat(values?.amount),
        location: values?.location,
      };

      if (selectedLeadId) {
        await editExpense(selectedLeadId, data);
        await refetch();
        showSuccessMsg(TOAST_MESSAGES.MARKETING_LEAD_UPDATE_SUCCESS);
      } else {
        await createExpense(data);
        await refetch();
        showSuccessMsg(TOAST_MESSAGES.MARKETING_LEAD_ADD_SUCCESS);
      }

      setSelectedLead(undefined);
      setSelectedLeadId(null);
      setShowAddModal(false);
    } catch (error) {
      const errorMessage =
        error instanceof Error
          ? error.message
          : TOAST_MESSAGES.MARKETING_LEAD_MODIFY_ERROR;
      showErrorMsg(errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    try {
      setIsSubmitting(true);
      if (selectedLeadId) {
        await deleteLead(selectedLeadId);
        await refetch();
        showSuccessMsg(TOAST_MESSAGES.MARKETING_LEAD_DELETE_SUCCESS);
        setShowDeleteModal(false);
        setSelectedLead(undefined);
        setSelectedLeadId(null);
      }
    } catch (error) {
      const errorMessage =
        error instanceof Error
          ? error.message
          : TOAST_MESSAGES.MARKETING_LEAD_DELETE_ERROR;
      showErrorMsg(errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <DataTableWithFixedColumn<ExpenseTable>
        data={expenses}
        page={filters.page || 1}
        pageSize={filters.pageSize || PAGE_SIZE[0]}
        actions={actions}
        totalItems={totalCount}
        loading={isLoading || isFilterLoading}
        showSkeleton={true}
        columns={marketingLeadsColumns}
        pageSizeOptions={PAGE_SIZE}
        sorting={sorting}
        showSearch={false}
        showPagination={true}
        showPageSize={false}
        showFooter={true}
        onPageChange={(newPage) => {
          setIsFilterLoading(true);
          setFilters((prev) => ({
            ...prev,
            page: newPage,
          }));
        }}
        onPageSizeChange={(newPageSize) => {
          setIsFilterLoading(true);
          setFilters((prev) => ({
            ...prev,
            pageSize: newPageSize,
            page: 1,
          }));
        }}
        onSortingChange={handleSortingChange}
        headerActions={
          <>
            <Button
              onClick={() => {
                setSelectedLead(undefined);
                setSelectedLeadId(null);
                setShowAddModal(true);
              }}
              variant="primary"
              className="!py-2.5"
            >
              <Icon iconName="plus" iconProps={{ className: `!h-5 !w-5` }} />
              Add New
            </Button>
            <Button
              variant="outlineLight"
              className="!py-2.5"
              onClick={handleExport}
              disabled={isExporting}
              icon={
                <Icon
                  iconName="export"
                  iconProps={{ className: '!w-5 !h-5 text-gray-600' }}
                />
              }
            >
              {isExporting ? 'Exporting...' : 'Export'}
            </Button>
          </>
        }
        showTableFilter={
          <div className="flex items-center gap-3 flex-wrap">
            <div className="w-80 block">
              <DateRangePickerWithSidebar
                value={selectedDateRange}
                onPrimaryBtnClick={(date) => {
                  if (!date?.[0] || !date?.[1]) return;
                  setSelectedDateRange(date);
                  updateFilters({
                    start_date: date[0].toLocaleDateString('en-CA'),
                    end_date: date[1].toLocaleDateString('en-CA'),
                  });
                }}
                onClearBtnClick={() => {
                  setSelectedDateRange(null);
                  updateFilters({
                    start_date: undefined,
                    end_date: undefined,
                  });
                }}
              />
            </div>
            <div className="w-[222px] block">
              <div className="relative">
                <Select
                  value={
                    filters.location_id ? filters.location_id.toString() : ''
                  }
                  onValueChange={(value) => {
                    updateFilters({
                      location_id: value ? parseInt(value) : undefined,
                    });
                  }}
                >
                  {filters.location_id && (
                    <span
                      className="z-10 pointer-events-auto py-2.5 px-1.5 absolute right-10 cursor-pointer hover:opacity-70"
                      onClick={(e) => {
                        e.stopPropagation();
                        updateFilters({ location_id: undefined });
                      }}
                    >
                      <Icon
                        iconName="cross"
                        iconProps={{ className: '!w-4 !h-4 text-red-600' }}
                      />
                    </span>
                  )}
                  <SelectTrigger
                    className="bg-gray-50 [&_svg]:mr-2 h-9 px-3"
                    icon={
                      <Icon
                        iconName="mapPin"
                        iconProps={{ className: 'text-gray-600' }}
                      />
                    }
                    innerSelectedValue="!block overflow-hidden text-ellipsis pr-4 whitespace-nowrap flex-grow max-w-[160px]"
                  >
                    <div className="flex items-center">
                      <SelectValue
                        placeholder="All Locations"
                        className="text-gray-500 text-xs"
                      />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    {renderLocationOptions(locations, isLoadingLocations)}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        }
        getRowId={(row) => row.id.toString()}
      />

      <Modal
        open={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        title="Delete Marketing Lead"
        primaryButton={{
          text: 'Delete',
          onClick: handleDelete,
          loading: isSubmitting,
        }}
        secondaryButton={{
          text: 'Cancel',
          onClick: () => setShowDeleteModal(false),
          disabled: isSubmitting,
        }}
      >
        <div className="text-left">
          <p className="text-gray-600">
            Are you sure you want to permanently delete this marketing lead?
          </p>
          <p className="mt-3 text-red-500">This action cannot be undone.</p>
        </div>
      </Modal>

      <AddMarketingLeadModal
        open={showAddModal}
        onClose={() => {
          setShowAddModal(false);
          setSelectedLead(undefined);
        }}
        onSubmit={handleSubmit}
        isSubmitting={isSubmitting}
        lead={selectedLead}
        locations={locations}
        isLoadingLocations={isLoadingLocations}
      />
    </>
  );
}
