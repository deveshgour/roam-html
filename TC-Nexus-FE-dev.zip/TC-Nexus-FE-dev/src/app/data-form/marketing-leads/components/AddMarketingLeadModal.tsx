import { Button } from '@/components/coreUI/button';
import Modal from '@/components/coreUI/dialog';
import { TextInput } from '@/components/coreUI/textInput';
import CustomDatePicker from '@/components/coreUI/datePicker';
import { Formik, FormikProps } from 'formik';
import React from 'react';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/coreUI/select';
import { useLeadSources } from '@/hooks/marketingLeads';
import * as Yup from 'yup';
import { format } from 'date-fns';

interface AddMarketingLeadModalProps {
  open: boolean;
  onClose: () => void;
  lead?: MarketingLeadFormValues;
  // eslint-disable-next-line no-unused-vars
  onSubmit: (formValues: MarketingLeadFormValues) => void | Promise<void>;
  isSubmitting?: boolean;
  locations: { id: number; name: string }[];
  isLoadingLocations: boolean;
}

export interface MarketingLeadFormValues {
  leadSource: string;
  date: string;
  location: string;
  amount: string;
}

const validationSchema = Yup.object().shape({
  leadSource: Yup.string().required('Lead source is required'),
  date: Yup.string()
    .required('Date is required')
    .test('is-valid-date', 'Please enter a valid date', function (value) {
      if (!value) return false;
      return !isNaN(new Date(value).getTime());
    }),
  location: Yup.string().required('Location is required'),
  amount: Yup.string()
    .required('Amount is required')
    .matches(/^\d+(\.\d{0,2})?$/, 'Amount must be a valid number'),
});

const AddMarketingLeadModal = ({
  open = false,
  onClose = () => {},
  onSubmit = async () => Promise.resolve(),
  lead = undefined,
  isSubmitting = false,
  locations,
  isLoadingLocations,
}: AddMarketingLeadModalProps) => {
  const formikRef = React.useRef<FormikProps<MarketingLeadFormValues>>(null);
  const isEditing = Boolean(lead);
  const { leadSources, isLoading: isLoadingLeadSources } = useLeadSources();

  const initialValues: MarketingLeadFormValues = {
    leadSource: lead?.leadSource || '',
    date: lead?.date || '',
    location: lead?.location || '',
    amount: lead?.amount || '',
  };

  const handleSubmit = async () => {
    if (formikRef.current) {
      const { validateForm, setTouched, values } = formikRef.current;

      // Mark all fields as touched to trigger validation
      setTouched({
        leadSource: true,
        date: true,
        location: true,
        amount: true,
      });

      const errors = await validateForm();

      if (Object.keys(errors).length === 0) {
        await onSubmit(values);
        onClose();
      }
    }
  };

  const renderLeadSourceOptions = () => {
    if (isLoadingLeadSources) {
      return (
        <SelectItem value="loading" disabled className="text-xs">
          Loading...
        </SelectItem>
      );
    }

    if (!leadSources?.length) {
      return (
        <SelectItem value="no-sources" disabled className="text-xs">
          No sources available
        </SelectItem>
      );
    }

    return leadSources
      .filter((source) => source?.name && source?.name.trim() !== '')
      .sort((a, b) => a.name.localeCompare(b.name))
      .map((source) => (
        <SelectItem key={source.name} value={source.name} className="text-xs">
          {source.name}
        </SelectItem>
      ));
  };

  const renderLocationOptions = () => {
    if (isLoadingLocations) {
      return (
        <SelectItem value="loading" disabled className="text-xs">
          Loading...
        </SelectItem>
      );
    }

    if (!locations?.length) {
      return (
        <SelectItem value="no-locations" disabled className="text-xs">
          No locations available
        </SelectItem>
      );
    }

    return locations
      .sort((a, b) => (a?.name || '').localeCompare(b?.name || ''))
      .map((location) => (
        <SelectItem
          key={location?.id || ''}
          value={location?.id?.toString() || ''}
          className="text-xs"
        >
          {location?.name || 'Unnamed Location'}
        </SelectItem>
      ));
  };

  return (
    <Modal
      maxWidth="2xl"
      isScrollable={false}
      header={
        <span className="text-lg inline-flex text-gray">
          {isEditing ? 'Edit Marketing Lead' : 'Marketing Leads'}
        </span>
      }
      open={open}
      onClose={onClose}
      showCloseButton={true}
      footer={
        <div className="flex items-center gap-4 w-full">
          <Button
            size="lg"
            onClick={onClose}
            variant="outlineLight"
            full
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            size="lg"
            onClick={() => handleSubmit()}
            variant="primary"
            full
            loading={isSubmitting}
            disabled={isSubmitting}
          >
            {isEditing ? 'Update' : 'Add'}
          </Button>
        </div>
      }
    >
      <div className="flex-1">
        <Formik
          innerRef={formikRef}
          initialValues={initialValues}
          validationSchema={validationSchema}
          validateOnMount={false}
          enableReinitialize={true}
          onSubmit={() => {}}
        >
          {({ errors, touched, setFieldValue, values }) => (
            <div className="grid gap-x-4 gap-y-5 grid-cols-2">
              <div className="relative">
                <label className="text-xs font-medium text-gray-700">
                  Lead Source
                </label>
                <Select
                  value={values.leadSource}
                  onValueChange={(value) => {
                    setFieldValue('leadSource', value);
                  }}
                >
                  <SelectTrigger className="bg-gray-50 [&_svg]:mr-2 h-9 px-3">
                    <div className="flex items-center text-xs">
                      <SelectValue
                        placeholder="Select Lead Source"
                        className="[&_*]:text-xs [&_.placeholder]:text-gray-500"
                      />
                    </div>
                  </SelectTrigger>
                  <SelectContent>{renderLeadSourceOptions()}</SelectContent>
                </Select>
                {touched.leadSource && errors.leadSource && (
                  <div className="text-xs text-red-500 mt-1">
                    {errors.leadSource}
                  </div>
                )}
              </div>
              <div className="relative">
                <CustomDatePicker
                  placeholder="MM/DD/YYYY"
                  selected={values.date ? new Date(values.date) : null}
                  onChange={(date: Date | null) => {
                    setFieldValue(
                      'date',
                      date ? format(date, 'yyyy-MM-dd') : ''
                    );
                  }}
                  error={touched.date && errors.date ? errors.date : ''}
                  label="Date"
                />
                {touched.date && errors.date && (
                  <div className="text-xs text-red-500 mt-1">{errors.date}</div>
                )}
              </div>
              <div className="relative">
                <label className="text-xs font-medium text-gray-700">
                  Location
                </label>
                <Select
                  value={values.location}
                  onValueChange={(value) => setFieldValue('location', value)}
                >
                  <SelectTrigger className="bg-gray-50 [&_svg]:mr-2 h-9 px-3">
                    <div className="flex items-center text-xs">
                      <SelectValue
                        placeholder="Select Location"
                        className="[&_*]:text-xs [&_.placeholder]:text-gray-500"
                      />
                    </div>
                  </SelectTrigger>
                  <SelectContent>{renderLocationOptions()}</SelectContent>
                </Select>
                {touched.location && errors.location && (
                  <div className="text-xs text-red-500 mt-1">
                    {errors.location}
                  </div>
                )}
              </div>
              <div className="relative">
                <TextInput
                  size="sm"
                  className="!bg-gray-50"
                  label="Amount"
                  name="amount"
                  placeholder="Enter Amount"
                  error={touched.amount && errors.amount ? errors.amount : ''}
                  value={values.amount}
                  onChange={(e) => setFieldValue('amount', e.target.value)}
                />
              </div>
            </div>
          )}
        </Formik>
      </div>
    </Modal>
  );
};

export default AddMarketingLeadModal;
