'use client';
import React from 'react';
import MarketingLeads from './components/MarketingLeads';

const NewConstructionBidsPage = () => {
  return (
    <div>
      <MarketingLeads />
    </div>
  );
};

export default NewConstructionBidsPage;
